
#pragma once

#define _AFXDLL


#include <afxcoll.h>
#include <winsock2.h>
#include <Ws2tcpip.h>
#include "stdio.h" 
#include "Markup.h"
#include "DSRC_ASN_Utils.h"

typedef struct configIP {
	CString ip;
	UINT    port;
} configIP_t;

typedef struct dispatch {
    CString version;
    CString type;
    CString psid;
    UINT    priority;
    CString txmode;
    UINT    txchannel;
    UINT    txinterval;
    CString deliverystart;
    CString deliverystop;
    BOOL    signature;
    BOOL    encryption;
} dispatch_t;

configIP_t mobjLocal;
configIP_t mobjTarget;
dispatch_t mobjDispatch;

int ATOI(CString string)
{
	size_t size = 0;
	char multibytestring[25];
	wcstombs_s(&size, multibytestring, string.GetLength() + 1, string, _TRUNCATE);
	return atoi(multibytestring);
}

void PRINTF(CString string)
{
	size_t sz = 0;
	char multibytestring[1000];
	wcstombs_s(&sz, multibytestring, string.GetLength() + 1, string, _TRUNCATE);
	printf(multibytestring);
}

void LoadConfiguration(CString filname)
{
	CMarkup objDocument;
	CFile objfile;

/*	Open the Configuration File  */
	if (!objfile.Open( filname, CFile::modeRead ))
		{
		printf("Failed to open configuration file.\n");
		return;
		}

/*	Read the Configuration File Contents  */
	int length = (int)objfile.GetLength();
	unsigned char *pBuffer = new unsigned char[length + 2];
	length = objfile.Read(pBuffer, length);
	objfile.Close();
	objDocument.SetDoc((CString)(LPCSTR)pBuffer);

/*	Get the Local and Target IP Addresses and Ports  */
	if (objDocument.FindChildElem(L"localip"))  {mobjLocal.ip = objDocument.GetChildData();}
	if (objDocument.FindChildElem(L"targetip")) {mobjTarget.ip = objDocument.GetChildData();}
	if (objDocument.FindChildElem(L"rtcm"))
		{
		objDocument.IntoElem();
		if (objDocument.FindChildElem(L"dispatch"))
			{
			objDocument.IntoElem();
			mobjDispatch.type = "RTCM";
			mobjDispatch.version = objDocument.GetAttrib(L"version");
			mobjDispatch.psid = objDocument.GetAttrib(L"psid");
			mobjDispatch.priority = ATOI(objDocument.GetAttrib(L"priority"));
			mobjDispatch.txmode = objDocument.GetAttrib(L"txmode");
			mobjDispatch.txchannel = ATOI(objDocument.GetAttrib(L"txchannel"));
			mobjDispatch.txinterval = ATOI(objDocument.GetAttrib(L"txinterval"));
			mobjDispatch.deliverystart = objDocument.GetAttrib(L"deliverystart");
			mobjDispatch.deliverystop = objDocument.GetAttrib(L"deliverystop");
			mobjDispatch.signature = (objDocument.GetAttrib(L"signature").MakeLower() == "true");
			mobjDispatch.encryption = (objDocument.GetAttrib(L"encryption").MakeLower() == "true");
			objDocument.OutOfElem();
			}
		if (objDocument.FindChildElem(L"localport"))  {mobjLocal.port = ATOI(objDocument.GetChildData());}
		if (objDocument.FindChildElem(L"targetport"))  {mobjTarget.port = ATOI(objDocument.GetChildData());}
		}

	return;
}

CString CreateDispatchHeader()
{
	CString sHeader = "";
	CString sValue;

	sHeader += "Version=" + mobjDispatch.version + "\n";
    sHeader += "Type=" + mobjDispatch.type + "\n";
    sHeader += "PSID=" + mobjDispatch.psid + "\n";
	sValue.Format(L"%i", mobjDispatch.priority);
    sHeader += "Priority=" + sValue + "\n";
    sHeader += "TxMode=" + mobjDispatch.txmode + "\n";
	sValue.Format(L"%i", mobjDispatch.txchannel);
    sHeader += "TxChannel=" + sValue + "\n";
	sValue.Format(L"%i", mobjDispatch.txinterval);
    sHeader += "TxInterval=" + sValue + "\n";
    sHeader += "DeliveryStart=" + mobjDispatch.deliverystart + "\n";
    sHeader += "DeliveryStop=" + mobjDispatch.deliverystop + "\n";
	if (mobjDispatch.signature) sValue = "True"; else sValue = "False";
    sHeader += "Signature=" + sValue + "\n";
	if (mobjDispatch.encryption) sValue = "True"; else sValue = "False";
    sHeader += "Encryption=" + sValue + "\n";

	return sHeader;
}

void ErrorMessage(int error)
{
	LPWSTR message;
	FormatMessage(0x1300, NULL, error, 0, (LPTSTR) &message, 0, NULL);
	printf("<%d> ", error);
	_tprintf( TEXT("%s\n"), message );
}

void IPv4(CString Message)
{
    int iResult;
    WSADATA wsaData;
    SOCKET Socket = INVALID_SOCKET;
    struct sockaddr_in Local; 
    struct sockaddr_in Remote; 

/*  Convert the CString to a Byte Array  */
	size_t sz = 0;
	char multibytestring[1000];
	wcstombs_s(&sz, multibytestring, Message.GetLength() + 1, Message, _TRUNCATE);
	char *bytes =  &multibytestring[0];

    iResult = WSAStartup(MAKEWORD(2,2), &wsaData);
    if (iResult != NO_ERROR) {
        wprintf(L"WSA Startup failed with error: %d\n", iResult);
 		ErrorMessage(WSAGetLastError());
		return;
    }

    Socket = socket(AF_INET, SOCK_DGRAM, IPPROTO_UDP);
    if (Socket == INVALID_SOCKET) {
        wprintf(L"Socket failed with error: %ld\n", WSAGetLastError());
		ErrorMessage(WSAGetLastError());
		WSACleanup();
        return;
	}

	Local.sin_family = AF_INET;
    Local.sin_port = htons(5530);
	Local.sin_addr.s_addr = inet_addr("169.254.11.55");

	iResult = bind(Socket, (SOCKADDR*) &Local, sizeof(Local));
    if (iResult == SOCKET_ERROR) {
        wprintf(L"Connect failed with error: %d\n", WSAGetLastError() );
		ErrorMessage(WSAGetLastError());
		closesocket(Socket);
        WSACleanup();
        return;
	  }

	Remote.sin_family = AF_INET;
    Remote.sin_port = htons(3001);
	Remote.sin_addr.s_addr = inet_addr("169.254.121.179");

	iResult = sendto(Socket, bytes,(int)strlen(bytes), 0, (SOCKADDR*)&Remote, sizeof(Remote));
    if (iResult == SOCKET_ERROR) {
        wprintf(L"Send failed with error: %d\n", WSAGetLastError());
		ErrorMessage(WSAGetLastError());
		closesocket(Socket);
        WSACleanup();
        return;
    }

    printf("Bytes Sent: %d\n", iResult);

    // shutdown the connection since no more data will be sent
    iResult = shutdown(Socket, SD_SEND);
    if (iResult == SOCKET_ERROR) {
        wprintf(L"Shutdown failed with error: %d\n", WSAGetLastError());
		ErrorMessage(WSAGetLastError());
		closesocket(Socket);
        WSACleanup();
        return;
	}

    // close the socket
    iResult = closesocket(Socket);
    if (iResult == SOCKET_ERROR) {
        wprintf(L"close failed with error: %d\n", WSAGetLastError());
 		ErrorMessage(WSAGetLastError());
		WSACleanup();
        return;
    }

    WSACleanup();
    return;
}

void IPv6()
{
    int iResult;
    WSADATA wsaData;

    SOCKET Socket = INVALID_SOCKET;
    struct sockaddr_in6 Local; 
    struct sockaddr_in6 Remote; 

    char *sendbuf = "Client: sending data test";

    iResult = WSAStartup(MAKEWORD(2,2), &wsaData);
    if (iResult != NO_ERROR) {
        wprintf(L"WSA Startup failed with error: %d\n", iResult);
 		ErrorMessage(WSAGetLastError());
		return;
    }

    Socket = socket(AF_INET6, SOCK_DGRAM, IPPROTO_UDP);
    if (Socket == INVALID_SOCKET) {
        wprintf(L"Socket failed with error: %ld\n", WSAGetLastError());
		ErrorMessage(WSAGetLastError());
		WSACleanup();
        return;
	}

	Local.sin6_family = AF_INET6;
    Local.sin6_port = htons(27015);
	inet_pton(AF_INET6, "fe80::8cc1:e54c:6078:b37%15", &Local.sin6_addr);

	iResult = bind(Socket, (SOCKADDR*) &Local, sizeof(Local));
    if (iResult == SOCKET_ERROR) {
        wprintf(L"Connect failed with error: %d\n", WSAGetLastError() );
		ErrorMessage(WSAGetLastError());
		closesocket(Socket);
        WSACleanup();
        return;
	  }

	Remote.sin6_family = AF_INET6;
    Remote.sin6_port = htons(30001);
	inet_pton(AF_INET6, "fe80::8cc2:7d34:9a33:79b3", &Remote.sin6_addr);

	iResult = sendto(Socket, sendbuf,(int)strlen(sendbuf), 0, (SOCKADDR*)&Remote, sizeof(Remote));
    if (iResult == SOCKET_ERROR) {
        wprintf(L"Send failed with error: %d\n", WSAGetLastError());
		ErrorMessage(WSAGetLastError());
		closesocket(Socket);
        WSACleanup();
        return;
    }

    printf("Bytes Sent: %d\n", iResult);

    // shutdown the connection since no more data will be sent
    iResult = shutdown(Socket, SD_SEND);
    if (iResult == SOCKET_ERROR) {
        wprintf(L"Shutdown failed with error: %d\n", WSAGetLastError());
		ErrorMessage(WSAGetLastError());
		closesocket(Socket);
        WSACleanup();
        return;
	}

    // close the socket
    iResult = closesocket(Socket);
    if (iResult == SOCKET_ERROR) {
        wprintf(L"close failed with error: %d\n", WSAGetLastError());
 		ErrorMessage(WSAGetLastError());
		WSACleanup();
        return;
    }

    WSACleanup();
    return;

}



int main(int argc, char* argv[])
{
	RTCMmsg_t RTCMmsg;
	RTCM_Corrections_t RTCM_Corrections;
	BYTE rtcm[16];
	BYTE buffer[MAX_MSG_SIZE];
	SSIZE_T size;
	CString sByte;

/*  Read the Application Configuration File  */
	LoadConfiguration("Config.xml");
	
/*  Assemble the Message Header  */
	CString sMessage = CreateDispatchHeader();

/*  SIMULATED RTCM MESSAGE  */
	for (int i=0; i<16; i++) rtcm[i] = i;

/*	Initialize the RTCM Message Structure  */
	RTCMmsg.rev = NULL;
	RTCMmsg.rtcmID = NULL; 
	RTCMmsg._asn_ctx.ptr = NULL;
	RTCMmsg.payload._asn_ctx.ptr = NULL;

/*	Load the RTCM Message Package  */
	RTCMmsg.payload.buf = &rtcm[0];
	RTCMmsg.payload.size = sizeof(rtcm);

/*	Initialize the RTCM Corrections Structure  */
	RTCM_Corrections_Init(&RTCM_Corrections);
	asn_set_init((void *)&RTCM_Corrections.rtcmSets);
	asn_set_add((void *)&RTCM_Corrections.rtcmSets, (void *)&RTCMmsg);
	
/*	Initialize the Buffer  */
	for (int i=0; i<MAX_MSG_SIZE; i++) buffer[i] = 0;

/*	Encode the RTCM Message  */
	size = DSRC_serializer(&asn_DEF_RTCM_Corrections, &RTCM_Corrections, buffer);

/*  Assemble the Message Payload  */
	sMessage += "payload=";
	for (int i=0; i<size; i++) {sByte.Format(L"%02X", buffer[i]); sMessage += sByte;}

/*	Display the Dispatch Message  */
	PRINTF(sMessage);
	printf("\n\n");
	PRINTF("Local IP: "+ mobjLocal.ip);
	printf("/%i\n", mobjLocal.port);

	IPv4(sMessage);


	getchar();

}