
#include "ASNJ2735.h"

#define BUFSIZE 5000
#define PIPE_TIMEOUT 5000

DWORD RTCM_toASN(BYTE *Buffer, BYTE *ASN)
	{
	int i = 1;

/*	Initialize the RTCM Structure  */
	RTCM_Corrections_t RTCM_Corrections;
	RTCM_Corrections_Init(&RTCM_Corrections);
	asn_set_init((void *)&RTCM_Corrections.rtcmSets);
	for (int j=0; j<4; j++) {RTCM_Corrections.msgCnt |= Buffer[i++] << (8*j);}
	RTCM_Corrections.rev = Buffer[i++];
	for (int j=0; j<5; j++) {RTCM_Corrections.rtcmHeader.buf[j] = Buffer[i++];}
	BYTE count = Buffer[i++];
	for (int j=0; j<count; j++)
		{

/*		Initialize the RTCM Message Structure  */
		RTCMmsg_t *RTCMmsg = new RTCMmsg_t;
		RTCMmsg->rev = NULL;
		RTCMmsg->rtcmID = NULL; 
		RTCMmsg->_asn_ctx.ptr = NULL;
		RTCMmsg->payload._asn_ctx.ptr = NULL;
		OCTET_STRING_init(&RTCMmsg->payload);

/*		Load he RTCM Message Version  */
		RTCM_Revision_t rev = (RTCM_Revision_t)Buffer[i++];
		//RTCMmsg->rev = &rev;

/*		Get the Payload Size  */
		int size = 0;
		for (int j=0; j<2; j++) {size |= Buffer[i++] << (8*j);}

/*		Load he RTCM Payload  */
		char rtcm[1024];
		for (int n=0; n<size; n++) rtcm[n] = Buffer[i++];

/*		Load the RTCM Payload  */
		OCTET_STRING_fromBuf(&RTCMmsg->payload, &rtcm[0], size);
		asn_set_add((void *)&RTCM_Corrections.rtcmSets, (void *)RTCMmsg);
		}

/*	Encode the RTCM Message  */
	for (int i=0; i<MAX_MSG_SIZE; i++) ASN[i] = 0;
	return DSRC_serializer(&asn_DEF_RTCM_Corrections, &RTCM_Corrections, ASN);		
	}

DWORD RTCM_fromASN(BYTE *ASN, BYTE *Buffer)
{
	RTCM_Corrections_t *RTCM_Corrections;
	RTCMmsg_t *RTCMmsg;
	void *structure = 0;
	int index = 0;

/*	Decode the ASN Message to a Structure  */
	int wordcount = GetMsgWordCnt(ASN);
	int size = wordcount + BytesUsed(wordcount);
	DSRC_UNserializer((void**)&structure, ASN, size, false);

/*  Cast the Structure  */
	RTCM_Corrections = (RTCM_Corrections_t*)structure;

/*	Encode the Structure Data  */
	InsertByte  (Buffer, &index, (BYTE)(*RTCM_Corrections).msgID);
	InsertLong  (Buffer, &index, (*RTCM_Corrections).msgCnt);
	InsertByte  (Buffer, &index, (BYTE)(*RTCM_Corrections).rev);
	InsertOctet (Buffer, &index, (&(*RTCM_Corrections).rtcmHeader), 5);
	InsertByte  (Buffer, &index, (BYTE)(*RTCM_Corrections).rtcmSets.list.count);
	for (int i=0; i<(*RTCM_Corrections).rtcmSets.list.count; i++)
		{
		RTCMmsg = (*RTCM_Corrections).rtcmSets.list.array[i];
		InsertByte    (Buffer, &index, (BYTE)RTCMmsg->rev);
		InsertInteger (Buffer, &index, RTCMmsg->payload.size);
		for (int b=0; b<RTCMmsg->payload.size; b++)
			{
			InsertByte (Buffer, &index, (BYTE)RTCMmsg->payload.buf[b]);
			}
		}

	return index;
}

DWORD SRM_toASN(BYTE *Buffer, BYTE *ASN)
{
	SignalRequestMsg_t SignalRequestMsg;
	long value;
	int i = 1;

/*  Initialize the Signal Request Message  */
	SignalRequestMsg_Init(&SignalRequestMsg);
	OCTET_STRING_init(&SignalRequestMsg.request.id);
	OCTET_STRING_init(&SignalRequestMsg.request.type);
	SignalRequestMsg.request.requestedAction = NULL;
	SignalRequestMsg.request.isCancel = NULL;
	SignalRequestMsg.request.codeWord = NULL;
	SignalRequestMsg.request.outLane = NULL;

/*  Load the Message Count  */
	for (int j=0; j<4; j++) {SignalRequestMsg.msgCnt |= Buffer[i++] << (8*j);}

/*  Load the Signal Request  */
	value = 0;
	for (int j=0; j<4; j++) {value |= Buffer[i++] << (8*j);}
	Long2OctetBuff(&SignalRequestMsg.request.id, value);
	SignalRequestMsg.request.inLane = OCTET_STRING_new_fromLong(Buffer[i++]);
	Long2OctetBuff(&SignalRequestMsg.request.type, Buffer[i++]);

/*  Load the Time of Service  */
	SignalRequestMsg.timeOfService = new DTime_t;
	SignalRequestMsg.timeOfService->hour = 0;
	for (int j=0; j<4; j++) {SignalRequestMsg.timeOfService->hour |= Buffer[i++] << (8*j);}
	SignalRequestMsg.timeOfService->minute = 0;
	for (int j=0; j<4; j++) {SignalRequestMsg.timeOfService->minute |= Buffer[i++] << (8*j);}
	SignalRequestMsg.timeOfService->second = 0;
	for (int j=0; j<4; j++) {SignalRequestMsg.timeOfService->second |= Buffer[i++] << (8*j);}
	SignalRequestMsg.timeOfService->_asn_ctx.ptr = NULL;

/*  Load the End of Service Time  */
	SignalRequestMsg.endOfService = new DTime_t;
	SignalRequestMsg.endOfService->hour = 0;
	for (int j=0; j<4; j++) {SignalRequestMsg.endOfService->hour |= Buffer[i++] << (8*j);}
	SignalRequestMsg.endOfService->minute = 0;
	for (int j=0; j<4; j++) {SignalRequestMsg.endOfService->minute |= Buffer[i++] << (8*j);}
	SignalRequestMsg.endOfService->second = 0;
	for (int j=0; j<4; j++) {SignalRequestMsg.endOfService->second |= Buffer[i++] << (8*j);}
	SignalRequestMsg.endOfService->_asn_ctx.ptr = NULL;

/*  Load the Vehicle VIN  */
	SignalRequestMsg.vehicleVIN = new VehicleIdent_t;
	value = 0;
	for (int j=0; j<4; j++) {value |= Buffer[i++] << (8*j);}
	SignalRequestMsg.vehicleVIN->id = OCTET_STRING_new_fromLong(value);
	SignalRequestMsg.vehicleVIN->name = NULL;
	SignalRequestMsg.vehicleVIN->vin = NULL;
	SignalRequestMsg.vehicleVIN->ownerCode = NULL;
	SignalRequestMsg.vehicleVIN->vehicleType = NULL;
	SignalRequestMsg.vehicleVIN->vehicleClass = NULL; 
	SignalRequestMsg.vehicleVIN->_asn_ctx.ptr = NULL;

/*	Encode the SRM Message  */
	for (int i=0; i<MAX_MSG_SIZE; i++) ASN[i] = 0;
	return DSRC_serializer(&asn_DEF_SignalRequestMsg, &SignalRequestMsg, ASN);	

}

DWORD SRM_fromASN(BYTE *ASN, BYTE *Buffer)
{
	SignalRequestMsg_t *SignalRequestMsg;
	void *structure = 0;
	int index = 0;

/*	Decode the ASN Message to a Structure  */
	int wordcount = GetMsgWordCnt(ASN);
	int size = wordcount + BytesUsed(wordcount);
	DSRC_UNserializer((void**)&structure, ASN, size, false);

/*  Cast the Structure  */
	SignalRequestMsg = (SignalRequestMsg_t*)structure;

/*	Encode the Structure Data  */
	InsertByte  (Buffer, &index, (BYTE)(*SignalRequestMsg).msgID);
	InsertLong  (Buffer, &index, (*SignalRequestMsg).msgCnt);
	InsertOctet (Buffer, &index, (&(*SignalRequestMsg).request.id), 4);
	InsertByte  (Buffer, &index, (BYTE)(*SignalRequestMsg).request.inLane->buf[0]);
	InsertByte  (Buffer, &index, (BYTE)(*SignalRequestMsg).request.type.buf[0]);
	InsertLong  (Buffer, &index, (*SignalRequestMsg).timeOfService->hour);
	InsertLong  (Buffer, &index, (*SignalRequestMsg).timeOfService->minute);
	InsertLong  (Buffer, &index, (*SignalRequestMsg).timeOfService->second);
	InsertLong  (Buffer, &index, (*SignalRequestMsg).endOfService->hour);
	InsertLong  (Buffer, &index, (*SignalRequestMsg).endOfService->minute);
	InsertLong  (Buffer, &index, (*SignalRequestMsg).endOfService->second);
	InsertOctet (Buffer, &index, (*SignalRequestMsg).vehicleVIN->id, 4);

	return index;
}

DWORD SSM_toASN(BYTE *Buffer, BYTE *ASN)
{
	SignalStatusMessage_t SignalStatusMessage;
	long value;
	int i = 1;

	SignalStatusMessage_Init(&SignalStatusMessage);
	OCTET_STRING_init(&SignalStatusMessage.id);
	OCTET_STRING_init(&SignalStatusMessage.status);

/*  Load the Message Count  */
	for (int j=0; j<4; j++) {SignalStatusMessage.msgCnt |= Buffer[i++] << (8*j);}

/*  Load the Intersection ID  */
	value = 0;
	for (int j=0; j<4; j++) {value |= Buffer[i++] << (8*j);}
	Long2OctetBuff(&SignalStatusMessage.id, value);

/*  Load the Signal Status  */
	Long2OctetBuff(&SignalStatusMessage.status, Buffer[i++]);

/*	Encode the SSM Message  */
	for (int i=0; i<MAX_MSG_SIZE; i++) ASN[i] = 0;
	return DSRC_serializer(&asn_DEF_SignalStatusMessage, &SignalStatusMessage, ASN);	

}

DWORD SSM_fromASN(BYTE *ASN, BYTE *Buffer)
{
	SignalStatusMessage_t *SignalStatusMessage;
	void *structure = 0;
	int index = 0;

/*	Decode the ASN Message to a Structure  */
	int wordcount = GetMsgWordCnt(ASN);
	int size = wordcount + BytesUsed(wordcount);
	DSRC_UNserializer((void**)&structure, ASN, size, false);

/*  Cast the Structure  */
	SignalStatusMessage = (SignalStatusMessage_t*)structure;

/*	Encode the Structure Data  */
	InsertByte  (Buffer, &index, (BYTE)(*SignalStatusMessage).msgID);
	InsertLong  (Buffer, &index, (*SignalStatusMessage).msgCnt);
	InsertOctet (Buffer, &index, (&(*SignalStatusMessage).id), 4);
	InsertByte  (Buffer, &index, (BYTE)(*SignalStatusMessage).status.buf[0]);

	return index;
}

DWORD WINAPI InstanceThread(LPVOID lpvParam)
	{
	if (lpvParam == NULL)
		{
		printf("ERROR - Pipe Server Failure:\n");
		return -1;
		}

	BOOL fSuccess = FALSE;
	BYTE inBuffer[BUFSIZE];
	BYTE outBuffer[BUFSIZE];
	BYTE bCount[2];
	DWORD dBytes = 0;
	DWORD dReadBytes = 0;
	DWORD dWriteBytes = 0;
	HANDLE hPipe = (HANDLE) lpvParam;
	int iMessageType = 0;

/*  Monitor the Pipe for Client Messages  */
	while (1) 
	{ 
	fSuccess = ReadFile(hPipe, &inBuffer, BUFSIZE*sizeof(BYTE), &dReadBytes, NULL);   
	if (!fSuccess || dReadBytes == 0)
		{
		printf("Client read failed, Error: %d.\n", GetLastError());
		break;
		}

/*  Produce an ASN Encoded Message */
	switch (inBuffer[0])
		{
		case 0x0c: 
			dBytes = RTCM_toASN(&inBuffer[0], &outBuffer[0]);
			break;
		case 0x0e:
			dBytes = SRM_toASN(&inBuffer[0], &outBuffer[0]);
			break;
		case 0x0f:
			dBytes = SSM_toASN(&inBuffer[0], &outBuffer[0]);
			break;
		case 0x30:

/*			Decode the ASN Message */
			iMessageType = GetMsgType(inBuffer, BytesUsed(GetMsgWordCnt(inBuffer)));
			switch (iMessageType)
				{
				case 0x0c: 
					dBytes = RTCM_fromASN(&inBuffer[0], &outBuffer[0]);
					break;
				case 0x0e:
					dBytes = SRM_fromASN(&inBuffer[0], &outBuffer[0]);
					break;				
				case 0x0f:
					dBytes = SSM_fromASN(&inBuffer[0], &outBuffer[0]);
					break;
				default:
					printf("Unrecognized ASN message type: %d.\n", iMessageType);
					dBytes = 0;
					break;
				}
			break;

		default:
			printf("Unrecognized Message ID: %d.\n", inBuffer[0]);
			dBytes = 0;
			break;
		}

/*  Send the Byte Count  */
	bCount[0] = (byte)(dBytes / 256);
	bCount[1] = (byte)(dBytes & 255);
	WriteFile(hPipe, &bCount, 2, &dWriteBytes, NULL);  

/*  Send the Output Byte Stream  */
	fSuccess = WriteFile(hPipe, &outBuffer, dBytes, &dWriteBytes, NULL);       
	if (!fSuccess || dWriteBytes == 0)
		{
		printf("Client write failed, Error: %d.\n", GetLastError());
		break;
		}
	}

/*  Flush the Pipe and Disconnect  */
	FlushFileBuffers(hPipe); 
	DisconnectNamedPipe(hPipe); 
	CloseHandle(hPipe); 

/*  Exit the Thread  */
	printf("Client thread exiting.\n");
	return 1;
	}

int main() 
	{
	BOOL   fConnected = FALSE; 
	DWORD  dwThreadId = 0; 
	HANDLE hPipe = INVALID_HANDLE_VALUE; 
	HANDLE hThread = NULL; 
	LPTSTR lpszPipename = TEXT("\\\\.\\pipe\\ASNJ2735"); 

	for (;;) 
	{ 
	printf("Creating named pipe: ASNJ2735\n");
	hPipe = CreateNamedPipe( 
		lpszPipename,             
        PIPE_ACCESS_DUPLEX,       
        PIPE_TYPE_MESSAGE |       
        PIPE_READMODE_BYTE |   
        PIPE_WAIT,                
        PIPE_UNLIMITED_INSTANCES, 
        BUFSIZE,                  
        BUFSIZE,                  
        0,                        
        NULL);          

      if (hPipe == INVALID_HANDLE_VALUE) 
      {
          printf("Create named pipe failed, Error: %d.\n", GetLastError()); 
          return -1;
      }

	 printf("Waiting for client connect...\n");
     fConnected = ConnectNamedPipe(hPipe, NULL) ? TRUE : (GetLastError() == ERROR_PIPE_CONNECTED); 

      if (fConnected) 
		{ 
        printf("Client connected, creating a processing thread..."); 
		hThread = CreateThread( 
            NULL,              
            0,                 
            InstanceThread,    
            (LPVOID) hPipe,   
            0,                
            &dwThreadId);   

		if (hThread == NULL) 
			{
			printf("Failed, Error: %d.\n", GetLastError()); 
            return -1;
			}
		else 
			{
			printf("Successful!\n\n"); 
			CloseHandle(hThread);
			}
		}
	  else CloseHandle(hPipe); 
	}

	return 0;
	}



