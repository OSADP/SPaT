#include <windows.h>
#include <stdio.h>
#include "DSRC_ASN_Utils.h"

inline void OCTET_STRING_init (OCTET_STRING *td)
{
	if (td != NULL)
	{
		td->buf = NULL;
		td->size = 0;
		td->_asn_ctx.ptr = NULL;
	}
}

inline OCTET_STRING_t *OCTET_STRING_new_fromLong(long theValue)
{
	int cnt = 1;
	uBYTE theData[4];
	theData[3] = (uBYTE)((0xFF000000 & theValue) >> 24);
    theData[2] = (uBYTE)((0x00FF0000 & theValue) >> 16);
    theData[1] = (uBYTE)((0x0000FF00 & theValue) >> 8);
    theData[0] = (uBYTE)((0x000000FF & theValue) >> 0);
	long i = abs(theValue);
	if      (i < 128)     {cnt = 1;}
    else if (i < 32768)   {cnt = 2;}
    else if (i < 8388608) {cnt = 3;}
	else                  {cnt = 4;}
	return OCTET_STRING_new_fromBuf(&asn_DEF_SignalRequest, (const char *)theData, cnt);
}

inline void InsertOctet(BYTE *Buffer, int *i, OCTET_STRING_t *os, int size)
{
	for (int j=0; j<os->size; j++) {Buffer[(*i)++] = (BYTE)(os->buf[j]);}
	for (int j=os->size; j<size; j++) {Buffer[(*i)++] = 0;}
}

inline void InsertLong(BYTE *Buffer, int *i, long value)
{
	for (int j=0; j<4; j++) {Buffer[(*i)++] = (BYTE)((value & (0x000000ff << (8*j))) >> (8*j));}
}

inline void InsertInteger(BYTE *Buffer, int *i, int value)
{
	for (int j=0; j<2; j++) {Buffer[(*i)++] = (BYTE)((value & (0x00ff << (8*j))) >> (8*j));}
}

inline void InsertByte(BYTE *Buffer, int *i, BYTE value)
{
	Buffer[(*i)++] = value;
}