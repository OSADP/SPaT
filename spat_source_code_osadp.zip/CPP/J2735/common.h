/*************************************************************************************
*
*  common.h : Common Procedure Header File
*
*************************************************************************************/

/* Common Structures */
struct blob 
    {
    unsigned int messageid;
    unsigned int version;
    unsigned char *pblob;
    unsigned int size;
    };

/* Common Function Prototypes */  
unsigned short crc_ccitt(unsigned char*, int);
blob blob_initialize(unsigned char*);
void blob_free(blob*);
