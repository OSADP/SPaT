
#include "stdafx.h"
#include "J2735.h"

/*  Local Procedures  */
void spat_load(spat *message)
    {
	(*message).intersectionid = 200;
	(*message).intersectionstatus = 0x00;
	(*message).timestampseconds = 1332855560;
	(*message).timestamptenths = 15;
	
	(*message).movement[0].type = straight;
	(*message).movement[0].lane[0] = 3;
	(*message).movement[0].lane[1] = 4;
	(*message).movement[0].data.state = 0x01;
	(*message).movement[0].data.mintime = 40;
	(*message).movement[0].data.maxtime = 1170;
	(*message).movement[0].data.yellowstate = 0x02;
	(*message).movement[0].data.yellowtime = 30;
	
	(*message).movement[1].type = straight;
	(*message).movement[1].lane[0] = 7;
	(*message).movement[1].lane[1] = 8;
	(*message).movement[1].data.state = 0x01;
	(*message).movement[1].data.mintime = 40;
	(*message).movement[1].data.maxtime = 390;
	(*message).movement[1].data.yellowstate = 0x02;
	(*message).movement[1].data.yellowtime = 30;
	
	(*message).movement[2].type = straight;
	(*message).movement[2].lane[0] = 5;
	(*message).movement[2].lane[1] = 6;
	(*message).movement[2].data.state = 0x01;
	(*message).movement[2].data.mintime = 40;
	(*message).movement[2].data.maxtime = 1170;
	(*message).movement[2].data.yellowstate = 0x02;
	(*message).movement[2].data.yellowtime = 30;

	(*message).movement[3].type  = rightturn;
	(*message).movement[3].lane[0] = 6;
	(*message).movement[3].data.state = 0x01;
	(*message).movement[3].data.mintime = 40;
	(*message).movement[3].data.maxtime = 1170;
	(*message).movement[3].data.yellowstate = 0x02;
	(*message).movement[3].data.yellowtime = 30;

	(*message).movement[4].type  = leftturn;
	(*message).movement[4].lane[0] = 10;
	(*message).movement[4].data.state = 0x10;
	(*message).movement[4].data.mintime = 40;
	(*message).movement[4].data.maxtime = 780;
	(*message).movement[4].data.yellowstate = 0x20;
	(*message).movement[4].data.yellowtime = 30;

	(*message).movement[5].type  = straight;
	(*message).movement[5].lane[0] = 1;
	(*message).movement[5].data.state = 0x01;
	(*message).movement[5].data.mintime = 40;
	(*message).movement[5].data.maxtime = 390;
	(*message).movement[5].data.yellowstate = 0x02;
	(*message).movement[5].data.yellowtime = 30;

	(*message).movement[6].type  = leftturn;
	(*message).movement[6].lane[0] = 2;
	(*message).movement[6].data.state = 0x10;
	(*message).movement[6].data.mintime = 0;
	(*message).movement[6].data.maxtime = 1560;
	(*message).movement[6].data.yellowstate = 0x20;
	(*message).movement[6].data.yellowtime = 30;

	(*message).movement[7].type  = straight;
	(*message).movement[7].lane[0] = 103;
	(*message).movement[7].data.state = 1;
	(*message).movement[7].data.mintime = 40;
	(*message).movement[7].data.maxtime = 1170;

	(*message).movement[8].type  = straight;
	(*message).movement[8].lane[0] = 101;
	(*message).movement[8].data.state = 1;
	(*message).movement[8].data.mintime = 40;
	(*message).movement[8].data.maxtime = 390;

	}
void spat_display(spat *message)
    {
    int m, l;
    
    printf("Intersection ID: %i\n", (*message).intersectionid);
    printf("Intersection Status: %i\n", (*message).intersectionstatus);
    printf("Intersection Timestamp: %i\n", (*message).timestampseconds);
    printf("Intersection Tenths: %i\n", (*message).timestamptenths);
    for(m=0; m<spat_maxmovements; m++)
        {
        if ((*message).movement[m].lane[0]!= 0 )
            {
            printf("Movement: %i\n", m);
            printf("Type: %i\n", (*message).movement[m].type);
            printf("Lane Set: ");
            l=0;
            while (((*message).movement[m].lane[l] != 0) && l<spat_maxlanes)
                {
                printf("%i ", (*message).movement[m].lane[l++] );
                }
            printf("\n");
            printf("Current State: %i\n", (*message).movement[m].data.state);
            printf("Minimum Time: %i\n", (*message).movement[m].data.mintime);
            printf("Maximum Time: %i\n", (*message).movement[m].data.maxtime);
            printf("Yellow State: %i\n", (*message).movement[m].data.yellowstate);
            printf("Yellow Time: %i\n", (*message).movement[m].data.yellowtime);
            printf("Pedestrian: %i\n", (*message).movement[m].data.pedestrian);
            }    
        }
    }
void map_load(map *message)
    {
    map_group *group;
	map_lane *lane;
    
/*  Populate the MAP Message */
	(*message).attributes = decimeter + geometric + navigational;
	(*message).intersectionid = 1;
    (*message).geometry[0].refpoint.latitude = -389549920;
    (*message).geometry[0].refpoint.longitude = 771793610;
    
/*  Populate the Approach Lanes */
    group = &(*message).geometry[0].approach;
        lane = &(*group).lane[0];
            (*lane).number = 1;
            (*lane).type = vehicle;
            (*lane).attributes = 0x002E;
			(*lane).width = 320;
            (*lane).node[0].eastern = -133;
            (*lane).node[0].nothern = 36;
            (*lane).node[1].eastern = -234;
            (*lane).node[1].nothern = 78;
            (*lane).node[2].eastern = -331;
            (*lane).node[2].nothern = 119;
            (*lane).node[3].eastern = -470;
            (*lane).node[3].nothern = 188;
            (*lane).node[4].eastern = -614;
            (*lane).node[4].nothern = 270;
            (*lane).node[5].eastern = -731;
            (*lane).node[5].nothern = 371;
            (*lane).node[6].eastern = -848;
            (*lane).node[6].nothern = 490;
        lane = &(*group).lane[1];
            (*lane).number = 2;
            (*lane).type = vehicle;
            (*lane).attributes = 0x004E;
            (*lane).node[0].eastern = 52;
            (*lane).node[0].nothern = 148;
            (*lane).node[0].width = 380;
            (*lane).node[1].eastern = 104;
            (*lane).node[1].nothern = 265;
            (*lane).node[1].width = 320;
        lane = &(*group).lane[2];
            (*lane).number = 3;
            (*lane).type = vehicle;
            (*lane).attributes = 0x006E;
			(*lane).width = 320;
			(*lane).node[0].eastern = 141;
            (*lane).node[0].nothern = -36;
            (*lane).node[1].eastern = 226;
            (*lane).node[1].nothern = -56;
            (*lane).node[2].eastern = 366;
            (*lane).node[2].nothern = -58;
            (*lane).node[3].eastern = 644;
            (*lane).node[3].nothern = -42;
            (*lane).node[4].eastern = 811;
            (*lane).node[4].nothern = -33;
            (*lane).node[5].eastern = 545;
            (*lane).node[5].nothern = -50;
        lane = &(*group).lane[3];
            (*lane).number = 4;
            (*lane).type = vehicle;
            (*lane).attributes = 0x002A;
			(*lane).width = 320;
			(*lane).node[0].eastern = -9;
            (*lane).node[0].nothern = -91;
            (*lane).node[1].eastern = -57;
            (*lane).node[1].nothern = -173;
            (*lane).node[2].eastern = -117;
            (*lane).node[2].nothern = -276;
            (*lane).node[3].eastern = -155;
            (*lane).node[3].nothern = -361;
            (*lane).node[4].eastern = -126;
            (*lane).node[4].nothern = -460;
            (*lane).node[5].eastern = -37;
            (*lane).node[5].nothern = -513;
            (*lane).node[6].eastern = 68;
            (*lane).node[6].nothern = -541;
        lane = &(*group).lane[4];
            (*lane).number = 5;
            (*lane).type = vehicle;
            (*lane).attributes = 0x0024;
			(*lane).width = 320;
			(*lane).node[0].eastern = -32;
            (*lane).node[0].nothern = -77;
            (*lane).node[1].eastern = -53;
            (*lane).node[1].nothern = -114;
            (*lane).node[2].eastern = -76;
            (*lane).node[2].nothern = -155;
            (*lane).node[3].eastern = -95;
            (*lane).node[3].nothern = -194;                  
    }   
void map_display(map *message)
    {
    int g, l, n;
    
    printf("Message Attributes: %i\n", (*message).attributes);
    printf("Intersection ID: %i\n", (*message).intersectionid);
    for(g=0; g<10; g++)
        {
        if ((*message).geometry[g].refpoint.latitude!= 0 )
            {
            printf("Geometry: %i\n", g);
            printf("latitude: %i\n", (*message).geometry[g].refpoint.latitude);
            printf("longitude: %i\n", (*message).geometry[g].refpoint.longitude);
            if ((*message).attributes & elevation)
                {
                printf("elevation: %i\n", (*message).geometry[g].refpoint.elevation);
                }
            printf("Approach\n");
            if ((*message).geometry[g].approach.width != 0)
                {
                printf("width: %i\n", (*message).geometry[g].approach.width);
                }
            for(l=0; l<10; l++)
                {
                if ((*message).geometry[g].approach.lane[l].number != 0)
                    {
                    printf("lane: %i\n", (*message).geometry[g].approach.lane[l].number);
                    printf("type: %i\n", (*message).geometry[g].approach.lane[l].type);
                    printf("attributes: %i\n", (*message).geometry[g].approach.lane[l].attributes);
                    if ((*message).geometry[g].approach.lane[l].width != 0)
                        {
                        printf("width: %i\n", (*message).geometry[g].approach.lane[l].width);
                        }
                    if ((*message).geometry[g].approach.lane[l].referencelane.lanenumber != 0)
                        {
                        printf("reference lane: %i\n", (*message).geometry[g].approach.lane[l].referencelane.lanenumber);
                        printf("lateral offset: %i\n", (*message).geometry[g].approach.lane[l].referencelane.lateraloffset);
                        }
                    else
                        {
                        for(n=0; n<10; n++)
                            {
                            if ((*message).geometry[g].approach.lane[l].node[n].eastern != 0)
                                {
                                printf("node: %i\n", n);
                                printf("eastern: %i\n", (*message).geometry[g].approach.lane[l].node[n].eastern);
                                printf("northern: %i\n", (*message).geometry[g].approach.lane[l].node[n].nothern);
                                if ((*message).attributes & elevation)
                                    {
                                    printf("elevation: %i\n", (*message).geometry[g].approach.lane[l].node[n].elevation);
                                    }
                                if ((*message).geometry[g].approach.lane[l].node[n].width !=0)
                                    {
                                    printf("width: %i\n", (*message).geometry[g].approach.lane[l].node[n].width);
                                    }
                                }
                            }
                        }
                    }
                }
            }    
        }
    }

/*  Main Program  */
void main(void)
{
	blob payload;
	spat spatmessage;
	map mapmessage;
	unsigned int i;

/*  Test the SPAT Message Encoding  */
	spat_initialize(&spatmessage);
    spat_load(&spatmessage);
    spat_encode(&spatmessage, 1);    
    printf("SPAT size: %d\n\n", spatmessage.payload.size);
    for (i=0; i<spatmessage.payload.size; i++) { printf("%02x ", spatmessage.payload.pblob[i]); }
    printf("\n\n");

/*  Test the SPAT Message Decoding  */
	payload = blob_initialize(spatmessage.payload.pblob);
    if (payload.messageid == 0x8d)
        {
    	spat_initialize(&spatmessage);
	    spatmessage.payload = payload;
        spat_decode(&spatmessage);
        spat_display(&spatmessage);
	    }
	blob_free(&payload);

/*  Test the MAP Message Encoding  */
	map_initialize(&mapmessage);
    map_load(&mapmessage);
    map_encode(&mapmessage, 1);    
    printf("\nMAP size: %d\n\n", mapmessage.payload.size);
    for (i=0; i<mapmessage.payload.size; i++) { printf("%02x ", mapmessage.payload.pblob[i]); }
    printf("\n\n");

/*  Test the MAP Message Decoding  */
	payload = blob_initialize(mapmessage.payload.pblob);
    if (payload.messageid == 0x87)
        {
    	map_initialize(&mapmessage);
	    mapmessage.payload = payload;
        map_decode(&mapmessage);
        map_display(&mapmessage);
	    }
	blob_free(&payload);

	getchar();
}