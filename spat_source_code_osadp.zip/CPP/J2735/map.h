/*************************************************************************************
*
*  map.h    : MAP Message Header File
*
*************************************************************************************/

#include "stdafx.h"

/* Constants */
#define map_maxgeometries 10
#define map_maxbarriers 20
#define map_maxnodes 20
#define map_maxlanes 20
#define map_maxconnections 10
   
/* MAP Enumerations */
enum map_message_attributes {elevation=1, decimeter=2, geometric=4, navigational=8};
enum map_node_attributes {width=1, packed=2};
enum map_group_direction {approach=1, egress=2};
enum map_lane_type {vehicle = 1, computed = 2, pedestrian = 3, special = 4};
enum map_movements {straight = 1, leftturn = 2, rightturn = 4, uturn = 8, softleft = 16, softright = 32, mergeleft = 64, mergeright = 128};

/* MAP Structures */
struct map_referencelane
    {
    unsigned char lanenumber;
    signed short lateraloffset;
    };
struct map_connection
    {
    unsigned char lanenumber;
    unsigned char maneuver;
    };
struct map_node
    {
    signed short eastern;
    signed short nothern;
    signed short elevation;
    signed short width;
    };
struct map_lane
    {
    unsigned char number;
    unsigned char type;
    unsigned short attributes;
    unsigned short width;
    map_node node[map_maxnodes];
    map_referencelane referencelane;
    map_connection connection[map_maxconnections];
    };
struct map_group
    {
    unsigned short width;
    map_lane lane[map_maxlanes];
    };
struct map_barrier
    {
    unsigned short attributes;
    unsigned short width;
    map_node node[map_maxnodes];
    };       
struct map_referencepoint
    {
    signed long latitude;
    signed long longitude;
    signed int elevation;
    };
struct map_geometry
    {
    map_referencepoint refpoint;
    map_group approach;
    map_group egress;
    map_barrier barrier[map_maxbarriers];
    };
struct map
    {
    unsigned long intersectionid;
    unsigned char attributes;
    map_geometry geometry[map_maxgeometries];
    blob payload;
    };   
    
/* MAP Function Prototypes */       
int map_initialize(map*);
int map_encode(map*, unsigned char);
int map_decode(map*);