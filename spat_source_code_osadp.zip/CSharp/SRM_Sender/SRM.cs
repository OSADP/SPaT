﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace SRM_Sender
    {
    public partial class SRM : Form
        {
        Application mobjApplication;

#region "Constructor"

    public SRM()
        {
        InitializeComponent();
        mobjApplication = new Application(txtOutput);
        }

#endregion

#region "botSend"

    private void botSend_Click(object sender, EventArgs e)
        {
//      Create the SRM Structure
        ASN_r36.SignalRequestMsg_t SignalRequestMsg = ASN_r36.SignalRequestMsg_t.Create();
        try
        {
        SignalRequestMsg.msgCnt = 0;
        SignalRequestMsg.request.id = Convert.ToUInt32(txtIntersectionID.Text);
        SignalRequestMsg.request.inLane = Convert.ToByte(txtInLane.Text);
        SignalRequestMsg.request.type = (byte)((Convert.ToByte(txtVehicleClass.Text)*16) + (Convert.ToByte(txtVehicleLevel.Text)));
        SignalRequestMsg.timeOfService.hour = Convert.ToInt32(txtTOSHour.Text);
        SignalRequestMsg.timeOfService.minute = Convert.ToInt32(txtTOSMinute.Text);
        SignalRequestMsg.timeOfService.second = Convert.ToInt32(txtTOSSecond.Text);
        SignalRequestMsg.endOfService.hour = Convert.ToInt32(txtEOSHour.Text);
        SignalRequestMsg.endOfService.minute = Convert.ToInt32(txtEOSMinute.Text);
        SignalRequestMsg.endOfService.second = Convert.ToInt32(txtEOSSecond.Text);
        SignalRequestMsg.vehicleVIN.id =  Convert.ToUInt32(txtVehicleIdentifier.Text);
        }
        catch
        {
        MessageBox.Show("SRM message elements invalid or missing, check the values and try again.");
        return;
        }

//      Read the Application Configuration File        
        if (!mobjApplication.LoadConfiguration(txtConfig.Text))
            { 
            MessageBox.Show("Unable to load the configuration file: \n" + txtConfig.Text);
            return;
            }

//      Create the UDP Client for the DSRC Radio
        if (!mobjApplication.CreateUDPClient()) return;

//      NOTE: The ASNJ2735 Server must be Running before this will work.
//      Connect the the J2735 ASN Server
        txtOutput.AppendText("Connecting to ASNJ2735 Server...");
        ASN_r36 ASNr36 = new ASN_r36();
        StreamByte objStream = ASNr36.CreatePipeStream();
        if (objStream == null) 
            {
            txtOutput.AppendText("Failed!\n"); 
            return;
            }
        txtOutput.AppendText("Successful!\n"); 

//      Convert the SRM Corrections Structure to the ASN Byte Stream
        objStream.Write(SignalRequestMsg.Serialize());
        List<byte> ASN = objStream.Read();

//      Send the Message to the DSRC Radio for Transmission
        if (optASCII.Checked)
            {
            string sMessage = mobjApplication.CreateDispatchHeader(mobjApplication.Dispatch);
            sMessage += "payload=";
            foreach (byte Byte in ASN) { sMessage += Byte.ToString("X2"); }
            mobjApplication.TX(Encoding.ASCII.GetBytes(sMessage));
            }
        else if (optBinary.Checked)
            {
            mobjApplication.TX(ASN.ToArray());
            }
        }

#endregion

#region "botBrowse"

    private void botBrowse_Click(object sender, EventArgs e)
        {
        OpenFileDialog objDialog = new OpenFileDialog();
        objDialog.Title = "Select Configuration File";
        objDialog.FileName = txtConfig.Text;
        objDialog.ShowDialog();
        if (objDialog.FileName != "") {txtConfig.Text = objDialog.FileName;}
        }

#endregion

        }
    }
