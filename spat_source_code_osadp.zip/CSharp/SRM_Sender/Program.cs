﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows.Forms;
using System.Net;
using System.Net.Sockets;
using System.Xml.Linq;

#region "Structures"

    struct configIP
        {
        public string ip ;
        public int    port;
        }

    struct dispatch
        {
        public string version;
        public string type;
        public string psid;
        public int    priority;
        public string txmode;
        public int    txchannel;
        public int    txinterval;
        public string deliverystart;
        public string deliverystop;
        public bool   signature;
        public bool   encryption;
        }

#endregion

#region "class Application"

class Application
    {
    private configIP   mobjLocal;
    private configIP   mobjTarget;
    private dispatch   mobjDispatch;
    private UdpClient  mobjUDPClient;
    private IPEndPoint mobjEndPoint;
    private TextBox    mobjOutput;

#region "Constructor"

    public Application(System.Windows.Forms.TextBox output)
        {
        mobjOutput = output;
        }

#endregion

#region "Public Members"

    public configIP LocalConfiguration {get {return mobjLocal;}}

    public configIP TargetConfiguration {get {return mobjTarget;}}

    public dispatch Dispatch {get {return mobjDispatch;}}

    public bool LoadConfiguration(string sFilename)
        {
        string sTag;
        string sValue;

//      Load the Configuration File
        try
        {
        XDocument doc = XDocument.Load(sFilename);
        XElement root = doc.Root;

//      Parse the Configuration File Elements
        foreach (XElement element in root.Elements())
            {
            sTag = element.Name.ToString();
            sValue = element.Value.ToString();
            switch (sTag.ToLower())
                {
                case "localip":    { mobjLocal.ip = sValue; break; } 
                case "targetip":   { mobjTarget.ip = sValue; break; } 

//              Parse the RTCM Configuration Elements
                case "srm": 
                    {
                    foreach (XElement child in element.Elements())
                        {
                        sTag = child.Name.ToString();
                        sValue = child.Value.ToString();
                        switch (sTag.ToLower())
                            {
                            case "localport":  { mobjLocal.port = Convert.ToInt32(sValue); break; } 
                            case "targetport": { mobjTarget.port = Convert.ToInt32(sValue); break; } 
                            case "dispatch":
                                {
                                mobjDispatch.type = "SRM";
                                foreach (XAttribute attribute in child.Attributes())
                                    {
                                    sTag = attribute.Name.ToString();
                                    sValue = attribute.Value.ToString();
                                    switch (sTag.ToLower())
                                        {
                                        case "version":       { mobjDispatch.version = sValue; break; } 
                                        case "psid":          { mobjDispatch.psid = sValue; break; } 
                                        case "priority":      { mobjDispatch.priority = Convert.ToInt32(sValue); break; } 
                                        case "txmode":        { mobjDispatch.txmode = sValue; break; } 
                                        case "txchannel":     { mobjDispatch.txchannel = Convert.ToInt32(sValue); break; } 
                                        case "txinterval":    { mobjDispatch.txinterval = Convert.ToInt32(sValue); break; } 
                                        case "deliverystart": { mobjDispatch.deliverystart = sValue; break; } 
                                        case "deliverystop":  { mobjDispatch.deliverystop = sValue; break; } 
                                        case "signature":     { mobjDispatch.signature = Convert.ToBoolean(sValue); break; }
                                        case "encryption":    { mobjDispatch.encryption = Convert.ToBoolean(sValue); break; }
                                        }
                                    }
                                break;
                                }
                            }
                        }
                    break;
                    }
                }
            }
        }

//      Error Handler
        catch (Exception Exp)
            {
            string sMsg = "Error reading configuration file: " + sFilename + "\n" + Exp.Message;
            mobjOutput.AppendText(sMsg + "\n");
            return false;
            }

//      Return Result
        return true;
        }

    public string CreateDispatchHeader(dispatch objDispatch)
        {
        string sHeader = "";

        sHeader += "Version=" + objDispatch.version + "\n";
        sHeader += "Type=" + objDispatch.type + "\n";
        sHeader += "PSID=" + objDispatch.psid + "\n";
        sHeader += "Priority=" + objDispatch.priority.ToString() + "\n";
        sHeader += "TxMode=" + objDispatch.txmode + "\n";
        sHeader += "TxChannel=" + objDispatch.txchannel.ToString() + "\n";
        sHeader += "TxInterval=" + objDispatch.txinterval.ToString() + "\n";
        sHeader += "DeliveryStart=" + objDispatch.deliverystart + "\n";
        sHeader += "DeliveryStop=" + objDispatch.deliverystop + "\n";
        sHeader += "Signature=" + objDispatch.signature.ToString() + "\n";
        sHeader += "Encryption=" + objDispatch.encryption.ToString() + "\n";

        return sHeader;
        }

    public bool CreateUDPClient()
        {

//      Create the UDP Client
        try
        {
        if (mobjUDPClient != null) return true;
        IPEndPoint localEndPoint = new IPEndPoint(IPAddress.Parse(mobjLocal.ip), mobjLocal.port);
        mobjUDPClient = new UdpClient(localEndPoint);
        mobjEndPoint = new IPEndPoint(IPAddress.Parse(mobjTarget.ip), mobjTarget.port);
        }

//      Error Handler
        catch (Exception Exp)
            {
            string sMsg = "Error creating UDP client.\n" + Exp.Message;
            mobjOutput.AppendText(sMsg + "\n");
            return false;
            }

        return true;
        }

    public void TX(byte[] bytes)
        {
        try
        {
        int bytesSent = mobjUDPClient.Send(bytes, bytes.Length, mobjEndPoint);
        mobjOutput.AppendText("Message sent: " + bytesSent.ToString() + "bytes\n");
        }

//      Error Handler
        catch (Exception Exp)
            {
            string sMsg = "SRM Transmission Error.\n" + Exp.Message;
            mobjOutput.AppendText(sMsg + "\n");
            }
        }

#endregion

    }

#endregion

namespace SRM_Sender
    {
    static class Program
        {
        /// <summary>
        /// The main entry point for the application.
        /// </summary>
        [STAThread]
        static void Main()
            {
            System.Windows.Forms.Application.EnableVisualStyles();
            System.Windows.Forms.Application.SetCompatibleTextRenderingDefault(false);
            System.Windows.Forms.Application.Run(new SRM());
            }
        }
    }
