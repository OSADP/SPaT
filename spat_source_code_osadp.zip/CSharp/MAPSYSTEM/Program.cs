﻿using System;
using System.Net;
using System.Net.Sockets;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Xml.Linq;
using System.Threading;
using System.IO;

#region "Structures"

    struct configIP
        {
        public string ip ;
        public int    port;
        }

    struct dispatch
        {
        public string version;
        public string type;
        public string psid;
        public int    priority;
        public string txmode;
        public int    txchannel;
        public int    txinterval;
        public string deliverystart;
        public string deliverystop;
        public bool   signature;
        public bool   encryption;
        }

    struct configMAP
        {
        public string        filename;
        public int           txrate;
        public dispatch      dispatch;
        }

#endregion

#region "class Application"

class Application
    {
    private configIP   mobjLocal;
    private configIP   mobjTarget;
    private configMAP  mobjMapConfiguration;
    private UdpClient  mobjUDPClient;
    private IPEndPoint mobjEndPoint;

#region "Public Members"

    public configMAP MapConfiguration {get {return mobjMapConfiguration;}}

    public configIP LocalConfiguration {get {return mobjLocal;}}

    public configIP TargetConfiguration {get {return mobjTarget;}}

    public bool LoadConfiguration(string sFilename)
        {
        string sTag;
        string sValue;

//      Load the Configuration File
        try
        {
        XDocument doc = XDocument.Load(sFilename);
        XElement root = doc.Root;

//      Parse the Configuration File Elements
        foreach (XElement element in root.Elements())
            {
            sTag = element.Name.ToString();
            sValue = element.Value.ToString();
            switch (sTag.ToLower())
                {
                case "localip":    { mobjLocal.ip = sValue; break; }
                case "targetip":   { mobjTarget.ip = sValue; break; }

//              Parse the Map Configuration Elements
                case "map":
                    {
                    foreach (XElement child in element.Elements())
                        {
                        sTag = child.Name.ToString();
                        sValue = child.Value.ToString();
                        switch (sTag.ToLower())
                            {
                            case "default":    { mobjMapConfiguration.filename = sValue; break; }
                            case "txrate":     { mobjMapConfiguration.txrate = Convert.ToInt32(sValue); break; }
                            case "localport":  { mobjLocal.port = Convert.ToInt32(sValue); break; }
                            case "targetport": { mobjTarget.port = Convert.ToInt32(sValue); break; }
                            case "dispatch":
                                {
                                mobjMapConfiguration.dispatch.type = "MAP";
                                foreach (XAttribute attribute in child.Attributes())
                                    {
                                    sTag = attribute.Name.ToString();
                                    sValue = attribute.Value.ToString();
                                    switch (sTag.ToLower())
                                        {
                                        case "version":       { mobjMapConfiguration.dispatch.version = sValue; break; }
                                        case "psid":          { mobjMapConfiguration.dispatch.psid = sValue; break; }
                                        case "priority":      { mobjMapConfiguration.dispatch.priority = Convert.ToInt32(sValue); break; }
                                        case "txmode":        { mobjMapConfiguration.dispatch.txmode = sValue; break; }
                                        case "txchannel":     { mobjMapConfiguration.dispatch.txchannel = Convert.ToInt32(sValue); break; }
                                        case "txinterval":    { mobjMapConfiguration.dispatch.txinterval = Convert.ToInt32(sValue); break; }
                                        case "deliverystart": { mobjMapConfiguration.dispatch.deliverystart = sValue; break; }
                                        case "deliverystop":  { mobjMapConfiguration.dispatch.deliverystop = sValue; break; }
                                        case "signature":     { mobjMapConfiguration.dispatch.signature = Convert.ToBoolean(sValue); break; }
                                        case "encryption":    { mobjMapConfiguration.dispatch.encryption = Convert.ToBoolean(sValue); break; }
                                        }
                                    }
                                break;
                                }
                            }
                        }
                    break;
                    }
                }
            }
        }

//      Error Handler
        catch (Exception Exp)
            {
            string sMsg = "Error reading configuration file: " + sFilename + "\n" + Exp.Message;
            Console.WriteLine(sMsg);
            return false;
            }

//      Limit the Transmission Rate
        if (mobjMapConfiguration.txrate < 1)  { mobjMapConfiguration.txrate = 1; }
        if (mobjMapConfiguration.txrate > 20) { mobjMapConfiguration.txrate = 20; }

//      Return Result
        return true;
        }

    public int GetActionNumber(string sFilename)
        {
        try
        {
        XDocument doc = XDocument.Load(sFilename);
        XElement element = doc.Element("config").Element("map").Element("currenttscactionnumber");
        if (element == null) { return 0; }
        return Convert.ToInt16(element.Value); 
        }
        catch (Exception Exp)
            {
            Console.WriteLine(Exp.Message);
            return 0;
            }     
        }

    public string GetActionFilename(string sFilename, int iActionNumber)
        {
        try
        {
        XDocument doc = XDocument.Load(sFilename);
        XElement element = doc.Element("config").Element("map").Element("mapconfigurations");
        if (element == null) { return mobjMapConfiguration.filename; }

//      Get the Map Configuration Filename for the Action Number
        foreach (XElement child in element.Elements())
            {
            if (Convert.ToInt16(child.Attribute("number").Value) == iActionNumber)
                { return child.Attribute("map").Value.ToString(); }
            }
        }
        catch 
            {
            string sMsg = "Map configuration not found, action number: " + iActionNumber.ToString();
            Console.WriteLine(sMsg);
            }        

//      Return the Default Configuration
        return mobjMapConfiguration.filename;
        }

    public string CreateDispatchHeader()
        {
        string sHeader = "";
        dispatch objDispatch = mobjMapConfiguration.dispatch;

        sHeader += "Version=" + objDispatch.version + "\n";
        sHeader += "Type=" + objDispatch.type + "\n";
        sHeader += "PSID=" + objDispatch.psid + "\n";
        sHeader += "Priority=" + objDispatch.priority.ToString() + "\n";
        sHeader += "TxMode=" + objDispatch.txmode + "\n";
        sHeader += "TxChannel=" + objDispatch.txchannel.ToString() + "\n";
        sHeader += "TxInterval=" + objDispatch.txinterval.ToString() + "\n";
        sHeader += "DeliveryStart=" + objDispatch.deliverystart + "\n";
        sHeader += "DeliveryStop=" + objDispatch.deliverystop + "\n";
        sHeader += "Signature=" + objDispatch.signature.ToString() + "\n";
        sHeader += "Encryption=" + objDispatch.encryption.ToString() + "\n";

        return sHeader;
        }

    public bool CreateUDPClient()
        {

//      Create the UDP Client
        try
        {
        IPEndPoint localEndPoint = new IPEndPoint(IPAddress.Parse(mobjLocal.ip), mobjLocal.port);
        mobjUDPClient = new UdpClient(localEndPoint);
        mobjEndPoint = new IPEndPoint(IPAddress.Parse(mobjTarget.ip), mobjTarget.port);
        }

//      Error Handler
        catch (Exception Exp)
            {
            string sMsg = "Error creating UDP client.\n" + Exp.Message + "\n" + mobjLocal.ip + " / " + mobjLocal.port.ToString();
            Console.WriteLine(sMsg);
            return false;
        }

        return true;
        }

    public void TX(byte[] bytes)
        {
        try
        {
        int bytesSent = mobjUDPClient.Send(bytes, bytes.Length, mobjEndPoint);
        }

//      Error Handler
        catch (Exception Exp)
            {
            string sMsg = "Transmission Error.\n" + Exp.Message;
            Console.WriteLine(sMsg);
            }
        }

#endregion

    }

#endregion

class Program
    {
    static void Main(string[] args)
        {
        Application objApplication = new Application();
        J2735.MAP map = new J2735.MAP();
        byte version = 0;
        string sConfiguration = "Config.xml";
        string sMessage = "";
        int iPreviousActionNumber = 0;
        int iActionNumber = 0;
        bool bSuccessful = false;

//      Get the Configuration Filename if Specified
        if (args.Length == 1) 
            {
            try {sConfiguration = args[0];} 
            catch {
            Console.WriteLine("usage: mapsystem <configuration filename>"); Console.ReadKey(); 
            return;}
            }

//      Set the Current Working Directory
        System.IO.Directory.SetCurrentDirectory(AppDomain.CurrentDomain.BaseDirectory);

//      Read the Application Configuration File        
        if (!objApplication.LoadConfiguration(sConfiguration)) { Console.ReadKey(); return; }

//      Assemble the Message Header
        string sHeader = objApplication.CreateDispatchHeader();
        sHeader += "Payload=";

//      Assemble the Message Payload
        sMessage = "";
        map.Read(objApplication.MapConfiguration.filename);
        foreach (byte Byte in map.Compile(version)) {sMessage += Byte.ToString("X2");}

//      Create the UDP Client
        do 
        { 
        bSuccessful = objApplication.CreateUDPClient(); 
        if (!bSuccessful) { Thread.Sleep(1000); }
        } while (!bSuccessful);

//      Transmit the Message 
        Console.WriteLine("GID message transmission started at a rate of " + objApplication.MapConfiguration.txrate.ToString()  +" per second.");
        Console.WriteLine("Target IP: < " + objApplication.TargetConfiguration.ip + " / " + objApplication.TargetConfiguration.port.ToString() + " >");
        Console.WriteLine("Press any key to exit...");
        do
        {
        iActionNumber = objApplication.GetActionNumber(sConfiguration);
        if (iActionNumber != iPreviousActionNumber)
            {
            sMessage = "";
            if (version == 255) {version = 0;}
            version++;
            map.Read(objApplication.GetActionFilename(sConfiguration, iActionNumber));
            foreach (byte Byte in map.Compile(version)) {sMessage += Byte.ToString("X2");}
            iPreviousActionNumber = iActionNumber;
            Console.WriteLine("Loaded map configuration number: " + iActionNumber.ToString());
            }

//      Convert the Message to a Byte String
        byte[] bytes = Encoding.ASCII.GetBytes(sHeader + sMessage);
        objApplication.TX(bytes);

//      Delay Interval Between Messages
        System.Threading.Thread.Sleep(1000 / objApplication.MapConfiguration.txrate);
        if (Console.KeyAvailable) break;
        } while (0==0);

        }

    }

