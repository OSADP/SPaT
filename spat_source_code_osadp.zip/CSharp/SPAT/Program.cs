﻿using System;
using System.Net;
using System.Net.Sockets;
using System.Text;
using System.Xml.Linq;
using System.Collections.Generic;

namespace J2735
{

#region "public class SPAT"

public class SPAT
    {
    public message Message = SPAT.message.Create(); 

#region "Enumerations"

    public enum status {manual=1, stopped=2, flash=4, preempt=8, priority=16};
    public enum pedestrian {unavailable=0, none=1, oneormore=2};
    public enum maneuvers {pedestrian = 0, straight = 1, leftturn = 2, rightturn = 4, uturn = 8};

#endregion

#region "Structures"

    private struct maneuver
        {
        public List <UInt16> maneuverlane;
        public spatdata data;

#region "Constructor"

    public maneuver(byte[] bytes, ref int index)
        {
        this = J2735.SPAT.maneuver.Create();
        int size;

//      Parse the Payload
        while ((bytes[index] != 4) && (bytes[index] != 255) && (index < bytes.Length - 2))
            {
            switch (bytes[index++])
                {

//              Decode the Maneuver Code and Lane Number
                case 5:
                size = bytes[index++];
                for (int i=0; i<size; i++) {maneuverlane.Add(ToUInt16(bytes, ref index)); i++;}
                break;

//              Decode the Current State
                case 6:
                size = bytes[index++];
                for (int i=0; i<size; i++) {data.state |= (UInt32)(bytes[index++] << (8*i));}
                break;

//              Decode the Minimum Time Remaining
                case 7:
                index++;
                data.mintime = ToUInt16(bytes, ref index);
                break;

//              Decode the Maximum Time Remaining
                case 8:
                index++;
                data.maxtime = ToUInt16(bytes, ref index);
                break;

//              Decode the Current State
                case 9:
                size = bytes[index++];
                for (int i=0; i<size; i++) {data.yellowstate |= (UInt32)(bytes[index++] << (8*i));}
                break;

//              Decode the Minimum Time Remaining
                case 10:
                index++;
                data.yellowtime = ToUInt16(bytes, ref index);
                break;

//              Decode the Pedestrian Detect
                case 11:
                index++;
                data.pedestrian = (pedestrian)bytes[index++];
                break;

//              Decode the Vehicle or Pedestrian Count
                case 12:
                index++;
                data.count = bytes[index++];
                break;
                }
            }
        }

#endregion

#region "Public Members"

    static public maneuver Create()
        {
        maneuver maneuver = new maneuver();
        maneuver.maneuverlane = new List <UInt16>();
        maneuver.data = SPAT.spatdata.Create();
        return maneuver;
        }
             
    public List <byte> Compile()
        {
        List <byte> payload = new List <byte>();

//      Compile the Movement Flag
        payload.Add(4);

//      Compile the Lane Set            
        payload.Add(5); 
        payload.Add((byte)(maneuverlane.Count * 2));
        foreach (UInt16 Item in maneuverlane)
            {
            foreach (byte Byte in Reverse(BitConverter.GetBytes(Item))) {payload.Add(Byte);}
            }

//      Compile the Movement Data
        foreach (byte Byte in data.Compile()) {payload.Add(Byte);}

        return payload;
        }

#endregion

       }

    public struct spatdata
        {
        public UInt32 state;
        public UInt16 mintime;
        public UInt16 maxtime;
        public UInt32 yellowstate;
        public UInt16 yellowtime;
        public pedestrian pedestrian;
        public byte count;

#region "Public Members"

    static public spatdata Create()
        {
        spatdata spatdata = new spatdata();
        spatdata.state = 0;
        spatdata.mintime = 0;
        spatdata.maxtime = 0;
        spatdata.yellowstate = 0;
        spatdata.yellowtime = 0;
        spatdata.pedestrian = SPAT.pedestrian.unavailable;
        spatdata.count = 0;
        return spatdata;
        }

    public List <byte> Compile()
        {
        List <byte> payload = new List <byte>();
        int n;

//      Encode the Current State
        payload.Add(6); 
        payload.Add(0); 
        n = payload.Count - 1;
        foreach (byte Byte in Reverse(BitConverter.GetBytes(state))) {if (Byte != 0) {payload.Add(Byte); payload[n]++;}}

//      Encode the Minimum Time Remaining
        payload.Add(7); 
        payload.Add(2); 
        foreach (byte Byte in Reverse(BitConverter.GetBytes(Clip(mintime)))) {payload.Add(Byte);}

//      Encode the Maximum Time Remaining
        payload.Add(8); 
        payload.Add(2); 
        foreach (byte Byte in Reverse(BitConverter.GetBytes(Clip(maxtime)))) {payload.Add(Byte);}

//      Encode the Yellow State
        if (yellowstate != 0)
            {
            payload.Add(9); 
            payload.Add(0); 
            n = payload.Count - 1;
            foreach (byte Byte in Reverse(BitConverter.GetBytes(yellowstate))) {if (Byte != 0) {payload.Add(Byte); payload[n]++;}}

//          Encode the Maximum Time Remaining
            payload.Add(10); 
            payload.Add(2); 
            foreach (byte Byte in Reverse(BitConverter.GetBytes(Clip(yellowtime)))) {payload.Add(Byte);}
            }
            
//      Encode the Pedestrian Detect
        if (pedestrian != SPAT.pedestrian.unavailable) 
            {
            payload.Add(11);
            payload.Add(1); 
            payload.Add((byte) pedestrian);
            }

//      Encode the Count
        if (count != 0) 
            {
            payload.Add(12);
            payload.Add(1); 
            payload.Add(count);
            }

        return payload;
        }

    public Boolean Equals(spatdata data)
        {
        if (state       != data.state)       return false;
        if (mintime     != data.mintime)     return false;
        if (maxtime     != data.maxtime)     return false;
        if (yellowstate != data.yellowstate) return false;
        if (yellowtime  != data.yellowtime)  return false;
        if (pedestrian  != data.pedestrian)  return false;
        if (count       != data.count)       return false;
        return true;
        }

    public void Copy(spatdata data)
        {
        state       = data.state;    
        mintime     = data.mintime;  
        maxtime     = data.maxtime; 
        yellowstate = data.yellowstate;
        yellowtime  = data.yellowtime;
        pedestrian  = data.pedestrian;
        count       = data.count;  
        }

#endregion

        };

    public struct movement
        {
        public maneuvers type;
        public List <byte> lane;
        public spatdata data;

#region "Public Members"

    static public movement Create()
        {
        movement movement = new movement();
        movement.type = SPAT.maneuvers.straight;
        movement.lane = new List <byte>();
        movement.data = SPAT.spatdata.Create();
        return movement;
        }

#endregion

        };

    public struct message
        {
        public UInt32 intersectionid;
        public status intersectionstatus;
        public UInt32 timestampseconds;
        public byte timestamptenths;
        public List <movement> movement;

#region "Constructor"

    public message(List <byte> payload)
        {
        this = J2735.SPAT.message.Create();
        List <maneuver> maneuvers = new List <maneuver>();

//      Exit if there is no Payload to Read.
        if (payload == null) return;

//      Read the Payload Bytes
        byte[] bytes = payload.ToArray();
        int index = 4;

//      Parse the Payload
        while ((bytes[index] != 255) && (index < bytes.Length - 2))
            {
            switch (bytes[index++])
                {

//              Decode the Intersection ID
                case 1:
                index++;
                intersectionid = ToUInt32(bytes, ref index);
                break;

//              Decode the Intersection Status
                case 2:
                index++;
                intersectionstatus = (status)bytes[index++];
                break;

//              Decode the Timestamp
                case 3:
                index++;
                timestampseconds = ToUInt32(bytes, ref index);
                timestamptenths = bytes[index++];
                break;

//              Decode the Maneuvers
                case 4:
                maneuvers.Add(new maneuver(bytes, ref index));
                break;
                }
            }

//      Decompile the Maneuvers to Movements
        foreach (movement Item in decompile_maneuvers(maneuvers)) {movement.Add(Item);}
        }

#endregion

#region "Public Members"

    static public message Create()
        {
        message spat = new message();
        spat.intersectionid = 0;
        spat.intersectionstatus = 0;
        spat.timestampseconds = 0;
        spat.timestamptenths = 0;
        spat.movement = new List <movement>();
        return spat;
        }

    public List <byte> Compile()
        {
        List <byte> payload = new List <byte>();

//      Compile the Intersection ID
        payload.Add(1);
        payload.Add(4); 
        foreach (byte Byte in Reverse(BitConverter.GetBytes(intersectionid))) {payload.Add(Byte);}

//      Compile the Intersection Status
        payload.Add(2);
        payload.Add(1); 
        payload.Add((byte) intersectionstatus);

//      Compile the Timestamp
        payload.Add(3);
        payload.Add(5); 
        foreach (byte Byte in Reverse(BitConverter.GetBytes(timestampseconds))) {payload.Add(Byte);}
        payload.Add(timestamptenths);

//      Compile Each Geometry Payload
        foreach(maneuver item in compile_maneuvers(movement)) {foreach (byte Byte in item.Compile()) {payload.Add(Byte);}}

        return payload;
        }

#endregion

        };

#endregion

#region "Private Members"

    private static byte[] Reverse(byte[] Bytes)
       {
        byte temp;
        int highCtr = Bytes.Length - 1;

        if (BitConverter.IsLittleEndian)
            {
            for (int ctr = 0; ctr < Bytes.Length / 2; ctr++)
                {
                temp = Bytes[ctr];
                Bytes[ctr] = Bytes[highCtr];
                Bytes[highCtr] = temp;
                highCtr -= 1;
                }
            }
        return Bytes;
       }

    private static List <maneuver> compile_maneuvers(List <movement> movements)
        {
        List <maneuver> maneuvers = new List <maneuver>();
        List <movement> list = new List <movement>();
        movement movement;
        maneuver maneuver;
        Boolean found;

//      Create a Working Copy of the Movement List
        foreach (movement Item in movements) {list.Add(Item);}

//      Combine Like Movements into Common Maneuver Objects
        while (list.Count > 0) 
            {
            maneuver = SPAT.maneuver.Create();
            movement = list[0];
            foreach (byte Lane in movement.lane) {maneuver.maneuverlane.Add((UInt16)((((byte) movement.type) << 8) + Lane));}
            maneuver.data.Copy(movement.data);
            list.Remove(movement);
            for (int index=0; index<list.Count; index++)
                {
                if (list[index].data.Equals(movement.data))
                    {
                    foreach (byte Lane in list[index].lane)
                        {
                        found = false;
                        for (int item=0; item<maneuver.maneuverlane.Count; item++)
                            {
                            if ((maneuver.maneuverlane[item] & 0x00ff) == Lane) 
                                {
                                maneuver.maneuverlane[item] |= (UInt16)(((byte) list[index].type) << 8); 
                                found = true;
                                break;
                                }
                            }
                        if (!found) {maneuver.maneuverlane.Add((UInt16)((((byte) list[index].type) << 8) + Lane));}
                        }
                    list.RemoveAt(index--);
                    }
                }
            maneuvers.Add(maneuver);
            } 
            
//      Return the Maneuver List
        return maneuvers;

        }

    private static List <movement> decompile_maneuvers(List <maneuver> maneuvers)
        {
        List <movement> movements = new List <movement>();
        movement movement;
        byte codes;
        byte code;

        foreach (maneuver maneuver in maneuvers)
            {
            codes = 0;
            foreach (UInt16 Item in maneuver.maneuverlane) { codes |= (byte)((Item & 0xff00) >> 8); }

//          Decompile Straight Maneuvers
            if ((codes & (byte)SPAT.maneuvers.straight) != 0) 
                {
                movement = movement.Create();
                movement.type = SPAT.maneuvers.straight;
                movement.data.Copy(maneuver.data);
                foreach (UInt16 Item in maneuver.maneuverlane)
                    {
                    code = (byte)((Item & 0xff00) >> 8);
                    if ((code & (byte)SPAT.maneuvers.straight) != 0) {movement.lane.Add((byte)(Item & 0xff));}
                    }
                movements.Add(movement);
                }

//          Decompile Right Turn Maneuvers
            if ((codes & (byte)SPAT.maneuvers.rightturn) != 0) 
                {
                movement = movement.Create();
                movement.type = SPAT.maneuvers.rightturn;
                movement.data.Copy(maneuver.data);
                foreach (UInt16 Item in maneuver.maneuverlane)
                    {
                    code = (byte)((Item & 0xff00) >> 8);
                    if ((code & (byte)SPAT.maneuvers.rightturn) != 0) {movement.lane.Add((byte)(Item & 0xff));}
                    }
                movements.Add(movement);
                }

//          Decompile Left Turn Maneuvers
            if ((codes & (byte)SPAT.maneuvers.leftturn) != 0) 
                {
                movement = movement.Create();
                movement.type = SPAT.maneuvers.leftturn;
                movement.data.Copy(maneuver.data);
                foreach (UInt16 Item in maneuver.maneuverlane)
                    {
                    code = (byte)((Item & 0xff00) >> 8);
                    if ((code & (byte)SPAT.maneuvers.leftturn) != 0) {movement.lane.Add((byte)(Item & 0xff));}
                    }
                movements.Add(movement);
                }

//          Decompile U Turn Maneuvers
            if ((codes & (byte)SPAT.maneuvers.uturn) != 0) 
                {
                movement = movement.Create();
                movement.type = SPAT.maneuvers.uturn;
                movement.data.Copy(maneuver.data);
                foreach (UInt16 Item in maneuver.maneuverlane)
                    {
                    code = (byte)((Item & 0xff00) >> 8);
                    if ((code & (byte)SPAT.maneuvers.uturn) != 0) {movement.lane.Add((byte)(Item & 0xff));}
                    }
                movements.Add(movement);
                }   

//          Decompile Pedestrian Maneuvers
            if (codes == 0) 
                {
                movement = movement.Create();
                movement.type = SPAT.maneuvers.pedestrian;
                movement.data.Copy(maneuver.data);
                foreach (UInt16 Item in maneuver.maneuverlane)
                    {
                    code = (byte)((Item & 0xff00) >> 8);
                    if (code == 0) {movement.lane.Add((byte)(Item & 0xff));}
                    }
                movements.Add(movement);
                }  
            }

        return movements;
        }

    private static UInt16 Clip(UInt16 value)
        {
        if (value == 0xffff) return 1202;
        if (value > 1200) return 1201;
        return value;
        }

    private static UInt32 ToUInt32(byte[] bytes, ref int index)
        {
        UInt32 value = BitConverter.ToUInt32(Reverse(BitConverter.GetBytes(BitConverter.ToUInt32(bytes, index))), 0);
        index += 4;
        return value;
        }

    private static UInt16 ToUInt16(byte[] bytes, ref int index)
        {
        UInt16 value = BitConverter.ToUInt16(Reverse(BitConverter.GetBytes(BitConverter.ToUInt16(bytes, index))), 0);
        index += 2;
        return value;
        }

    private static Int32 ToInt32(byte[] bytes, ref int index)
        {
        Int32 value = BitConverter.ToInt32(Reverse(BitConverter.GetBytes(BitConverter.ToInt32(bytes, index))), 0);
        index += 4;
        return value;
        }

    private static Int16 ToInt16(byte[] bytes, ref int index)
        {
        Int16 value = BitConverter.ToInt16(Reverse(BitConverter.GetBytes(BitConverter.ToInt16(bytes, index))), 0);
        index += 2;
        return value;
        }

#endregion

#region "Public Members"

    public List <byte> Compile(byte version)
        {
        List <byte> payload = new List <byte>();

//      Compile the Message Header
        payload.Add(0x8d);        
        payload.Add(version);
        payload.Add(0);
        payload.Add(0);
        foreach (byte Byte in Message.Compile()) {payload.Add(Byte);}
        payload.Add(0xff);

//      Store the Payload Size
        int i = 2;
        foreach (byte Byte in Reverse(BitConverter.GetBytes((Int16)(payload.Count-4)))) {payload[i++] = Byte;}

//      Calculate the CRC Value
        CRC crc = new CRC();
        foreach (byte Byte in Reverse(BitConverter.GetBytes(crc.crc_ccitt(payload)))) {payload.Add(Byte);}

        return payload;
        }

    public Boolean Decompile(List <byte> payload)
        {

//      Validate the Message Integrity
        CRC crc = new CRC();
        if (crc.crc_ccitt(payload) != 0)
            {
            Console.WriteLine("CRC checksum failed, message not decoded.");
            return false;
            }

//      De-compile the GID payload
        try
        {
        Message = new message(payload);
        }
        
//      Error Handler
        catch (Exception Exp)
            {
            string sMsg = "Error de-compiling payload.\n" + Exp.Message;
            Console.WriteLine(sMsg);
            return false;
            }

        return true;
        }

#endregion

    }

#endregion

#region "public class CRC"

public class CRC
    {
    static List <UInt16> crc_table;

#region "Constructor"

    public CRC()
        {
        UInt16 crc, c;

//      Initialize the CRC Table
        crc_table = new List <UInt16>();
        for (int i=0; i<256; i++) 
            {
            crc = 0;
            c = (UInt16)(i << 8);
            for (int j=0; j<8; j++) 
                {
                if (((crc^c) & 0x8000) != 0) {crc = (UInt16)((crc << 1)^0x1021);}
                else                         {crc = (UInt16)(crc << 1);}
                c = (UInt16)(c << 1);
                }
            crc_table.Add(crc);
            }
        }

#endregion

#region "Private Members"

    private static UInt16 crc_update(UInt16 crc, byte Byte)
        {
        UInt16 tmp = (UInt16)((crc >> 8) ^ Byte);
        crc = (UInt16)((crc << 8) ^ crc_table[tmp]);
        return crc;
        }

#endregion

#region "Public Members"

    public UInt16 crc_ccitt(List <byte> payload)
        {
        UInt16 crc = 0;
        foreach(byte Byte in payload) {crc = crc_update(crc, Byte);}
        return crc;
        }

#endregion

    }

#endregion

}

public class Program
    {    

    static void Main()
        {
        J2735.SPAT spat = new J2735.SPAT();
        J2735.SPAT.movement movement;

        spat.Message.intersectionid = 200;
        spat.Message.intersectionstatus = 0;
        spat.Message.timestampseconds = 1332855560;
        spat.Message.timestamptenths = 15;

        movement = J2735.SPAT.movement.Create();
        movement.type = J2735.SPAT.maneuvers.straight;
        movement.lane.Add((byte) 3);
        movement.lane.Add((byte) 4);
        movement.data.state = 0x01;
        movement.data.mintime = 40;
        movement.data.maxtime = 1170;
        movement.data.yellowstate = 0x02;
        movement.data.yellowtime = 30;
        spat.Message.movement.Add(movement);

        movement = J2735.SPAT.movement.Create();
        movement.type = J2735.SPAT.maneuvers.straight;
        movement.lane.Add((byte) 7);
        movement.lane.Add((byte) 8);
        movement.data.state = 0x04;
        movement.data.mintime = 40;
        movement.data.maxtime = 390;
        movement.data.yellowstate = 0x02;
        movement.data.yellowtime = 30;
        spat.Message.movement.Add(movement);

        movement = J2735.SPAT.movement.Create();
        movement.type = J2735.SPAT.maneuvers.straight;
        movement.lane.Add((byte) 5);
        movement.lane.Add((byte) 6);
        movement.data.state = 0x04;
        movement.data.mintime = 40;
        movement.data.maxtime = 1170;
        movement.data.yellowstate = 0x02;
        movement.data.yellowtime = 30;
        spat.Message.movement.Add(movement);

        movement = J2735.SPAT.movement.Create();
        movement.type = J2735.SPAT.maneuvers.rightturn;
        movement.lane.Add((byte) 6);
        movement.data.state = 0x04;
        movement.data.mintime = 40;
        movement.data.maxtime = 1170;
        movement.data.yellowstate = 0x02;
        movement.data.yellowtime = 30;
        spat.Message.movement.Add(movement);

        movement = J2735.SPAT.movement.Create();
        movement.type = J2735.SPAT.maneuvers.leftturn;
        movement.lane.Add((byte) 10);
        movement.data.state = 0x40;
        movement.data.mintime = 40;
        movement.data.maxtime = 780;
        movement.data.yellowstate = 0x20;
        movement.data.yellowtime = 30;
        spat.Message.movement.Add(movement);

        movement = J2735.SPAT.movement.Create();
        movement.type = J2735.SPAT.maneuvers.straight;
        movement.lane.Add((byte) 1);
        movement.data.state = 0x01;
        movement.data.mintime = 40;
        movement.data.maxtime = 390;
        movement.data.yellowstate = 0x02;
        movement.data.yellowtime = 30;
        spat.Message.movement.Add(movement);

        movement = J2735.SPAT.movement.Create();
        movement.type = J2735.SPAT.maneuvers.leftturn;
        movement.lane.Add((byte) 2);
        movement.data.state = 0x10;
        movement.data.mintime = 0;
        movement.data.maxtime = 1560;
        movement.data.yellowstate = 0x20;
        movement.data.yellowtime = 30;
        spat.Message.movement.Add(movement);

        movement = J2735.SPAT.movement.Create();
        movement.type = J2735.SPAT.maneuvers.pedestrian;
        movement.lane.Add((byte) 103);
        movement.data.state = 1;
        movement.data.mintime = 40;
        movement.data.maxtime = 1170;
        spat.Message.movement.Add(movement);

        movement = J2735.SPAT.movement.Create();
        movement.type = J2735.SPAT.maneuvers.pedestrian;
        movement.lane.Add((byte) 101);
        movement.data.state = 1;
        movement.data.mintime = 40;
        movement.data.maxtime = 390;
        spat.Message.movement.Add(movement);

//      Display Compiled Bytes
        List <byte> bytes = spat.Compile(217);
        foreach(byte Byte in bytes)
            {
            Console.Write(Byte.ToString("X2") + " ");
            }

        //string pl = "8D BC 00 8A 01 04 00 00 00 64 02 01 00 03 05 50 29 01 7C 03 04 05 02 07 01 06 01 01 07 02 00 DB 08 02 01 5E 09 01 02 0A 02 00 1E 04 05 06 07 02 05 04 02 05 06 01 04 07 02 01 03 08 02 03 0C 04 05 02 07 03 06 01 01 07 02 00 00 08 02 01 5E 09 01 02 0A 02 00 1E 04 05 02 02 05 06 01 40 07 02 01 03 08 02 01 86 04 05 02 00 65 06 01 01 07 02 00 00 08 02 00 00 04 05 02 00 66 06 01 13 07 02 00 3B 08 02 00 3B 09 01 02 0A 02 00 10 FF 20 36";
        string pl = "8d 0b 00 72 01 04 00 00 00 64 02 01 00 03 05 50 3e 2b b2 02 04 05 04 07 01 07 03 06 01 01 07 02 00 ba 08 02 01 46 09 01 02 0a 02 00 28 04 05 02 07 02 06 01 04 07 02 00 ec 08 02 02 9a 04 05 04 05 04 02 05 06 01 04 07 02 00 ec 08 02 01 78 04 05 02 00 65 06 01 01 07 02 00 00 08 02 00 00 0b 01 01 04 05 02 00 66 06 01 01 07 02 00 ec 08 02 02 9a 0b 01 01 ff 60 cd";

        bytes = new List<byte>();
        foreach (string sByte in pl.Split(new string[] {" "},StringSplitOptions.RemoveEmptyEntries))
            {
            bytes.Add((byte)int.Parse(sByte, System.Globalization.NumberStyles.HexNumber));
            }

//      Decompile the Bytes
        J2735.SPAT respat = new J2735.SPAT();
        respat.Decompile(bytes);

        Console.ReadKey();
        }

    }  


