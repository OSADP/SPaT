﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;


class Program
    {

#region "private static void ExampleRTCM(StreamByte objStream)"

    private static void ExampleRTCM(StreamByte objStream)
        {
        Console.WriteLine("RCTM Example.\n");

//      Create the RTCM Message Structure
        ASN_r36.RTCM_Corrections_t rtcmCorrections = ASN_r36.RTCM_Corrections_t.Create();

//      Initialize the Structure with some Data
        rtcmCorrections.msgID = ASN_r36.DSRCmsgID_t.DSRCmsgID_rtcmCorrections;
        rtcmCorrections.msgCnt = 1;
        rtcmCorrections.rev = ASN_r36.RTCM_Revision_t.RTCM_Revision_unknown;

//      Add a Simulated RTCM Message Payload    
        ASN_r36.RTCMmsg_t RTCMmsg = ASN_r36.RTCMmsg_t.Create();
        for (byte i=0; i<16; i++) {RTCMmsg.payload.Add((i));}
        rtcmCorrections.rtcmSets.Add(RTCMmsg);
    
//      Add Another Simulated RTCM Message Payload 
        RTCMmsg = ASN_r36.RTCMmsg_t.Create();
        for (byte i=50; i<55; i++) {RTCMmsg.payload.Add((i));}
        rtcmCorrections.rtcmSets.Add(RTCMmsg);

//      Serialize the RTCM Structure    
        List<byte> BUFFER = rtcmCorrections.Serialize();

//      Display the Serialized RTCM Structure
        Console.WriteLine("RTCM serialized data...");
        foreach(byte Byte in BUFFER) {Console.Write(((byte)Byte).ToString("X2"));}
        Console.Write("\n\n");

//      CALL THE ASNJ2735 SERVER TO ENCODE THE MESSAGE TO ASN
        objStream.Write(BUFFER);
        List<byte> ASN = objStream.Read();

//      Display the ASN Encode Message
        Console.WriteLine("RTCM ASN Encoded...");
        foreach(byte Byte in ASN) {Console.Write(((byte)Byte).ToString("X2"));}
        Console.Write("\n\n\n");

//      CALL THE ASNJ2735 SERVER TO DECODE THE ASN BACK TO THE MESSAGE DATA
        objStream.Write(ASN);
        BUFFER = objStream.Read();

//      Restore the Serialized Data to the RTCM Structure
        rtcmCorrections.Deserialize(BUFFER);
    }

#endregion

#region "private static void ExampleSRM(StreamByte objStream)"

    private static void ExampleSRM(StreamByte objStream)
        {
        Console.WriteLine("SRM Example.\n");

//      Create the SRM Message Structure
        ASN_r36.SignalRequestMsg_t signalRequest = ASN_r36.SignalRequestMsg_t.Create();

//      Initialize the Structure with some Data
        signalRequest.msgCnt = 0;
        signalRequest.request.id = 100;
        signalRequest.request.inLane = 6;
        signalRequest.request.type = 4;
        signalRequest.timeOfService.hour = 18;
        signalRequest.timeOfService.minute = 30;
        signalRequest.timeOfService.second = 0;
        signalRequest.endOfService.hour = 18;
        signalRequest.endOfService.minute = 35;
        signalRequest.endOfService.second = 0;
        signalRequest.vehicleVIN.id = 1001;

//      Serialize the SRM Structure    
        List<byte> BUFFER = signalRequest.Serialize();

//      Display the Serialized SRM Structure
        Console.WriteLine("SRM Serialized Data...");
        foreach(byte Byte in BUFFER) {Console.Write(((byte)Byte).ToString("X2"));}
        Console.Write("\n\n");

//      CALL THE ASNJ2735 SERVER TO ENCODE THE MESSAGE TO ASN
        objStream.Write(BUFFER);
        List<byte> ASN = objStream.Read();

//      Display the ASN Encode Message
        Console.WriteLine("SRM ASN Encoded...");
        foreach(byte Byte in ASN) {Console.Write(((byte)Byte).ToString("X2"));}
        Console.Write("\n\n\n");

//      CALL THE ASNJ2735 SERVER TO DECODE THE ASN BACK TO THE MESSAGE DATA
        objStream.Write(ASN);
        BUFFER = objStream.Read();

//      Restore the Serialized Data to the SRM Structure
        signalRequest.Deserialize(BUFFER);

    }

#endregion

#region "private static void ExampleSSM(StreamByte objStream)"

    private static void ExampleSSM(StreamByte objStream)
        {
        Console.WriteLine("SSM Example.\n");

//      Create the SSM Message Structure
        ASN_r36.SignalStatusMessage_t signalStatus = ASN_r36.SignalStatusMessage_t.Create();

//      Initialize the Structure with some Data
        signalStatus.msgCnt = 0;
        signalStatus.id = 100;
        signalStatus.status = 27;

//      Serialize the SSM Structure    
        List<byte> BUFFER = signalStatus.Serialize();

//      Display the Serialized SSM Structure
        Console.WriteLine("SSM Serialized Data...");
        foreach(byte Byte in BUFFER) {Console.Write(((byte)Byte).ToString("X2"));}
        Console.Write("\n\n");

//      CALL THE ASNJ2735 SERVER TO ENCODE THE MESSAGE TO ASN
        objStream.Write(BUFFER);
        List<byte> ASN = objStream.Read();

//      Display the ASN Encode Message
        Console.WriteLine("SSM ASN Encoded...");
        foreach(byte Byte in ASN) {Console.Write(((byte)Byte).ToString("X2"));}
        Console.Write("\n\n\n");

//      CALL THE ASNJ2735 SERVER TO DECODE THE ASN BACK TO THE MESSAGE DATA
        objStream.Write(ASN);
        BUFFER = objStream.Read();

//      Restore the Serialized Data to the SSM Structure
        signalStatus.Deserialize(BUFFER);
    }

#endregion

    static void Main(string[] args)
        {

//      Create the Pipe Connection to the ASNJ2735 Server
        ASN_r36 ASN_r36 = new ASN_r36();
        StreamByte objStream = ASN_r36.CreatePipeStream();
        if (objStream == null) 
            {
            Console.WriteLine("Unable to connect to the ASNJ2735 server; please make sure it is running.");
            Console.WriteLine("Press any key to exit.");
            Console.ReadKey();
            return;
            }

//      ASNJ2735 Server Examples
        ExampleRTCM(objStream);
        ExampleSRM(objStream);
        ExampleSSM(objStream);

        Console.WriteLine("Press any key to exit.");
        Console.ReadKey();

        objStream.Close();
        }
    }
 
