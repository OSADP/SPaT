﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Xml.Linq;

namespace J2735
{

#region "public class MAP"

public class MAP
    {
    public message Message = MAP.message.Create();
    static bool mbElevation;
    static int miMode;

#region "Enumerations"

    public enum lanetypes {vehicle=1, computed=2, pedestrian=3, special=4};

#endregion

#region "Structures"

    public struct referencelane
        {
        public byte lanenumber;
        public Int16 lateraloffset;

#region "Constructors"

    public referencelane(XElement objRoot)
        {
        this = J2735.MAP.referencelane.Create();
 
//      Exit if there is no XML Root to read.
        if (objRoot == null) return;

//      Read the XML Elements
        try
        {
        foreach (XElement element in objRoot.Elements())
            {
            switch (element.Name.ToString().ToLower())
                {
                case "lanenumber":    {lanenumber =  Convert.ToByte(element.Value); break; }
                case "lateraloffset": {lateraloffset =  Convert.ToInt16(element.Value); break; }
                }
            }
        }

//      Error Handler
        catch (Exception Exp)
            {
            string sMsg = "Error reading GID reference lane information.\n" + Exp.Message;
            Console.WriteLine(sMsg);
            }
        }

    public referencelane(byte[] bytes, ref int index)
        {
        this = J2735.MAP.referencelane.Create();
            
//      Decode the Connection Lane and Maneuver
        lanenumber = bytes[index++];
        lateraloffset = ToInt16(bytes, ref index); 

        }

#endregion

#region "Public Members"

    static public referencelane Create()
        {
        referencelane referencelane = new referencelane();
        referencelane.lanenumber = 0;
        referencelane.lateraloffset = 0;
        return referencelane;
        }

    public List <byte> Compile()
        {
        List <byte> payload = new List <byte>();

//      Compile the Reference Lane and Offset
        payload.Add(11);
        payload.Add(3);
        payload.Add(lanenumber);
        foreach (byte Byte in Reverse(BitConverter.GetBytes(lateraloffset))) {payload.Add(Byte);}

        return payload;
        }

#endregion

        }

    public struct connection
        {
        public byte lanenumber;
        public byte maneuver;

#region "Constructors"

    public connection(XElement objRoot)
        {
        this = J2735.MAP.connection.Create();
 
//      Exit if there is no XML Root to read.
        if (objRoot == null) return;

//      Read the XML Elements
        try
        {
        foreach (XElement element in objRoot.Elements())
            {
            switch (element.Name.ToString().ToLower())
                {
                case "lanenumber": {lanenumber =  Convert.ToByte(element.Value); break; }
                case "maneuver":   {maneuver =  Convert.ToByte(element.Value); break; }
                }
            }
        }

//      Error Handler
        catch (Exception Exp)
            {
            string sMsg = "Error reading GID connection information.\n" + Exp.Message;
            Console.WriteLine(sMsg);
            }
        }

    public connection(byte[] bytes, ref int index)
        {
        this = J2735.MAP.connection.Create();
            
//      Decode the Connection Lane and Maneuver
        lanenumber = bytes[index++];
        maneuver = bytes[index++];

        }

#endregion

#region "Public Members"

    static public connection Create()
        {
        connection connection = new connection();
        connection.lanenumber = 0;
        connection.maneuver = 0;
        return connection;
        }

    public List <byte> Compile()
        {
        List <byte> payload = new List <byte>();

//      Compile the Connection Lane and Maneuver
        payload.Add(10);
        payload.Add(2);
        payload.Add(lanenumber);
        payload.Add(maneuver);

        return payload;
        }

#endregion

        }

    public struct node
        {
        public Int16 eastern;
        public Int16 northern;
        public Int16 elevation;
        public Int16 width;

#region "Constructors"

    public node(XElement objRoot)
        {
        this = J2735.MAP.node.Create();

//      Exit if there is no XML Root to read.
        if (objRoot == null) return;

//      Read the XML Elements
        try
        {
        foreach (XElement element in objRoot.Elements())
            {
            switch (element.Name.ToString().ToLower())
                {
                case "eastern":   {eastern =  Convert.ToInt16(element.Value); break; }
                case "nothern":   {northern =  Convert.ToInt16(element.Value); break; }   // Keep for Backward Compatibility
                case "northern":  {northern =  Convert.ToInt16(element.Value); break; }
                case "elevation": {elevation =  Convert.ToInt16(element.Value); break; }
                case "width":     {width =  Convert.ToInt16(element.Value); break; }
                }
            }
        }

//      Error Handler
        catch (Exception Exp)
            {
            string sMsg = "Error reading GID node information.\n" + Exp.Message;
            Console.WriteLine(sMsg);
            }
        }

    public node(byte[] bytes, ref int index, byte attributes)
        {
        this = J2735.MAP.node.Create();

//      Initialize Variables
        bool bWidth = ((attributes & 0x01) != 0x00);
        bool bPacked = ((attributes & 0x02) != 0x00);

//      Decode an Unpacked Node List
        if (!bPacked)
            {
            eastern = ToInt16(bytes, ref index); 
            northern = ToInt16(bytes, ref index);
            if (mbElevation) { elevation = ToInt16(bytes, ref index); }
            if (bWidth)      { width = ToInt16(bytes, ref index); }
            }

//      Decode a Packed Node List
        else
            {
            if (miMode == 1)
                {
                eastern = (Int16)(((SByte)bytes[index++] * 0x10) | ((bytes[index] & 0xf0) >> 4));
                northern = (Int16)(((SByte)((bytes[index++] & 0x0f) << 4) * 0x10) | bytes[index++]);
                if (mbElevation)
                    {
                    elevation = (Int16)(((SByte)bytes[index++] * 0x10) | ((bytes[index] & 0xf0) >> 4)); miMode = 2;
                    if (bWidth) { width = (Int16)(((SByte)((bytes[index++] & 0x0f) << 4) * 0x10) | bytes[index++]); miMode = 1; }
                    }
                else
                    {
                    if (bWidth) { width = (Int16)(((SByte)bytes[index++] * 0x10) | ((bytes[index] & 0xf0) >> 4)); miMode = 2; }
                    }
                }
            else
                {
                eastern = (Int16)(((SByte)((bytes[index++] & 0x0f) << 4) * 0x10) | bytes[index++]); 
                northern = (Int16)(((SByte)bytes[index++] * 0x10) | ((bytes[index] & 0xf0) >> 4));
                if (mbElevation)
                    {
                    elevation = (Int16)(((SByte)((bytes[index++] & 0x0f) << 4) * 0x10) | bytes[index++]);  miMode = 1;
                    if (bWidth) { width = (Int16)(((SByte)bytes[index++] * 0x10) | ((bytes[index] & 0xf0) >> 4)); miMode = 2; }
                    }
                else
                    {
                    if (bWidth) { width = (Int16)(((SByte)((bytes[index++] & 0x0f) << 4) * 0x10) | bytes[index++]); miMode = 1; }
                    }
                }
            }

        }

#endregion

#region "Public Members"

    static public node Create()
        {
        node node = new node();
        node.eastern = 0;
        node.northern = 0;            
        node.elevation = 0;
        node.width = 0;
        return node;
        }

    static public node Create(Int16 eastern, Int16 northern)
        {
        node node = J2735.MAP.node.Create();
        node.eastern = eastern;
        node.northern = northern;            
        return node;
        }

    static public node Create(Int16 eastern, Int16 northern, Int16 elevation)
        {
        node node = J2735.MAP.node.Create();
        node.eastern = eastern;
        node.northern = northern;            
        node.elevation = elevation;
        return node;
        }

    static public node Create(Int16 eastern, Int16 northern, Int16 elevation, Int16 width)
        {
        node node = J2735.MAP.node.Create();
        node.eastern = eastern;
        node.northern = northern;            
        node.elevation = elevation;
        node.width = width;
        return node;
        }

#endregion

        }

    public struct lane
        {
        public byte number;
        public lanetypes type;
        public UInt16 attributes;
        public Int16 width;
        public referencelane referencelane;
        public List <node> node;
        public List <connection> connection;

#region "Constructors"

    public lane(XElement objRoot)
        {
        this = J2735.MAP.lane.Create();

//      Exit if there is no XML Root to read.
        if (objRoot == null) return;

//      Read the XML Elements
        try
        {
        number = Convert.ToByte(objRoot.Attribute("Number").Value);
        foreach (XElement element in objRoot.Elements())
            {
            switch (element.Name.ToString().ToLower())
                {
                case "type":          
                    {
                    switch (element.Value.ToLower())
                        {
                        case "vehicle":    {type = MAP.lanetypes.vehicle; break;} 
                        case "computed":   {type = MAP.lanetypes.computed; break;} 
                        case "pedestrian": {type = MAP.lanetypes.pedestrian; break;} 
                        case "special":    {type = MAP.lanetypes.special; break;} 
                        }
                    break;
                    }
                case "attributes":    {attributes =  Convert.ToUInt16(element.Value); break; }
                case "width":         {width =  Convert.ToInt16(element.Value); break; }
                case "referencelane": {referencelane = new referencelane(element); break;}
                case "nodes":     
                    {
                    foreach (XElement child in element.Elements()) {node.Add(new node(child));}
                    break;
                    }
                case "connections":     
                    {
                    foreach (XElement child in element.Elements()) {connection.Add(new connection(child));}
                    break;
                    }                    
                }
            }
        }

//      Error Handler
        catch (Exception Exp)
            {
            string sMsg = "Error reading GID lane information.\n" + Exp.Message;
            Console.WriteLine(sMsg);
            }
        }

    public lane(byte[] bytes, ref int index)
        {
        this = J2735.MAP.lane.Create();

//      Decode the Lane Number
        number = bytes[index++];

//      Decode the Lane Type
        type = (MAP.lanetypes)bytes[index++];

//      Parse the Payload
        while ((bytes[index] != 5) && (bytes[index] != 255) && (index < bytes.Length - 2))
            {
            switch (bytes[index++])
                {

//              Decode the Lane Attributes
                case 6:
                index++;
                attributes = ToUInt16(bytes, ref index);
                break;

//              Decode the Width
                case 8:
                index++;
                width = ToInt16(bytes, ref index); 
                break;

//              Decode the Node List
                case 9:
                int end = index + bytes[index++];
                byte node_attributes = bytes[index++];
                miMode = 1;
                do {node.Add(new node(bytes, ref index, node_attributes));}
                while (index < end);
                break;

//              Decode the Lane Connections
                case 10:
                index++;
                connection.Add(new connection(bytes, ref index));
                break;

//              Decode the Reference Lane
                case 11:
                index++;
                referencelane = new referencelane(bytes, ref index);
                break;
                }
            }

        }

#endregion

#region "Public Members"

    static public lane Create()
        {
        lane lane = new lane();
        lane.number = 0;
        lane.type = 0;            
        lane.attributes = 0;
        lane.width = 0;
        lane.referencelane = J2735.MAP.referencelane.Create();
        lane.node = new List <node>();
        lane.connection = new List <connection>();
        return lane;
        }
    
    public List <byte> Compile()
        {
        List <byte> payload = new List <byte>();

//      Compile the Lane Number and Type
        payload.Add(5);
        payload.Add(2);
        payload.Add(number);
        payload.Add((byte)type);

//      Compile the Lane Attributes
        payload.Add(6);
        payload.Add(2);
        foreach (byte Byte in Reverse(BitConverter.GetBytes(attributes))) {payload.Add(Byte);}

//      Compile the Lane Width
        if (width > 0)
            {
            payload.Add(8);
            payload.Add(2);
            foreach (byte Byte in Reverse(BitConverter.GetBytes(width))) {payload.Add(Byte);}
            }

//      Compile the Reference Lane
        if (referencelane.lanenumber > 0)
            {
            foreach (byte Byte in referencelane.Compile()) {payload.Add(Byte);}
            }

//      Compile the Node List
        else
            {
            foreach(byte Byte in Compile_Nodelist(node)) {payload.Add(Byte);}
            }

//      Compile the Lane Connections 
        foreach(connection item in connection) {foreach (byte Byte in item.Compile()) {payload.Add(Byte);}}

        return payload;
        }

#endregion

        }

    public struct group
        {
        public Int16 width;
        public List <lane> lane;

#region "Constructors"

    public group(XElement objRoot)
        {
        this = J2735.MAP.group.Create();
 
//      Exit if there is no XML Root to read.
        if (objRoot == null) return;

//      Read the XML Elements
        try
        {
        foreach (XElement element in objRoot.Elements())
            {
            switch (element.Name.ToString().ToLower())
                {
                case "width": {width =  Convert.ToInt16(element.Value); break; }
                case "lane":  {lane.Add(new lane(element)); break;}
                }
            }
        }

//      Error Handler
        catch (Exception Exp)
            {
            string sMsg = "Error reading GID group information.\n" + Exp.Message;
            Console.WriteLine(sMsg);
            }
        }

    public group(byte[] bytes, ref int index)
        {
        this = J2735.MAP.group.Create();

//      Parse the Payload
        while ((bytes[index] != 4) && (bytes[index] != 255) && (index < bytes.Length - 2))
            {
            switch (bytes[index++])
                {

//              Decode the Lane
                case 5:
                index++;
                lane.Add(new lane(bytes, ref index));
                break;

//              Decode the Width
                case 8:
                index++;
                width = ToInt16(bytes, ref index); 
                break;
                }
            }

        }

#endregion

#region "Public Members"

    static public group Create()
        {
        group group = new group();
        group.width = 0;
        group.lane = new List <lane>();
        return group;
        }

    public List <byte> Compile()
        {
        List <byte> payload = new List <byte>();

//          Compile the Group Width
        if (width > 0)
            {
            payload.Add(8);
            payload.Add(2);
            foreach (byte Byte in Reverse(BitConverter.GetBytes(width))) {payload.Add(Byte);}
            }
            
//          Compile Each Lane in the Group
        foreach(lane item in lane) {foreach (byte Byte in item.Compile()) {payload.Add(Byte);}}
  
        return payload;
        }

#endregion

        }

    public struct barrier
        {
        public UInt16 attributes;
        public Int16 width;
        public List <node> node;

#region "Constructors"

    public barrier(XElement objRoot)
        {
        this = J2735.MAP.barrier.Create();
 
//      Exit if there is no XML Root to read.
        if (objRoot == null) return;

//      Read the XML Elements
        try
        {
        foreach (XElement element in objRoot.Elements())
            {
            switch (element.Name.ToString().ToLower())
                {
                case "attributes": {attributes =  Convert.ToUInt16(element.Value); break; }
                case "width":      {width =  Convert.ToInt16(element.Value); break; }
                case "nodes":     
                    {
                    foreach (XElement child in element.Elements()) {node.Add(new node(child));}
                    break;
                    }                    
                }
            }
        }

//      Error Handler
        catch (Exception Exp)
            {
            string sMsg = "Error reading GID barrier information.\n" + Exp.Message;
            Console.WriteLine(sMsg);
            }
        }

    public barrier(byte[] bytes, ref int index)
        {
        this = J2735.MAP.barrier.Create();

//      Parse the Payload
        while ((bytes[index] != 4) && (bytes[index] != 255) && (index < bytes.Length - 2))
            {
            switch (bytes[index++])
                {

//              Decode the Barrier Attributes
                case 7:
                index++;
                attributes = ToUInt16(bytes, ref index); 
                break;

//              Decode the Width
                case 8:
                index++;
                width = ToInt16(bytes, ref index);
                break;

//              Decode the Node List
                case 9:
                int end = index + bytes[index++];
                byte node_attributes = bytes[index++];
                miMode = 1;
                do {node.Add(new node(bytes, ref index, node_attributes));}
                while (index < end);
                break;

                }
            }
        }

#endregion

#region "Public Members"

    static public barrier Create()
        {
        barrier barrier = new barrier();
        barrier.attributes = 0;
        barrier.width = 0;
        barrier.node = new List <node>();
        return barrier;
        }

    public List <byte> Compile()
        {
        List <byte> payload = new List <byte>();

//      Compile the Barrier 
        payload.Add(4);
        payload.Add(1);
        payload.Add(3);

//      Compile the Barrier Attributes
        payload.Add(7);
        payload.Add(2);
        foreach (byte Byte in Reverse(BitConverter.GetBytes(attributes))) {payload.Add(Byte);}

//      Compile the Barrier Width
        if (width > 0)
            {
            payload.Add(8);
            payload.Add(2);
            foreach (byte Byte in Reverse(BitConverter.GetBytes(width))) {payload.Add(Byte);}
            }

//      Compile the Node List
        foreach(byte Byte in Compile_Nodelist(node)) {payload.Add(Byte);}

        return payload;
        }

#endregion

        }

    public struct referencepoint
        {
        public Int32 latitude;
        public Int32 longitude;
        public Int16 elevation;

#region "Constructors"

    public referencepoint(XElement objRoot)
        {
        this = J2735.MAP.referencepoint.Create();

//      Exit if there is no XML Root to read.
        if (objRoot == null) return;

//      Read the XML Elements
        try
        {
        foreach (XElement element in objRoot.Elements())
            {
            switch (element.Name.ToString().ToLower())
                {
                case "latitude":  {latitude =  Convert.ToInt32(Convert.ToDouble(element.Value)*1e7); break; }
                case "longitude": {longitude =  Convert.ToInt32(Convert.ToDouble(element.Value)*1e7); break; }
                case "elevation": {elevation =  Convert.ToInt16(element.Value); break; }
                }
            }
        }

//      Error Handler
        catch (Exception Exp)
            {
            string sMsg = "Error reading GID reference point information.\n" + Exp.Message;
            Console.WriteLine(sMsg);
            }
        }

    public referencepoint(byte[] bytes, ref int index)
        {
        this = J2735.MAP.referencepoint.Create();
            
//      Decode the Reference Point       
        latitude = ToInt32(bytes, ref index);
        longitude = ToInt32(bytes, ref index);
        if (mbElevation) {elevation = ToInt16(bytes, ref index);}            
        }

#endregion

#region "Public Members"

    static public referencepoint Create()
        {
        referencepoint referencepoint = new referencepoint();
        referencepoint.latitude = 0;
        referencepoint.longitude = 0;
        referencepoint.elevation = 0;
        return referencepoint;
        }

    public List <byte> Compile()
        {
        List <byte> payload = new List <byte>();

//      Compile the Reference Point
        payload.Add(3);
        if (mbElevation) {payload.Add(10);} else {payload.Add(8);}
        foreach (byte Byte in Reverse(BitConverter.GetBytes(latitude))) {payload.Add(Byte);}
        foreach (byte Byte in Reverse(BitConverter.GetBytes(longitude))) {payload.Add(Byte);}
        if (mbElevation)
            {
            foreach (byte Byte in Reverse(BitConverter.GetBytes(elevation))) {payload.Add(Byte);}
            }

        return payload;
        }

#endregion

        }

    public struct geometry
        {
        public referencepoint referencepoint;
        public group approach;
        public group egress;
        public List <barrier> barrier;

#region "Constructors"

    public geometry(XElement objRoot)
        {
        this = J2735.MAP.geometry.Create();

//      Exit if there is no XML Root to read.
        if (objRoot == null) return;

//      Read the XML Elements
        try
        {
        foreach (XElement element in objRoot.Elements())
            {
            switch (element.Name.ToString().ToLower())
                {
                case "referencepoint": {referencepoint = new referencepoint(element); break; }
                case "approach":       {approach = new group(element); break; }
                case "egress":         {egress = new group(element); break; }
                case "barrier":        {barrier.Add(new barrier(element)); break; }
                }
            }
        }

//      Error Handler
        catch (Exception Exp)
            {
            string sMsg = "Error reading GID geometry information.\n" + Exp.Message;
            Console.WriteLine(sMsg);
            }
        }

    public geometry(byte[] bytes, ref int index)
        {
        this = J2735.MAP.geometry.Create();

//      Decode the Reference Point
        referencepoint = new referencepoint(bytes, ref index);

//      Parse the Payload
        while ((bytes[index] != 3) && (bytes[index] != 255) && (index < bytes.Length - 2))
            {
            switch (bytes[index++])
                {

//              Decode the Approach, Egress, or Barrier
                case 4:
                index++;
                switch (bytes[index++])
                    {
                    case 1: approach = new group(bytes, ref index); break;
                    case 2: egress = new group(bytes, ref index); break;
                    case 3: barrier.Add(new barrier(bytes, ref index)); break;
                    }
                break;
                }
            }
        }

#endregion

#region "Public Members"

    static public geometry Create()
        {
        geometry geometry = new geometry();
        geometry.referencepoint = J2735.MAP.referencepoint.Create();
        geometry.approach = J2735.MAP.group.Create();
        geometry.egress = J2735.MAP.group.Create();
        geometry.barrier = new List <barrier>();
        return geometry;
        }

    public List <byte> Compile()
        {
        List <byte> payload = new List <byte>();

//      Compile the Reference Point
        foreach (byte Byte in referencepoint.Compile()) {payload.Add(Byte);}

//      Compile the Approach Group
        if (approach.lane.Count > 0)
            {
            payload.Add(4);
            payload.Add(1);
            payload.Add(1);
            foreach (byte Byte in approach.Compile()) {payload.Add(Byte);}
            }

//      Compile the Egress Group
        if (egress.lane.Count > 0)
            {
            payload.Add(4);
            payload.Add(1);
            payload.Add(2);            
            foreach (byte Byte in egress.Compile()) {payload.Add(Byte);}
            }

//      Compile the Barriers
        foreach(barrier item in barrier) {foreach (byte Byte in item.Compile()) {payload.Add(Byte);}}

        return payload;
        }

#endregion

        }

    public struct message
        {
        public UInt32 intersectionid;
        public byte attributes;
        public List<geometry> geometry;

#region "Constructors"

    public message(XElement objRoot)
        {
        this = J2735.MAP.message.Create();

//      Exit if there is no XML Root to read.
        if (objRoot == null) return;

//      Read the XML Elements
        try
        {
        foreach (XElement element in objRoot.Elements())
            {
            switch (element.Name.ToString().ToLower())
                {
                case "intersectionid": {intersectionid = Convert.ToUInt32(element.Value); break; }
                case "geometry":       {geometry.Add(new geometry(element)); break; }
                case "elevation":      { if (element.Value.ToLower() == "true") {attributes |= 0x01;} break;}
                case "resolution":     { if (element.Value.ToLower() == "decimeter") {attributes |= 0x02; } break; }
                }
            }
        }

//      Error Handler
        catch (Exception Exp)
            {
            string sMsg = "Error reading GID map information.\n" + Exp.Message;
            Console.WriteLine(sMsg);
            }
        }

    public message(List <byte> payload)
        {
        this = J2735.MAP.message.Create();

//      Exit if there is no Payload to Read.
        if (payload == null) return;

//      Read the Payload Bytes
        byte[] bytes = payload.ToArray();
        int index = 4;

//      Parse the Payload
        while ((bytes[index] != 255) && (index < bytes.Length - 2))
            {
            switch (bytes[index++])
                {

//              Decode the Message Attributes
                case 1:
                index++;
                attributes = bytes[index++];

//              Set the Elevation Flag
                mbElevation = ((attributes & 0x01) != 0x00);
                break;
                    
//              Decode the Intersection ID
                case 2:
                index++;
                intersectionid = ToUInt32(bytes, ref index);
                break;
                        
//              Decode the Geometry
                case 3:
                index++;
                geometry.Add(new geometry(bytes, ref index));
                break;
                }
            }
        }

#endregion

#region "Public Members"

    static public message Create()
        {
        message map = new message();
        map.intersectionid = 0;
        map.attributes = 0x0c;
        map.geometry = new List<geometry>();
        return map;
        }

    public List <byte> Compile()
        {
        List <byte> payload = new List <byte>();

//      Compile the Message Attributes
        payload.Add(1);
        payload.Add(1);
        payload.Add(attributes);

//      Set the Elevation Flag
        mbElevation = ((attributes & 0x01) != 0x00);

//      Compile the Intersection ID
        payload.Add(2);
        payload.Add(4); 
        foreach (byte Byte in Reverse(BitConverter.GetBytes(intersectionid))) {payload.Add(Byte);}

//      Compile Each Geometry Payload
        foreach(geometry item in geometry) {foreach (byte Byte in item.Compile()) {payload.Add(Byte);}}

        return payload;
        }

#endregion

        }

#endregion

#region "Private Members"

    private static byte[] Reverse(byte[] Bytes)
       {
        byte temp;
        int highCtr = Bytes.Length - 1;

        if (BitConverter.IsLittleEndian)
            {
            for (int ctr = 0; ctr < Bytes.Length / 2; ctr++)
                {
                temp = Bytes[ctr];
                Bytes[ctr] = Bytes[highCtr];
                Bytes[highCtr] = temp;
                highCtr -= 1;
                }
            }
        return Bytes;
       }

    private static List <byte> Compile_Nodelist(List <node> nodes)
        {
        List <byte> payload = new List <byte>();

//      Determine if the Node List has Width Data
        byte attributes = 0;
        foreach(node item in nodes) {if (item.width > 0) {attributes |= 0x01; break;}}
        bool bWidth = ((attributes & 0x01) != 0x00);

//      Create the Node List
        List <Int16> nodelist= new List <Int16>();
        foreach(node item in nodes)
            {
            nodelist.Add(item.eastern);
            nodelist.Add(item.northern);
            if (mbElevation) {nodelist.Add(item.elevation);}
            if (bWidth) {nodelist.Add(item.width);}
            }

//      Determine if the Node List can be Packed
        attributes |= 0x02;
        foreach(Int16 item in nodelist) {if ((item > 2047) | (item < -2048)) {attributes &= 0xfd; break;}}
        bool bPacked = ((attributes & 0x02) != 0x00);

//      Compile the Node List
        payload.Add(9);
        payload.Add(0);
        payload.Add(attributes);

//      Encode an Unpacked Node List
        if (!bPacked) {foreach(Int16 item in nodelist) {foreach (byte Byte in Reverse(BitConverter.GetBytes(item))) {payload.Add(Byte);}}}

//      Encode a Packed Node List
        else
            {
            for (int i=0; i<nodelist.Count; i++)
                {
                payload.Add((byte)((nodelist[i] & 0x0ff0) >> 4));
                if (i < nodelist.Count-1)
                    {
                    payload.Add((byte)(((nodelist[i] & 0x000f) << 4) | ((nodelist[i+1] & 0x0f00) >> 8)));
                    payload.Add((byte)(nodelist[i+1] & 0x00ff));
                    i++;
                    }
                else {payload.Add((byte)((nodelist[i] & 0x000f) << 4));}
                }
            }

//      Store the Payload Size
        payload[1] = (byte)(payload.Count-2);

        return payload;
        }

    private static UInt32 ToUInt32(byte[] bytes, ref int index)
        {
        UInt32 value = BitConverter.ToUInt32(Reverse(BitConverter.GetBytes(BitConverter.ToUInt32(bytes, index))), 0);
        index += 4;
        return value;
        }

    private static UInt16 ToUInt16(byte[] bytes, ref int index)
        {
        UInt16 value = BitConverter.ToUInt16(Reverse(BitConverter.GetBytes(BitConverter.ToUInt16(bytes, index))), 0);
        index += 2;
        return value;
        }

    private static Int32 ToInt32(byte[] bytes, ref int index)
        {
        Int32 value = BitConverter.ToInt32(Reverse(BitConverter.GetBytes(BitConverter.ToInt32(bytes, index))), 0);
        index += 4;
        return value;
        }

    private static Int16 ToInt16(byte[] bytes, ref int index)
        {
        Int16 value = BitConverter.ToInt16(Reverse(BitConverter.GetBytes(BitConverter.ToInt16(bytes, index))), 0);
        index += 2;
        return value;
        }
         
#endregion

#region "Public Members"

    public bool Read(string sFilename)
        {

//      Load the GID File
        try
        {
        XDocument doc = XDocument.Load(sFilename);
        Message = new message(doc.Root);
        }
        
//      Error Handler
        catch (Exception Exp)
            {
            string sMsg = "Error reading GID file: " + sFilename + "\n" + Exp.Message;
            Console.WriteLine(sMsg);
            return false;
            }

//      Return Result
        return true;
        }

    public List <byte> Compile(byte version)
        {
        List <byte> payload = new List <byte>();

//      Compile the Message Header
        payload.Add(0x87);        
        payload.Add(version);
        payload.Add(0);
        payload.Add(0);
        foreach (byte Byte in Message.Compile()) {payload.Add(Byte);}
        payload.Add(0xff);

//      Store the Payload Size
        int i = 2;
        foreach (byte Byte in Reverse(BitConverter.GetBytes((Int16)(payload.Count-4)))) {payload[i++] = Byte;}

//      Calculate the CRC Value
        CRC crc = new CRC();
        foreach (byte Byte in Reverse(BitConverter.GetBytes(crc.crc_ccitt(payload)))) {payload.Add(Byte);}

        return payload;
        }

    public Boolean Decompile(List <byte> payload)
        {

//      Validate the Message Integrity
        CRC crc = new CRC();
        if (crc.crc_ccitt(payload) != 0)
            {
            Console.WriteLine("CRC checksum failed, message not decoded.");
            return false;
            }

//      De-compile the GID payload
        try
        {
        Message = new message(payload);
        }
        
//      Error Handler
        catch (Exception Exp)
            {
            string sMsg = "Error de-compiling payload.\n" + Exp.Message;
            Console.WriteLine(sMsg);
            return false;
            }

        return true;
        }

#endregion

    }

#endregion

#region "public class CRC"

public class CRC
    {
    static List <UInt16> crc_table;

#region "Constructor"

    public CRC()
        {
        UInt16 crc, c;

//      Initialize the CRC Table
        crc_table = new List <UInt16>();
        for (int i=0; i<256; i++) 
            {
            crc = 0;
            c = (UInt16)(i << 8);
            for (int j=0; j<8; j++) 
                {
                if (((crc^c) & 0x8000) != 0) {crc = (UInt16)((crc << 1)^0x1021);}
                else                         {crc = (UInt16)(crc << 1);}
                c = (UInt16)(c << 1);
                }
            crc_table.Add(crc);
            }
        }

#endregion

#region "Private Members"

    private static UInt16 crc_update(UInt16 crc, byte Byte)
        {
        UInt16 tmp = (UInt16)((crc >> 8) ^ Byte);
        crc = (UInt16)((crc << 8) ^ crc_table[tmp]);
        return crc;
        }

#endregion

#region "Public Members"

    public UInt16 crc_ccitt(List <byte> payload)
        {
        UInt16 crc = 0;
        foreach(byte Byte in payload) {crc = crc_update(crc, Byte);}
        return crc;
        }

#endregion

    }

#endregion

}

class Program
    {
    static void Main()
        {
        J2735.MAP map = new J2735.MAP();
        //J2735.MAP.geometry geometry;
        //J2735.MAP.lane lane;

        //map.Message.intersectionid = 200;
        //map.Message.attributes = 0x0e;

        //geometry = J2735.MAP.geometry.Create();
        //geometry.referencepoint.latitude = (Int32)(42.286469 * 1e7);
        //geometry.referencepoint.longitude = (Int32)(82.732492 * 1e7);
        //map.Message.geometry.Add(geometry);

        //lane = J2735.MAP.lane.Create();
        //lane.number = 1;
        //lane.type = J2735.MAP.lanetypes.vehicle;
        //lane.attributes = 0xe2;
        //lane.width = 380;
        //lane.node.Add(J2735.MAP.node.Create(-101, 217));
        //lane.node.Add(J2735.MAP.node.Create(-121, 278));
        //lane.node.Add(J2735.MAP.node.Create(-138, 340));
        //lane.node.Add(J2735.MAP.node.Create(-159, 412));
        //geometry.approach.lane.Add(lane);        

        //lane = J2735.MAP.lane.Create();
        //lane.number = 2;
        //lane.type = J2735.MAP.lanetypes.vehicle;
        //lane.attributes = 0xe2;
        //lane.width = 380;
        //lane.node.Add(J2735.MAP.node.Create(199, 95));
        //lane.node.Add(J2735.MAP.node.Create(301, 125));
        //lane.node.Add(J2735.MAP.node.Create(417, 146));
        //lane.node.Add(J2735.MAP.node.Create(541, 165));
        //geometry.approach.lane.Add(lane);        

        //lane = J2735.MAP.lane.Create();
        //lane.number = 3;
        //lane.type = J2735.MAP.lanetypes.computed;
        //lane.attributes = 0xa8;
        //lane.width = 380;
        //lane.referencelane.lanenumber = 2;
        //lane.referencelane.lateraloffset = 400;
        //geometry.approach.lane.Add(lane);        

//      Read a Map from an External XML File
        map.Read("GID_Test.xml");

//      Display Compiled Bytes
        List <byte> bytes = map.Compile(217);
        foreach(byte Byte in bytes)
            {
            Console.Write(Byte.ToString("X2"));
            }

//      Decompile the Bytes
        J2735.MAP remap = new J2735.MAP();
        remap.Decompile(bytes);

        Console.ReadKey();
        }
    }
