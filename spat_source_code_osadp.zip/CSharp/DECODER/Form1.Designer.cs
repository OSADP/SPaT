﻿namespace SPAT_Decoder
    {
    partial class Form1
        {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
            {
        if (disposing && (components != null))
            {
        components.Dispose();
            }
        base.Dispose(disposing);
            }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
            {
            this.txtData = new System.Windows.Forms.TextBox();
            this.botConvert = new System.Windows.Forms.Button();
            this.botPayload = new System.Windows.Forms.Button();
            this.botDecode = new System.Windows.Forms.Button();
            this.txtResult = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.optDispatch = new System.Windows.Forms.RadioButton();
            this.optPayload = new System.Windows.Forms.RadioButton();
            this.botSpace = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // txtData
            // 
            this.txtData.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.txtData.Location = new System.Drawing.Point(12, 25);
            this.txtData.Multiline = true;
            this.txtData.Name = "txtData";
            this.txtData.Size = new System.Drawing.Size(701, 206);
            this.txtData.TabIndex = 0;
            // 
            // botConvert
            // 
            this.botConvert.Location = new System.Drawing.Point(12, 265);
            this.botConvert.Name = "botConvert";
            this.botConvert.Size = new System.Drawing.Size(148, 38);
            this.botConvert.TabIndex = 1;
            this.botConvert.Text = "Covert to ASCII";
            this.botConvert.UseVisualStyleBackColor = true;
            this.botConvert.Click += new System.EventHandler(this.botConvert_Click);
            // 
            // botPayload
            // 
            this.botPayload.Location = new System.Drawing.Point(166, 265);
            this.botPayload.Name = "botPayload";
            this.botPayload.Size = new System.Drawing.Size(148, 38);
            this.botPayload.TabIndex = 2;
            this.botPayload.Text = "Get Payload";
            this.botPayload.UseVisualStyleBackColor = true;
            this.botPayload.Click += new System.EventHandler(this.botPayload_Click);
            // 
            // botDecode
            // 
            this.botDecode.Location = new System.Drawing.Point(320, 265);
            this.botDecode.Name = "botDecode";
            this.botDecode.Size = new System.Drawing.Size(148, 38);
            this.botDecode.TabIndex = 3;
            this.botDecode.Text = "Decode Message";
            this.botDecode.UseVisualStyleBackColor = true;
            this.botDecode.Click += new System.EventHandler(this.botDecode_Click);
            // 
            // txtResult
            // 
            this.txtResult.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.txtResult.Location = new System.Drawing.Point(12, 317);
            this.txtResult.Multiline = true;
            this.txtResult.Name = "txtResult";
            this.txtResult.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.txtResult.Size = new System.Drawing.Size(701, 356);
            this.txtResult.TabIndex = 4;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(12, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(64, 13);
            this.label1.TabIndex = 5;
            this.label1.Text = "Byte Stream";
            // 
            // optDispatch
            // 
            this.optDispatch.AutoSize = true;
            this.optDispatch.Checked = true;
            this.optDispatch.Location = new System.Drawing.Point(16, 239);
            this.optDispatch.Name = "optDispatch";
            this.optDispatch.Size = new System.Drawing.Size(152, 17);
            this.optDispatch.TabIndex = 6;
            this.optDispatch.TabStop = true;
            this.optDispatch.Text = "Complete Dispatch Header";
            this.optDispatch.UseVisualStyleBackColor = true;
            this.optDispatch.CheckedChanged += new System.EventHandler(this.optDispatch_CheckedChanged);
            // 
            // optPayload
            // 
            this.optPayload.AutoSize = true;
            this.optPayload.Location = new System.Drawing.Point(184, 239);
            this.optPayload.Name = "optPayload";
            this.optPayload.Size = new System.Drawing.Size(87, 17);
            this.optPayload.TabIndex = 7;
            this.optPayload.Text = "Payload Only";
            this.optPayload.UseVisualStyleBackColor = true;
            // 
            // botSpace
            // 
            this.botSpace.Location = new System.Drawing.Point(474, 265);
            this.botSpace.Name = "botSpace";
            this.botSpace.Size = new System.Drawing.Size(148, 38);
            this.botSpace.TabIndex = 8;
            this.botSpace.Text = "Insert Spaces";
            this.botSpace.UseVisualStyleBackColor = true;
            this.botSpace.Click += new System.EventHandler(this.botSpace_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(725, 685);
            this.Controls.Add(this.botSpace);
            this.Controls.Add(this.optPayload);
            this.Controls.Add(this.optDispatch);
            this.Controls.Add(this.botConvert);
            this.Controls.Add(this.botPayload);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.botDecode);
            this.Controls.Add(this.txtResult);
            this.Controls.Add(this.txtData);
            this.Name = "Form1";
            this.Text = "Message Decoder";
            this.ResumeLayout(false);
            this.PerformLayout();

            }

        #endregion

        private System.Windows.Forms.TextBox txtData;
        private System.Windows.Forms.Button botConvert;
        private System.Windows.Forms.Button botPayload;
        private System.Windows.Forms.Button botDecode;
        private System.Windows.Forms.TextBox txtResult;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.RadioButton optDispatch;
        private System.Windows.Forms.RadioButton optPayload;
        private System.Windows.Forms.Button botSpace;
        }
    }

