﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

class Program
{
    static void Main(string[] args)
    {
        string sfilename = "Config.xml";

//      Get the Configuration Filename if Specified
        if (args.Length == 1) 
            {
            try {sfilename = args[0];}
            catch {Console.WriteLine("usage: rtcmsender <configuration filename>"); return;}
            }

//      Start the RTCM Server
        Server objServer = new Server(sfilename);
    }
}

