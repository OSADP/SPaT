﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Xml.Linq;
using System.Net.Sockets;
using System.Threading;
using System.Net;
using System.Collections;

#region "Structures"

struct configIP
    {
    public string ip;
    public int port;
    }

#endregion

#region "class Server"

class Server
{
    private TcpListener tcpListener;
    private Thread listenThread;
    private configIP mobjRTCM;

    private string msRTCM1001;
    private string msRTCM1002;
    private string msRTCM1005;

#region "Constructor"

    public Server(string sConfigurationFilename)
        {
        if (!LoadConfiguration(sConfigurationFilename)) return;
        CreateRTCMMessagesStrings();
        this.tcpListener = new TcpListener(IPAddress.Parse(mobjRTCM.ip),mobjRTCM.port);
        this.listenThread = new Thread(new ThreadStart(ListenForClients));
        Console.Write("Starting RTCM thread...");
        this.listenThread.Start();
        Console.Write("Successful!\n");
        Console.Write("Listening for RTCM clients...\n");
        }
     
#endregion

#region "Private Members"
    
    private bool LoadConfiguration(string sFilename)
        {
        string sTag;
        string sValue;

//      Load the Configuration File
        try
        {
        XDocument doc = XDocument.Load(sFilename);
        XElement root = doc.Root;

//      Parse the Configuration File Elements
        foreach (XElement element in root.Elements())
            {
            sTag = element.Name.ToString();
            sValue = element.Value.ToString();
            switch (sTag.ToLower())
                {
                case "rtcm":
                    {
                    foreach (XElement child in element.Elements())
                        {
                        sTag = child.Name.ToString();
                        sValue = child.Value.ToString();
                        switch (sTag.ToLower())    
                            {
                            case "rtcmip":    { mobjRTCM.ip = sValue; break; }
                            case "rtcmport":  { mobjRTCM.port = Convert.ToInt32(sValue); break; }
                            }
                        }            
                    break;
                    }
                }
            }
        }

//      Error Handler
        catch (Exception Exp)
            {
            string sMsg = "Error reading configuration file: " + sFilename + "\n" + Exp.Message;
            Console.WriteLine(sMsg);
            return false;
            }

//      Return Result
        return true;
        }

    private void CreateRTCMMessagesStrings()
        {
        //msRTCM1001
        //Header
        msRTCM1001 = "001111101001";                        // Message Number
        msRTCM1001 += "000000001111";                       // Reference Station
        msRTCM1001 += "000000001111000000001111111111";     // TOW    
        msRTCM1001 += "1";                                  // Synchronous GNSS Flag
        msRTCM1001 += "01010";                              // Number of Sat    
        msRTCM1001 += "1";                                  // Smoothing Indicator
        msRTCM1001 += "101";                                // Smoothing Interval  

        //Message
        msRTCM1001 += "101010";                             // GPS Sat ID
        msRTCM1001 += "1";                                  // GPS L1 Code Indicator
        msRTCM1001 += "001111000000001111111111";           // GPS L1 Code Pseudorange    
        msRTCM1001 += "11000000001111111111";               // GPS L1 Phase Range
        msRTCM1001 += "1101010";                            // L1 Lock Time Indicator 

        //Console.WriteLine(msRTCM1001.Length);

        //msRTCM1002
        //Header
        msRTCM1002 = "001111101010";                        // Message Number
        msRTCM1002 += "000000001111";                       // Reference Station
        msRTCM1002 += "000000001111000000001111111111";     // TOW    
        msRTCM1002 += "1";                                  // Synchronous GNSS Flag
        msRTCM1002 += "01010";                              // Number of Sat    
        msRTCM1002 += "1";                                  // Smoothing Indicator
        msRTCM1002 += "101";                                // Smoothing Interval  

        msRTCM1002 += "101010";                             // GPS Sat ID
        msRTCM1002 += "1";                                  // GPS L1 Code Indicator
        msRTCM1002 += "001111000000001111111111";           // GPS L1 Code Pseudorange    
        msRTCM1002 += "11000000001111111111";               // GPS L1 Phase Range
        msRTCM1002 += "1101010";                            // L1 Lock Time Indicator 
        msRTCM1002 += "11101010";                           // L1 Pseudorange Ambiguity 
        msRTCM1002 += "11101010";                           // L1 CNR 

        //Console.WriteLine(msRTCM1002.Length);

        //msRTCM1005
        msRTCM1005 = "001111101101";                            // Message Number
        msRTCM1005 += "000000001111";                           // Reference Station
        msRTCM1005 += "010100";                                 // ITRF Year    
        msRTCM1005 += "1";                                      // GPS Indicator
        msRTCM1005 += "1";                                      // GLONASS Indicator
        msRTCM1005 += "1";                                      // Galileo Indicator
        msRTCM1005 += "1";                                      // Ref Station Indicator
        msRTCM1005 += "10010011001111001100110101011100110101"; // ANt Ref Point X
        msRTCM1005 += "1";                                      // Oscillator Indicator
        msRTCM1005 += "1";                                      // Reserved
        msRTCM1005 += "10010011001111001100110101011100110101"; // ANt Ref Point Y
        msRTCM1005 += "01";                                     // Cycle Indicator
        msRTCM1005 += "10010011001111001100110101011100110101"; // ANt Ref Point Z

        }

    private byte[] CreateMessageBytes(string sMessage)
        {

        int i;
        BitArray bits = new BitArray(sMessage.Length);
        int size = (int)Math.Ceiling((double)sMessage.Length / (double)8); 
        byte[] result=new byte[size];

        for (i = 0; i < sMessage.Length; i++)
        {
            if (sMessage[i] == '1')
                bits[i] = true;
            else
                bits[i] = false;
        }
        bits.CopyTo(result, 0);
        return result;
        }

    private void ListenForClients()
        {
        this.tcpListener.Start();

        while (true)
            {
            //blocks until a client has connected to the server
            TcpClient client = this.tcpListener.AcceptTcpClient();

            //create a thread to handle communication 
            //with connected client
            Thread clientThread = new Thread(new ParameterizedThreadStart(SendRTCM));
            clientThread.Start(client);
            }
        }

    private void SendRTCM(object client)
        {
        TcpClient tcpClient = (TcpClient)client;
        NetworkStream clientStream = tcpClient.GetStream();
        byte[] buffer;

        Console.Write("Client joined at : ");
        Console.WriteLine("TCPIP: < " + mobjRTCM.ip + " / " + mobjRTCM.port.ToString() + " >");
        Console.WriteLine("Sending RTCM messages...");
        
        while (true)
            {            
            try
            {
            buffer = CreateMessageBytes(msRTCM1001);
            clientStream.Write(buffer, 0, buffer.Length);
            clientStream.Flush();
            System.Threading.Thread.Sleep(1000);

            buffer = CreateMessageBytes(msRTCM1002);
            clientStream.Write(buffer, 0, buffer.Length);
            clientStream.Flush();
            System.Threading.Thread.Sleep(1000);

            buffer = CreateMessageBytes(msRTCM1005);
            clientStream.Write(buffer, 0, buffer.Length);
            clientStream.Flush();
            System.Threading.Thread.Sleep(1000);
                    
            // Check if Client is Connected
            if (tcpClient.Client.Poll(0, SelectMode.SelectRead))
                {
                byte[] checkConn = new byte[1];
                if (tcpClient.Client.Receive(checkConn, SocketFlags.Peek) == 0) { break; }
                }
            }
            catch 
                {
                Console.WriteLine("Client connection lost.");
                break; 
                }
            }

        tcpClient.Close();
        }

#endregion 
 
}

#endregion