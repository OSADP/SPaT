﻿using System;
using System.Net;
using System.Net.Sockets;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Xml.Linq;
using System.IO;
using System.IO.Pipes;
using System.Security.Principal;
using System.Collections;

#region "Structures"

    struct configIP
        {
        public string ip ;
        public int    port;
        }

    struct dispatch
        {
        public string version;
        public string type;
        public string psid;
        public int    priority;
        public string txmode;
        public int    txchannel;
        public int    txinterval;
        public string deliverystart;
        public string deliverystop;
        public bool   signature;
        public bool   encryption;
        }

#endregion

#region "class Application"

class Application
    {
    private configIP   mobjLocal;
    private configIP   mobjTarget;
    private configIP   mobjRTCM30;
    private configIP   mobjRTCM23;
    private dispatch   mobjDispatch;
    private TcpClient  mobjTCPClient30;
    private TcpClient  mobjTCPClient23;
    private UdpClient  mobjUDPClient;
    private IPEndPoint mobjEndPoint;

#region "Public Members"

    public configIP LocalConfiguration {get {return mobjLocal;}}

    public configIP TargetConfiguration {get {return mobjTarget;}}

    public dispatch Dispatch {get {return mobjDispatch;}}

    public int GetMessageID(byte[] message)
        {
        int id = 0;
        BitArray bits = new BitArray(message);
        for (int i = 11; i >= 0; i--) { if (bits[i]) {id += (int)Math.Pow(2, 11 - i);} }
        return id;
        }

    public string GetMessage(byte[] message)
        {
        string result = "";
        BitArray bits = new BitArray(message);
        for (int i = 0; i < message.Length * 8; i++) { if (bits[i]) { result += "1"; } else { result += "0";} }
        return result;
        }

    public bool LoadConfiguration(string sFilename)
        {
        string sTag;
        string sValue;

//      Load the Configuration File
        try
        {
        XDocument doc = XDocument.Load(sFilename);
        XElement root = doc.Root;

//      Parse the Configuration File Elements
        foreach (XElement element in root.Elements())
            {
            sTag = element.Name.ToString();
            sValue = element.Value.ToString();
            switch (sTag.ToLower())
                {
                case "localip":    { mobjLocal.ip = sValue; break; } 
                case "targetip":   { mobjTarget.ip = sValue; break; } 

//              Parse the RTCM Configuration Elements
                case "rtcm": 
                    {
                    foreach (XElement child in element.Elements())
                        {
                        sTag = child.Name.ToString();
                        sValue = child.Value.ToString();
                        switch (sTag.ToLower())
                            {
                            case "localport":  { mobjLocal.port = Convert.ToInt32(sValue); break; } 
                            case "targetport": { mobjTarget.port = Convert.ToInt32(sValue); break; } 
                            case "format":
                                {
                                if (child.Attribute("version").Value == "2.3")
                                    {
                                    mobjRTCM23.ip = child.Attribute("ip").Value.ToString();
                                    mobjRTCM23.port = Convert.ToInt16(child.Attribute("port").Value.ToString());
                                    }
                                if (child.Attribute("version").Value == "3.0")
                                    {
                                    mobjRTCM30.ip = child.Attribute("ip").Value.ToString();
                                    mobjRTCM30.port = Convert.ToInt16(child.Attribute("port").Value.ToString());
                                    }
                                }
                                break;
                            case "dispatch":
                                {
                                mobjDispatch.type = "RTCM";
                                foreach (XAttribute attribute in child.Attributes())
                                    {
                                    sTag = attribute.Name.ToString();
                                    sValue = attribute.Value.ToString();
                                    switch (sTag.ToLower())
                                        {
                                        case "version":       { mobjDispatch.version = sValue; break; } 
                                        case "psid":          { mobjDispatch.psid = sValue; break; } 
                                        case "priority":      { mobjDispatch.priority = Convert.ToInt32(sValue); break; } 
                                        case "txmode":        { mobjDispatch.txmode = sValue; break; } 
                                        case "txchannel":     { mobjDispatch.txchannel = Convert.ToInt32(sValue); break; } 
                                        case "txinterval":    { mobjDispatch.txinterval = Convert.ToInt32(sValue); break; } 
                                        case "deliverystart": { mobjDispatch.deliverystart = sValue; break; } 
                                        case "deliverystop":  { mobjDispatch.deliverystop = sValue; break; } 
                                        case "signature":     { mobjDispatch.signature = Convert.ToBoolean(sValue); break; }
                                        case "encryption":    { mobjDispatch.encryption = Convert.ToBoolean(sValue); break; }
                                        }
                                    }
                                break;
                                }
                            }
                        }
                    break;
                    }
                }
            }
        }

//      Error Handler
        catch (Exception Exp)
            {
            string sMsg = "Error reading configuration file: " + sFilename + "\n" + Exp.Message;
            Console.WriteLine(sMsg);
            return false;
            }

//      Return Result
        return true;
        }

    public string CreateDispatchHeader(dispatch objDispatch)
        {
        string sHeader = "";

        sHeader += "Version=" + objDispatch.version + "\n";
        sHeader += "Type=" + objDispatch.type + "\n";
        sHeader += "PSID=" + objDispatch.psid + "\n";
        sHeader += "Priority=" + objDispatch.priority.ToString() + "\n";
        sHeader += "TxMode=" + objDispatch.txmode + "\n";
        sHeader += "TxChannel=" + objDispatch.txchannel.ToString() + "\n";
        sHeader += "TxInterval=" + objDispatch.txinterval.ToString() + "\n";
        sHeader += "DeliveryStart=" + objDispatch.deliverystart + "\n";
        sHeader += "DeliveryStop=" + objDispatch.deliverystop + "\n";
        sHeader += "Signature=" + objDispatch.signature.ToString() + "\n";
        sHeader += "Encryption=" + objDispatch.encryption.ToString() + "\n";

        return sHeader;
        }

    public bool CreateUDPClient()
        {

//      Create the UDP Client
        try
        {
        IPEndPoint localEndPoint = new IPEndPoint(IPAddress.Parse(mobjLocal.ip), mobjLocal.port);
        mobjUDPClient = new UdpClient(localEndPoint);
        mobjEndPoint = new IPEndPoint(IPAddress.Parse(mobjTarget.ip), mobjTarget.port);
        }

//      Error Handler
        catch (Exception Exp)
            {
            string sMsg = "Error creating UDP client.\n" + Exp.Message;
            Console.WriteLine(sMsg);
            return false;
            }

        return true;
        }

    public bool CreateTCPClients()
    {
        IPEndPoint localEndPoint;

//      Create the TCP Client for RTCM 2.3
        try
        {
        if (mobjRTCM23.port != 0)
            {
            mobjTCPClient23 = new TcpClient();
            localEndPoint = new IPEndPoint(IPAddress.Parse(mobjRTCM23.ip), mobjRTCM23.port);
            mobjTCPClient23.Connect(localEndPoint);
            Console.Write("RTCM 2.3 Source Acquired at : ");
            Console.WriteLine("TCPIP: < " + mobjRTCM23.ip + " / " + mobjRTCM23.port.ToString() + " >");            
            }

//      Create the TCP Client for RTCM 3.0
        if (mobjRTCM30.port != 0)
            {
            mobjTCPClient30 = new TcpClient();
            localEndPoint = new IPEndPoint(IPAddress.Parse(mobjRTCM30.ip), mobjRTCM30.port);
            mobjTCPClient30.Connect(localEndPoint);
            Console.Write("RTCM 3.0 Source Acquired at : ");
            Console.WriteLine("TCPIP: < " + mobjRTCM30.ip + " / " + mobjRTCM30.port.ToString() + " >");            
            }
        }

//      Error Handler
        catch (Exception Exp)
            {
            string sMsg = "Error creating TCP client.\n" + Exp.Message;
            Console.WriteLine(sMsg);
            return false;
            }

        return true;
    }

    public void TX(byte[] bytes)
        {
        try
        {
        int bytesSent = mobjUDPClient.Send(bytes, bytes.Length, mobjEndPoint);
        }

//      Error Handler
        catch (Exception Exp)
            {
            string sMsg = "RTCM Transmission Error.\n" + Exp.Message;
            Console.WriteLine(sMsg);
            }
        }

    public byte[] RX23()
        {
        byte[] bytes = new byte[4096];

        try
        {
        if (mobjRTCM23.port != 0)
            {
            int bytesReceived = mobjTCPClient23.GetStream().Read(bytes, 0, bytes.Length);
            bytes = bytes.Take(bytesReceived).ToArray();         
            }
        else { bytes = bytes.Take(0).ToArray(); }
        }

//      Error Handler
        catch (Exception Exp)
            {
            string sMsg = "RTCM 2.3 Reception Error.\n" + Exp.Message;
            Console.WriteLine(sMsg);
            }

        return bytes;

        }

    public byte[] RX30()
    {
        byte[] bytes = new byte[4096];

        try
        {
        if (mobjRTCM30.port != 0)
            {
            int bytesReceived = mobjTCPClient30.GetStream().Read(bytes, 0, bytes.Length);
            bytes = bytes.Take(bytesReceived).ToArray();
            }
        else { bytes = bytes.Take(0).ToArray(); }
        }

//      Error Handler
        catch (Exception Exp)
        {
            string sMsg = "RTCM 3.0 Reception Error.\n" + Exp.Message;
            Console.WriteLine(sMsg);
        }

        return bytes;

    }

#endregion

    }

#endregion

class Program
    {
    static void Main(string[] args)
        {
        Application objApplication = new Application();
        string sfilename = "Config.xml";
        byte[] bytes;

//      Get the Configuration Filename if Specified
        if (args.Length == 1) 
            {
            try {sfilename = args[0];}
            catch {Console.WriteLine("usage: rtcmmsg <configuration filename>"); return;} 
            }

//      Read the Application Configuration File        
        if (!objApplication.LoadConfiguration(sfilename)) return;

//      Create the TCP Clients for the RTCM Source
        if (!objApplication.CreateTCPClients()) return;

//      Create the UDP Client for the DSRC Radio
        if (!objApplication.CreateUDPClient()) return;

//      NOTE: The ASNJ2735 Server must be Running before this will work.
//      Connect the the J2735 ASN Server
        ASN_r36 ASN_r36 = new ASN_r36();
        StreamByte objStream = ASN_r36.CreatePipeStream();

//      Start Transmitting the RTCM Messages
        Console.WriteLine("RTCM message transmission started...");
        Console.WriteLine("TargetIP: < " + objApplication.TargetConfiguration.ip + " / " + objApplication.TargetConfiguration.port.ToString() + " >");
        Console.WriteLine("Press any key to exit...");

//      Assemble the Message Header
        string sHeader = objApplication.CreateDispatchHeader(objApplication.Dispatch);

//      Create the RTCM Corrections Structure
        ASN_r36.RTCM_Corrections_t rtcmCorrections = ASN_r36.RTCM_Corrections_t.Create();
        Hashtable objMessageSets = new Hashtable();

//      Get the Time
        DateTime dtMessageSentAt = DateTime.Now;
        do
        {
   
//      Receive the raw RTCM 2.3 Sentence.
        bytes = objApplication.RX23();
        if (bytes.Length > 0)
            {
            if (objMessageSets.ContainsKey(23)) { objMessageSets.Remove(23); }
            objMessageSets.Add(23, bytes);   
            }

//      Receive the raw RTCM 3.0 Sentence.
        bytes = objApplication.RX30();
        if (bytes.Length > 0)
            {
            if (objMessageSets.ContainsKey(30)) { objMessageSets.Remove(30); }
            objMessageSets.Add(30, bytes);
            }
        
//      Check if it is time to send new data
        TimeSpan interval = DateTime.Now - dtMessageSentAt;
        if (interval.TotalSeconds > 3)
            {

//          Clear out any Old Messages
            rtcmCorrections.rtcmSets.Clear();

//          Fill the RTCM Structure Contents.
            foreach (DictionaryEntry objEntry in objMessageSets)
                {
                bytes = (byte[])objEntry.Value;
                ASN_r36.RTCMmsg_t RTCMmsg = ASN_r36.RTCMmsg_t.Create();
                RTCMmsg.rev = (ASN_r36.RTCM_Revision_t)objEntry.Key;
                for (int i = 0; i < bytes.Length; i++) { RTCMmsg.payload.Add(bytes[i]); }
                rtcmCorrections.rtcmSets.Add(RTCMmsg);
                }

//          Convert the RTCM Corrections Structure to the ASN Byte Stream
            objStream.Write(rtcmCorrections.Serialize());
            List<byte> asn = objStream.Read();

//          Put the RTCM ASN Encode Bytes into the Message Payload
            string sMessage = sHeader + "payload=";
            foreach (byte Byte in asn) { sMessage += Byte.ToString("X2"); }

//          Send the Message to the DSRC Radio for Transmission
            objApplication.TX(Encoding.ASCII.GetBytes(sMessage));

//          Record last message send time
            dtMessageSentAt = DateTime.Now;
            }
        } while (0==0);

        }
    }

