﻿using System;
using System.IO;
using System.IO.Pipes;
using System.Collections.Generic;
using System.Security.Principal;
using System.Linq;
using System.Text;

class ASN_r36
    {
    public enum DSRCmsgID_t
        {
 	    DSRCmsgID_reserved	                  = 0,
	    DSRCmsgID_alaCarteMessage	          = 1,
	    DSRCmsgID_basicSafetyMessage	      = 2,
	    DSRCmsgID_basicSafetyMessageVerbose	  = 3,
	    DSRCmsgID_commonSafetyRequest	      = 4,
	    DSRCmsgID_emergencyVehicleAlert	      = 5,
	    DSRCmsgID_intersectionCollisionAlert  = 6,
	    DSRCmsgID_mapData	                  = 7,
	    DSRCmsgID_nmeaCorrections	          = 8,
	    DSRCmsgID_probeDataManagement	      = 9,
	    DSRCmsgID_probeVehicleData	          = 10,
	    DSRCmsgID_roadSideAlert	              = 11,
	    DSRCmsgID_rtcmCorrections	          = 12,
	    DSRCmsgID_signalPhaseAndTimingMessage = 13,
	    DSRCmsgID_signalRequestMessage	      = 14,
	    DSRCmsgID_signalStatusMessage   	  = 15,
	    DSRCmsgID_travelerInformation	      = 16
        }

    public enum RTCM_Revision_t
        {
        RTCM_Revision_unknown   	= 0,
	    RTCM_Revision_reserved  	= 1,
	    RTCM_Revision_rtcmCMR   	= 2,
	    RTCM_Revision_rtcmCMR_Plus	= 3,
	    RTCM_Revision_rtcmSAPOS  	= 4,
	    RTCM_Revision_rtcmSAPOS_Adv	= 5,
	    RTCM_Revision_rtcmRTCA	    = 6,
	    RTCM_Revision_rtcmRAW	    = 7,
	    RTCM_Revision_rtcmRINEX	    = 8,
	    RTCM_Revision_rtcmSP3	    = 9,
	    RTCM_Revision_rtcmBINEX   	= 10,
	    RTCM_Revision_rtcmRev2_x	= 19,
	    RTCM_Revision_rtcmRev2_0	= 20,
	    RTCM_Revision_rtcmRev2_1	= 21,
	    RTCM_Revision_rtcmRev2_3	= 23,
	    RTCM_Revision_rtcmRev3_0	= 30,
	    RTCM_Revision_rtcmRev3_1	= 31
        }

    public struct AntennaOffsetSet_t
        {
        public Int16 antOffsetX;
        public byte antOffsetY;
        public byte antOffsetZ;

        public List<Byte> Serialize()
            {
            List <Byte> bytes = new List<byte>();
            foreach (byte b in BitConverter.GetBytes((Int16)antOffsetX)) {bytes.Add(b);}
            bytes.Add(antOffsetY);
            bytes.Add(antOffsetZ);
            return bytes;
            }

        public int Deserialize(byte[] array, int index)
            {
            antOffsetX = BitConverter.ToInt16(array, index);   index += 2;
            antOffsetY = array[index++];
            antOffsetZ = array[index++];
            return index;
            }
        }

    public struct RTCMHeader_t
        {
        public byte status;
        public AntennaOffsetSet_t offsetSet;

        public List<Byte> Serialize()
            {
            List <Byte> bytes = new List<byte>();
            bytes.Add(status);
            foreach (byte b in offsetSet.Serialize()) {bytes.Add(b);}
            return bytes;
            }

        public int Deserialize(byte[] array, int index)
            {
            status = array[index++];
            index = offsetSet.Deserialize(array, index);
            return index;
            }
        }

    public struct RTCMmsg_t
        {
        public RTCM_Revision_t rev;
        public List<byte> payload;

        static public RTCMmsg_t Create()
            {
            RTCMmsg_t RTCMmsg = new RTCMmsg_t();
            RTCMmsg.rev = ASN_r36.RTCM_Revision_t.RTCM_Revision_unknown;
            RTCMmsg.payload = new List <byte>();
            return RTCMmsg;
            }
 
        public List<Byte> Serialize()
            {
            List <Byte> bytes = new List<byte>();
            bytes.Add((Byte)rev);
            foreach (byte b in BitConverter.GetBytes((Int16)payload.Count)) { bytes.Add(b); }
            foreach (byte b in payload) {bytes.Add(b);}
            return bytes;
            }

        public int Deserialize(byte[] array, int index)
            {
            rev = (RTCM_Revision_t)array[index++];
            int count = BitConverter.ToInt16(array, index); index += 2;
            for (int i = 0; i<count; i++) {payload.Add(array[index++]);}
            return index;
            }
        }

    public struct RTCM_Corrections_t
        {
        public DSRCmsgID_t msgID;
        public Int32 msgCnt;
        public RTCM_Revision_t rev;
        public RTCMHeader_t rtcmHeader;
        public List <RTCMmsg_t> rtcmSets;

        static public RTCM_Corrections_t Create()
            {
            RTCM_Corrections_t RTCM_Corrections = new RTCM_Corrections_t();
            RTCM_Corrections.msgID = ASN_r36.DSRCmsgID_t.DSRCmsgID_rtcmCorrections;
            RTCM_Corrections.msgCnt = 0;
            RTCM_Corrections.rev = ASN_r36.RTCM_Revision_t.RTCM_Revision_unknown;
            RTCM_Corrections.rtcmSets = new List <RTCMmsg_t>();
            return RTCM_Corrections;
            }

        public List<Byte> Serialize()
            {
            List <Byte> bytes = new List<byte>();
            bytes.Add((Byte)msgID);
            foreach (byte b in BitConverter.GetBytes((Int32)msgCnt)) {bytes.Add(b);}
            bytes.Add((Byte)rev);
            foreach (byte b in rtcmHeader.Serialize()) {bytes.Add(b);}
            bytes.Add((byte)rtcmSets.Count);
            foreach (RTCMmsg_t rtmcMsg in rtcmSets) {foreach (byte b in rtmcMsg.Serialize()) {bytes.Add(b);}}
            return bytes;
            }

        public bool Deserialize(List<Byte> bytes)
            {
            byte[] array = bytes.ToArray();
            if ((DSRCmsgID_t)array[0] != ASN_r36.DSRCmsgID_t.DSRCmsgID_rtcmCorrections)
                {
                Console.Write("Deserialize failed, data is not a RTCM byte stream.\n"); 
                return false;
                }
            int index = 1;
            msgCnt = BitConverter.ToInt32(array, index); index += 4;
            rev = (RTCM_Revision_t)array[index++];
            index = rtcmHeader.Deserialize(array, index);

            rtcmSets = new List <RTCMmsg_t>();
            int count = array[index++];
            for (int i=0; i<count; i++)
                {
                RTCMmsg_t RTCMmsg = ASN_r36.RTCMmsg_t.Create();
                index = RTCMmsg.Deserialize(array, index);
                rtcmSets.Add(RTCMmsg);
                }

            return true;
            }

        } 

    public struct DTime_t 
        {
	    public Int32 hour;
	    public Int32 minute;
	    public Int32 second;

        public List<Byte> Serialize()
            {
            List <Byte> bytes = new List<byte>();
            foreach (byte b in BitConverter.GetBytes((Int32)hour)) {bytes.Add(b);}
            foreach (byte b in BitConverter.GetBytes((Int32)minute)) {bytes.Add(b);}
            foreach (byte b in BitConverter.GetBytes((Int32)second)) {bytes.Add(b);}
            return bytes;
            }

            public int Deserialize(byte[] array, int index)
            {
            hour = BitConverter.ToInt32(array, index);   index += 4;
            minute = BitConverter.ToInt32(array, index); index += 4;
            second = BitConverter.ToInt32(array, index); index += 4;
            return index;
            }
        }

    public struct VehicleIdent_t
        {
        public UInt32 id;

        public List<Byte> Serialize()
            {
            List <Byte> bytes = new List<byte>();
            foreach (byte b in BitConverter.GetBytes((UInt32)id)) {bytes.Add(b);}
            return bytes;
            }
 
        public int Deserialize(byte[] array, int index)
            {
            id = BitConverter.ToUInt32(array, index); index += 4;
            return index;
            }
    }

    public struct SignalRequest_t
        {
        public UInt32 id;
        public Byte inLane;
        public Byte type;

        public List<Byte> Serialize()
            {
            List <Byte> bytes = new List<byte>();
            foreach (byte b in BitConverter.GetBytes((UInt32)id)) {bytes.Add(b);}
            bytes.Add(inLane);
            bytes.Add(type);
            return bytes;
            }

        public int Deserialize(byte[] array, int index)
            {
            id = BitConverter.ToUInt32(array, index); index += 4;
            inLane = array[index++];
            type = array[index++];
            return index;
            }
        }

    public struct SignalRequestMsg_t
        {
        public DSRCmsgID_t msgID;
        public Int32 msgCnt;
        public SignalRequest_t request;
        public DTime_t timeOfService;
        public DTime_t endOfService;
        public VehicleIdent_t vehicleVIN;

        static public SignalRequestMsg_t Create()
            {
            SignalRequestMsg_t SignalRequestMsg = new SignalRequestMsg_t();
            SignalRequestMsg.msgID = ASN_r36.DSRCmsgID_t.DSRCmsgID_signalRequestMessage;
            SignalRequestMsg.msgCnt = 0;
            return SignalRequestMsg;
            }

        public List<Byte> Serialize()
            {
            List <Byte> bytes = new List<byte>();
            bytes.Add((Byte)msgID);
            foreach (byte b in BitConverter.GetBytes((Int32)msgCnt)) {bytes.Add(b);}
            foreach (byte b in request.Serialize()) {bytes.Add(b);}
            foreach (byte b in timeOfService.Serialize()) {bytes.Add(b);}
            foreach (byte b in endOfService.Serialize()) {bytes.Add(b);}
            foreach (byte b in vehicleVIN.Serialize()) {bytes.Add(b);}
            return bytes;
            }

        public bool Deserialize(List<Byte> bytes)
            {
            byte[] array = bytes.ToArray();
            if ((DSRCmsgID_t)array[0] != ASN_r36.DSRCmsgID_t.DSRCmsgID_signalRequestMessage)
                {
                Console.Write("Deserialize failed, data is not a SRM byte stream.\n"); 
                return false;
                }
            int index = 1;
            msgCnt = BitConverter.ToInt32(array, index); index += 4;
            index = request.Deserialize(array, index);
            index = timeOfService.Deserialize(array, index);
            index = endOfService.Deserialize(array, index);
            vehicleVIN.Deserialize(array, index);
            return true;
            }

        }

    public struct SignalStatusMessage_t
        {
        public DSRCmsgID_t msgID;
        public Int32 msgCnt;
        public UInt32 id;
        public Byte status;

        static public SignalStatusMessage_t Create()
            {
            SignalStatusMessage_t SignalStatusMessage = new SignalStatusMessage_t();
            SignalStatusMessage.msgID = ASN_r36.DSRCmsgID_t.DSRCmsgID_signalStatusMessage;
            SignalStatusMessage.msgCnt = 0;
            return SignalStatusMessage;
            }

        public List<Byte> Serialize()
            {
            List <Byte> bytes = new List<byte>();
            bytes.Add((Byte)msgID);
            foreach (byte b in BitConverter.GetBytes((Int32)msgCnt)) {bytes.Add(b);}
            foreach (byte b in BitConverter.GetBytes((UInt32)id)) {bytes.Add(b);}
            bytes.Add(status);
            return bytes;
            }

        public bool Deserialize(List<Byte> bytes)
            {
            byte[] array = bytes.ToArray();
            if ((DSRCmsgID_t)array[0] != ASN_r36.DSRCmsgID_t.DSRCmsgID_signalStatusMessage)
                {
                Console.Write("Deserialize failed, data is not a SSM byte stream.\n"); 
                return false;
                }
            int index = 1;
            msgCnt = BitConverter.ToInt32(array, index); index += 4;
            id = BitConverter.ToUInt32(array, index); index += 4;
            status = array[index++];
            return true;
            }

        }

    public StreamByte CreatePipeStream()
        {
        try
        {
        NamedPipeClientStream pipeClient = new NamedPipeClientStream(".", "ASNJ2735", PipeDirection.InOut, PipeOptions.None, TokenImpersonationLevel.Impersonation);
        Console.Write("Connecting to ASNJ2735 Server...");
        pipeClient.Connect();
        Console.WriteLine("Successful!\n");
        return new StreamByte(pipeClient);
        }
        catch {return null;}        
        }
    }

public class StreamByte
{
    private Stream ioStream;

#region "Constructor"

    public StreamByte(Stream ioStream)
        {
        this.ioStream = ioStream;
        }

#endregion

#region "Public Members"

    public List <byte> Read()
        {
        int length;
        length = ioStream.ReadByte() * 256;
        length += ioStream.ReadByte();
        byte[] array = new byte[length];
        ioStream.Read(array, 0, length);
        return new List <byte>(array);
        }

    public int Write(List <byte> buffer)
        {
        byte[] array = buffer.ToArray();
        int length = array.Length;
        ioStream.Write(array, 0, length);
        ioStream.Flush();
        return length + 2;
        }

    public void Close()
        {
        this.ioStream.Flush();
        this.ioStream.Close();
        }

#endregion

}

