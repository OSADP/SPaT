﻿using System;
using System.Net;
using System.Net.Sockets;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Xml.Linq;

namespace SPAT_Listener
    {

#region "Structures"

    struct configIP
        {
        public string ip ;
        public int    port;
        }

    struct connection
        {
        public configIP local;
        public configIP remote;
        }

#endregion

public partial class Main : Form
    {
    private connection mobjSPAT;
    private connection mobjMAP;
    private Boolean mbPause;

#region "Public Members"

    private string Get_ASCII(string sData)
        {
        string sASCII = "";
        
        foreach (string sValue in sData.Split(new string[] {" "},StringSplitOptions.RemoveEmptyEntries))
            {
            sASCII +=  Encoding.Default.GetString(new[] {(byte)int.Parse(sValue, System.Globalization.NumberStyles.HexNumber)});
            }
        return sASCII;
        }

    private string Get_Payload(string sData)
        {
        string sASCII = "";
        int iCount = 0;

        if (optPayload.Checked) {return sData;}
              
        sASCII = Get_ASCII(sData);
        sASCII = sASCII.Substring(sASCII.IndexOf("payload=")+8);
        sASCII = sASCII.Trim();
        for (int iIndex = 0; iIndex < sASCII.Length; iIndex++)
            {
            if (((float)iCount / 2) == (int)(iCount /2))
                {
                sASCII = sASCII.Insert(iIndex, " ");
                iIndex++;
                }
            iCount++;
            }

        return sASCII.Trim();
        }

    private string Get_State(J2735.SPAT.maneuvers eType, uint iState)
        {
        string sState = "";
        
        if (eType == J2735.SPAT.maneuvers.pedestrian)
            {
            if ((iState & 0x0f) == 0x00) {sState += "Unavailable ";}
            if ((iState & 0x0f) == 0x01) {sState += "Do-Not Walk ";}
            if ((iState & 0x0f) == 0x02) {sState += "Flashing Do-Not Walk ";}
            if ((iState & 0x0f) == 0x03) {sState += "Walk ";}
            if ((iState & 0xf0) == 0x10) {sState += "(Call Active) ";}
           }
        
        else
            {
            if ((iState & 0x00000001) == 0x00000001) {sState += "Green Ball ";}
            if ((iState & 0x00000002) == 0x00000002) {sState += "Yellow Ball ";}
            if ((iState & 0x00000004) == 0x00000004) {sState += "Red Ball ";}
            if ((iState & 0x00000008) == 0x00000008) {sState += "Flashing Ball ";}

            if ((iState & 0x00000010) == 0x00000010) {sState += "Green Left Arrow ";}
            if ((iState & 0x00000020) == 0x00000020) {sState += "Yellow Left Arrow ";}
            if ((iState & 0x00000040) == 0x00000040) {sState += "Red Left Arrow ";}
            if ((iState & 0x00000080) == 0x00000080) {sState += "Flashing Left Arrow ";}

            if ((iState & 0x00000100) == 0x00000100) {sState += "Green Right Arrow ";}
            if ((iState & 0x00000200) == 0x00000200) {sState += "Yellow Right Arrow ";}
            if ((iState & 0x00000400) == 0x00000400) {sState += "Red Right Arrow ";}
            if ((iState & 0x00000800) == 0x00000800) {sState += "Flashing Right Arrow ";}

            if ((iState & 0x00001000) == 0x00001000) {sState += "Green Straight Arrow ";}
            if ((iState & 0x00002000) == 0x00002000) {sState += "Yellow Straight Arrow ";}
            if ((iState & 0x00004000) == 0x00004000) {sState += "Red Straight Arrow ";}
            if ((iState & 0x00008000) == 0x00008000) {sState += "Flashing Straight Arrow ";}

            if ((iState & 0x00010000) == 0x00010000) {sState += "Green Soft Left Arrow ";}
            if ((iState & 0x00020000) == 0x00020000) {sState += "Yellow Soft Left Arrow ";}
            if ((iState & 0x00040000) == 0x00040000) {sState += "Red Soft Left Arrow ";}
            if ((iState & 0x00080000) == 0x00080000) {sState += "Flashing Soft Left Arrow ";}

            if ((iState & 0x00100000) == 0x00100000) {sState += "Green Soft Right Arrow ";}
            if ((iState & 0x00200000) == 0x00200000) {sState += "Yellow Soft Right Arrow ";}
            if ((iState & 0x00400000) == 0x00400000) {sState += "Red Soft Right Arrow ";}
            if ((iState & 0x00800000) == 0x00800000) {sState += "Flashing Soft Right Arrow ";}

            if ((iState & 0x01000000) == 0x01000000) {sState += "Green U-Turn Arrow ";}
            if ((iState & 0x02000000) == 0x02000000) {sState += "Yellow U-Turn Arrow ";}
            if ((iState & 0x04000000) == 0x04000000) {sState += "Red U-Turn Arrow ";}
            if ((iState & 0x08000000) == 0x08000000) {sState += "Flashing U-Turn Arrow ";}
            }

        return sState;
        }

    private string Lane_Message(J2735.MAP.lane lane)
        {
        string sMessage = "";

        sMessage += "lane: " + lane.number.ToString() + "\r\n";
        sMessage += "type: " + lane.type.ToString() + "\r\n";
        sMessage += "attributes: " + lane.attributes.ToString("X4") + "\r\n";
        if ( lane.width > 0 ) { sMessage += "width: " + lane.width.ToString() + "\r\n"; }
        if (lane.referencelane.lanenumber > 0)
            {
            sMessage += "reference lane: " + lane.referencelane.lanenumber.ToString() + "\r\n";
            sMessage += "lateral offset: " + lane.referencelane.lateraloffset.ToString() + "\r\n";
            }
        else
            {
            sMessage += Node_Message(lane.node);
            }
        return sMessage;
        }

    private string Node_Message(List <J2735.MAP.node> nodes)
        {
        int iCount = 1;
        string sMessage = "";

        foreach (J2735.MAP.node node in nodes)
            {
            sMessage += "node: " + iCount.ToString() + "\r\n";
            sMessage += "eastern: " + node.eastern.ToString() + "\r\n";
            sMessage += "northern: " + node.nothern.ToString() + "\r\n";
            if (node.elevation > 0) { sMessage += "elevation: " + node.elevation.ToString() + "\r\n";}
            if (node.width > 0) { sMessage += "width: " + node.width.ToString() + "\r\n";}
            iCount++;
            }

        return sMessage;
        }

    private string Decode(string sData)
        {
        List <byte> bytes = new List<byte>();
        string sMessage = "";

//      Get the Message Bytes
        foreach (string sByte in sData.Split(new string[] {" "}, StringSplitOptions.RemoveEmptyEntries))
            {
            bytes.Add((byte)int.Parse(sByte, System.Globalization.NumberStyles.HexNumber));
            }

//      Decode a SPAT Message
        if (bytes[0] == 0x8d)
            {
            sMessage = "Message Type: SPAT\r\n\r\n";
            J2735.SPAT spat = new J2735.SPAT();
            spat.Decompile(bytes);
            sMessage += "Intersection ID: " + spat.Message.intersectionid.ToString() + "\r\n";
            sMessage += "Status: " + spat.Message.intersectionstatus.ToString() + "\r\n";
            sMessage += "Timestamp: " + spat.Message.timestampseconds.ToString() + "\r\n";
            sMessage += "Tenths: " + spat.Message.timestamptenths.ToString() + "\r\n";
            foreach (J2735.SPAT.movement movement in spat.Message.movement)
                {
                sMessage += "\r\n";
                sMessage += "Type: " + movement.type.ToString() + "\r\n";
                sMessage += "Lane(s):  "; 
                foreach (byte lane in movement.lane)
                    {
                    sMessage +=  lane.ToString() + ", ";
                    }
                sMessage = sMessage.Substring(0, sMessage.Length - 2);
                sMessage += "\r\n";
                sMessage += "State: " + movement.data.state.ToString("X2") + ": " + Get_State(movement.type, movement.data.state) + "\r\n";
                sMessage += "Minimum Time: " + ((float)movement.data.mintime/10).ToString("0.0") + " seconds\r\n";
                sMessage += "Maximum Time: " + ((float)movement.data.maxtime/10).ToString("0.0") + " seconds\r\n";
                sMessage += "Yellow Time: " + ((float)movement.data.yellowtime/10).ToString("0.0") + " seconds\r\n";
                sMessage += "Yellow State: " + movement.data.yellowstate.ToString("X2") + ": " + Get_State(movement.type, movement.data.yellowstate) + "\r\n";
                sMessage += "Pedestrian Detect: " + movement.data.pedestrian.ToString() + "\r\n";
                sMessage += "Count: " + movement.data.count.ToString() + "\r\n";
                }
            }

//      Decode a MAP Message
        if (bytes[0] == 0x87)
            {
            sMessage = "Message Type: MAP\r\n\r\n";
            J2735.MAP map = new J2735.MAP();
            map.Decompile(bytes);
            sMessage += "Intersection ID: " + map.Message.intersectionid.ToString() + "\r\n";
            sMessage += "Attributes: " + map.Message.attributes.ToString("X2") + "\r\n";
            foreach (J2735.MAP.geometry geometry in map.Message.geometry)
                {
                sMessage += "\r\n";
                sMessage += "Latitude: " + geometry.referencepoint.latitude.ToString() + "\r\n";
                sMessage += "Longitude: " + geometry.referencepoint.longitude.ToString() + "\r\n";
                if ( geometry.referencepoint.elevation > 0) {sMessage += "Elevation: " + geometry.referencepoint.elevation.ToString() + "\r\n\r\n";}
                sMessage += "\r\nApproach: \r\n";
                if ( geometry.approach.width > 0) {sMessage += "width: " + geometry.approach.width.ToString() + "\r\n";}
                foreach (J2735.MAP.lane lane in geometry.approach.lane)
                    {
                    sMessage += "\r\n";
                    sMessage += Lane_Message(lane);
                    }
                sMessage += "\r\nEgress: \r\n";
                if ( geometry.egress.width > 0) {sMessage += "width: " + geometry.egress.width.ToString() + "\r\n";}
                foreach (J2735.MAP.lane lane in geometry.egress.lane)
                    {
                    sMessage += "\r\n";
                    sMessage += Lane_Message(lane);
                    }
                sMessage += "\r\nBarrier: \r\n";
                foreach (J2735.MAP.barrier barrier in geometry.barrier)
                    {
                    sMessage += "\r\n";
                    sMessage += "Attributes: " +  barrier.attributes.ToString("X2") + "\r\n";
                    if (  barrier.width > 0) {sMessage += "width: " +  barrier.width.ToString() + "\r\n";}
                    sMessage += Node_Message(barrier.node);
                    }
                }
            }

//      Identify and Unknown Message Type
        if (sMessage == "") {sMessage = "Unknown Message Type: \r\n" + sData;}

//      Return Result
        return sMessage;
        }

    private bool LoadConfiguration(string sFilename)
        {
        string sTag;
        string sValue;

//      Load the Configuration File
        try
        {
        XDocument doc = XDocument.Load(sFilename);
        XElement root = doc.Root;

//      Parse the Configuration File Elements
        foreach (XElement element in root.Elements())
            {
            sTag = element.Name.ToString();
            sValue = element.Value.ToString();
            switch (sTag.ToLower())
                {
                case "localip":    { mobjSPAT.local.ip = sValue; mobjMAP.local.ip = sValue; break; } 
                case "remoteip":   { mobjSPAT.remote.ip = sValue; mobjMAP.remote.ip = sValue; break; } 

//              Parse the SPAT Configuration Elements
                case "spat": 
                    {
                    foreach (XElement child in element.Elements())
                        {
                        sTag = child.Name.ToString();
                        sValue = child.Value.ToString();
                        switch (sTag.ToLower())
                            {
                            case "localport":  { mobjSPAT.local.port = Convert.ToInt32(sValue); break; } 
                            case "remoteport": { mobjSPAT.remote.port = Convert.ToInt32(sValue); break; } 
                            }
                        }
                    break;
                    }

//              Parse the MAP Configuration Elements
                case "map": 
                    {
                    foreach (XElement child in element.Elements())
                        {
                        sTag = child.Name.ToString();
                        sValue = child.Value.ToString();
                        switch (sTag.ToLower())
                            {
                            case "localport":  { mobjMAP.local.port = Convert.ToInt32(sValue); break; } 
                            case "remoteport": { mobjMAP.remote.port = Convert.ToInt32(sValue); break; } 
                            }
                        }
                    break;
                    }
                }
            }
        }

//      Error Handler
        catch (Exception Exp)
            {
            string sMsg = "Error reading configuration file: " + sFilename + "\n" + Exp.Message;
            Console.WriteLine(sMsg);
            return false;
            }

//      Return Result
        return true;
        }

    private void Run()
        {
        byte[] bytes;
        string sMessage;
        UdpClient  objUDPClient;
        IPEndPoint objEndPoint;
        int icount = 1;

        Application.DoEvents();

//      Create a UDP Listener for the SPAT Message
        if (optSPAT.Checked)
            {
            IPEndPoint localEndPoint = new IPEndPoint(IPAddress.Parse(mobjSPAT.local.ip), mobjSPAT.local.port);
            objUDPClient = new UdpClient(localEndPoint);
            objEndPoint =  new IPEndPoint(IPAddress.Parse(mobjSPAT.remote.ip), mobjSPAT.remote.port);
            }        

//      Create a UDP Listener for the MAP Message
        else
            {
            IPEndPoint localEndPoint = new IPEndPoint(IPAddress.Parse(mobjMAP.local.ip), mobjMAP.local.port);
            objUDPClient = new UdpClient(localEndPoint);
            objEndPoint =  new IPEndPoint(IPAddress.Parse(mobjMAP.remote.ip), mobjMAP.remote.port);
            } 

//      Begin Listening
        txtMessage.Text = "";
        do
        {
        bytes = objUDPClient.Receive(ref objEndPoint);      
        if (bytes.Length > 0)
            {

//          Display the Byte Stream
            lblMessage.Text = "Byte Stream - timestamp: " + DateTime.Now.ToLongTimeString() + "  count: " + icount.ToString();
            sMessage = "";
            foreach(byte b in bytes) { sMessage += b.ToString("X2") + " "; }
            txtMessage.Text = sMessage;
            icount++;

//          Decode the Message Content
            if (optDispatch.Checked)
                {
                txtResult.Text = Decode(Get_Payload(txtMessage.Text));
                }

//          Decode the Message Content
            if (optPayload.Checked)
                {
                txtResult.Text = Decode(txtMessage.Text);
                }
            }

//      Exit the Loop if Paused
        Application.DoEvents();
        if (mbPause) { break; }

        } while (true);

//      Close the UDP Client
        objUDPClient.Close();
        }

#endregion

#region "Main"

    public Main(string sfilename)
        {
        InitializeComponent();

//      Read the Application Configuration File        
        if (!LoadConfiguration(sfilename)) return;
        optSPAT.Checked = true;
        optPayload.Checked = true;
        txtResult.Dock = DockStyle.Fill;
        mbPause = true;
        }

#endregion

#region "botBegin"

    private void botBegin_Click(object sender, EventArgs e)
        {
        mbPause = !mbPause;
        if (mbPause == true) 
            {
            botBegin.Text = "Begin";
            pnlMessage.Enabled = true;
            } 
        else 
            {
            botBegin.Text = "Pause"; 
            pnlMessage.Enabled = false;
            Run();
            }
        }

#endregion

#region "optSPAT"

    private void optSPAT_CheckedChanged(object sender, EventArgs e)
        {
        lblIP.Text = mobjSPAT.local.ip + " / " + mobjSPAT.local.port.ToString() + "\n" + mobjSPAT.remote.ip + " / " + mobjSPAT.remote.port.ToString();
        }

#endregion

#region "optMAP"

    private void optMAP_CheckedChanged(object sender, EventArgs e)
        {
        lblIP.Text = mobjMAP.local.ip + " / " + mobjMAP.local.port.ToString() + "\n" + mobjMAP.remote.ip + " / " + mobjMAP.remote.port.ToString();
        }

#endregion

    }
}
