﻿namespace SPAT_Listener
    {
    partial class Main
        {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
            {
        if (disposing && (components != null))
            {
        components.Dispose();
            }
        base.Dispose(disposing);
            }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
            {
            this.txtMessage = new System.Windows.Forms.TextBox();
            this.lblMessage = new System.Windows.Forms.Label();
            this.botBegin = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.lblIP = new System.Windows.Forms.Label();
            this.optSPAT = new System.Windows.Forms.RadioButton();
            this.optMAP = new System.Windows.Forms.RadioButton();
            this.panel1 = new System.Windows.Forms.Panel();
            this.pnlMessage = new System.Windows.Forms.Panel();
            this.panel2 = new System.Windows.Forms.Panel();
            this.txtResult = new System.Windows.Forms.TextBox();
            this.optPayload = new System.Windows.Forms.RadioButton();
            this.optDispatch = new System.Windows.Forms.RadioButton();
            this.splitter1 = new System.Windows.Forms.Splitter();
            this.label2 = new System.Windows.Forms.Label();
            this.panel1.SuspendLayout();
            this.pnlMessage.SuspendLayout();
            this.panel2.SuspendLayout();
            this.SuspendLayout();
            // 
            // txtMessage
            // 
            this.txtMessage.Dock = System.Windows.Forms.DockStyle.Top;
            this.txtMessage.Location = new System.Drawing.Point(4, 68);
            this.txtMessage.Multiline = true;
            this.txtMessage.Name = "txtMessage";
            this.txtMessage.Size = new System.Drawing.Size(859, 137);
            this.txtMessage.TabIndex = 0;
            // 
            // lblMessage
            // 
            this.lblMessage.AutoSize = true;
            this.lblMessage.Dock = System.Windows.Forms.DockStyle.Top;
            this.lblMessage.Location = new System.Drawing.Point(4, 47);
            this.lblMessage.Name = "lblMessage";
            this.lblMessage.Padding = new System.Windows.Forms.Padding(0, 4, 0, 4);
            this.lblMessage.Size = new System.Drawing.Size(64, 21);
            this.lblMessage.TabIndex = 1;
            this.lblMessage.Text = "Byte Stream";
            // 
            // botBegin
            // 
            this.botBegin.Location = new System.Drawing.Point(12, 7);
            this.botBegin.Name = "botBegin";
            this.botBegin.Size = new System.Drawing.Size(82, 26);
            this.botBegin.TabIndex = 2;
            this.botBegin.Text = "Begin";
            this.botBegin.UseVisualStyleBackColor = true;
            this.botBegin.Click += new System.EventHandler(this.botBegin_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Dock = System.Windows.Forms.DockStyle.Left;
            this.label1.Location = new System.Drawing.Point(2, 2);
            this.label1.Name = "label1";
            this.label1.Padding = new System.Windows.Forms.Padding(4, 1, 0, 0);
            this.label1.Size = new System.Drawing.Size(64, 27);
            this.label1.TabIndex = 3;
            this.label1.Text = "Local IP:\r\nRemote IP:";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // lblIP
            // 
            this.lblIP.AutoSize = true;
            this.lblIP.Dock = System.Windows.Forms.DockStyle.Left;
            this.lblIP.Font = new System.Drawing.Font("Courier New", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblIP.Location = new System.Drawing.Point(66, 2);
            this.lblIP.Name = "lblIP";
            this.lblIP.Size = new System.Drawing.Size(84, 28);
            this.lblIP.TabIndex = 4;
            this.lblIP.Text = "00-00-00-00\r\n00-00-00-00";
            this.lblIP.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // optSPAT
            // 
            this.optSPAT.AutoSize = true;
            this.optSPAT.Location = new System.Drawing.Point(3, 1);
            this.optSPAT.Name = "optSPAT";
            this.optSPAT.Size = new System.Drawing.Size(150, 17);
            this.optSPAT.TabIndex = 5;
            this.optSPAT.Text = "Listen for SPAT Messages";
            this.optSPAT.UseVisualStyleBackColor = true;
            this.optSPAT.CheckedChanged += new System.EventHandler(this.optSPAT_CheckedChanged);
            // 
            // optMAP
            // 
            this.optMAP.AutoSize = true;
            this.optMAP.Location = new System.Drawing.Point(3, 17);
            this.optMAP.Name = "optMAP";
            this.optMAP.Size = new System.Drawing.Size(145, 17);
            this.optMAP.TabIndex = 6;
            this.optMAP.Text = "Listen for MAP Messages";
            this.optMAP.UseVisualStyleBackColor = true;
            this.optMAP.CheckedChanged += new System.EventHandler(this.optMAP_CheckedChanged);
            // 
            // panel1
            // 
            this.panel1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.panel1.Controls.Add(this.optPayload);
            this.panel1.Controls.Add(this.optDispatch);
            this.panel1.Controls.Add(this.pnlMessage);
            this.panel1.Controls.Add(this.panel2);
            this.panel1.Controls.Add(this.botBegin);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel1.Location = new System.Drawing.Point(4, 4);
            this.panel1.Name = "panel1";
            this.panel1.Padding = new System.Windows.Forms.Padding(2);
            this.panel1.Size = new System.Drawing.Size(859, 43);
            this.panel1.TabIndex = 8;
            // 
            // pnlMessage
            // 
            this.pnlMessage.Controls.Add(this.optSPAT);
            this.pnlMessage.Controls.Add(this.optMAP);
            this.pnlMessage.Location = new System.Drawing.Point(104, 2);
            this.pnlMessage.Name = "pnlMessage";
            this.pnlMessage.Size = new System.Drawing.Size(165, 35);
            this.pnlMessage.TabIndex = 7;
            // 
            // panel2
            // 
            this.panel2.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.panel2.Controls.Add(this.lblIP);
            this.panel2.Controls.Add(this.label1);
            this.panel2.Dock = System.Windows.Forms.DockStyle.Right;
            this.panel2.Location = new System.Drawing.Point(489, 2);
            this.panel2.Name = "panel2";
            this.panel2.Padding = new System.Windows.Forms.Padding(2);
            this.panel2.Size = new System.Drawing.Size(364, 35);
            this.panel2.TabIndex = 0;
            // 
            // txtResult
            // 
            this.txtResult.Location = new System.Drawing.Point(18, 245);
            this.txtResult.Multiline = true;
            this.txtResult.Name = "txtResult";
            this.txtResult.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.txtResult.Size = new System.Drawing.Size(507, 179);
            this.txtResult.TabIndex = 9;
            // 
            // optPayload
            // 
            this.optPayload.AutoSize = true;
            this.optPayload.Location = new System.Drawing.Point(286, 19);
            this.optPayload.Name = "optPayload";
            this.optPayload.Size = new System.Drawing.Size(95, 17);
            this.optPayload.TabIndex = 9;
            this.optPayload.Text = "Binary Payload";
            this.optPayload.UseVisualStyleBackColor = true;
            // 
            // optDispatch
            // 
            this.optDispatch.AutoSize = true;
            this.optDispatch.Location = new System.Drawing.Point(286, 3);
            this.optDispatch.Name = "optDispatch";
            this.optDispatch.Size = new System.Drawing.Size(135, 17);
            this.optDispatch.TabIndex = 8;
            this.optDispatch.Text = "ASCII Dispatch Header";
            this.optDispatch.UseVisualStyleBackColor = true;
            // 
            // splitter1
            // 
            this.splitter1.Dock = System.Windows.Forms.DockStyle.Top;
            this.splitter1.Location = new System.Drawing.Point(4, 205);
            this.splitter1.Name = "splitter1";
            this.splitter1.Size = new System.Drawing.Size(859, 6);
            this.splitter1.TabIndex = 10;
            this.splitter1.TabStop = false;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Dock = System.Windows.Forms.DockStyle.Top;
            this.label2.Location = new System.Drawing.Point(4, 211);
            this.label2.Name = "label2";
            this.label2.Padding = new System.Windows.Forms.Padding(0, 4, 0, 4);
            this.label2.Size = new System.Drawing.Size(53, 21);
            this.label2.TabIndex = 11;
            this.label2.Text = "Message:";
            // 
            // Main
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(867, 493);
            this.Controls.Add(this.txtResult);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.splitter1);
            this.Controls.Add(this.txtMessage);
            this.Controls.Add(this.lblMessage);
            this.Controls.Add(this.panel1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.SizableToolWindow;
            this.Name = "Main";
            this.Padding = new System.Windows.Forms.Padding(4);
            this.Text = "SPAT Listener";
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.pnlMessage.ResumeLayout(false);
            this.pnlMessage.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

            }

        #endregion

        private System.Windows.Forms.TextBox txtMessage;
        private System.Windows.Forms.Label lblMessage;
        private System.Windows.Forms.Button botBegin;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label lblIP;
        private System.Windows.Forms.RadioButton optSPAT;
        private System.Windows.Forms.RadioButton optMAP;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Panel pnlMessage;
        private System.Windows.Forms.RadioButton optPayload;
        private System.Windows.Forms.RadioButton optDispatch;
        private System.Windows.Forms.TextBox txtResult;
        private System.Windows.Forms.Splitter splitter1;
        private System.Windows.Forms.Label label2;
        }
    }

