﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace SPaTSystem
{
    class clsSRM
    {

        public enum RequestStatus
        {
            UnKnown = 0,
            Received = 1,
            InQueue = 2,
            Active = 3,
            Expired = 4
        }

        public enum DSRCmsgID_t
        {
            DSRCmsgID_reserved = 0,
            DSRCmsgID_alaCarteMessage = 1,
            DSRCmsgID_basicSafetyMessage = 2,
            DSRCmsgID_basicSafetyMessageVerbose = 3,
            DSRCmsgID_commonSafetyRequest = 4,
            DSRCmsgID_emergencyVehicleAlert = 5,
            DSRCmsgID_intersectionCollisionAlert = 6,
            DSRCmsgID_mapData = 7,
            DSRCmsgID_nmeaCorrections = 8,
            DSRCmsgID_probeDataManagement = 9,
            DSRCmsgID_probeVehicleData = 10,
            DSRCmsgID_roadSideAlert = 11,
            DSRCmsgID_rtcmCorrections = 12,
            DSRCmsgID_signalPhaseAndTimingMessage = 13,
            DSRCmsgID_signalRequestMessage = 14,
            DSRCmsgID_signalStatusMessage = 15,
            DSRCmsgID_travelerInformation = 16
        }


        public struct DTime_t
        {
            public Int32 hour;
            public Int32 minute;
            public Int32 second;

        }

        public struct VehicleIdent_t
        {
            public UInt32 id;

            public List<Byte> Serialize()
            {
                List<Byte> bytes = new List<byte>();
                foreach (byte b in BitConverter.GetBytes((UInt32)id)) { bytes.Add(b); }
                return bytes;
            }

            public int Deserialize(byte[] array, int index)
            {
                id = BitConverter.ToUInt32(array, index); index += 4;
                return index;
            }
        }

        public struct SignalRequest_t
        {
            public UInt32 id;
            public Byte inLane;
            public Byte type;

            public List<Byte> Serialize()
            {
                List<Byte> bytes = new List<byte>();
                foreach (byte b in BitConverter.GetBytes((UInt32)id)) { bytes.Add(b); }
                bytes.Add(inLane);
                bytes.Add(type);
                return bytes;
            }

            public int Deserialize(byte[] array, int index)
            {
                id = BitConverter.ToUInt32(array, index); index += 4;
                inLane = array[index++];
                type = array[index++];
                return index;
            }
        }
        
        public DSRCmsgID_t msgID;
        public Int32 msgCnt;
        public SignalRequest_t request;
        public DTime_t timeOfService;
        public DTime_t endOfService;
        public VehicleIdent_t vehicleVIN;
        public DateTime desiredTimeofService;
        public DateTime desiredEndofService;
        public int strategyNumber;
        public int preemptNumber;
        public byte vehicleClassType;
        public byte vehicleClassLevel;
        public RequestStatus status;
        public UInt32 requestID;
    }
}
