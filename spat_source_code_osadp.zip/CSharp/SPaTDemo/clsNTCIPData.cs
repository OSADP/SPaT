﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace SPaTSystem
{
    class clsNTCIPData
    {
        private int intInAddress;
        private string strInCommunity;
        private int intInReqID;
        private int intInReqType;
        private int intInErrorStatus;
        private int intInErrorIndex;
        private string strInOID;
        private object varInOIDValue;
        private int intInOIDType;

        private bool blnGotResponse;
        private float sglStartTime;

        public int InAddress
        {
            get { return intInAddress; }
            set { intInAddress = value; }
        }
        public string InCommunity
        {
            get { return strInCommunity; }
            set { strInCommunity = value; }
        }
        public int InReqID
        {
            get { return intInReqID; }
            set { intInReqID = value; }
        }
        public int InReqType
        {
            get { return intInReqType; }
            set { intInReqType = value; }
        }
        public int InErrorStatus
        {
            get { return intInErrorStatus; }
            set { intInErrorStatus = value; }
        }
        public int InErrorIndex
        {
            get { return intInErrorIndex; }
            set { intInErrorIndex = value; }
        }
        public string InOID
        {
            get { return strInOID; }
            set { strInOID = value; }
        }
        public object InOIDValue
        {
            get { return varInOIDValue; }
            set { varInOIDValue = value; }
        }
        public int InOIDType
        {
            get { return intInOIDType; }
            set { intInOIDType = value; }
        }
        public bool GotResponse
        {
            get { return blnGotResponse; }
            set { blnGotResponse = value; }
        }
        public float StartTime
        {
            get { return sglStartTime; }
            set { sglStartTime = value; }
        }

    }
}
