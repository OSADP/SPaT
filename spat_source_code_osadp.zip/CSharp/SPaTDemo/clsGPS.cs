﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;
using System.IO.Ports;
using System.Threading;

namespace SPaTSystem
{
    class clsGPS
    {
/*        public enum EnumPortStatus { Open, Closed };
        public enum EnumPortConfigurationMode { Manual, Automatic };


        private static bool m_gpsPortFound;
        private static EnumPortStatus m_gpsPortStatus;

        void clsGPS(string CommPort, string portSettings)
        {
            m_gpsPortFound = false;
            m_gpsPortStatus = EnumPortStatus.Closed;
        }


        public static bool PortFound
        {
            get { return m_gpsPortFound; }
            set { m_gpsPortFound = value; }
        }

        public static EnumPortStatus PortStatus
        {
            get { return m_gpsPortStatus; }
            set { m_gpsPortStatus = value; }
        }

        private string VerifyGPSDeviceConnection(ref SerialPort gpsPort)
        {
            int num;
            string retValue;
            string error = string.Empty;

            //string[] ports = SerialPort.GetPortNames().OrderBy(a => a.Length > 3 && int.TryParse(a.Substring(3), out num) ? num : 0).ToAr            
           
            if (gpsPort.IsOpen == true)
            {
                try
                {
                    gpsPort.Close();
                    Thread.Sleep(300);
                }
                catch (UnauthorizedAccessException unauthEx)
                {
                    error = unauthEx.Message;
                }
                catch (IOException ioEx)
                {
                    error = ioEx.Message;
                }
                catch (ArgumentException ArgEx)
                {
                    error = ArgEx.Message;
                }
            }

            if (error.Length > 0)
            {
                retValue = "\r\nError in verifying the GPS device connectivity. The GPS port is laready in use by some other device." +
                           "\r\n\t" + error;
                return retValue;
            }

            if (gpsPort.IsOpen == false)
            {
                try
                {
                    // Open the port
                    gpsPort.Open();
                }
                catch (UnauthorizedAccessException unauthEx)
                {
                    error = unauthEx.Message;
                }
                catch (IOException ioEx)
                {
                    error = ioEx.Message;
                }
                catch (ArgumentException argEx)
                {
                    error = argEx.Message;
                }

                if (error.Length > 0)
                {
                    retValue = "\r\nError in verifying the opening the GPS device serial port: "  + gpsPort.PortName + 
                               "\tSettings: " + gpsPort.Parity + "," + gpsPort.DataBits + "," + gpsPort.StopBits + "," + gpsPort.BaudRate + "\tHandShake: " + gpsPort.Handshake +
                               "\r\n\t" + error;
                    return retValue;
                }
                else
                {
                    for (int j = 1; j <= 10; j++)
                    {
                        retValue = ReadSerialPort();
                        if (FoundGPSDevice)
                        {
                            //txtLog.Clear();
                            retValue = "GPS device is prsent on CommPort: " + gpsPort.PortName + " and communicating properly.";
                            return retValue;
                        }
                        Thread.Sleep(100);
                    }
                    if (!FoundGPSDevice)
                        else
                        {
                            LogTxtMsg(txtLog, "\t" + "No valid response was received from port yet since last read trial. Trying again ...");
                        }
                    {
                        SPGPS.Close();
                    }
                }
                //    //txtSendData.Focus();
            }
            return FoundGPSDevice;
        }

        public bool DetectGPSSerialPort()
        {
            int num;
            bool error = false;

            FoundGPSDevice = false;
            string[] ports = SerialPort.GetPortNames().OrderBy(a => a.Length > 3 && int.TryParse(a.Substring(3), out num) ? num : 0).ToArray();
            txtLog.Clear();
            LogTxtMsg(txtLog, "Checking for a GPS device on one of the available serial ports:: ");

            if (SPGPS.IsOpen == true)
            {
                try
                {
                    SPGPS.Close();
                }
                catch (UnauthorizedAccessException)
                {
                    error = true;
                }
                catch (IOException)
                {
                    error = true;
                }
                catch (ArgumentException)
                {
                    error = true;
                }
                Thread.Sleep(300);
            }

            if (error)
            {
                MessageBox.Show(this, "Could not close the Serial port: " + SPGPS.PortName, "Serial Port Unavalible", MessageBoxButtons.OK, MessageBoxIcon.Stop);
                return FoundGPSDevice;
            }

            SPGPS.DataBits = int.Parse("8");
            SPGPS.Parity = Parity.None;
            SPGPS.StopBits = StopBits.One;
            SPGPS.Handshake = Handshake.None;

            foreach (string port in ports)
            {
                SPGPS.PortName = port;
                for (int i = 1; i <= 5; i++)
                {
                    switch (i)
                    {
                        case 1:
                            SPGPS.BaudRate = 9600;
                            break;
                        case 2:
                            SPGPS.BaudRate = 19200;
                            break;
                        case 3:
                            SPGPS.BaudRate = 38400;
                            break;
                        case 4:
                            SPGPS.BaudRate = 57600;
                            break;
                        case 5:
                            SPGPS.BaudRate = 115200;
                            break;
                    }

                    LogTxtMsg(txtLog, "");
                    LogTxtMsg(txtLog, "");
                    LogTxtMsg(txtLog, "\n\t Opening port: " + port + " with Baudrate: " + SPGPS.BaudRate);
                    if (SPGPS.IsOpen == false)
                    {
                        try
                        {
                            // Open the port
                            //Thread.Sleep(300);
                            SPGPS.Open();
                        }
                        catch (UnauthorizedAccessException)
                        {
                            error = true;
                        }
                        catch (IOException)
                        {
                            error = true;
                        }
                        catch (ArgumentException)
                        {
                            error = true;
                        }
                    }

                    if (error)
                    {
                        MessageBox.Show(this, "Could not open the COM port: " + SPGPS.PortName + " .  Most likely it is already in use, has been removed, or is unavailable.", "COM Port Unavalible", MessageBoxButtons.OK, MessageBoxIcon.Stop);
                        break;
                    }
                    else
                    {
                        LogTxtMsg(txtLog, "\tPort: " + port + " was opened successfuly");

                        //// Show the initial pin states
                        //UpdatePinState();
                        //chkDTR.Checked = comport.DtrEnable;
                        //chkRTS.Checked = comport.RtsEnable;

                        for (int j = 1; j <= 10; j++)
                        {
                            FoundGPSDevice = ReadSerialPort();
                            if (FoundGPSDevice)
                            {
                                //txtLog.Clear();
                                LogTxtMsg(txtLog, "\t" + "A GPS device is available on port: " + SPGPS.PortName);
                                GlobalVars.RMCDebugMode = false;
                                return FoundGPSDevice;
                            }
                            else
                            {
                                LogTxtMsg(txtLog, "\t" + "No valid response was received from port yet since last read trial. Trying again ...");
                            }
                            Thread.Sleep(100);
                        }
                        if (!FoundGPSDevice)
                        {
                            SPGPS.Close();
                            Thread.Sleep(200);
                        }
                    }
                    //if (FoundGPSDevice)
                    //{
                    //    break;
                    //}
                }
                //if (FoundGPSDevice)
                //{
                //    break;
                //}
            }
            return FoundGPSDevice;
        }


        private string  ReadSerialPort(ref SerialPort gpsPort)       //Used for timer reads from the GPS port
        {
            string GPSMsg;
            string CurrTime;
            string Sentence;
            bool RMCSentenceFound = false;

            GPSMsg = gpsPort.ReadExisting();
            CurrTime = DateTime.Now.Year + "/" + DateTime.Now.Month + "/" + DateTime.Now.Day + "  " +
                       DateTime.Now.Hour + ":" + DateTime.Now.Hour + ":" + DateTime.Now.Second + ":" +
                       DateTime.Now.Millisecond;
            //currtime1 = DateTime.Now.ToString();
            int NLLocation = 0;
            int GPRMCLocation = 0;
            if (GPSMsg.Length > 0)
            {
                while ((NLLocation = GPSMsg.LastIndexOf("\n")) > 0)
                {
                    GPRMCLocation = GPSMsg.LastIndexOf("$GPRMC");
                    if (NLLocation > GPRMCLocation)
                    {
                        RMCSentenceFound = true;
                        break;
                    }
                }
                while (NLLocation > 0)
                {
                    Application.DoEvents();
                    Application.DoEvents();

                    Sentence = GPSMsg.Substring(GPRMCLocation, NLLocation - 1);
                    if (MyInterpreter.Parse(Sentence))
                    {
                        //A valid RMC sentence was found
                        RMCSentenceFound = true;
                        if (GlobalVars.RMCDebugMode)
                        {
                            LogTxtMsg(txtLog, "\t" + CurrTime + " ::: A $GPRMC sentence was detected.");
                            LogTxtMsg(txtLog, "\t\t\t\t\t" + Sentence);
                        }

                        RMCSentenceForm.txtGPSTime.Text = GlobalVars.CUTCTime;
                        RMCSentenceForm.txtLocalTime.Text = GlobalVars.CLocalTime;
                        RMCSentenceForm.txtGPSFix.Text = GlobalVars.CFix;
                        RMCSentenceForm.txtGPSLat.Text = GlobalVars.CLat.ToString();
                        RMCSentenceForm.txtGPSLon.Text = GlobalVars.CLon.ToString();
                        RMCSentenceForm.txtGPSNS.Text = GlobalVars.CNSHemisphere;
                        RMCSentenceForm.txtGPSEW.Text = GlobalVars.CEWHemisphere;
                        RMCSentenceForm.txtGPSSpeedKnots.Text = GlobalVars.CSpeedKnots.ToString();
                        //RMCSentenceForm.txtSpeedMPH.Text = GlobalVars.CSpeedMph.ToString();
                        RMCSentenceForm.txtSpeedMPH.Text = string.Format("{0:#.##}", (GlobalVars.CSpeedMph));
                        RMCSentenceForm.txtGPSDate.Text = GlobalVars.CDate;

                        txtGPSFix.Text = GlobalVars.CFix;
                        txtGPSLat.Text = GlobalVars.CLat.ToString();
                        txtGPSLon.Text = GlobalVars.CLon.ToString();
                        txtGPSNS.Text = GlobalVars.CNSHemisphere;
                        txtGPSEW.Text = GlobalVars.CEWHemisphere;
                        txtGPSSpeedKnots.Text = GlobalVars.CSpeedKnots.ToString();
                        //txtSpeedMPH.Text = GlobalVars.CSpeedMph.ToString();
                        txtSpeedMPH.Text = string.Format("{0:#.##}", (GlobalVars.CSpeedMph));
                        txtGPSDate.Text = GlobalVars.CDate;


                        if (GlobalVars.CBearing == 0.0)
                        {
                            RMCSentenceForm.txtGPSBearing.Text = GlobalVars.CBearing.ToString() + "\tNorth";
                            txtGPSBearing.Text = GlobalVars.CBearing.ToString() + "\tNorth";
                        }
                        else if ((GlobalVars.CBearing > 0.0) & (GlobalVars.CBearing < 90.0))
                        {
                            RMCSentenceForm.txtGPSBearing.Text = GlobalVars.CBearing.ToString() + "   North  " + GlobalVars.CBearing.ToString() + "º  East";
                            txtGPSBearing.Text = GlobalVars.CBearing.ToString() + "   North  " + Math.Round(GlobalVars.CBearing).ToString() + "º  East";
                        }
                        else if (GlobalVars.CBearing == 90.0)
                        {
                            RMCSentenceForm.txtGPSBearing.Text = GlobalVars.CBearing.ToString() + "\tEast";
                            txtGPSBearing.Text = GlobalVars.CBearing.ToString() + "\tEast";
                        }
                        else if ((GlobalVars.CBearing > 90.0) & (GlobalVars.CBearing < 180.0))
                        {
                            RMCSentenceForm.txtGPSBearing.Text = GlobalVars.CBearing.ToString() + "   South  " + Convert.ToString(GlobalVars.CBearing - 90.0) + "º East";
                            txtGPSBearing.Text = GlobalVars.CBearing.ToString() + "   South  " + Convert.ToString(Math.Round(GlobalVars.CBearing - 90.0)) + "º East";
                        }
                        else if (GlobalVars.CBearing == 180.0)
                        {
                            RMCSentenceForm.txtGPSBearing.Text = GlobalVars.CBearing.ToString() + "\tSouth";
                            txtGPSBearing.Text = GlobalVars.CBearing.ToString() + "\tSouth";
                        }
                        else if ((GlobalVars.CBearing > 180.0) & (GlobalVars.CBearing < 270.0))
                        {
                            RMCSentenceForm.txtGPSBearing.Text = GlobalVars.CBearing.ToString() + "   South  " + Convert.ToString(GlobalVars.CBearing - 180) + "º West";
                            txtGPSBearing.Text = GlobalVars.CBearing.ToString() + "   South  " + Convert.ToString(Math.Round(GlobalVars.CBearing - 180)) + "º West";
                        }
                        else if (GlobalVars.CBearing == 270.0)
                        {
                            RMCSentenceForm.txtGPSBearing.Text = GlobalVars.CBearing.ToString() + "\tWest";
                            txtGPSBearing.Text = GlobalVars.CBearing.ToString() + "\tWest";
                        }
                        else if ((GlobalVars.CBearing > 270.0) & (GlobalVars.CBearing < 360.0))
                        {
                            RMCSentenceForm.txtGPSBearing.Text = GlobalVars.CBearing.ToString() + "   North  " + Convert.ToString(GlobalVars.CBearing - 270) + "º  West";
                            txtGPSBearing.Text = GlobalVars.CBearing.ToString() + "   North  " + Convert.ToString(Math.Round(GlobalVars.CBearing - 270)) + "º  West";
                        }
                        else
                        {
                            RMCSentenceForm.txtGPSBearing.Text = GlobalVars.CBearing.ToString() + "North";
                            txtGPSBearing.Text = GlobalVars.CBearing.ToString() + "North";
                        }

                        if (String.Compare(GlobalVars.CFix.ToUpper(), "A".ToUpper()) == 0)
                        {
                            RMCSentenceForm.gbRMCSentence.BackColor = Color.LightGreen;
                            gbRMCSentence.BackColor = Color.LightGreen;
                            //gbGPS.BackColor = Color.LightGreen;
                        }
                        else if (string.Compare(GlobalVars.CFix.ToUpper(), "V".ToUpper()) == 0)
                        {
                            RMCSentenceForm.gbRMCSentence.BackColor = Color.OrangeRed;
                            gbRMCSentence.BackColor = Color.OrangeRed;
                            //gbGPS.BackColor = Color.OrangeRed;
                        }
                        CalculateGPSDistanceBetween2Points();
                        //txtDistIncr.Text =(GlobalVars.IncrDistance.ToString());
                        txtDistIncr.Text = string.Format("{0:#.##}", (GlobalVars.IncrDistance));
                        txtTotalTrip.Text = string.Format("{0:#.##}", GlobalVars.TotalTripDistance);
                        //txtTotalTrip.Text = (System.Math.Round(GlobalVars.TotalTripDistance)).ToString();
                        //save GPS record if the system has been armed and found a trigger.
                        if ((GlobalVars.SystemStatus == GlobalVars.EnumSystemStatus.Recording) | (GlobalVars.SystemStatus == GlobalVars.EnumSystemStatus.WaitForStopTrigger))
                        {
                            try
                            {
                                txtGPSDistance.Text = string.Format("{0:#.##}", GlobalVars.CTripDistance);
                                GPSCTMSSM = (DateTime.Now.Hour * 3600 + DateTime.Now.Minute * 60 + DateTime.Now.Second) * 1000 + DateTime.Now.Millisecond;
                                GPSDeltaT = GPSCTMSSM - GPSPTMSSM;
                                GPSPTMSSM = GPSCTMSSM;

                                string[] parts = Sentence.Split(',');
                                string tmpTime = DateTime.Now.TimeOfDay.ToString() + "," + DateTime.Now.Hour.ToString() + ":" + DateTime.Now.Minute.ToString() + ":" +
                                                                                           DateTime.Now.Second.ToString() + ":" + DateTime.Now.Millisecond.ToString();
                                GPSRecCnt = GPSRecCnt + 1;
                                GPSFile.WriteLine(TripNo + "," + GPSRecCnt.ToString() + "," + GPSDeltaT.ToString() + "," + GlobalVars.CFix + "," + GlobalVars.CUTCTime + "," + GlobalVars.CLocalTime + "," + DateTime.Now + "," +
                                                  GlobalVars.CLat.ToString() + "," + GlobalVars.CLatDDM.ToString() + "," + GlobalVars.CNSHemisphere + "," +
                                                  GlobalVars.CLon.ToString() + "," + GlobalVars.CLonDDM.ToString() + "," + GlobalVars.CEWHemisphere + "," +
                                                  GlobalVars.CSpeedKnots.ToString() + "," + GlobalVars.CSpeedMph.ToString() + "," +
                                                  GlobalVars.CBearing.ToString() + "," + txtGPSBearing.Text + "," +
                                                  GlobalVars.CSLatRad + "," + GlobalVars.CSLonRad + "," +
                                                  GlobalVars.CX + "," + GlobalVars.CY + "," + GlobalVars.CZ + "," +
                                                  GlobalVars.IncrDistance.ToString() + "," + GlobalVars.CTripDistance.ToString() + "," + DMICnt + "," + TotalDMICnt + "," + string.Format("{0:#.##}", (TotalDMICnt / GlobalVars.DMICalibFactor)) + "," + PressedKey + "," + TriggerDetected);

                                GlobalVars.GPSRecordsList.Add(TripNo + "," + GPSRecCnt.ToString() + "," + GlobalVars.CFix + "," + GlobalVars.CUTCTime + "," + GlobalVars.CLocalTime + "," + DateTime.Now + "," +
                                                  GlobalVars.CLat.ToString() + "," + GlobalVars.CLatDDM.ToString() + "," + GlobalVars.CNSHemisphere + "," +
                                                  GlobalVars.CLon.ToString() + "," + GlobalVars.CLonDDM.ToString() + "," + GlobalVars.CEWHemisphere + "," +
                                                  GlobalVars.CSpeedKnots.ToString() + "," + GlobalVars.CSpeedMph.ToString() + "," +
                                                  GlobalVars.CBearing.ToString() + "," + txtGPSBearing.Text + "," +
                                                  GlobalVars.CSLatRad + "," + GlobalVars.CSLonRad + "," +
                                                  GlobalVars.CX + "," + GlobalVars.CY + "," + GlobalVars.CZ + "," +
                                                  GlobalVars.IncrDistance.ToString() + "," + GlobalVars.CTripDistance.ToString() + "," + DMICnt + "," + TotalDMICnt + "," + string.Format("{0:#.##}", (TotalDMICnt / GlobalVars.DMICalibFactor)) + "," + PressedKey + "," + TriggerDetected);
                                //txtDMICount.Text = "T= " + ((GPSCTMSSM - TripStartTime) / 1000).ToString + "  C= " + TotalDMICnt.ToString() + " - " + GPSDeltaT.ToString() + " MSec  -  " + DMICnt.ToString();
                                txtDMIDistance.Text = string.Format("{0:#.##}", (TotalDMICnt / GlobalVars.DMICalibFactor));
                                txtDMICount.Text = "Secs= " + ((GPSCTMSSM - TripStartTime) / 1000).ToString() + "  Count= " + TotalDMICnt.ToString();
                                DMICnt = 0;
                                TriggerDetected = "";
                                PressedKey = "";
                            }
                            catch (Exception e)
                            {
                                LogTxtMsg(txtLog, e.Message);
                            }
                        }
                        break;
                    }
                    Application.DoEvents();
                    Application.DoEvents();
                    NLLocation = GPSMsg.IndexOf("\n");
                }
            }
            else
            {
                LogTxtMsg(txtLog, "\t" + CurrTime + " :::  " + "No valid sentence was received from port: " + SPGPS.PortName + "\t" + GPSMsg);
            }
            txtLog.Update();
            return (RMCSentenceFound);
        }
        */
    }
}
