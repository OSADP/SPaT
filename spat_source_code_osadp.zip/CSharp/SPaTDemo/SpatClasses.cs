﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace SPaTSystem
{
    #region "class SPAT"

    class SPAT
    {
        public message Message = SPAT.message.Create();

        #region "Enumerations"

        //public enum status { normal = 0, manual = 1, stopped = 2, flash = 4, preempt = 8, priority = 16 };
        public enum status { normal = 0, manual = 1, stopped = 2, faultflash = 4, preempt = 8, priority = 16, coordination = 32, coordinationintransition = 64, programmedflash = 128  };
        public enum pedestrian { unavailable = 0, none = 1, oneormore = 2 };
        public enum maneuvers { pedestrian = 0, straight = 1, leftturn = 2, rightturn = 4, uturn = 8 };

        #endregion

        #region "Structures"

        private struct maneuver
        {
            public List<UInt16> maneuverlane;
            public spatdata data;

            static public maneuver Create()
            {
                maneuver maneuver = new maneuver();
                maneuver.maneuverlane = new List<UInt16>();
                maneuver.data = SPAT.spatdata.Create();
                return maneuver;
            }

            public List<byte> Compile()
            {
                List<byte> payload = new List<byte>();

                //          Compile the Movement Flag
                payload.Add(4);

                //          Compile the Lane Set            
                payload.Add(5);
                payload.Add((byte)(maneuverlane.Count * 2));
                foreach (UInt16 Item in maneuverlane)
                {
                    foreach (byte Byte in Reverse(BitConverter.GetBytes(Item))) { payload.Add(Byte); }
                }

                //          Compile the Movement Data
                foreach (byte Byte in data.Compile()) { payload.Add(Byte); }

                return payload;
            }

        }

        public struct spatdata
        {
            public UInt32 state;
            public UInt16 mintime;
            public UInt16 maxtime;
            public UInt32 yellowstate;
            public UInt16 yellowtime;
            public byte pedestrian;
            public byte count;

            static public spatdata Create()
            {
                spatdata spatdata = new spatdata();
                spatdata.state = 0;
                spatdata.mintime = 0;
                spatdata.maxtime = 0;
                spatdata.yellowstate = 0;
                spatdata.yellowtime = 0;
                spatdata.pedestrian = (byte)SPAT.pedestrian.unavailable;
                spatdata.count = 0;
                return spatdata;
            }

            public List<byte> Compile()
            {
                List<byte> payload = new List<byte>();
                int n;

                //          Encode the Current State
                payload.Add(6);
                payload.Add(0);
                n = payload.Count - 1;
                foreach (byte Byte in Reverse(BitConverter.GetBytes(state))) { if (Byte != 0) { payload.Add(Byte); payload[n]++; } }

                //          Encode the Minimum Time Remaining
                payload.Add(7);
                payload.Add(2);
                foreach (byte Byte in Reverse(BitConverter.GetBytes(Clip(mintime)))) { payload.Add(Byte); }

                //          Encode the Maximum Time Remaining
                payload.Add(8);
                payload.Add(2);
                foreach (byte Byte in Reverse(BitConverter.GetBytes(Clip(maxtime)))) { payload.Add(Byte); }

                //          Encode the Yellow State
                if (yellowstate != 0)
                {
                    payload.Add(9);
                    payload.Add(0);
                    n = payload.Count - 1;
                    foreach (byte Byte in Reverse(BitConverter.GetBytes(yellowstate))) { if (Byte != 0) { payload.Add(Byte); payload[n]++; } }

                    //              Encode the Maximum Time Remaining
                    payload.Add(10);
                    payload.Add(2);
                    foreach (byte Byte in Reverse(BitConverter.GetBytes(Clip(yellowtime)))) { payload.Add(Byte); }
                }

                //          Encode the Pedestrian Detect
                if (pedestrian != (byte)SPAT.pedestrian.unavailable)
                {
                    payload.Add(11);
                    payload.Add(1);
                    payload.Add((byte)pedestrian);
                }

                //          Encode the Count
                if (count != 0)
                {
                    payload.Add(12);
                    payload.Add(1);
                    payload.Add(count);
                }

                return payload;
            }

            public Boolean Equals(spatdata data)
            {
                if (state != data.state) return false;
                if (mintime != data.mintime) return false;
                if (maxtime != data.maxtime) return false;
                if (yellowstate != data.yellowstate) return false;
                if (yellowtime != data.yellowtime) return false;
                if (pedestrian != data.pedestrian) return false;
                if (count != data.count) return false;
                return true;
            }

            public void Copy(spatdata data)
            {
                state = data.state;
                mintime = data.mintime;
                maxtime = data.maxtime;
                yellowstate = data.yellowstate;
                yellowtime = data.yellowtime;
                pedestrian = data.pedestrian;
                count = data.count;
            }

        };

        public struct movement
        {
            public maneuvers type;
            public List<byte> lane;
            public spatdata data;

            static public movement Create()
            {
                movement movement = new movement();
                movement.type = SPAT.maneuvers.straight;
                movement.lane = new List<byte>();
                movement.data = SPAT.spatdata.Create();
                return movement;
            }

        };

        public struct message
        {
            public UInt32 intersectionid;
            public status intersectionstatus;
            public UInt32 timestampseconds;
            public byte timestamptenths;
            public List<movement> movement;

            static public message Create()
            {
                message spat = new message();
                spat.intersectionid = 0;
                spat.intersectionstatus = 0;
                spat.timestampseconds = 0;
                spat.timestamptenths = 0;
                spat.movement = new List<movement>();
                return spat;
            }

            public List<byte> Compile()
            {
                List<byte> payload = new List<byte>();

                //          Compile the Intersection ID
                payload.Add(1);
                payload.Add(4);
                foreach (byte Byte in Reverse(BitConverter.GetBytes(intersectionid))) { payload.Add(Byte); }

                //          Compile the Intersection Status
                payload.Add(2);
                payload.Add(1);
                payload.Add((byte)intersectionstatus);

                //          Compile the Timestamp
                payload.Add(3);
                payload.Add(5);
                foreach (byte Byte in Reverse(BitConverter.GetBytes(timestampseconds))) { payload.Add(Byte); }
                payload.Add(timestamptenths);

                //          Compile Each Geometry Payload
                foreach (maneuver item in compile_maneuvers(movement)) { foreach (byte Byte in item.Compile()) { payload.Add(Byte); } }

                return payload;
            }
        };

        #endregion

        #region "Private Members"

        private static byte[] Reverse(byte[] Bytes)
        {
            byte temp;
            int highCtr = Bytes.Length - 1;

            if (BitConverter.IsLittleEndian)
            {
                for (int ctr = 0; ctr < Bytes.Length / 2; ctr++)
                {
                    temp = Bytes[ctr];
                    Bytes[ctr] = Bytes[highCtr];
                    Bytes[highCtr] = temp;
                    highCtr -= 1;
                }
            }
            return Bytes;
        }

        private static List<maneuver> compile_maneuvers(List<movement> movements)
        {
            List<maneuver> maneuvers = new List<maneuver>();
            List<movement> list = new List<movement>();
            movement movement;
            maneuver maneuver;
            Boolean found;

            //      Create a Working Copy of the Movement List
            foreach (movement Item in movements) { list.Add(Item); }

            //      Combine Like Movements into Common Maneuver Objects
            while (list.Count > 0)
            {
                maneuver = SPAT.maneuver.Create();
                movement = list[0];
                foreach (byte Lane in movement.lane) { maneuver.maneuverlane.Add((UInt16)((((byte)movement.type) << 8) + Lane)); }
                maneuver.data.Copy(movement.data);
                list.Remove(movement);
                for (int index = 0; index < list.Count; index++)
                {
                    if (list[index].data.Equals(movement.data))
                    {
                        foreach (byte Lane in list[index].lane)
                        {
                            found = false;
                            for (int item = 0; item < maneuver.maneuverlane.Count; item++)
                            {
                                if ((maneuver.maneuverlane[item] & 0x00ff) == Lane)
                                {
                                    maneuver.maneuverlane[item] |= (UInt16)(((byte)list[index].type) << 8);
                                    found = true;
                                    break;
                                }
                            }
                            if (!found) { maneuver.maneuverlane.Add((UInt16)((((byte)list[index].type) << 8) + Lane)); }
                        }
                        list.RemoveAt(index--);
                    }
                }
                maneuvers.Add(maneuver);
            }

            //      Return the Maneuver List
            return maneuvers;

        }

        private static UInt16 Clip(UInt16 value)
        {
            if (value == 0xffff) return 1202;
            if (value > 1200) return 1201;
            return value;
        }

        #endregion

        #region "Public Members"

        public List<byte> Compile(byte version)
        {
            List<byte> payload = new List<byte>();

            //      Compile the Message Header
            payload.Add(0x8d);
            payload.Add(version);
            payload.Add(0);
            payload.Add(0);
            foreach (byte Byte in Message.Compile()) { payload.Add(Byte); }
            payload.Add(0xff);

            //      Store the Payload Size
            int i = 2;
            foreach (byte Byte in Reverse(BitConverter.GetBytes((Int16)(payload.Count - 4)))) { payload[i++] = Byte; }

            //      Calculate the CRC Value
            CRC crc = new CRC();
            foreach (byte Byte in Reverse(BitConverter.GetBytes(crc.crc_ccitt(payload)))) { payload.Add(Byte); }

            return payload;
        }

        #endregion

    }

    #endregion

    #region "class CRC"

    class CRC
    {
        static List<UInt16> crc_table;

        #region "Constructor"

        public CRC()
        {
            UInt16 crc, c;

            //      Initialize the CRC Table
            crc_table = new List<UInt16>();
            for (int i = 0; i < 256; i++)
            {
                crc = 0;
                c = (UInt16)(i << 8);
                for (int j = 0; j < 8; j++)
                {
                    if (((crc ^ c) & 0x8000) != 0) { crc = (UInt16)((crc << 1) ^ 0x1021); }
                    else { crc = (UInt16)(crc << 1); }
                    c = (UInt16)(c << 1);
                }
                crc_table.Add(crc);
            }
        }

        #endregion

        #region "Private Members"

        private static UInt16 crc_update(UInt16 crc, byte Byte)
        {
            UInt16 tmp = (UInt16)((crc >> 8) ^ Byte);
            crc = (UInt16)((crc << 8) ^ crc_table[tmp]);
            return crc;
        }

        #endregion

        #region "Public Members"

        public UInt16 crc_ccitt(List<byte> payload)
        {
            UInt16 crc = 0;
            foreach (byte Byte in payload) { crc = crc_update(crc, Byte); }
            return crc;
        }

        #endregion

    }

    #endregion

}
