﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Net;
using System.Net.Sockets;
using System.Xml;
using System.Xml.Linq;

namespace SPaTSystem
{
    public class clsSPATBroadcast
    {
        struct configIP
        {
            public string ip;
            public int port;
        }

        public struct dispatch
        {
            public string version;
            public string type;
            public string psid;
            public int priority;
            public string txmode;
            public int txchannel;
            public int txinterval;
            public string deliverystart;
            public string deliverystop;
            public bool signature;
            public bool encryption;
        }

        public struct configSPATMsgs
        {
            public string filename;
            public int txrate;
            public dispatch dispatch;
        }

        private configIP mobjLocal;
        public string LocalIP
        {
            get { return mobjLocal.ip; }
        }
        public int LocalPort
        {
            get { return mobjLocal.port; }
        }
        private configIP mobjTarget;
        public string TargetIP
        {
            get { return mobjTarget.ip; }
        }
        public int TargetPort
        {
            get { return mobjTarget.port; }
        }
        private configSPATMsgs mobjConfiguration;

        private UdpClient mobjUDPClient;
        private IPEndPoint mobjEndPoint;

        public configSPATMsgs ObjConfiguration
        {
            get { return mobjConfiguration; }
        }

        public string LoadConfiguration(string sFilename, string MsgType)
        {
            string strRetMsg = string.Empty;
            string sTag;
            string sValue;

            //      Load the Configuration File
            try
            {
                XDocument doc = XDocument.Load(sFilename);
                XElement root = doc.Root;

                //      Parse the Configuration File Elements
                foreach (XElement element in root.Elements())
                {
                    sTag = element.Name.ToString();
                    sValue = element.Value.ToString();
                    if (sTag.ToLower() == "localip") { mobjLocal.ip = sValue;  }
                    else if (sTag.ToLower() == "targetip") { mobjTarget.ip = sValue;  }

                    //Parse the Configuration Elements
                    else if (sTag.ToLower() == MsgType)
                    {
                        foreach (XElement child in element.Elements())
                        {
                            sTag = child.Name.ToString();
                            sValue = child.Value.ToString();
                            switch (sTag.ToLower())
                            {
                                //case "default": { mobjSpatConfiguration.filename = sValue; break; }
                                case "localport": { mobjLocal.port = Convert.ToInt32(sValue); break; }
                                case "targetport": { mobjTarget.port = Convert.ToInt32(sValue); break; }
                                case "txrate": { mobjConfiguration.txrate = Convert.ToInt32(sValue); break; }
                                case "dispatch":
                                {
                                    mobjConfiguration.dispatch.type = MsgType.ToUpper();
                                    foreach (XAttribute attribute in child.Attributes())
                                    {
                                        sTag = attribute.Name.ToString();
                                        sValue = attribute.Value.ToString();
                                        switch (sTag.ToLower())
                                        {
                                            case "version": { mobjConfiguration.dispatch.version = sValue; break; }
                                            case "psid": { mobjConfiguration.dispatch.psid = sValue; break; }
                                            case "priority": { mobjConfiguration.dispatch.priority = Convert.ToInt32(sValue); break; }
                                            case "txmode": { mobjConfiguration.dispatch.txmode = sValue; break; }
                                            case "txchannel": { mobjConfiguration.dispatch.txchannel = Convert.ToInt32(sValue); break; }
                                            case "txinterval": { mobjConfiguration.dispatch.txinterval = Convert.ToInt32(sValue); break; }
                                            case "deliverystart": { mobjConfiguration.dispatch.deliverystart = sValue; break; }
                                            case "deliverystop": { mobjConfiguration.dispatch.deliverystop = sValue; break; }
                                            case "signature": { mobjConfiguration.dispatch.signature = Convert.ToBoolean(sValue); break; }
                                            case "encryption": { mobjConfiguration.dispatch.encryption = Convert.ToBoolean(sValue); break; }
                                        }
                                    }
                                    break;
                                }
                            }
                        }
                    }
                }
            }
    //      Error Handler
            catch (Exception Exp)
            {
                strRetMsg = "Error reading configuration file: " + sFilename + "\n" + Exp.Message;
                
                return strRetMsg;
            }

            //      Limit the Transmission Rate
            if (mobjConfiguration.txrate < 1) { mobjConfiguration.txrate = 1; }
            if (mobjConfiguration.txrate > 20) { mobjConfiguration.txrate = 20; }

            //      Return Result
            return strRetMsg;
        }

        public string CreateDispatchHeader(dispatch objDispatch)
        {
            string sHeader = "";

            sHeader += "Version=" + objDispatch.version + "\n";
            sHeader += "Type=" + objDispatch.type + "\n";
            sHeader += "PSID=" + objDispatch.psid + "\n";
            sHeader += "Priority=" + objDispatch.priority.ToString() + "\n";
            sHeader += "TxMode=" + objDispatch.txmode + "\n";
            sHeader += "TxChannel=" + objDispatch.txchannel.ToString() + "\n";
            sHeader += "TxInterval=" + objDispatch.txinterval.ToString() + "\n";
            sHeader += "DeliveryStart=" + objDispatch.deliverystart + "\n";
            sHeader += "DeliveryStop=" + objDispatch.deliverystop + "\n";
            sHeader += "Signature=" + objDispatch.signature.ToString() + "\n";
            sHeader += "Encryption=" + objDispatch.encryption.ToString() + "\n";

            return sHeader;
        }

        public string  CreateUDPClient()
        {
            string retValue = string.Empty;

            //      Create the UDP Client
            try
            {
                IPEndPoint localEndPoint = new IPEndPoint(IPAddress.Parse(mobjLocal.ip), mobjLocal.port);
                mobjUDPClient = new UdpClient(localEndPoint);
                mobjEndPoint = new IPEndPoint(IPAddress.Parse(mobjTarget.ip), mobjTarget.port);
            }

    //      Error Handler
            catch (Exception Exp)
            {
                retValue = "Error creating UDP client with the following addrees: " + mobjLocal.ip.ToString() + "::" + mobjLocal.port.ToString() + ".\n" + Exp.Message;

                return retValue; ;
            }

            return retValue; 
        }

        public string TX(byte[] bytes)
        {
            string retValue = string.Empty; ;
            try
            {
                int bytesSent = mobjUDPClient.Send(bytes, bytes.Length, mobjEndPoint);
            }

    //      Error Handler
            catch (Exception Exp)
            {
                retValue = "Transmission Error.\n" + Exp.Message;
                return retValue;
            }
            return retValue;
        }
    }
}
