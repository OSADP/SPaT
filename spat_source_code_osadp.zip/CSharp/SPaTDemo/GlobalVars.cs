﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Net;
using System.Net.Sockets;
using System.IO.Ports;

namespace SPaTSystem
{
    class GlobalVars
    {
        public enum status { normal = 0, manual = 1, stopped = 2, flash = 4, preempt = 8, priority = 16 };
        public enum pedestrian { unavailable = 0, none = 1, oneormore = 2 };
        public enum maneuvers { straight = 1, leftturn = 2, rightturn = 4, uturn = 8 };

        public enum enum_phase_type { protectedPhase = 1, permittedPhase = 2 };
        public enum enum_Lane_type { unavailable, ped, vehicle, special };
        public enum enum_TSC_control_entity { unavailable, phase, ovlp };
        
        public enum enum_phase_status
        {
            UnAvailable = 0,
            Dark = 1,
            Green = 2,
            Yellow = 3,
            Red = 4,
            RedRivert = 5,
            RedClear = 6,
            Walk = 7,
            DontWalk = 8,
            PedClear = 9,
            FlashingDontWalk = 10,
        }

        public enum enum_lane_movement_status
        {
            Dark = 0x00,
            GreenBall = 0x01,
            YellowBall = 0x02,
            RedBall = 0x04,
            FlashingGreenBall = 0x09,
            FlashingYellowBall = 0x0A,
            FlashingRedBall = 0x0C,

            GreenLeftArrow = 0x10,
            YellowLeftArrow = 0x20,
            RedLeftArrow = 0x40,
            FlashingGreenLeftArrow = 0x90,
            FlashingYellowLeftArrow = 0xA0,
            FlashingRedLeftArrow = 0xC0,
            GreenRightArrow = 0x0100,
            YellowRightArrow = 0x0200,
            RedRightArrow = 0x0400,
            FlashingGreenRightArrow = 0x0900,
            FlashingYellowRightArrow = 0x0A00,
            FlashingRedRightArrow = 0x0C00,

            GreenSoftLeftArrow = 0x010000,
            YellowSoftLeftArrow = 0x020000,
            RedSoftLeftArrow = 0x040000,
            FlashingGreenSoftLeftArrow = 0x090000,
            FlashingYellowSoftLeftArrow = 0x0A0000,
            FlashingRedSoftLeftArrow = 0x0C0000,
            GreenSoftRightArrow = 0x100000,
            YellowSoftRightArrow = 0x200000,
            RedSoftRightArrow = 0x400000,
            FlashingGreenSoftRightArrow = 0x900000,
            FlashingYellowSoftRightArrow = 0xA00000,
            FlashingRedSoftRightArrow = 0xC00000,

            GreenUTurnArrow = 0x01000000,
            YellowUTurnArrow = 0x02000000,
            RedUTurnArrow = 0x41000000,
            FlashingGreenUTurnArrow = 0x09000000,
            FlashingYellowUTurnArrow = 0x0A000000,
            FlashingRedUTurnArrow = 0x0C000000,
        }

        public enum enum_log_file_type
        {
            uknown = 0,
            SPATBroadcastMsg = 1,
            SSMBroadcastMsg = 2,
            DailyLog = 3,
            TSCSPATData = 4
        }

        public struct PriorityStrategy
        {
            public string inLanes;
            public byte vehicleClassType;
            public byte vehicleClassLevel;
            public byte strategyNumber;
            public byte preemptNumber;
        }

        public struct ByteSPATMsg
        {
            public byte[] VMinTime;
            public byte[] VMaxTime;
            public byte[] PedMinTime;
            public byte[] PedMaxTime;
            public byte[] OvlpMinTime;
            public byte[] OvlpMaxTime;
        };

        public struct IntersectionStatusObject
        {
            public bool ManualControlActive;
            public bool StopTimeActive;
            public bool FaultFlashActive;
            public bool PreemptActive;
            public bool TSPActive;
            public bool CoordinationActive;
            public bool CoordinationInTransitionActive;
            public bool ProgrammedFlashActive;
        };

        public struct TSCPedInfo
        {
            public bool DetectionAvailable;
            public bool Call;
            public bool Detect;
        }
        public struct PTLM
        {
            public SPAT.maneuvers Movement;
            public string Lanes;
            public byte LanesType;
            public byte TSCEntityType;
            public int TSCPhsOvlp;
            public byte PhaseType;
            public string PedCalls;
            public string PedDetectors;
            public bool Enabled;

            public uint state;
            public UInt16 minTime;
            public UInt16 maxTime;
            public uint yellowState;
            public UInt16 yellowTime;
            public byte pedestrian;
            public byte count;
        };

        
        public static PTLM[] PTLMTable = new PTLM[100];
        //public static List<PTLM> PTLMList = new List<PTLM>();

        public static int PTLMRecords = 0;
        public static TSCPedInfo[] TSCPed = new TSCPedInfo[17];

        public static string RSEIPV6Address = string.Empty;
        public static string SPATSystemIPV4Address = string.Empty;
        public static int SPATSystemSPATPort = 6053;
        public static string SPATSystemIPV6Address = string.Empty;
        public static string TSCIPV4Address = string.Empty;
        public static int TSCNTCIPPort = 501;

        public static int SPaTMsgLocalPort = 0;
        public static int SPaTMsgTargetPort = 0;

        public static int MAPMsgLocalPort = 0;
        public static int MAPMsgTargetPort = 0;

        public static int SRMMsgLocalPort = 0;
        public static int SRMMsgTargetPort = 0;

        public static int SSMMsgLocalPort = 0;
        public static int SSMMsgTargetPort = 0;

        public static int RTCMMsgLocalPort = 0;
        public static int RTCMMsgTargetPort = 0;


        public static int TimeOutPeriod = 5;

        public static int maxPhases = 16;       //Maximum number of phases supported by the controller
        public static int maxOvlps = 16;       //Maximum number of Ovlps supported by the controller
        public static int maxPhaseGroups = 2;    //Each phase group consists of 8 phases. It indicates the maximum number of phase groups available in the controller
        
        //Some of the phase information in NTCIP is grouped into groups like Phase Yellow state
        public static string IntersectionState = string.Empty;
        public static string IntersectionCity = string.Empty;
        public static string IntersectionName = string.Empty;
        public static uint IntersectionID = 0;

        public static SPAT.status IntersectionStatus = SPAT.status.normal;
        public static uint timestampseconds = 0;
        public static uint timestamptenths = 0;

        public static string SPATDispatchInfoFile = "SPATDispatchInfo.xml";
        public static string PTLMMappingFile = string.Empty;
        public static int MaxNumberofDetectors = 64;
        public static string SPATDailyLogFolderPath = string.Empty;
        public static bool SPATSystemRunning = false;
        public static DateTime ReferenceDate = new DateTime(1970, 1, 1, 0, 0, 0, 0);
        public static bool PedSimulatorEnabled = false;
        public static string SPaTPushCode = "2";
        public static bool PedDetectionAvailable = false;
        
        public static Int64 DataLoggingDispSpaceLimit = (Int64)((Int64)(10)*(1024)*(1024)*(1024));
        public static Int64 OneGB = (Int64)((Int64)(1024) * (1024) * (1024));

        
        public static bool IncludeSRMSSM = false;   //Flag to enable or disable SRM/SSM code.

        //public static string GPSMessage = string.Empty;

        private static int m_gpsUpdateFrequency = 60;     //Update local time every 60 minutes
        public static int GPSUpdateFrequency
        {
            get { return m_gpsUpdateFrequency; }
            set { m_gpsUpdateFrequency = value; }
        }

        public static int GPSTmrCounter = 0;
    }
}
