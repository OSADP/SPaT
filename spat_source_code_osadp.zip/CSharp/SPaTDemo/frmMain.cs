﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Xml;
using System.Xml.Linq;
using System.Net;
using System.Net.Sockets;
using System.IO;
using System.Threading;
using System.IO.Ports;

namespace SPaTSystem
{
    public partial class frmMain : Form
    {
        private const int maxNumberofPreempts = 6;
        private const string preemptControlStateOIDPrefix = "1.3.6.1.4.1.1206.4.2.1.6.3.1.2.";
        private const string preemptStateOIDPrefix = "1.3.6.1.4.1.1206.4.2.1.6.2.1.16.";
        private const int preemptTimeToLive = 30;

        enum OIDTypes
        {
            intOID,
            stringOID
        }

        struct MvmntInfo
        {
            public string m_Info;
            public int m_Number;
            public uint state;
            public SPAT.maneuvers Movement;
        }
        private List<MvmntInfo> MvmntsList = new List<MvmntInfo>();

        private byte ManualControlMask = 1;
        private byte StopTimeMask = 2;
        private byte FaultFlashMask = 4;
        private byte PreemptMask = 8;
        private byte TSPMask = 16;
        private byte CoordinationMask = 32;
        private byte CoordinationinTransitionMask = 64;
        private byte ProgrammedFlashMask = 128;
        private GlobalVars.IntersectionStatusObject IntersectionStatus;

        private byte byteTimeBaseASCActionStatus;
        private int intCurrTimeBaseAscActionStatus = 0;
        private int intPrevTimeBaseAscActionStatus = 0;

        private byte byteDiscontinuousFlag;
        private int intCurrDiscontinuousFlag = 0;
        private int intPrevDiscontinuousFlag = 0;

        private byte byteMsgNo;
        private int intMsgNo;

        private clsNTCIPData NTCIPData = new clsNTCIPData();

        private clsPhase[] Phases;
        private List<clsPhase> PhasesList = new List<clsPhase>();

        private clsPhase[] Ovlps;
        private List<clsPhase> OvlpsList = new List<clsPhase>();

        private clsPhase[] Peds;
        private List<clsPhase> PedsList = new List<clsPhase>();


        private static IPEndPoint ipepBBSPATData; //= new IPEndPoint(IPAddress.Parse(RSEIPAddress), RSEPort);
        private UdpClient TSCListener; //= new UdpClient(ipepBBSPATData);
        private static IPEndPoint TSC; //= new IPEndPoint(IPAddress.Any, 0);

        private static IPEndPoint ipepBBSRMData; //= new IPEndPoint(IPAddress.Parse(RSEIPAddress), SPATSystemSRMPort);
        private UdpClient SRMListener; //= new UdpClient(ipepBBSRMData);
        private static IPEndPoint SRM; //= new IPEndPoint(IPAddress.Any, 0);

        private OIDTypes ReceivedValuesType;
        private int[] intReceivedValues = new int[128];
        private string[] strReceivedValues = new string[128];
        private int NoReceivedValues = 0;

        private UInt16[] PedClear;
        private UInt16[] YellowChange;
        private int[] RedClear;
        private int[] RedRevert;

        string OID = string.Empty;

        private long prevTmrWakeUpTimeMsecs = 0;
        private long currTmrWakeUpTimeMsecs = 0;
        private long endWakeUpTime = 0;
        private long BeginTime = 0;
        private long EndTime = 0;
        private long Duration = 0;
        private long prevTSCTimeMsec = 0;
        private long currTSCTimeMsec = 0;

        private StreamWriter dailyLogFile;
        private StreamWriter spatMsgFile;
        private StreamWriter spatErrorsLog;

        private string FileName;
        public string FilePath;

        //private string SenderFunction = string.Empty;

        private clsSPATBroadcast spatBroadcast = new clsSPATBroadcast();
        private clsSPATBroadcast ssmBroadcast = new clsSPATBroadcast();

        private string SPATDispatchtInfo = string.Empty;
        private string SSMDispatchtInfo = string.Empty;

        private NMEAInterpreter GPSDevice = new NMEAInterpreter();
        private string txtBuffer = string.Empty;
        private byte[] byteBuffer = new byte[10000];
        private bool FoundGPSDevice = false;

        private ASN_r36 ASN_r36; //= new ASN_r36();
        private StreamByte SRMobjStream; //= ASN_r36.CreatePipeStream();


        private List<ASN_r36.SignalRequestMsg_t> ActiveSRMList = new List<ASN_r36.SignalRequestMsg_t>();

        private List<clsSRM> ActiveSRMs = new List<clsSRM>();

        private List<GlobalVars.PriorityStrategy> PriorityStrategytable = new List<GlobalVars.PriorityStrategy>();

        public frmMain()
        {
            InitializeComponent();
        }

        private string OpenDailyLogFile(GlobalVars.enum_log_file_type FileType, ref string Filename)
        {
            string retValue = string.Empty;
            string tmpFileName = string.Empty;
            DateTime DT = DateTime.Now;

            try
            {
                switch (FileType)
                {
                    case GlobalVars.enum_log_file_type.DailyLog:
                        Filename = GlobalVars.SPATDailyLogFolderPath + "SPATDailyLog-" + DT.Year.ToString() + "-" + DT.Month.ToString() + "-" + DT.Day.ToString() + "-" +
                                                  DT.Hour.ToString() + "-" + DT.Minute.ToString() + "-" + DT.Second.ToString() + ".DLog";
                        dailyLogFile = new StreamWriter(Filename);
                        dailyLogFile.WriteLine(DateTime.Now.ToString() + "--New logfile");
                        break;
                    case GlobalVars.enum_log_file_type.SPATBroadcastMsg:
                        Filename = GlobalVars.SPATDailyLogFolderPath + "SPATMsg-" + DT.Year.ToString() + "-" + DT.Month.ToString() + "-" + DT.Day.ToString() + "-" +
                                                   DT.Hour.ToString() + "-" + DT.Minute.ToString() + "-" + DT.Second.ToString() + ".SPATMsg";
                        spatMsgFile = new StreamWriter(Filename);
                        spatMsgFile.WriteLine(DateTime.Now.ToString() + "--New SPATMsg logfile");
                        break;
                }
            }
            catch (Exception e)
            {
                retValue = e.Message;
            }
            return retValue;
        }

        private string GetCurrentTimeStamp()
        {
            return (DateTime.Now.Month.ToString() + "/" + DateTime.Now.Day.ToString() + "/" + DateTime.Now.Year.ToString() + " - " +
                    DateTime.Now.Hour.ToString() + ":" + DateTime.Now.Minute.ToString() + ":" + DateTime.Now.Second.ToString() + ":" + DateTime.Now.Millisecond.ToString());
        }
        private string WriteMsgToLogFile(StreamWriter LogFile, string Msg)
        {
            string retValue = string.Empty;
            DateTime DT = DateTime.Now;

            try
            {
                if (LogFile != null)
                {
                    LogFile.WriteLine(Msg);
                }
                else
                {
                    retValue = "WriteMsgToDailyLogFile: \tLog file " + LogFile + " is not open to write msg: " + Msg;
                }
            }
            catch (Exception ex)
            {
                //Send email msg to Hassan Charara with the following error
                retValue = "WriteMsgToDailyLogFile: Error in writing msg to dailyLogFile. \r\n\tMsg: " + Msg +
                           "\r\nLogfile: " + LogFile +
                           "\r\n\tExceptionErrorMsg: " + ex.Message;
            }
            return retValue;
        }

        private string ReadSPaTConfigFile(string SpatConfigFile)
        {
            string retValue = string.Empty;
            //Port gpsPort = new Port();

            try
            {
                XDocument doc = XDocument.Load(SpatConfigFile);
                XElement root = doc.Root;

                string strTagName = string.Empty;
                string strTagValue = string.Empty;

                foreach (XElement element in root.Elements())
                {
                    strTagName = element.Name.ToString();
                    strTagValue = element.Value.ToString();

                    if (strTagName.ToUpper() == "TSCIPV4Address".ToUpper())
                    {
                        GlobalVars.TSCIPV4Address = strTagValue;
                        txtTSCIPV4Address.Text = strTagValue;
                        LogTxtMsg(txtActivityLog, "\t--TSCIPV4Address: " + strTagValue);
                    }
                    else if (strTagName.ToUpper() == "SPATSystemIPV4Address".ToUpper())
                    {
                        GlobalVars.SPATSystemIPV4Address = strTagValue;
                        txtSPATSystemIPV4Address.Text = GlobalVars.SPATSystemIPV4Address;
                        LogTxtMsg(txtActivityLog, "\t--SPATSystemIPV4Address: " + strTagValue);
                    }
                    else if (strTagName.ToUpper() == "localip".ToUpper())
                    {
                        GlobalVars.SPATSystemIPV6Address = strTagValue;
                        txtSPATSystemIPV6Address.Text = GlobalVars.SPATSystemIPV6Address;
                        LogTxtMsg(txtActivityLog, "\t--SPATSystemIPV6Address: " + strTagValue);
                    }
                    else if (strTagName.ToUpper() == "targetip".ToUpper())
                    {
                        GlobalVars.RSEIPV6Address = strTagValue;
                        txtRSEIPV6Address.Text = GlobalVars.RSEIPV6Address;
                        LogTxtMsg(txtActivityLog, "\t--RSEIPV6Address: " + strTagValue);
                    }
                    else if (strTagName.ToUpper() == "TSCNTCIPPort".ToUpper())
                    {
                        GlobalVars.TSCNTCIPPort = Convert.ToInt32(strTagValue);
                        txtTSCNTCIPPort.Text = strTagValue;
                        LogTxtMsg(txtActivityLog, "\t--TSCNTCIPPort: " + strTagValue);
                    }
                    else if (strTagName.ToUpper() == "SPATSystemSPATPort".ToUpper())
                    {
                        GlobalVars.SPATSystemSPATPort = Convert.ToInt32(strTagValue);
                        txtSPATSystemSPATPort.Text = strTagValue;
                        LogTxtMsg(txtActivityLog, "\t--SPATSystemSPATPort: " + strTagValue);
                    }
                    else if (strTagName.ToUpper() == "PTLMMappingFile".ToUpper())
                    {
                        GlobalVars.PTLMMappingFile = strTagValue;
                        txtPTLMFile.Text = GlobalVars.PTLMMappingFile;
                        LogTxtMsg(txtActivityLog, "\t--PTLMMappingFile: " + GlobalVars.PTLMMappingFile);
                    }
                    else if (strTagName.ToUpper() == "LogDataDir".ToUpper())
                    {
                        GlobalVars.SPATDailyLogFolderPath = strTagValue;
                        txtSPATDailyLogFolder.Text = GlobalVars.SPATDailyLogFolderPath;
                        LogTxtMsg(txtActivityLog, "\t--SPAT Daily Log Dir: " + GlobalVars.SPATDailyLogFolderPath);
                    }
                    else if (strTagName.ToUpper() == "spatpushcode".ToUpper())
                    {
                        GlobalVars.SPaTPushCode = strTagValue;
                        txtOIDValue.Text = GlobalVars.SPaTPushCode;
                        txtSPaTPushCode.Text = GlobalVars.SPaTPushCode;
                        LogTxtMsg(txtActivityLog, "\t--TSC SPaT Push Code: " + GlobalVars.SPaTPushCode);
                    }
                    else if (strTagName.ToUpper() == "gpsupdatefrequency".ToUpper())
                    {
                        GlobalVars.GPSUpdateFrequency = Convert.ToInt32( strTagValue);
                        txtGPSUpdateFrequency.Text = strTagValue;
                        LogTxtMsg(txtActivityLog, "\t--GPSUpdateFrequency: " + strTagValue);
                    }
                    else if (strTagName.ToUpper() == "GPSPort".ToUpper())
                    {
                        foreach (XElement child in element.Elements())
                        {
                            strTagName = child.Name.ToString();
                            strTagValue = child.Value.ToString();
                            switch (strTagName)
                            {
                                case "portname":
                                {
                                    spGPS.PortName = strTagValue;    
                                    switch (strTagValue.ToLower())
                                    {
                                        case "com1": { cmbPortName.SelectedIndex = 0; break; }
                                        case "com2": { cmbPortName.SelectedIndex = 1; break; }
                                        case "com3": { cmbPortName.SelectedIndex = 2; break; }
                                        case "com4": { cmbPortName.SelectedIndex = 3; break; }
                                        case "com5": { cmbPortName.SelectedIndex = 4; break; }
                                        case "com6": { cmbPortName.SelectedIndex = 5; break; }
                                        case "com7": { cmbPortName.SelectedIndex = 6; break; }
                                        case "com8": { cmbPortName.SelectedIndex = 7; break; }
                                        case "com9": { cmbPortName.SelectedIndex = 8; break; }
                                        case "com10": { cmbPortName.SelectedIndex =9; break; }
                                        case "com11": { cmbPortName.SelectedIndex = 10; break; }
                                        case "com12": { cmbPortName.SelectedIndex = 11; break; }
                                        case "com13": { cmbPortName.SelectedIndex = 12; break; }
                                        case "com14": { cmbPortName.SelectedIndex = 13; break; }
                                        case "com15": { cmbPortName.SelectedIndex = 14; break; }
                                        case "com16": { cmbPortName.SelectedIndex = 15; break; }
                                        case "com17": { cmbPortName.SelectedIndex = 16; break; }
                                        case "com18": { cmbPortName.SelectedIndex = 17; break; }
                                        case "com19": { cmbPortName.SelectedIndex = 18; break; }
                                        case "com20": { cmbPortName.SelectedIndex = 19; break; }
                                    }
                                    break;
                                }
                                case "baudrate": 
                                {
                                    spGPS.BaudRate = Convert.ToInt32(strTagValue);
                                    switch (strTagValue.ToLower())
                                    {
                                        case "1200": { cmbBaudRate.SelectedIndex = 0; break; }
                                        case "2400": { cmbBaudRate.SelectedIndex = 1; break; }
                                        case "4800": { cmbBaudRate.SelectedIndex = 2; break; }
                                        case "9600": { cmbBaudRate.SelectedIndex = 3; break; }
                                        case "19200": { cmbBaudRate.SelectedIndex = 4; break; }
                                        case "38400": { cmbBaudRate.SelectedIndex = 5; break; }
                                        case "57600": { cmbBaudRate.SelectedIndex = 6; break; }
                                        case "115200": { cmbBaudRate.SelectedIndex = 7; break; }
                                    }
                                    break;
                                }
                                case "databits": 
                                {
                                    spGPS.DataBits = Convert.ToInt32(strTagValue);
                                    switch (strTagValue.ToLower())
                                    {
                                        case "7": { cmbDataBits.SelectedIndex = 0; break; }
                                        case "8": { cmbDataBits.SelectedIndex = 1; break; }
                                        case "9": { cmbDataBits.SelectedIndex = 2; break; }
                                    }
                                    break;
                                }
                                case "stopbits": 
                                {
                                    switch (strTagValue.ToLower())
                                    {
                                        case "1": { cmbStopBits.SelectedIndex = 0; spGPS.StopBits = StopBits.One; break; }
                                        case "1.5": { cmbStopBits.SelectedIndex = 1; spGPS.StopBits = StopBits.OnePointFive; break; }
                                        case "2": { cmbStopBits.SelectedIndex = 2; spGPS.StopBits = StopBits.Two; break; }
                                        case "none": { cmbStopBits.SelectedIndex = 3; spGPS.StopBits = StopBits.None; break; }
                                    }
                                    break;
                                }
                                case "handshake": 
                                {
                                    switch (strTagValue.ToLower())
                                    {
                                        case "none": { cmbHandShake.SelectedIndex = 0; spGPS.Handshake = Handshake.None; break; }
                                        case "xonxoff": { cmbHandShake.SelectedIndex = 1; spGPS.Handshake = Handshake.XOnXOff; break; }
                                        case "send": { cmbHandShake.SelectedIndex = 2; spGPS.Handshake = Handshake.RequestToSend; break; }
                                        case "sendxonxoff": { cmbHandShake.SelectedIndex = 3; spGPS.Handshake = Handshake.RequestToSendXOnXOff; break; }
                                    }
                                    break;
                                }
                                case "parity": 
                                {
                                    switch (strTagValue.ToLower())
                                    {
                                        case "none": { cmbParity.SelectedIndex = 0; spGPS.Parity = Parity.None; break; }
                                        case "even": { cmbParity.SelectedIndex = 1; spGPS.Parity = Parity.Even; break; }
                                        case "odd": { cmbParity.SelectedIndex = 2; spGPS.Parity = Parity.Odd; break; }
                                        case "mark": { cmbParity.SelectedIndex = 3; spGPS.Parity = Parity.Mark; break; }
                                        case "space": { cmbParity.SelectedIndex = 4; spGPS.Parity = Parity.Space; break; }
                                    }
                                    break;
                                }
                            }
                        }
                    }

                    else if (strTagName.ToUpper() == "PedDetection".ToUpper())
                    {
                        foreach (XElement child in element.Elements())
                        {
                            strTagName = child.Name.ToString();
                            strTagValue = child.Value.ToString();
                            switch (strTagName.ToLower())
                            {
                                case "pedphase1":
                                    {
                                        GlobalVars.TSCPed[1].DetectionAvailable = Convert.ToBoolean(strTagValue);
                                        LogTxtMsg(txtActivityLog, "\t--PedPhase 1 ped detection avialable: " + strTagValue);
                                        break;
                                    }
                                case "pedphase2":
                                    {
                                        GlobalVars.TSCPed[2].DetectionAvailable = Convert.ToBoolean(strTagValue);
                                        LogTxtMsg(txtActivityLog, "\t--PedPhase 2 ped detection avialable: " + strTagValue);
                                        break;
                                    }
                                case "pedphase3":
                                    {
                                        GlobalVars.TSCPed[3].DetectionAvailable = Convert.ToBoolean(strTagValue);
                                        LogTxtMsg(txtActivityLog, "\t--PedPhase 3 ped detection avialable: " + strTagValue);
                                        break;
                                    }
                                case "pedphase4":
                                    {
                                        GlobalVars.TSCPed[4].DetectionAvailable = Convert.ToBoolean(strTagValue);
                                        LogTxtMsg(txtActivityLog, "\t--PedPhase 4 ped detection avialable: " + strTagValue);
                                        break;
                                    }
                                case "pedphase5":
                                    {
                                        GlobalVars.TSCPed[5].DetectionAvailable = Convert.ToBoolean(strTagValue);
                                        LogTxtMsg(txtActivityLog, "\t--PedPhase 5 ped detection avialable: " + strTagValue);
                                        break;
                                    }
                                case "pedphase6":
                                    {
                                        GlobalVars.TSCPed[6].DetectionAvailable = Convert.ToBoolean(strTagValue);
                                        LogTxtMsg(txtActivityLog, "\t--PedPhase 6 ped detection avialable: " + strTagValue);
                                        break;
                                    }
                                case "pedphase7":
                                    {
                                        GlobalVars.TSCPed[7].DetectionAvailable = Convert.ToBoolean(strTagValue);
                                        LogTxtMsg(txtActivityLog, "\t--PedPhase 7 ped detection avialable: " + strTagValue);
                                        break;
                                    }
                                case "pedphase8":
                                    {
                                        GlobalVars.TSCPed[8].DetectionAvailable = Convert.ToBoolean(strTagValue);
                                        LogTxtMsg(txtActivityLog, "\t--PedPhase8 ped detection avialable: " + strTagValue);
                                        break;
                                    }
                                case "pedphase9":
                                    {
                                        GlobalVars.TSCPed[9].DetectionAvailable = Convert.ToBoolean(strTagValue);
                                        LogTxtMsg(txtActivityLog, "\t--PedPhase 9 ped detection avialable: " + strTagValue);
                                        break;
                                    }
                                case "pedphase10":
                                    {
                                        GlobalVars.TSCPed[10].DetectionAvailable = Convert.ToBoolean(strTagValue);
                                        LogTxtMsg(txtActivityLog, "\t--PedPhase 10 ped detection avialable: " + strTagValue);
                                        break;
                                    }
                                case "pedphase11":
                                    {
                                        GlobalVars.TSCPed[11].DetectionAvailable = Convert.ToBoolean(strTagValue);
                                        LogTxtMsg(txtActivityLog, "\t--PedPhase 11 ped detection avialable: " + strTagValue);
                                        break;
                                    }
                                case "pedphase12":
                                    {
                                        GlobalVars.TSCPed[12].DetectionAvailable = Convert.ToBoolean(strTagValue);
                                        LogTxtMsg(txtActivityLog, "\t--PedPhase 12 ped detection avialable: " + strTagValue);
                                        break;
                                    }
                                case "pedphase13":
                                    {
                                        GlobalVars.TSCPed[13].DetectionAvailable = Convert.ToBoolean(strTagValue);
                                        LogTxtMsg(txtActivityLog, "\t--PedPhase 13 ped detection avialable: " + strTagValue);
                                        break;
                                    }
                                case "pedphase14":
                                    {
                                        GlobalVars.TSCPed[14].DetectionAvailable = Convert.ToBoolean(strTagValue);
                                        LogTxtMsg(txtActivityLog, "\t--PedPhase 14 ped detection avialable: " + strTagValue);
                                        break;
                                    }
                                case "pedphase15":
                                    {
                                        GlobalVars.TSCPed[15].DetectionAvailable = Convert.ToBoolean(strTagValue);
                                        LogTxtMsg(txtActivityLog, "\t--PedPhase 15 ped detection avialable: " + strTagValue);
                                        break;
                                    }
                                case "pedphase16":
                                    {
                                        GlobalVars.TSCPed[16].DetectionAvailable = Convert.ToBoolean(strTagValue);
                                        LogTxtMsg(txtActivityLog, "\t--PedPhase 16 ped detection avialable: " + strTagValue);
                                        break;
                                    }
                            }
                        }
                    }
                    else if (strTagName.ToUpper() == "PriorityStrategies".ToUpper())
                    {
                        foreach (XElement child in element.Elements())
                        {
                            GlobalVars.PriorityStrategy strategy = new GlobalVars.PriorityStrategy();

                            strTagName = child.Name.ToString();
                            strTagValue = child.Value.ToString();
                            strategy.strategyNumber = Convert.ToByte(strTagValue);
                            foreach (XAttribute attribute in child.Attributes())
                            {
                                strTagName = attribute.Name.ToString();
                                strTagValue = attribute.Value.ToString();
                                switch (strTagName)
                                {
                                    case "inlanes": { strategy.inLanes = "," + strTagValue + ","; break; }
                                    case "vclasstype": { strategy.vehicleClassType = Convert.ToByte(strTagValue); break; }
                                    case "vclasslevel": { strategy.vehicleClassLevel = Convert.ToByte(strTagValue); break; }
                                    case "preempt": { strategy.preemptNumber = Convert.ToByte(strTagValue); break; }
                                }
                            }
                            PriorityStrategytable.Add(strategy);
                        }
                    }
                    else if (strTagName.ToUpper() == "SPAT".ToUpper())
                    {
                        foreach (XElement child in element.Elements())
                        {
                            strTagName = child.Name.ToString();
                            strTagValue = child.Value.ToString();
                            switch (strTagName.ToLower())
                            {
                                case "localport": 
                                { 
                                    GlobalVars.SPaTMsgLocalPort = Convert.ToInt32(strTagValue);
                                    txtSpatMsgLocalPort.Text = strTagValue;
                                    LogTxtMsg(txtActivityLog, "\t--SPaTMsgLocalPort: " + strTagValue);
                                    break; 
                                }
                                case "targetport": 
                                { 
                                    GlobalVars.SPaTMsgTargetPort = Convert.ToInt32(strTagValue);
                                    txtSpatMsgTargetPort.Text = strTagValue;
                                    LogTxtMsg(txtActivityLog, "\t--SPaTMsgTargetPort: " + strTagValue);
                                    break; 
                                }
                                //case "dispatch":
                                //{
                                //    mobjMapConfiguration.dispatch.type = "SPAT";
                                //    foreach (XAttribute attribute in child.Attributes())
                                //    {
                                //        strTagName = attribute.Name.ToString();
                                //        strTagValue = attribute.Value.ToString();
                                //        switch (strTagName.ToUpper())
                                //        {
                                //            case "version": { SPAtBroadcastMsg.SpatConfiguration.dispatch.version = strTagValue; break; }
                                //            case "psid": { mobjMapConfiguration.dispatch.psid = strTagValue; break; }
                                //            case "priority": { mobjMapConfiguration.dispatch.priority = Convert.ToInt32(strTagValue); break; }
                                //            case "txmode": { mobjMapConfiguration.dispatch.txmode = strTagValue; break; }
                                //            case "txchannel": { mobjMapConfiguration.dispatch.txchannel = Convert.ToInt32(strTagValue); break; }
                                //            case "txinterval": { mobjMapConfiguration.dispatch.txinterval = Convert.ToInt32(strTagValue); break; }
                                //            case "deliverystart": { mobjMapConfiguration.dispatch.deliverystart = strTagValue; break; }
                                //            case "deliverystop": { mobjMapConfiguration.dispatch.deliverystop = strTagValue; break; }
                                //            case "signature": { mobjMapConfiguration.dispatch.signature = Convert.ToBoolean(strTagValue); break; }
                                //            case "encryption": { mobjMapConfiguration.dispatch.encryption = Convert.ToBoolean(strTagValue); break; }
                                //        }
                                //    }
                                //    break;
                                //}
                            }
                        }
                    }
                    else if (strTagName.ToUpper() == "MAP".ToUpper())
                    {
                        foreach (XElement child in element.Elements())
                        {
                            strTagName = child.Name.ToString();
                            strTagValue = child.Value.ToString();
                            switch (strTagName.ToLower())
                            {
                                case "localport":
                                    {
                                        GlobalVars.MAPMsgLocalPort = Convert.ToInt32(strTagValue);
                                        txtMapMsgLocalPort.Text = strTagValue;
                                        LogTxtMsg(txtActivityLog, "\t--MAPMsgLocalPort: " + strTagValue);
                                        break;
                                    }
                                case "targetport":
                                    {
                                        GlobalVars.MAPMsgTargetPort = Convert.ToInt32(strTagValue);
                                        txtMapMsgTargetPort.Text = strTagValue;
                                        LogTxtMsg(txtActivityLog, "\t--MAPMsgTargetPort: " + strTagValue);
                                        break;
                                    }
                            }
                        }
                    }
                    else if (strTagName.ToUpper() == "SRM".ToUpper())
                    {
                        foreach (XElement child in element.Elements())
                        {
                            strTagName = child.Name.ToString();
                            strTagValue = child.Value.ToString();
                            switch (strTagName.ToLower())
                            {
                                case "localport":
                                    {
                                        GlobalVars.SRMMsgLocalPort = Convert.ToInt32(strTagValue);
                                        txtSRMMsgLocalPort.Text = strTagValue;
                                        LogTxtMsg(txtActivityLog, "\t--SRMMsgLocalPort: " + strTagValue);
                                        break;
                                    }
                                case "targetport":
                                    {
                                        GlobalVars.SRMMsgTargetPort = Convert.ToInt32(strTagValue);
                                        txtSRMMsgTargetPort.Text = strTagValue;
                                        LogTxtMsg(txtActivityLog, "\t--SRMMsgTargetPort: " + strTagValue);
                                        break;
                                    }
                            }
                        }
                    }
                    else if (strTagName.ToUpper() == "SSM".ToUpper())
                    {
                        foreach (XElement child in element.Elements())
                        {
                            strTagName = child.Name.ToString();
                            strTagValue = child.Value.ToString();
                            switch (strTagName.ToLower())
                            {
                                case "localport":
                                    {
                                        GlobalVars.SSMMsgLocalPort = Convert.ToInt32(strTagValue);
                                        txtSSMMsgLocalPort.Text = strTagValue;
                                        LogTxtMsg(txtActivityLog, "\t--SSMMsgLocalPort: " + strTagValue);
                                        break;
                                    }
                                case "targetport":
                                    {
                                        GlobalVars.SSMMsgTargetPort = Convert.ToInt32(strTagValue);
                                        txtSSMMsgTargetPort.Text = strTagValue;
                                        LogTxtMsg(txtActivityLog, "\t--SSMMsgTargetPort: " + strTagValue);
                                        break;
                                    }
                            }
                        }
                    }
                    else if (strTagName.ToUpper() == "RTCM".ToUpper())
                    {
                        foreach (XElement child in element.Elements())
                        {
                            strTagName = child.Name.ToString();
                            strTagValue = child.Value.ToString();
                            switch (strTagName.ToLower())
                            {
                                case "localport":
                                    {
                                        GlobalVars.RTCMMsgLocalPort = Convert.ToInt32(strTagValue);
                                        txtRTCMMsgLocalPort.Text = strTagValue;
                                        LogTxtMsg(txtActivityLog, "\t--RTCMMsgLocalPort: " + strTagValue);
                                        break;
                                    }
                                case "targetport":
                                    {
                                        GlobalVars.RTCMMsgTargetPort = Convert.ToInt32(strTagValue);
                                        txtRTCMMsgTargetPort.Text = strTagValue;
                                        LogTxtMsg(txtActivityLog, "\t--RTCMMsgTargetPort: " + strTagValue);
                                        break;
                                    }
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                retValue = "\r\n--Error while reading the SPaT configuration file: " + SpatConfigFile +
                           "\r\n\t" + ex.Message;
                return retValue;
            }
            for (int i = 1; i <= 16; i++)
            {
                bool detectionAvailable = false;
                if (GlobalVars.TSCPed[i].DetectionAvailable == true)
                {
                    detectionAvailable = true;
                }
                else
                {
                    detectionAvailable = false;
                }
                switch (i)
                {
                    case 1:
                        chkPedDetectPhase1.Checked = detectionAvailable;
                        break;
                    case 2:
                        chkPedDetectPhase2.Checked = detectionAvailable;
                        break;
                    case 3:
                        chkPedDetectPhase3.Checked = detectionAvailable;
                        break;
                    case 4:
                        chkPedDetectPhase4.Checked = detectionAvailable;
                        break;
                    case 5:
                        chkPedDetectPhase5.Checked = detectionAvailable;
                        break;
                    case 6:
                        chkPedDetectPhase6.Checked = detectionAvailable;
                        break;
                    case 7:
                        chkPedDetectPhase7.Checked = detectionAvailable;
                        break;
                    case 8:
                        chkPedDetectPhase8.Checked = detectionAvailable;
                        break;
                    case 9:
                        chkPedDetectPhase9.Checked = detectionAvailable;
                        break;
                    case 10:
                        chkPedDetectPhase10.Checked = detectionAvailable;
                        break;
                    case 11:
                        chkPedDetectPhase11.Checked = detectionAvailable;
                        break;
                    case 12:
                        chkPedDetectPhase12.Checked = detectionAvailable;
                        break;
                    case 13:
                        chkPedDetectPhase13.Checked = detectionAvailable;
                        break;
                    case 14:
                        chkPedDetectPhase14.Checked = detectionAvailable;
                        break;
                    case 15:
                        chkPedDetectPhase15.Checked = detectionAvailable;
                        break;
                    case 16:
                        chkPedDetectPhase16.Checked = detectionAvailable;
                        break;
                }
            }
            return retValue;
        }

        private string ReadPTLMMappingFile(string PTLMFile, ref int NoMovements)
        {
            string retValue = string.Empty;
            NoMovements = 0;
            int i = 0;
            try
            {
                XDocument doc = XDocument.Load(PTLMFile);
                XElement root = doc.Root;

                string strTagName = string.Empty;
                string strTagValue = string.Empty;

                foreach (XElement element in root.Elements())
                {
                    strTagName = element.Name.ToString();
                    strTagValue = element.Value.ToString();

                    if (strTagName.ToUpper() == "Intersection".ToUpper())
                    {
                        foreach (XElement s in element.Elements())
                        {
                            strTagName = s.Name.ToString();
                            strTagValue = s.Value.ToString();

                            if (strTagName.ToUpper() == "Name".ToUpper())
                            {
                                GlobalVars.IntersectionName = strTagValue;
                                txtIntersectionName.Text = GlobalVars.IntersectionName;
                                LogTxtMsg(txtActivityLog, "\t--IntersectionName: " + GlobalVars.IntersectionName);
                            }
                            else if (strTagName.ToUpper() == "ID".ToUpper())
                            {
                                GlobalVars.IntersectionID = Convert.ToUInt32(strTagValue);
                                txtIntersectionID.Text = GlobalVars.IntersectionID.ToString();
                                LogTxtMsg(txtActivityLog, "\t--IntersectionID: " + GlobalVars.IntersectionID.ToString());
                            }
                            else if (strTagName.ToUpper() == "City".ToUpper())
                            {
                                GlobalVars.IntersectionCity = strTagValue;
                                txtCity.Text = GlobalVars.IntersectionCity;
                                LogTxtMsg(txtActivityLog, "\t--IntersectionCity: " + GlobalVars.IntersectionCity);
                            }
                            else if (strTagName.ToUpper() == "State".ToUpper())
                            {
                                GlobalVars.IntersectionState = strTagValue;
                                txtState.Text = GlobalVars.IntersectionState;
                                LogTxtMsg(txtActivityLog, "\t--IntersectionState: " + GlobalVars.IntersectionState);
                            }
                        }
                    }

                    else if (strTagName.ToUpper() == "SPATMovement".ToUpper())
                    {
                        LogTxtMsg(txtActivityLog, "\r\n\t--Movement: " + i.ToString());
                        foreach (XElement m in element.Elements())
                        {
                            strTagName = m.Name.ToString();
                            strTagValue = m.Value.ToString();

                            if (strTagName.ToUpper() == "Movement".ToUpper())
                            {
                                if (strTagValue.ToUpper() == "Straight".ToUpper())
                                {
                                    GlobalVars.PTLMTable[i].Movement = SPAT.maneuvers.straight;
                                    LogTxtMsg(txtActivityLog, "\t\t--Straight");
                                }
                                else if (strTagValue.ToUpper() == "Left".ToUpper())
                                {
                                    GlobalVars.PTLMTable[i].Movement = SPAT.maneuvers.leftturn;
                                    LogTxtMsg(txtActivityLog, "\t\t--Left");
                                }
                                else if (strTagValue.ToUpper() == "Right".ToUpper())
                                {
                                    GlobalVars.PTLMTable[i].Movement = SPAT.maneuvers.rightturn;
                                    LogTxtMsg(txtActivityLog, "\t\t--Right");
                                }
                                else if (strTagValue.ToUpper() == "Uturn".ToUpper())
                                {
                                    GlobalVars.PTLMTable[i].Movement = SPAT.maneuvers.uturn;
                                    LogTxtMsg(txtActivityLog, "\t\t--Uturn");
                                }
                                else if (strTagValue.ToUpper() == "ped".ToUpper())
                                {
                                    GlobalVars.PTLMTable[i].Movement = SPAT.maneuvers.pedestrian;
                                    LogTxtMsg(txtActivityLog, "\t\t--Ped");
                                }
                            }
                            else if (strTagName.ToUpper() == "Lanes".ToUpper())
                            {
                                GlobalVars.PTLMTable[i].Lanes = strTagValue;
                                LogTxtMsg(txtActivityLog, "\t\t--Lanes: " + strTagValue);
                            }
                            else if (strTagName.ToUpper() == "LanesType".ToUpper())
                            {
                                if (strTagValue.ToUpper() == "Ped".ToUpper())
                                {
                                    GlobalVars.PTLMTable[i].LanesType = (byte)GlobalVars.enum_Lane_type.ped;
                                    LogTxtMsg(txtActivityLog, "\t\t--LnaeType: Ped");
                                }
                                else if (strTagValue.ToUpper() == "vehicle".ToUpper())
                                {
                                    GlobalVars.PTLMTable[i].LanesType = (byte)GlobalVars.enum_Lane_type.vehicle;
                                    LogTxtMsg(txtActivityLog, "\t\t--LnaeType: Vehicle");
                                }
                                else if (strTagValue.ToUpper() == "special".ToUpper())
                                {
                                    GlobalVars.PTLMTable[i].LanesType = (byte)GlobalVars.enum_Lane_type.special;
                                    LogTxtMsg(txtActivityLog, "\t\t--LnaeType: Special");
                                }
                            }
                            else if (strTagName.ToUpper() == "Phase".ToUpper())
                            {
                                GlobalVars.PTLMTable[i].TSCEntityType = (byte)GlobalVars.enum_TSC_control_entity.phase;
                                GlobalVars.PTLMTable[i].TSCPhsOvlp = Convert.ToInt32(strTagValue);
                                LogTxtMsg(txtActivityLog, "\t\t--Phase " + GlobalVars.PTLMTable[i].TSCPhsOvlp.ToString());
                            }
                            else if (strTagName.ToUpper() == "Ovlp".ToUpper())
                            {
                                GlobalVars.PTLMTable[i].TSCEntityType = (byte)GlobalVars.enum_TSC_control_entity.ovlp;
                                GlobalVars.PTLMTable[i].TSCPhsOvlp = Convert.ToInt32(strTagValue);
                                LogTxtMsg(txtActivityLog, "\t\t--Ovlp " + GlobalVars.PTLMTable[i].TSCPhsOvlp.ToString());
                            }
                            else if (strTagName.ToUpper() == "pedCalls".ToUpper())
                            {
                                GlobalVars.PTLMTable[i].PedCalls = strTagValue;
                                LogTxtMsg(txtActivityLog, "\t\t--PedCalls " + strTagValue);
                            }
                            else if (strTagName.ToUpper() == "pedDetectors".ToUpper())
                            {
                                GlobalVars.PTLMTable[i].PedDetectors = strTagValue;
                                LogTxtMsg(txtActivityLog, "\t\t--PedDetectors " + strTagValue);
                            }
                            else if (strTagName.ToUpper() == "PhaseType".ToUpper())
                            {
                                if (strTagValue.ToUpper() == "Protected".ToUpper())
                                {
                                    GlobalVars.PTLMTable[i].PhaseType = (byte)GlobalVars.enum_phase_type.protectedPhase;
                                    LogTxtMsg(txtActivityLog, "\t\t--Protected: ");
                                }
                                else if (strTagValue.ToUpper() == "Permitted".ToUpper())
                                {
                                    GlobalVars.PTLMTable[i].PhaseType = (byte)GlobalVars.enum_phase_type.permittedPhase;
                                    LogTxtMsg(txtActivityLog, "\t\t--Permitted: ");
                                }
                            }
                            else if (strTagName.ToUpper() == "MovementType".ToUpper())
                            {
                                if (strTagValue.ToUpper() == "Protected".ToUpper())
                                {
                                    GlobalVars.PTLMTable[i].PhaseType = (byte)GlobalVars.enum_phase_type.protectedPhase;
                                    LogTxtMsg(txtActivityLog, "\t\t--Protected: ");
                                }
                                else if (strTagValue.ToUpper() == "Permitted".ToUpper())
                                {
                                    GlobalVars.PTLMTable[i].PhaseType = (byte)GlobalVars.enum_phase_type.permittedPhase;
                                    LogTxtMsg(txtActivityLog, "\t\t--Permitted: ");
                                }
                            }
                        }
                        i++;
                    }
                }
            }
            catch (Exception ex)
            {
                retValue = "\r\n--Error while reading the PTLM Mapping file: " + PTLMFile +
                           "\r\n\t" + ex.Message;
                return retValue;
            }
            NoMovements = i;
            return retValue;
        }
        private void EnableDataLoggingOptions()
        {
            chkSPaTMsg.Checked = false;
            chkTSCData.Checked = false;
            chkLaneMvmnt.Checked = false;
            chkSPaTMsg.Enabled = true;
            chkTSCData.Enabled = true;
            chkLaneMvmnt.Enabled = true;
        }
        private void DisableDataLoggingOptions()
        {
            chkSPaTMsg.Checked = false;
            chkTSCData.Checked = false;
            chkLaneMvmnt.Checked = false;
            chkSPaTMsg.Enabled = false;
            chkTSCData.Enabled = false;
            chkLaneMvmnt.Enabled = false;
        }
        private void frmMain_Load(object sender, EventArgs e)
        {
            string retValue = string.Empty;

            this.Show();
            tabCntrlSAPTSystem.SelectedTab = tabpgSPATMsg;

            spatErrorsLog = new StreamWriter(Application.StartupPath + "\\SPaTErrorsLog.Log");

            retValue = StartSPATSystem();
            if (retValue.Length > 0)
            {
                WriteMsgToLogFile(spatErrorsLog, GetCurrentTimeStamp() + retValue);
   
                MessageBox.Show("An error was detected during the SPaT system startup. \r\n" +
                                "Please check the SPaT System errors log file" +  Application.StartupPath + "\\SPaTErrorsLog.Log" +
                                "\r\nfor a description of the errors detected");

                spatErrorsLog.Close();
                return;
            }

            if (GlobalVars.IncludeSRMSSM == true)
            {
                //      Create the Pipe Connection to the ASNJ2735 Server
                ASN_r36 = new ASN_r36();
                while (SRMobjStream == null)
                {
                    SRMobjStream = ASN_r36.CreatePipeStream();
                    if (SRMobjStream == null)
                    {
                        MessageBox.Show("Unable to connect to the ASNJ2735 server; please make sure it is running." + "\r\n\t" +
                                        "Do you want to run the ASNJ2735 and Continue", "ASNJ2735 Server", MessageBoxButtons.YesNo);
                        //Console.WriteLine("Unable to connect to the ASNJ2735 server; please make sure it is running.");
                        //Console.WriteLine("Press any key to exit.");
                        //Console.ReadKey();
                        //return;
                    }
                }
            }
            spatErrorsLog.Close();
        }

        private string StartSPATSystem()
        {
            string strRetValue = string.Empty;

            //Compose the configuration file name
            string SpatConfigFile = Application.StartupPath + "\\config.xml";

            LogTxtMsg(txtActivityLog, "\r\n--Reading the SPAT System configuration file: " + SpatConfigFile);

            //Read SPAT configuration file
            try
            {
                strRetValue = ReadSPaTConfigFile(SpatConfigFile);
                if (strRetValue.Length > 0)
                {
                    strRetValue = "--Processing SPAT Configuration File Error." +
                                  "\r\nSPATConfigurationFile: " + SpatConfigFile + 
                                  "\r\n\t" + strRetValue;
                }
                else
                {
                    if (GlobalVars.SPATDailyLogFolderPath.ToUpper() == "DailyLog".ToUpper())
                    {
                        GlobalVars.SPATDailyLogFolderPath = Application.StartupPath + "\\DailyLog\\";
                        txtSPATDailyLogFolder.Text = GlobalVars.SPATDailyLogFolderPath;
                    }
                }
            }
            catch (Exception ex)
            {
                strRetValue = "--Reading SPAT Configuration File ERROR." + 
                              "\r\n\tSPATConfigurationFile: " + SpatConfigFile + 
                              "\r\n\t" + ex.Message;
            }

            if (strRetValue.Length > 0)
            {
                strRetValue = strRetValue +
                                          "\r\n\t--RSE IPV6 Address: " + GlobalVars.RSEIPV6Address.ToString() + //"\t Port: " + RSEIPV6Port.ToString() +
                                          "\r\n\t--TSC IPV4 Address: " + GlobalVars.TSCIPV4Address.ToString() + "\tNTCIP Port: " + GlobalVars.TSCNTCIPPort.ToString() +
                                          "\r\n\t--SPAT System IPV4 Address: " + GlobalVars.SPATSystemIPV4Address + "\tTSC Port: " + GlobalVars.SPATSystemSPATPort.ToString() +
                                          "\r\n\t--SPAT System IPV6 Address: " + GlobalVars.SPATSystemIPV6Address + //"\tSPAT Port: " + SPATSystemIPV6Port.ToString() +
                                          "\r\n\t--SPAT Intersection Name: " + GlobalVars.IntersectionName +
                                          "\r\n\t--SPAT Intersection ID: " + GlobalVars.IntersectionID +
                                          "\r\n\t--SPAT Intersection City: " + GlobalVars.IntersectionCity +
                                          "\r\n\t--SPAT Intersection State: " + GlobalVars.IntersectionState +
                                          "\r\n\t--SPAT PTLM Mapping File: " + GlobalVars.PTLMMappingFile +
                                          "\r\n\t--SPAT Daily Log Dir: " + GlobalVars.SPATDailyLogFolderPath;

                return strRetValue;
            }

            /*spGPS.PortName = "COM8";
            spGPS.BaudRate = 4800;
            spGPS.StopBits = StopBits.One;
            spGPS.DataBits = 8;
            spGPS.Parity = Parity.None;
            spGPS.Handshake = Handshake.None;*/
            spGPS.DtrEnable = true;
            spGPS.ReceivedBytesThreshold = 1;
            LogTxtMsg(txtGPSActivity, "GPSDevice Properties: " + spGPS.PortName + ", " + spGPS.BaudRate.ToString() + ", " + spGPS.Parity.ToString() + ", " +
                                      spGPS.DataBits.ToString() + ", " + spGPS.StopBits.ToString() + "\tHandShake: " + spGPS.Handshake.ToString());


            strRetValue = GPSDevice.OpenGPSDeviceSerialPort(spGPS);
            if (strRetValue.Length > 0)
            {
                LogTxtMsg(txtGPSActivity, GetCurrentTimeStamp() + " --- " + strRetValue);
            }
            
            
            //GPSDevice.ReadGPSPortInfo(SpatConfigFile);
            //GPSDevice.PopulateGPSPortInfo();
            //strRetValue =  GPSDevice.VerifyGPSDeviceOnSerialPort(GPSDevice.spGPS1, ref FoundGPSDevice);

            //string tmpretval = GPSDevice.VerifyGPSDeviceOnSerialPort(ref spGPS, ref FoundGPSDevice);
            
            /*if ((FoundGPSDevice == true) && (strRetValue.Length == 0))
            {
                LogTxtMsg(txtGPSActivity, "FoundGPSDevice: " + "\t" + GPSDevice.GPRMCSentence +
                                  "\r\n\r\n\tLat: " + GPSDevice.Lat.ToString() + "\tLon: " + GPSDevice.PLon +
                                  "\r\n\tLatitude: " + GPSDevice.Latitude + "\tLongitude: " + GPSDevice.Longitude + " " +
                                  "\r\n\tDirection " + GPSDevice.Direction + " " + "\tSpeedMPH " + GPSDevice.SpeedMph + " " +
                                  "\r\n\tUTCTime:\t\t" + GPSDevice.UTCTime +
                                  "\r\n\tLocalBeforeTime:\t" + GPSDevice.SystemLocalTimeBefore +
                                  "\r\n\tLocalGPSTime:\t" + GPSDevice.GPSLocalTime +
                                  "\r\n\tLocalAfterTime:\t" + GPSDevice.SystemLocalTimeAfter);
            }
            else if (FoundGPSDevice == true)
            {
                LogTxtMsg(txtGPSActivity, "FoundGPSDevice: " + strRetValue + "\t" + GPSDevice.GPRMCSentence + 
                                  "\r\n\r\n\tLat: " + GPSDevice.Lat.ToString() + "\tLon: " + GPSDevice.PLon +
                                  "\r\n\tLatitude: " + GPSDevice.Latitude + "\tLongitude: " + GPSDevice.Longitude + " " +
                                  "\r\n\tDirection " + GPSDevice.Direction + " " + "\tSpeedMPH " + GPSDevice.SpeedMph + " " +
                                  "\r\n\tUTCTime:\t\t" + GPSDevice.UTCTime +
                                  "\r\n\tLocalBeforeTime:\t" + GPSDevice.SystemLocalTimeBefore +
                                  "\r\n\tLocalGPSTime:\t" + GPSDevice.GPSLocalTime +
                                  "\r\n\tLocalAfterTime:\t" + GPSDevice.SystemLocalTimeAfter);

            }
            else if (strRetValue.Length == 0)
            {
                LogTxtMsg(txtGPSActivity, "Could not verify presence of GPS device on port: " + spGPS.PortName + "\t" + strRetValue +
                                  "\r\n\r\n\tLat: " + GPSDevice.Lat.ToString() + "\tLon: " + GPSDevice.PLon +
                                  "\r\n\tLatitude: " + GPSDevice.Latitude + "\tLongitude: " + GPSDevice.Longitude + " " +
                                  "\r\n\tDirection " + GPSDevice.Direction + " " + "\tSpeedMPH " + GPSDevice.SpeedMph + " " +
                                  "\r\n\tUTCTime:\t\t" + GPSDevice.UTCTime +
                                  "\r\n\tLocalBeforeTime:\t" + GPSDevice.SystemLocalTimeBefore +
                                  "\r\n\tLocalGPSTime:\t" + GPSDevice.GPSLocalTime +
                                  "\r\n\tLocalAfterTime:\t" + GPSDevice.SystemLocalTimeAfter);
            }
            else if ((FoundGPSDevice == false) && (strRetValue.Length > 0))
            {
                LogTxtMsg(txtGPSActivity, "Could not verify presence of GPS device on port: " + spGPS.PortName + "\t" + strRetValue +
                                  "\r\n\r\n\tLat: " + GPSDevice.Lat.ToString() + "\tLon: " + GPSDevice.PLon +
                                  "\r\n\tLatitude: " + GPSDevice.Latitude + "\tLongitude: " + GPSDevice.Longitude + " " +
                                  "\r\n\tDirection " + GPSDevice.Direction + " " + "\tSpeedMPH " + GPSDevice.SpeedMph + " " +
                                  "\r\n\tUTCTime:\t\t" + GPSDevice.UTCTime +
                                  "\r\n\tLocalBeforeTime:\t" + GPSDevice.SystemLocalTimeBefore +
                                  "\r\n\tLocalGPSTime:\t" + GPSDevice.GPSLocalTime +
                                  "\r\n\tLocalAfterTime:\t" + GPSDevice.SystemLocalTimeAfter);
                //string tmpval1 = GPSDevice.VerifyGPSDeviceConnection(ref spGPS);
            }*/

            if (chkEnableDataLogging.Checked == true)
            {
                //Check for remaining disk space and terminate logging if less than 10 GB left
                long FreeSpace = 0;
                DriveInfo driveInfo = new DriveInfo(@"C:");
                if (driveInfo.IsReady == true)
                {
                    FreeSpace = driveInfo.AvailableFreeSpace;
                    if (FreeSpace < GlobalVars.DataLoggingDispSpaceLimit)
                    {
                        chkEnableDataLogging.Checked = false;
                        MessageBox.Show("Data logging Can not be started because remaining disk space is below " + (GlobalVars.DataLoggingDispSpaceLimit / GlobalVars.OneGB) + " GB.\r\n" +
                                                  "Delete log files to allow data logging again.");
                        LogTxtMsg(txtActivityLog, "Data logging Can not be started because remaining disk space is below " + (GlobalVars.DataLoggingDispSpaceLimit / GlobalVars.OneGB) + " GB.\r\n" +
                                                  "Delete log files to allow data logging again.");
                    }
                    else
                    {
                        //open a new daily logfile
                        string Filename = string.Empty;
                        strRetValue = OpenDailyLogFile(GlobalVars.enum_log_file_type.DailyLog, ref FileName);
                        if (strRetValue.Length > 0)
                        {
                            strRetValue = "--Opening a new daily logfile ERROR." +
                                          "\r\n\tDaily logFile name: " + FileName +
                                          "\r\n\t" + strRetValue;
                            WriteMsgToLogFile(spatErrorsLog, GetCurrentTimeStamp() + strRetValue);
                        }

                        //open a new daily SPAT Msg logfile
                        strRetValue = OpenDailyLogFile(GlobalVars.enum_log_file_type.SPATBroadcastMsg, ref FileName);
                        if (strRetValue.Length > 0)
                        {
                            strRetValue = "--Opening a new daily SPAT Msg logfile ERROR." +
                                          "\r\n\tDaily SPAT Msg logfile name: " + FileName +
                                          "\r\n\t" + strRetValue;
                            WriteMsgToLogFile(spatErrorsLog, GetCurrentTimeStamp() + strRetValue);
                        }
                        //EnableDataLoggingOptions();
                    }
                }
            }

            //Read the SPAT Msg broadcast information
            string SpatDispatchFile = Application.StartupPath + "\\Config.xml";
            try
            {
                strRetValue = spatBroadcast.LoadConfiguration(SpatDispatchFile, "spat");

                if (strRetValue.Length > 0)
                {
                    strRetValue = "--Processing SPAT dispatch info file ERROR." +
                                  "\r\n\tDispatch info file: " + SpatDispatchFile +
                                  "\r\n\t" + strRetValue;
                }
            }
            catch (Exception ex)
            {
                strRetValue = "--Reading SPAT Dispatch info file ERROR." +
                              "\r\n\tSPAT Dispatch info file: " + SpatDispatchFile +
                              "\r\n\t" + ex.Message;
            }
            if (strRetValue.Length > 0)
            {
                //WriteMsgToLogFile(spatErrorsLog, GetCurrentTimeStamp() + strRetValue);
                return strRetValue;
            }

            //open a new a UdpClient Client for broadcast of SPAT Messages 
            LogTxtMsg(txtSPATMsgLog, "\r\n--Creating SPAT Dispatch header and UDP Client for broadcast of SPAT Message." +
                                     "\r\n\t" + spatBroadcast.LocalIP.ToString() + "\t" + spatBroadcast.LocalPort.ToString() +
                                     "\r\n\t" + spatBroadcast.TargetIP + "\t" + spatBroadcast.TargetPort.ToString());
            try
            {
                SPATDispatchtInfo = spatBroadcast.CreateDispatchHeader(spatBroadcast.ObjConfiguration.dispatch);
                strRetValue = spatBroadcast.CreateUDPClient();

                if (strRetValue.Length > 0)
                {
                    strRetValue = "--Creating UDP client for broadcasting SPAT message to RSE Error." + 
                                                "\r\n\tLocalIP and Port:" + spatBroadcast.LocalIP.ToString() + "\t" + spatBroadcast.LocalPort.ToString() +
                                                "\r\n\tTargetIP and Port:" + spatBroadcast.TargetIP + "\t" + spatBroadcast.TargetPort.ToString() + 
                                                "\r\n\t" + strRetValue;

                }

                //The following line of code need to be removed in the future
                WriteMsgToLogFile(spatErrorsLog, GetCurrentTimeStamp() + strRetValue);
                strRetValue = string.Empty;
            }
            catch (Exception ex)
            {
                strRetValue = "--Creating UDP client for broadcasting SPAT message to RSE Error." + 
                              "\r\n\tLocalIP and Port:" + spatBroadcast.LocalIP.ToString() + "\t" + spatBroadcast.LocalPort.ToString() +
                              "\r\n\tTargetIP and Port:" + spatBroadcast.TargetIP + "\t" + spatBroadcast.TargetPort.ToString() +
                              "\r\n\t" + ex.Message;
            }

            if (strRetValue.Length > 0)
            {
                //WriteMsgToLogFile(spatErrorsLog, GetCurrentTimeStamp() +  strRetValue);
                return strRetValue;
            }





            if (GlobalVars.IncludeSRMSSM == true)
            {
                //Read the SSM Msg broadcast information
                string SsmDispatchFile = Application.StartupPath + "\\Config.xml";
                try
                {
                    strRetValue = ssmBroadcast.LoadConfiguration(SpatDispatchFile, "ssm");

                    if (strRetValue.Length > 0)
                    {
                        strRetValue = "--Processing SSM dispatch info file ERROR." +
                                      "\r\n\tDispatch info file: " + SsmDispatchFile +
                                      "\r\n\t" + strRetValue;
                    }
                }
                catch (Exception ex)
                {
                    strRetValue = "--Reading SSM Dispatch info file ERROR." +
                                  "\r\n\tSSM Dispatch info file: " + SsmDispatchFile +
                                  "\r\n\t" + ex.Message;
                }

                if (strRetValue.Length > 0)
                {
                    //WriteMsgToLogFile(spatErrorsLog, GetCurrentTimeStamp() + strRetValue);
                    return strRetValue;
                }

                //open a new UdpClient Client for broadcast of SSM Messages 
                try
                {
                    SSMDispatchtInfo = ssmBroadcast.CreateDispatchHeader(ssmBroadcast.ObjConfiguration.dispatch);
                    strRetValue = ssmBroadcast.CreateUDPClient();

                    if (strRetValue.Length > 0)
                    {
                        strRetValue = "--Creating UDP client for broadcasting SSM message to RSE Error." +
                                      "\r\n\tLocalIP and Port:" + ssmBroadcast.LocalIP.ToString() + "\t" + ssmBroadcast.LocalPort.ToString() +
                                      "\r\n\tTargetIP and Port:" + ssmBroadcast.TargetIP + "\t" + ssmBroadcast.TargetPort.ToString() +
                                      "\r\n\t" + strRetValue;
                    }

                    //The following line of code need to be removed later on
                    WriteMsgToLogFile(spatErrorsLog, GetCurrentTimeStamp() + strRetValue);
                    strRetValue = string.Empty;
                }
                catch (Exception ex)
                {
                    strRetValue = "--Creating UDP client for broadcasting SSM message to RSE Error." +
                                  "\r\n\tLocalIP and Port:" + ssmBroadcast.LocalIP.ToString() + "\t" + ssmBroadcast.LocalPort.ToString() +
                                  "\r\n\tTargetIP and Port:" + ssmBroadcast.TargetIP + "\t" + ssmBroadcast.TargetPort.ToString() +
                                  "\r\n\t" + ex.Message;
                }
                if (strRetValue.Length > 0)
                {
                    //WriteMsgToLogFile(spatErrorsLog, GetCurrentTimeStamp() + strRetValue);
                    return strRetValue;
                }
            }
            
            
            
            
            //Compose the PTLMMapping file name
            string PTLMFile = Application.StartupPath + "\\Config\\" + GlobalVars.PTLMMappingFile;

            //Read the PTLM Mapping file
            int tmpPTLMRecords = 0;
            try
            {
                strRetValue = ReadPTLMMappingFile(PTLMFile, ref tmpPTLMRecords);
                GlobalVars.PTLMRecords = tmpPTLMRecords;
                if (strRetValue.Length > 0)
                {
                    strRetValue = "--Reading PTLM mapping file ERROR." +
                                  "\r\n\tPTLM mapping file name: " + PTLMFile + 
                                  "\r\n\t" +  strRetValue;
                }
            }
            catch (Exception ex)
            {
                strRetValue = "--Reading PTLM mapping file ERROR." +
                              "\r\n\tPTLM mapping file name: " + PTLMFile + 
                              "\r\n\t" + ex.Message;
            }
            if (strRetValue.Length > 0)
            {
                //WriteMsgToLogFile(spatErrorsLog, GetCurrentTimeStamp() +  strRetValue);
                return strRetValue;
            }




            //Verifying SPAT machine IPV4 address used to connect to TSC
            bool FoundSPATMachineIPAddress = false;
            string localIPAddresses = string.Empty;

            try
            { // get host IP addresses
                string localComputerName = Dns.GetHostName();
                //IPAddress[] hostIPs = Dns.GetHostAddresses(host);
                // get local IP addresses
                IPAddress[] localIPs = Dns.GetHostAddresses(Dns.GetHostName());

                foreach (IPAddress localIP in localIPs)
                {
                    localIPAddresses = localIPAddresses + ", " + localIP.ToString();
                    if (localIP.ToString() == GlobalVars.SPATSystemIPV4Address)
                    {
                        FoundSPATMachineIPAddress = true;
                        break;
                    }
                }
                if (FoundSPATMachineIPAddress == false)
                {

                    strRetValue = "--SPAT System configuration file IPV4 address Error." +
                                  "\r\n\tThe specified SPAT System IPV4 Address: " + GlobalVars.SPATSystemIPV4Address + " is not a valid IPV4 address on the local machine. See available IP addresses on local machine below: " + 
                                  "\r\n\tSPaT System Local IP Addresses: " + localIPAddresses;
                }
            }
            catch (Exception ex)
            {
                strRetValue = "--SPAT System configuration file IPV4 address Error." +
                              "\r\n\tThe specified SPAT System IPV4 Address: " + GlobalVars.SPATSystemIPV4Address + " is not a valid IPV4 address on the local machine. See available IP addresses on local machine below: " +
                              "\r\n\tLocal IP Addresses: " + localIPAddresses +
                              "\r\nSPaT System Error Message: " + ex.Message;
            }
            if (strRetValue.Length > 0)
            {
                //WriteMsgToLogFile(spatErrorsLog, GetCurrentTimeStamp() +  strRetValue);
                return strRetValue;
            }



            //Updating NTCIP library settings
            try
            {
                axaxNtcipIO1.ConnectionType = axNtcipIOControl.TxsetConnectionType.ctEthernet;
                axaxNtcipIO1.ClientServerType = axNtcipIOControl.TxsetClientServerType.csClient;
                axaxNtcipIO1.TransportType = axNtcipIOControl.TxsetTransportType.transUDP;
                axaxNtcipIO1.NetServerAddress = GlobalVars.TSCIPV4Address;
                axaxNtcipIO1.NetServerPortNo = GlobalVars.TSCNTCIPPort;
            }
            catch (Exception ex)
            {
                strRetValue = "--Updating settings of the NTCIP library connection Error." +
                              "\r\n\tNetServerAddress: " + GlobalVars.TSCIPV4Address +
                              "\r\n\tNTCIP Port: " + GlobalVars.TSCNTCIPPort.ToString() +
                              "\r\n\t" + ex.Message;
            }
            if (strRetValue.Length > 0)
            {
                //WriteMsgToLogFile(spatErrorsLog, GetCurrentTimeStamp() +  strRetValue);
                return strRetValue;
            }
            //***********************************************************************************************************************************

            //Connecting to the TSC controller
            int TrialNo = 0;

            while (axaxNtcipIO1.Connected == false)
            {
                axaxNtcipIO1.Connect();
                if (axaxNtcipIO1.Connected == true)
                {
                    lblControllerConnection.BackColor = Color.Green;
                    lblControllerConnection.Text = "Connected to Traffic Signal Controller: " + axaxNtcipIO1.NetServerAddress.ToString() + "::501";
                    break;
                }
                else
                {
                    lblControllerConnection.BackColor = Color.Red;
                    lblControllerConnection.Text = "Unable to connect to controller: " + axaxNtcipIO1.NetServerAddress.ToString();

                    if (TrialNo >= 10)
                    {
                        strRetValue = "--NTCIP Library connection to TSC Error." + 
                                      "\r\n\t NetServerAddress: " + axaxNtcipIO1.NetServerAddress.ToString() + 
                                      "\r\n\t Port #: " + axaxNtcipIO1.NetServerPortNo.ToString();
                        break;
                    }
                    Thread.Sleep(100);
                }
            }
            if (strRetValue.Length > 0)
            {
                //WriteMsgToLogFile(spatErrorsLog, GetCurrentTimeStamp() + strRetValue);
                return strRetValue;
            }


            //Opening a UDP client to Listen to SPAT data pushed by controller
            ipepBBSPATData = new IPEndPoint(IPAddress.Parse(GlobalVars.SPATSystemIPV4Address), GlobalVars.SPATSystemSPATPort);
            try
            {
                TSCListener = new UdpClient(ipepBBSPATData);
            }
            catch (Exception ex)
            {
                strRetValue = "--Opening a UDP client to listen to SPAt data pushed by TSC Error. " +
                              "\r\n\tSPAT System IPV4 address: " + GlobalVars.SPATSystemIPV4Address.ToString() +
                              "\r\n\tSPAT data Port: " + GlobalVars.SPATSystemSPATPort.ToString() +
                              "\r\n\t" + ex.Message;

            }
            if (strRetValue.Length > 0)
            {
                //WriteMsgToLogFile(spatErrorsLog, GetCurrentTimeStamp() +  strRetValue);
                return strRetValue;
            }
            TSC = new IPEndPoint(IPAddress.Any, 0);

            if (GlobalVars.IncludeSRMSSM == true)
            {
                //Opening a UDP client to listen to SRM requests sent by mobile devices.
                ipepBBSRMData = new IPEndPoint(IPAddress.Parse(GlobalVars.SPATSystemIPV4Address), GlobalVars.SRMMsgLocalPort);
                try
                {
                    SRMListener = new UdpClient(ipepBBSRMData);
                }
                catch (Exception ex)
                {
                    strRetValue = "--Opening a UDP client to listen to SRM requests sent by Mobile Devices Error. " +
                                  "\r\n\tSPAT System IPV4 address: " + GlobalVars.SPATSystemIPV4Address.ToString() +
                                  "\r\n\tSRM data Port: " + GlobalVars.SRMMsgLocalPort +
                                  "\r\n\t" + ex.Message;
                }
                if (strRetValue.Length > 0)
                {
                    WriteMsgToLogFile(spatErrorsLog, GetCurrentTimeStamp() + strRetValue);
                    //return strRetValue;
                }
                SRM = new IPEndPoint(IPAddress.Any, 0);
            }

            bool TSCUPandRunning = false;
            while (TSCUPandRunning == false)
            {
                strRetValue = InitializeSPATSystem();
                if (strRetValue.Length > 0)
                {
                    LogTxtMsg(txtTSCLog, strRetValue + "\r\nUnable to communicate with TSC. Please make sure that the TSC is up and running and the SPaT system is configured properly.");
                    //MessageBox.Show(strRetValue + "\r\nUnable to communicate with TSC. Please make sure that the TSC is up and running and the SPaT system is configured properly.");
                    //return strRetValue;
                }
                else
                {
                    TSCUPandRunning = true;
                    LogTxtMsg(txtTSCLog, "TSC is connected. SPaT data push was enabled.");
                }
            }

            LogTxtMsg(txtEnableSPATPush, "\r\n" + GetCurrentTimeStamp() + "--- Disable SPaT TSC Data Push.");
            strRetValue = string.Empty;
            strRetValue = EnableSpatMessagePush("1.3.6.1.4.1.1206.3.5.2.9.44.1.0", "0");
            if (strRetValue.Length > 0)
            {
                WriteMsgToLogFile(spatErrorsLog, GetCurrentTimeStamp() + strRetValue);
            }

            tmrUDPClient.Interval = 10;
            btnHaltSPATSystem.Text = "Halt SPAT System";

            GlobalVars.SPATSystemRunning = true;

            chkEnableDisableSPAT.Checked = true;


            if (spGPS.IsOpen == true)
            {
                tmrGPS.Interval = 60 * 1000;    //Clear the gps buffer every minute
                tmrGPS.Enabled = true;
            }
            else
            {
                tmrGPS.Enabled = false;
            }

            tmrUDPClient.Enabled = true;

            if (GlobalVars.IncludeSRMSSM == true)
            {
                tmrSRM.Enabled = true;
            }
            else
            {
                tmrSRM.Enabled = false;
            }

            strRetValue = string.Empty;

            LogTxtMsg(txtEnableSPATPush, "\r\n" + GetCurrentTimeStamp() + "--- Enable SPaT TSC Data Push.");
            strRetValue = EnableSpatMessagePush("1.3.6.1.4.1.1206.3.5.2.9.44.1.0", GlobalVars.SPaTPushCode);
            if (strRetValue.Length > 0)
            {
                //WriteMsgToLogFile(spatErrorsLog, GetCurrentTimeStamp() + strRetValue);
                MessageBox.Show(strRetValue);
                return strRetValue;
            }

            btnHaltSPATSystem.Enabled = true;
            chkEnableSpatMessagePush.Checked = true;
            if (GlobalVars.IncludeSRMSSM == true)
            {
                chkEnableSSMMessagePush.Visible = true;
                chkEnableSSMMessagePush.Checked = false;
                chkEnableSSMMessagePush.Visible = true;
                chkEnableSSMMessagePush.Enabled = false;
            }
            else
            {
                chkEnableSSMMessagePush.Visible = false;
                chkEnableSSMMessagePush.Checked = false;
                chkEnableSSMMessagePush.Visible = false;
                chkEnableSSMMessagePush.Enabled = false;
            }
            return strRetValue;
        }


        private string InitializeSPATSystem()
        {
            bool retValue = false;
            string strRetValue = string.Empty;

            //Get MaxPhases
            //SenderFunction = "Get NTCIP Object MaxPhases";
            GlobalVars.maxPhases = GetNumberofMaximumPhases();
            //SenderFunction = string.Empty;
            if ((GlobalVars.maxPhases == 0) || (GlobalVars.maxPhases > 16))
            {
                strRetValue = "--Retrieve value for NTCIP object maxPhases from controller Error." +
                              "\r\n\tRetrieved value: " + GlobalVars.maxPhases;
                return strRetValue;
            }

            Phases = new clsPhase[GlobalVars.maxPhases + 1];
            Peds = new clsPhase[GlobalVars.maxPhases + 1];
            for (int i = 0; i <= GlobalVars.maxPhases; i++)
            {
                Phases[i] = new clsPhase();
                Peds[i] = new clsPhase();
                PhasesList.Add(new clsPhase());
                PedsList.Add(new clsPhase());
            }

            //Get MaxPhaseGroups
            //SenderFunction = "Get NTCIP Object MaxPhaseGroups";
            GlobalVars.maxPhaseGroups = GetNumberofMaximumPhaseGroups();
            //SenderFunction = string.Empty;

            if ((GlobalVars.maxPhaseGroups == 0) || (GlobalVars.maxPhaseGroups > 2))
            {
                strRetValue = "--Retrieve value for NTCIP object maxPhaseGroups from controller Error." + 
                              "\r\n\tRetrieved value: " + GlobalVars.maxPhaseGroups;
                return strRetValue;
            }

            //Get MaxOvlps
            //SenderFunction = "Get NTCIP Object MaxOvlps";
            GlobalVars.maxOvlps = GetNumberofMaximumOvlps();
            //SenderFunction = string.Empty;
            if ((GlobalVars.maxOvlps == 0) || (GlobalVars.maxOvlps > 16))
            {
                strRetValue = "--Retrieve value for NTCIP object maxOvlps from controller Error." + 
                              "\r\n\tRetrieved value: " + GlobalVars.maxOvlps;
                return strRetValue;
            }

            Ovlps = new clsPhase[GlobalVars.maxOvlps + 1];
            for (int i = 0; i <= GlobalVars.maxOvlps; i++)
            {
                Ovlps[i] = new clsPhase();
                OvlpsList.Add(new clsPhase());
            }

            //Get phaseYellowChange Parameter
            //SenderFunction = "Get NTCIP Object phaseYellowChange";
            YellowChange = new UInt16[GlobalVars.maxPhases + 1];
            retValue = GetPhaseYellowChange(ref YellowChange);

            for (int i = 1; i <= GlobalVars.maxPhases; i++)
            {
                Phases[i].YellowChange = YellowChange[i];
                PhasesList[i].YellowChange = YellowChange[i];
                LogTxtMsg(txtEnableSPATPush, "\r\n\tPhase " + i + "\t" + YellowChange[i] + "\t" + Phases[i].YellowChange);
            }
            //SenderFunction = "";

            bool ZeroYellows = true;
            for (int y = 1; y <= GlobalVars.maxPhases + 1; y++)
            {
                if (Phases[y].YellowChange > 0)
                {
                    ZeroYellows = false;
                    break;
                }
            }
            if (ZeroYellows == true)
            {
                strRetValue = "--Retrieve value for NTCIP object phaseYellowChange property from controller Error.";
                return strRetValue;
            }


            //Get phasePedestrianClear Parameter
            PedClear = new UInt16[GlobalVars.maxPhases + 1];
            //SenderFunction = "Get NTCIP Object PedClear";
            retValue = GetPhasePedestrianClear(ref PedClear);

            for (int i = 1; i <= GlobalVars.maxPhases; i++)
            {
                Phases[i].PedClear = PedClear[i];
                PhasesList[i].PedClear = PedClear[i];
            }
            //SenderFunction = "";

            //Get phaseRedClear Parameter
            RedClear = new int[GlobalVars.maxPhases + 1];
            //SenderFunction = "Get NTCIP Object RedClear";
            retValue = GetPhaseRedClear(ref RedClear);

            for (int i = 1; i <= GlobalVars.maxPhases; i++)
            {
                Phases[i].RedClear = RedClear[i];
                PhasesList[i].RedClear = RedClear[i];
            }
            //SenderFunction = "";

            //Get phaseRedRevert Parameter
            RedRevert = new int[GlobalVars.maxPhases + 1];
            //SenderFunction = "Get NTCIP Object RedRevert";
            retValue = GetPhaseRedRevert(ref RedRevert);

            for (int i = 1; i <= GlobalVars.maxPhases; i++)
            {
                Phases[i].RedRevert = RedRevert[i];
                PhasesList[i].RedRevert = RedRevert[i];
            }
            //SenderFunction = "";

            return strRetValue;
        }

        private void UpdatePhaseStatusDisplay()
        {
            for (int i = 1; i <= GlobalVars.maxPhases; i++)
            {
                switch (i)
                {
                    case 1:
                        txtVMinTime1.Text = ((int)(Phases[i].VMinTime / 10)).ToString();
                        txtVMaxTime1.Text = ((int)(Phases[i].VMaxTime / 10)).ToString();
                        txtPMinTime1.Text = ((int)(Phases[i].PedMinTime / 10)).ToString();
                        txtPMaxTime1.Text = ((int)(Phases[i].PedMaxTime / 10)).ToString();
                        txtOMinTime1.Text = ((int)(Phases[i].OvlpMinTime / 10)).ToString();
                        txtOMaxTime1.Text = ((int)(Phases[i].OvlpMaxTime / 10)).ToString();
                        break;
                    case 2:
                        txtVMinTime2.Text = ((int)(Phases[i].VMinTime / 10)).ToString();
                        txtVMaxTime2.Text = ((int)(Phases[i].VMaxTime / 10)).ToString();
                        txtPMinTime2.Text = ((int)(Phases[i].PedMinTime / 10)).ToString();
                        txtPMaxTime2.Text = ((int)(Phases[i].PedMaxTime / 10)).ToString();
                        txtOMinTime2.Text = ((int)(Phases[i].OvlpMinTime / 10)).ToString();
                        txtOMaxTime2.Text = ((int)(Phases[i].OvlpMaxTime / 10)).ToString();
                        break;
                    case 3:
                        txtVMinTime3.Text = ((int)(Phases[i].VMinTime / 10)).ToString();
                        txtVMaxTime3.Text = ((int)(Phases[i].VMaxTime / 10)).ToString();
                        txtPMinTime3.Text = ((int)(Phases[i].PedMinTime / 10)).ToString();
                        txtPMaxTime3.Text = ((int)(Phases[i].PedMaxTime / 10)).ToString();
                        txtOMinTime3.Text = ((int)(Phases[i].OvlpMinTime / 10)).ToString();
                        txtOMaxTime3.Text = ((int)(Phases[i].OvlpMaxTime / 10)).ToString();
                        break;
                    case 4:
                        txtVMinTime4.Text = ((int)(Phases[i].VMinTime / 10)).ToString();
                        txtVMaxTime4.Text = ((int)(Phases[i].VMaxTime / 10)).ToString();
                        txtPMinTime4.Text = ((int)(Phases[i].PedMinTime / 10)).ToString();
                        txtPMaxTime4.Text = ((int)(Phases[i].PedMaxTime / 10)).ToString();
                        txtOMinTime4.Text = ((int)(Phases[i].OvlpMinTime / 10)).ToString();
                        txtOMaxTime4.Text = ((int)(Phases[i].OvlpMaxTime / 10)).ToString();
                        break;
                    case 5:
                        txtVMinTime5.Text = ((int)(Phases[i].VMinTime / 10)).ToString();
                        txtVMaxTime5.Text = ((int)(Phases[i].VMaxTime / 10)).ToString();
                        txtPMinTime5.Text = ((int)(Phases[i].PedMinTime / 10)).ToString();
                        txtPMaxTime5.Text = ((int)(Phases[i].PedMaxTime / 10)).ToString();
                        txtOMinTime5.Text = ((int)(Phases[i].OvlpMinTime / 10)).ToString();
                        txtOMaxTime5.Text = ((int)(Phases[i].OvlpMaxTime / 10)).ToString();
                        break;
                    case 6:
                        txtVMinTime6.Text = ((int)(Phases[i].VMinTime / 10)).ToString();
                        txtVMaxTime6.Text = ((int)(Phases[i].VMaxTime / 10)).ToString();
                        txtPMinTime6.Text = ((int)(Phases[i].PedMinTime / 10)).ToString();
                        txtPMaxTime6.Text = ((int)(Phases[i].PedMaxTime / 10)).ToString();
                        txtOMinTime6.Text = ((int)(Phases[i].OvlpMinTime / 10)).ToString();
                        txtOMaxTime6.Text = ((int)(Phases[i].OvlpMaxTime / 10)).ToString();
                        break;
                    case 7:
                        txtVMinTime7.Text = ((int)(Phases[i].VMinTime / 10)).ToString();
                        txtVMaxTime7.Text = ((int)(Phases[i].VMaxTime / 10)).ToString();
                        txtPMinTime7.Text = ((int)(Phases[i].PedMinTime / 10)).ToString();
                        txtPMaxTime7.Text = ((int)(Phases[i].PedMaxTime / 10)).ToString();
                        txtOMinTime7.Text = ((int)(Phases[i].OvlpMinTime / 10)).ToString();
                        txtOMaxTime7.Text = ((int)(Phases[i].OvlpMaxTime / 10)).ToString();
                        break;
                    case 8:
                        txtVMinTime8.Text = ((int)(Phases[i].VMinTime / 10)).ToString();
                        txtVMaxTime8.Text = ((int)(Phases[i].VMaxTime / 10)).ToString();
                        txtPMinTime8.Text = ((int)(Phases[i].PedMinTime / 10)).ToString();
                        txtPMaxTime8.Text = ((int)(Phases[i].PedMaxTime / 10)).ToString();
                        txtOMinTime8.Text = ((int)(Phases[i].OvlpMinTime / 10)).ToString();
                        txtOMaxTime8.Text = ((int)(Phases[i].OvlpMaxTime / 10)).ToString();
                        break;
                    case 9:
                        txtVMinTime9.Text = ((int)(Phases[i].VMinTime / 10)).ToString();
                        txtVMaxTime9.Text = ((int)(Phases[i].VMaxTime / 10)).ToString();
                        txtPMinTime9.Text = ((int)(Phases[i].PedMinTime / 10)).ToString();
                        txtPMaxTime9.Text = ((int)(Phases[i].PedMaxTime / 10)).ToString();
                        txtOMinTime9.Text = ((int)(Phases[i].OvlpMinTime / 10)).ToString();
                        txtOMaxTime9.Text = ((int)(Phases[i].OvlpMaxTime / 10)).ToString();
                        break;
                    case 10:
                        txtVMinTime10.Text = ((int)(Phases[i].VMinTime / 10)).ToString();
                        txtVMaxTime10.Text = ((int)(Phases[i].VMaxTime / 10)).ToString();
                        txtPMinTime10.Text = ((int)(Phases[i].PedMinTime / 10)).ToString();
                        txtPMaxTime10.Text = ((int)(Phases[i].PedMaxTime / 10)).ToString();
                        txtOMinTime10.Text = ((int)(Phases[i].OvlpMinTime / 10)).ToString();
                        txtOMaxTime10.Text = ((int)(Phases[i].OvlpMaxTime / 10)).ToString();
                        break;
                    case 11:
                        txtVMinTime11.Text = ((int)(Phases[i].VMinTime / 10)).ToString();
                        txtVMaxTime11.Text = ((int)(Phases[i].VMaxTime / 10)).ToString();
                        txtPMinTime11.Text = ((int)(Phases[i].PedMinTime / 10)).ToString();
                        txtPMaxTime11.Text = ((int)(Phases[i].PedMaxTime / 10)).ToString();
                        txtOMinTime11.Text = ((int)(Phases[i].OvlpMinTime / 10)).ToString();
                        txtOMaxTime11.Text = ((int)(Phases[i].OvlpMaxTime / 10)).ToString();
                        break;
                    case 12:
                        txtVMinTime12.Text = ((int)(Phases[i].VMinTime / 10)).ToString();
                        txtVMaxTime12.Text = ((int)(Phases[i].VMaxTime / 10)).ToString();
                        txtPMinTime12.Text = ((int)(Phases[i].PedMinTime / 10)).ToString();
                        txtPMaxTime12.Text = ((int)(Phases[i].PedMaxTime / 10)).ToString();
                        txtOMinTime12.Text = ((int)(Phases[i].OvlpMinTime / 10)).ToString();
                        txtOMaxTime12.Text = ((int)(Phases[i].OvlpMaxTime / 10)).ToString();
                        break;
                    case 13:
                        txtVMinTime13.Text = ((int)(Phases[i].VMinTime / 10)).ToString();
                        txtVMaxTime13.Text = ((int)(Phases[i].VMaxTime / 10)).ToString();
                        txtPMinTime13.Text = ((int)(Phases[i].PedMinTime / 10)).ToString();
                        txtPMaxTime13.Text = ((int)(Phases[i].PedMaxTime / 10)).ToString();
                        txtOMinTime13.Text = ((int)(Phases[i].OvlpMinTime / 10)).ToString();
                        txtOMaxTime13.Text = ((int)(Phases[i].OvlpMaxTime / 10)).ToString();
                        break;
                    case 14:
                        txtVMinTime14.Text = ((int)(Phases[i].VMinTime / 10)).ToString();
                        txtVMaxTime14.Text = ((int)(Phases[i].VMaxTime / 10)).ToString();
                        txtPMinTime14.Text = ((int)(Phases[i].PedMinTime / 10)).ToString();
                        txtPMaxTime14.Text = ((int)(Phases[i].PedMaxTime / 10)).ToString();
                        txtOMinTime14.Text = ((int)(Phases[i].OvlpMinTime / 10)).ToString();
                        txtOMaxTime14.Text = ((int)(Phases[i].OvlpMaxTime / 10)).ToString();
                        break;
                    case 15:
                        txtVMinTime15.Text = ((int)(Phases[i].VMinTime / 10)).ToString();
                        txtVMaxTime15.Text = ((int)(Phases[i].VMaxTime / 10)).ToString();
                        txtPMinTime15.Text = ((int)(Phases[i].PedMinTime / 10)).ToString();
                        txtPMaxTime15.Text = ((int)(Phases[i].PedMaxTime / 10)).ToString();
                        txtOMinTime15.Text = ((int)(Phases[i].OvlpMinTime / 10)).ToString();
                        txtOMaxTime15.Text = ((int)(Phases[i].OvlpMaxTime / 10)).ToString();
                        break;
                    case 16:
                        txtVMinTime16.Text = ((int)(Phases[i].VMinTime / 10)).ToString();
                        txtVMaxTime16.Text = ((int)(Phases[i].VMaxTime / 10)).ToString();
                        txtPMinTime16.Text = ((int)(Phases[i].PedMinTime / 10)).ToString();
                        txtPMaxTime16.Text = ((int)(Phases[i].PedMaxTime / 10)).ToString();
                        txtOMinTime16.Text = ((int)(Phases[i].OvlpMinTime / 10)).ToString();
                        txtOMaxTime16.Text = ((int)(Phases[i].OvlpMaxTime / 10)).ToString();
                        break;
                }
                if (Phases[i].Green == true)
                {
                    switch (i)
                    {
                        case 1:
                            shpPhase1.BackColor = Color.Green;
                            break;
                        case 2:
                            shpPhase2.BackColor = Color.Green;
                            break;
                        case 3:
                            shpPhase3.BackColor = Color.Green;
                            break;
                        case 4:
                            shpPhase4.BackColor = Color.Green;
                            break;
                        case 5:
                            shpPhase5.BackColor = Color.Green;
                            break;
                        case 6:
                            shpPhase6.BackColor = Color.Green;
                            break;
                        case 7:
                            shpPhase7.BackColor = Color.Green;
                            break;
                        case 8:
                            shpPhase8.BackColor = Color.Green;
                            break;
                        case 9:
                            shpPhase9.BackColor = Color.Green;
                            break;
                        case 10:
                            shpPhase10.BackColor = Color.Green;
                            break;
                        case 11:
                            shpPhase11.BackColor = Color.Green;
                            break;
                        case 12:
                            shpPhase12.BackColor = Color.Green;
                            break;
                        case 13:
                            shpPhase13.BackColor = Color.Green;
                            break;
                        case 14:
                            shpPhase14.BackColor = Color.Green;
                            break;
                        case 15:
                            shpPhase15.BackColor = Color.Green;
                            break;
                        case 16:
                            shpPhase16.BackColor = Color.Green;
                            break;
                    }
                }
                else if (Phases[i].Yellow == true)
                {
                    switch (i)
                    {
                        case 1:
                            shpPhase1.BackColor = Color.Yellow;
                            lblPhase1.BackColor = Color.Yellow;
                            break;
                        case 2:
                            shpPhase2.BackColor = Color.Yellow;
                            lblPhase2.BackColor = Color.Yellow;
                            break;
                        case 3:
                            shpPhase3.BackColor = Color.Yellow;
                            lblPhase3.BackColor = Color.Yellow;
                            break;
                        case 4:
                            shpPhase4.BackColor = Color.Yellow;
                            lblPhase4.BackColor = Color.Yellow;
                            break;
                        case 5:
                            shpPhase5.BackColor = Color.Yellow;
                            lblPhase5.BackColor = Color.Yellow;
                            break;
                        case 6:
                            shpPhase6.BackColor = Color.Yellow;
                            lblPhase6.BackColor = Color.Yellow;
                            break;
                        case 7:
                            shpPhase7.BackColor = Color.Yellow;
                            lblPhase7.BackColor = Color.Yellow;
                            break;
                        case 8:
                            shpPhase8.BackColor = Color.Yellow;
                            lblPhase8.BackColor = Color.Yellow;
                            break;
                        case 9:
                            shpPhase9.BackColor = Color.Yellow;
                            lblPhase9.BackColor = Color.Yellow;
                            break;
                        case 10:
                            shpPhase10.BackColor = Color.Yellow;
                            lblPhase10.BackColor = Color.Yellow;
                            break;
                        case 11:
                            shpPhase11.BackColor = Color.Yellow;
                            lblPhase11.BackColor = Color.Yellow;
                            break;
                        case 12:
                            shpPhase12.BackColor = Color.Yellow;
                            lblPhase12.BackColor = Color.Yellow;
                            break;
                        case 13:
                            shpPhase13.BackColor = Color.Yellow;
                            lblPhase13.BackColor = Color.Yellow;
                            break;
                        case 14:
                            shpPhase14.BackColor = Color.Yellow;
                            lblPhase14.BackColor = Color.Yellow;
                            break;
                        case 15:
                            shpPhase15.BackColor = Color.Yellow;
                            lblPhase15.BackColor = Color.Yellow;
                            break;
                        case 16:
                            shpPhase16.BackColor = Color.Yellow;
                            lblPhase16.BackColor = Color.Yellow;
                            break;
                    }
                }
                else if (Phases[i].Red == true)
                {
                    switch (i)
                    {
                        case 1:
                            shpPhase1.BackColor = Color.Red;
                            lblPhase1.BackColor = Color.Red;
                            break;
                        case 2:
                            shpPhase2.BackColor = Color.Red;
                            lblPhase2.BackColor = Color.Red;
                            break;
                        case 3:
                            shpPhase3.BackColor = Color.Red;
                            lblPhase3.BackColor = Color.Red;
                            break;
                        case 4:
                            shpPhase4.BackColor = Color.Red;
                            lblPhase4.BackColor = Color.Red;
                            break;
                        case 5:
                            shpPhase5.BackColor = Color.Red;
                            lblPhase5.BackColor = Color.Red;
                            break;
                        case 6:
                            shpPhase6.BackColor = Color.Red;
                            lblPhase6.BackColor = Color.Red;
                            break;
                        case 7:
                            shpPhase7.BackColor = Color.Red;
                            lblPhase7.BackColor = Color.Red;
                            break;
                        case 8:
                            shpPhase8.BackColor = Color.Red;
                            lblPhase8.BackColor = Color.Red;
                            break;
                        case 9:
                            shpPhase9.BackColor = Color.Red;
                            lblPhase9.BackColor = Color.Red;
                            break;
                        case 10:
                            shpPhase10.BackColor = Color.Red;
                            lblPhase10.BackColor = Color.Red;
                            break;
                        case 11:
                            shpPhase11.BackColor = Color.Red;
                            lblPhase11.BackColor = Color.Red;
                            break;
                        case 12:
                            shpPhase12.BackColor = Color.Red;
                            lblPhase12.BackColor = Color.Red;
                            break;
                        case 13:
                            shpPhase13.BackColor = Color.Red;
                            lblPhase13.BackColor = Color.Red;
                            break;
                        case 14:
                            shpPhase14.BackColor = Color.Red;
                            lblPhase14.BackColor = Color.Red;
                            break;
                        case 15:
                            shpPhase15.BackColor = Color.Red;
                            lblPhase15.BackColor = Color.Red;
                            break;
                        case 16:
                            shpPhase16.BackColor = Color.Red;
                            lblPhase16.BackColor = Color.Red;
                            break;
                    }
                }
                else
                {
                    Phases[i].Status = (byte)GlobalVars.enum_phase_status.UnAvailable;
                    switch (i)
                    {
                        case 1:
                            shpPhase1.BackColor = Color.LightGray;
                            break;
                        case 2:
                            shpPhase2.BackColor = Color.LightGray;
                            break;
                        case 3:
                            shpPhase3.BackColor = Color.LightGray;
                            break;
                        case 4:
                            shpPhase4.BackColor = Color.LightGray;
                            break;
                        case 5:
                            shpPhase5.BackColor = Color.LightGray;
                            break;
                        case 6:
                            shpPhase6.BackColor = Color.LightGray;
                            break;
                        case 7:
                            shpPhase7.BackColor = Color.LightGray;
                            break;
                        case 8:
                            shpPhase8.BackColor = Color.LightGray;
                            break;
                        case 9:
                            shpPhase9.BackColor = Color.LightGray;
                            break;
                        case 10:
                            shpPhase10.BackColor = Color.LightGray;
                            break;
                        case 11:
                            shpPhase11.BackColor = Color.LightGray;
                            break;
                        case 12:
                            shpPhase12.BackColor = Color.LightGray;
                            break;
                        case 13:
                            shpPhase13.BackColor = Color.LightGray;
                            break;
                        case 14:
                            shpPhase14.BackColor = Color.LightGray;
                            break;
                        case 15:
                            shpPhase15.BackColor = Color.LightGray;
                            break;
                        case 16:
                            shpPhase16.BackColor = Color.LightGray;
                            break;
                    }
                }

                if (Phases[i].OvlpGreen == true)
                {
                    switch (i)
                    {
                        case 1:
                            shpOvlp1.BackColor = Color.Green;
                            break;
                        case 2:
                            shpOvlp2.BackColor = Color.Green;
                            break;
                        case 3:
                            shpOvlp3.BackColor = Color.Green;
                            break;
                        case 4:
                            shpOvlp4.BackColor = Color.Green;
                            break;
                        case 5:
                            shpOvlp5.BackColor = Color.Green;
                            break;
                        case 6:
                            shpOvlp6.BackColor = Color.Green;
                            break;
                        case 7:
                            shpOvlp7.BackColor = Color.Green;
                            break;
                        case 8:
                            shpOvlp8.BackColor = Color.Green;
                            break;
                        case 9:
                            shpOvlp9.BackColor = Color.Green;
                            break;
                        case 10:
                            shpOvlp10.BackColor = Color.Green;
                            break;
                        case 11:
                            shpOvlp11.BackColor = Color.Green;
                            break;
                        case 12:
                            shpOvlp12.BackColor = Color.Green;
                            break;
                        case 13:
                            shpOvlp13.BackColor = Color.Green;
                            break;
                        case 14:
                            shpOvlp14.BackColor = Color.Green;
                            break;
                        case 15:
                            shpOvlp15.BackColor = Color.Green;
                            break;
                        case 16:
                            shpOvlp16.BackColor = Color.Green;
                            break;
                    }
                }
                else if (Phases[i].OvlpYellow == true)
                {
                    switch (i)
                    {
                        case 1:
                            shpOvlp1.BackColor = Color.Yellow;
                            lblOvlp1.BackColor = Color.Yellow;
                            break;
                        case 2:
                            shpOvlp2.BackColor = Color.Yellow;
                            lblOvlp2.BackColor = Color.Yellow;
                            break;
                        case 3:
                            shpOvlp3.BackColor = Color.Yellow;
                            lblOvlp3.BackColor = Color.Yellow;
                            break;
                        case 4:
                            shpOvlp4.BackColor = Color.Yellow;
                            lblOvlp4.BackColor = Color.Yellow;
                            break;
                        case 5:
                            shpOvlp5.BackColor = Color.Yellow;
                            lblOvlp5.BackColor = Color.Yellow;
                            break;
                        case 6:
                            shpOvlp6.BackColor = Color.Yellow;
                            lblOvlp6.BackColor = Color.Yellow;
                            break;
                        case 7:
                            shpOvlp7.BackColor = Color.Yellow;
                            lblOvlp7.BackColor = Color.Yellow;
                            break;
                        case 8:
                            shpOvlp8.BackColor = Color.Yellow;
                            lblOvlp8.BackColor = Color.Yellow;
                            break;
                        case 9:
                            shpOvlp9.BackColor = Color.Yellow;
                            lblOvlp9.BackColor = Color.Yellow;
                            break;
                        case 10:
                            shpOvlp10.BackColor = Color.Yellow;
                            lblOvlp10.BackColor = Color.Yellow;
                            break;
                        case 11:
                            shpOvlp11.BackColor = Color.Yellow;
                            lblOvlp11.BackColor = Color.Yellow;
                            break;
                        case 12:
                            shpOvlp12.BackColor = Color.Yellow;
                            lblOvlp12.BackColor = Color.Yellow;
                            break;
                        case 13:
                            shpOvlp13.BackColor = Color.Yellow;
                            lblOvlp13.BackColor = Color.Yellow;
                            break;
                        case 14:
                            shpOvlp14.BackColor = Color.Yellow;
                            lblOvlp14.BackColor = Color.Yellow;
                            break;
                        case 15:
                            shpOvlp15.BackColor = Color.Yellow;
                            lblOvlp15.BackColor = Color.Yellow;
                            break;
                        case 16:
                            shpOvlp16.BackColor = Color.Yellow;
                            lblOvlp16.BackColor = Color.Yellow;
                            break;
                    }
                }
                else if (Phases[i].OvlpRed == true)
                {
                    switch (i)
                    {
                        case 1:
                            shpOvlp1.BackColor = Color.Red;
                            lblOvlp1.BackColor = Color.Red;
                            break;
                        case 2:
                            shpOvlp2.BackColor = Color.Red;
                            lblOvlp2.BackColor = Color.Red;
                            break;
                        case 3:
                            shpOvlp3.BackColor = Color.Red;
                            lblOvlp3.BackColor = Color.Red;
                            break;
                        case 4:
                            shpOvlp4.BackColor = Color.Red;
                            lblOvlp4.BackColor = Color.Red;
                            break;
                        case 5:
                            shpOvlp5.BackColor = Color.Red;
                            lblOvlp5.BackColor = Color.Red;
                            break;
                        case 6:
                            shpOvlp6.BackColor = Color.Red;
                            lblOvlp6.BackColor = Color.Red;
                            break;
                        case 7:
                            shpOvlp7.BackColor = Color.Red;
                            lblOvlp7.BackColor = Color.Red;
                            break;
                        case 8:
                            shpOvlp8.BackColor = Color.Red;
                            lblOvlp8.BackColor = Color.Red;
                            break;
                        case 9:
                            shpOvlp9.BackColor = Color.Red;
                            lblOvlp9.BackColor = Color.Red;
                            break;
                        case 10:
                            shpOvlp10.BackColor = Color.Red;
                            lblOvlp10.BackColor = Color.Red;
                            break;
                        case 11:
                            shpOvlp11.BackColor = Color.Red;
                            lblOvlp11.BackColor = Color.Red;
                            break;
                        case 12:
                            shpOvlp12.BackColor = Color.Red;
                            lblOvlp12.BackColor = Color.Red;
                            break;
                        case 13:
                            shpOvlp13.BackColor = Color.Red;
                            lblOvlp13.BackColor = Color.Red;
                            break;
                        case 14:
                            shpOvlp14.BackColor = Color.Red;
                            lblOvlp14.BackColor = Color.Red;
                            break;
                        case 15:
                            shpOvlp15.BackColor = Color.Red;
                            lblOvlp15.BackColor = Color.Red;
                            break;
                        case 16:
                            shpOvlp16.BackColor = Color.Red;
                            lblOvlp16.BackColor = Color.Red;
                            break;
                    }
                }
                else
                {
                    switch (i)
                    {
                        case 1:
                            shpOvlp1.BackColor = Color.LightGray;
                            break;
                        case 2:
                            shpOvlp2.BackColor = Color.LightGray;
                            break;
                        case 3:
                            shpOvlp3.BackColor = Color.LightGray;
                            break;
                        case 4:
                            shpOvlp4.BackColor = Color.LightGray;
                            break;
                        case 5:
                            shpOvlp5.BackColor = Color.LightGray;
                            break;
                        case 6:
                            shpOvlp6.BackColor = Color.LightGray;
                            break;
                        case 7:
                            shpOvlp7.BackColor = Color.LightGray;
                            break;
                        case 8:
                            shpOvlp8.BackColor = Color.LightGray;
                            break;
                        case 9:
                            shpOvlp9.BackColor = Color.LightGray;
                            break;
                        case 10:
                            shpOvlp10.BackColor = Color.LightGray;
                            break;
                        case 11:
                            shpOvlp11.BackColor = Color.LightGray;
                            break;
                        case 12:
                            shpOvlp12.BackColor = Color.LightGray;
                            break;
                        case 13:
                            shpOvlp13.BackColor = Color.LightGray;
                            break;
                        case 14:
                            shpOvlp14.BackColor = Color.LightGray;
                            break;
                        case 15:
                            shpOvlp15.BackColor = Color.LightGray;
                            break;
                        case 16:
                            shpOvlp16.BackColor = Color.LightGray;
                            break;
                    }
                }
                if (Phases[i].PhsFlashing == true)
                {
                    switch (i)
                    {
                        case 1:
                            lblPhase1.Visible = true;
                            break;
                        case 2:
                            lblPhase2.Visible = true;
                            break;
                        case 3:
                            lblPhase3.Visible = true;
                            break;
                        case 4:
                            lblPhase4.Visible = true;
                            break;
                        case 5:
                            lblPhase5.Visible = true;
                            break;
                        case 6:
                            lblPhase6.Visible = true;
                            break;
                        case 7:
                            lblPhase7.Visible = true;
                            break;
                        case 8:
                            lblPhase8.Visible = true;
                            break;
                        case 9:
                            lblPhase9.Visible = true;
                            break;
                        case 10:
                            lblPhase10.Visible = true;
                            break;
                        case 11:
                            lblPhase11.Visible = true;
                            break;
                        case 12:
                            lblPhase12.Visible = true;
                            break;
                        case 13:
                            lblPhase13.Visible = true;
                            break;
                        case 14:
                            lblPhase14.Visible = true;
                            break;
                        case 15:
                            lblPhase15.Visible = true;
                            break;
                        case 16:
                            lblPhase16.Visible = true;
                            break;
                    }
                }
                else
                {
                    switch (i)
                    {
                        case 1:
                            lblPhase1.Visible = false;
                            break;
                        case 2:
                            lblPhase2.Visible = false;
                            break;
                        case 3:
                            lblPhase3.Visible = false;
                            break;
                        case 4:
                            lblPhase4.Visible = false;
                            break;
                        case 5:
                            lblPhase5.Visible = false;
                            break;
                        case 6:
                            lblPhase6.Visible = false;
                            break;
                        case 7:
                            lblPhase7.Visible = false;
                            break;
                        case 8:
                            lblPhase8.Visible = false;
                            break;
                        case 9:
                            lblPhase9.Visible = false;
                            break;
                        case 10:
                            lblPhase10.Visible = false;
                            break;
                        case 11:
                            lblPhase11.Visible = false;
                            break;
                        case 12:
                            lblPhase12.Visible = false;
                            break;
                        case 13:
                            lblPhase13.Visible = false;
                            break;
                        case 14:
                            lblPhase14.Visible = false;
                            break;
                        case 15:
                            lblPhase15.Visible = false;
                            break;
                        case 16:
                            lblPhase16.Visible = false;
                            break;
                    }
                }

                if (Phases[i].OvlpFlashing == true)
                {
                    switch (i)
                    {
                        case 1:
                            lblOvlp1.Visible = true;
                            break;
                        case 2:
                            lblOvlp2.Visible = true;
                            break;
                        case 3:
                            lblOvlp3.Visible = true;
                            break;
                        case 4:
                            lblOvlp4.Visible = true;
                            break;
                        case 5:
                            lblOvlp5.Visible = true;
                            break;
                        case 6:
                            lblOvlp6.Visible = true;
                            break;
                        case 7:
                            lblOvlp7.Visible = true;
                            break;
                        case 8:
                            lblOvlp8.Visible = true;
                            break;
                        case 9:
                            lblOvlp9.Visible = true;
                            break;
                        case 10:
                            lblOvlp10.Visible = true;
                            break;
                        case 11:
                            lblOvlp11.Visible = true;
                            break;
                        case 12:
                            lblOvlp12.Visible = true;
                            break;
                        case 13:
                            lblOvlp13.Visible = true;
                            break;
                        case 14:
                            lblOvlp14.Visible = true;
                            break;
                        case 15:
                            lblOvlp15.Visible = true;
                            break;
                        case 16:
                            lblOvlp16.Visible = true;
                            break;
                    }
                }
                else
                {
                    switch (i)
                    {
                        case 1:
                            lblOvlp1.Visible = false;
                            break;
                        case 2:
                            lblOvlp2.Visible = false;
                            break;
                        case 3:
                            lblOvlp3.Visible = false;
                            break;
                        case 4:
                            lblOvlp4.Visible = false;
                            break;
                        case 5:
                            lblOvlp5.Visible = false;
                            break;
                        case 6:
                            lblOvlp6.Visible = false;
                            break;
                        case 7:
                            lblOvlp7.Visible = false;
                            break;
                        case 8:
                            lblOvlp8.Visible = false;
                            break;
                        case 9:
                            lblOvlp9.Visible = false;
                            break;
                        case 10:
                            lblOvlp10.Visible = false;
                            break;
                        case 11:
                            lblOvlp11.Visible = false;
                            break;
                        case 12:
                            lblOvlp12.Visible = false;
                            break;
                        case 13:
                            lblOvlp13.Visible = false;
                            break;
                        case 14:
                            lblOvlp14.Visible = false;
                            break;
                        case 15:
                            lblOvlp15.Visible = false;
                            break;
                        case 16:
                            lblOvlp16.Visible = false;
                            break;
                    }
                }
                if (Phases[i].PedDontWalk == true)
                {
                    switch (i)
                    {
                        case 1:
                            shpPed1.BackColor = Color.DarkOrange;
                            txtPed1.Text = "DONTWALK";
                            txtPed1.ForeColor = Color.DarkOrange;
                            break;
                        case 2:
                            shpPed2.BackColor = Color.DarkOrange;
                            txtPed2.Text = "DONTWALK";
                            txtPed2.ForeColor = Color.DarkOrange;
                            break;
                        case 3:
                            shpPed3.BackColor = Color.DarkOrange;
                            txtPed3.Text = "DONTWALK";
                            txtPed3.ForeColor = Color.DarkOrange;
                            break;
                        case 4:
                            shpPed4.BackColor = Color.DarkOrange;
                            txtPed4.Text = "DONTWALK";
                            txtPed4.ForeColor = Color.DarkOrange;
                            break;
                        case 5:
                            shpPed5.BackColor = Color.DarkOrange;
                            txtPed5.Text = "DONTWALK";
                            txtPed5.ForeColor = Color.DarkOrange;
                            break;
                        case 6:
                            shpPed6.BackColor = Color.DarkOrange;
                            txtPed6.Text = "DONTWALK";
                            txtPed6.ForeColor = Color.DarkOrange;
                            break;
                        case 7:
                            shpPed7.BackColor = Color.DarkOrange;
                            txtPed7.Text = "DONTWALK";
                            txtPed7.ForeColor = Color.DarkOrange;
                            break;
                        case 8:
                            shpPed8.BackColor = Color.DarkOrange;
                            txtPed8.Text = "DONTWALK";
                            txtPed8.ForeColor = Color.DarkOrange;
                            break;
                        case 9:
                            shpPed9.BackColor = Color.DarkOrange;
                            txtPed9.Text = "DONTWALK";
                            txtPed9.ForeColor = Color.DarkOrange;
                            break;
                        case 10:
                            shpPed10.BackColor = Color.DarkOrange;
                            txtPed10.Text = "DONTWALK";
                            txtPed10.ForeColor = Color.DarkOrange;
                            break;
                        case 11:
                            shpPed11.BackColor = Color.DarkOrange;
                            txtPed11.Text = "DONTWALK";
                            txtPed11.ForeColor = Color.DarkOrange;
                            break;
                        case 12:
                            shpPed12.BackColor = Color.DarkOrange;
                            txtPed12.Text = "DONTWALK";
                            txtPed12.ForeColor = Color.DarkOrange;
                            break;
                        case 13:
                            shpPed13.BackColor = Color.DarkOrange;
                            txtPed13.Text = "DONTWALK";
                            txtPed13.ForeColor = Color.DarkOrange;
                            break;
                        case 14:
                            shpPed14.BackColor = Color.DarkOrange;
                            txtPed14.Text = "DONTWALK";
                            txtPed14.ForeColor = Color.DarkOrange;
                            break;
                        case 15:
                            shpPed15.BackColor = Color.DarkOrange;
                            txtPed15.Text = "DONTWALK";
                            txtPed15.ForeColor = Color.DarkOrange;
                            break;
                        case 16:
                            shpPed16.BackColor = Color.DarkOrange;
                            txtPed16.Text = "DONTWALK";
                            txtPed16.ForeColor = Color.DarkOrange;
                            break;
                    }
                }
                else if (Phases[i].PedWalk == true)
                {
                    switch (i)
                    {
                        case 1:
                            shpPed1.BackColor = Color.White;
                            txtPed1.Text = "WALK";
                            txtPed1.ForeColor = Color.White;
                            break;
                        case 2:
                            shpPed2.BackColor = Color.White;
                            txtPed2.Text = "WALK";
                            txtPed2.ForeColor = Color.White;
                            break;
                        case 3:
                            shpPed3.BackColor = Color.White;
                            txtPed3.Text = "WALK";
                            txtPed3.ForeColor = Color.White;
                            break;
                        case 4:
                            shpPed4.BackColor = Color.White;
                            txtPed4.Text = "WALK";
                            txtPed4.ForeColor = Color.White;
                            break;
                        case 5:
                            shpPed5.BackColor = Color.White;
                            txtPed5.Text = "WALK";
                            txtPed5.ForeColor = Color.White;
                            break;
                        case 6:
                            shpPed6.BackColor = Color.White;
                            txtPed6.Text = "WALK";
                            txtPed6.ForeColor = Color.White;
                            break;
                        case 7:
                            shpPed7.BackColor = Color.White;
                            txtPed7.Text = "WALK";
                            txtPed7.ForeColor = Color.White;
                            break;
                        case 8:
                            shpPed8.BackColor = Color.White;
                            txtPed8.Text = "WALK";
                            txtPed8.ForeColor = Color.White;
                            break;
                        case 9:
                            shpPed9.BackColor = Color.White;
                            txtPed9.Text = "WALK";
                            txtPed9.ForeColor = Color.White;
                            break;
                        case 10:
                            shpPed10.BackColor = Color.White;
                            txtPed10.Text = "WALK";
                            txtPed10.ForeColor = Color.White;
                            break;
                        case 11:
                            shpPed11.BackColor = Color.White;
                            txtPed11.Text = "WALK";
                            txtPed11.ForeColor = Color.White;
                            break;
                        case 12:
                            shpPed12.BackColor = Color.White;
                            txtPed12.Text = "WALK";
                            txtPed12.ForeColor = Color.White;
                            break;
                        case 13:
                            shpPed13.BackColor = Color.White;
                            txtPed13.Text = "WALK";
                            txtPed13.ForeColor = Color.White;
                            break;
                        case 14:
                            shpPed14.BackColor = Color.White;
                            txtPed14.Text = "WALK";
                            txtPed14.ForeColor = Color.White;
                            break;
                        case 15:
                            shpPed15.BackColor = Color.White;
                            txtPed15.Text = "WALK";
                            txtPed15.ForeColor = Color.White;
                            break;
                        case 16:
                            shpPed16.BackColor = Color.White;
                            txtPed16.Text = "WALK";
                            txtPed16.ForeColor = Color.White;
                            break;
                    }
                }
                else if (Phases[i].PedClearState == true)
                {
                    switch (i)
                    {
                        case 1:
                            shpPed1.BackColor = Color.Yellow;
                            txtPed1.Text = "PEDCLEAR";
                            txtPed1.ForeColor = Color.Yellow;
                            break;
                        case 2:
                            shpPed2.BackColor = Color.Yellow;
                            txtPed2.Text = "PEDClear";
                            txtPed2.ForeColor = Color.Yellow;
                            break;
                        case 3:
                            shpPed3.BackColor = Color.Yellow;
                            txtPed3.Text = "PEDClear";
                            txtPed3.ForeColor = Color.Yellow;
                            break;
                        case 4:
                            shpPed4.BackColor = Color.Yellow;
                            txtPed4.Text = "PEDClear";
                            txtPed4.ForeColor = Color.Yellow;
                            break;
                        case 5:
                            shpPed5.BackColor = Color.Yellow;
                            txtPed5.Text = "PEDClear";
                            txtPed5.ForeColor = Color.Yellow;
                            break;
                        case 6:
                            shpPed6.BackColor = Color.Yellow;
                            txtPed6.Text = "PEDClear";
                            txtPed6.ForeColor = Color.Yellow;
                            break;
                        case 7:
                            shpPed7.BackColor = Color.Yellow;
                            txtPed7.Text = "PEDClear";
                            txtPed7.ForeColor = Color.Yellow;
                            break;
                        case 8:
                            shpPed8.BackColor = Color.Yellow;
                            txtPed8.Text = "PEDClear";
                            txtPed8.ForeColor = Color.Yellow;
                            break;
                        case 9:
                            shpPed9.BackColor = Color.Yellow;
                            txtPed9.Text = "PEDClear";
                            txtPed9.ForeColor = Color.Yellow;
                            break;
                        case 10:
                            shpPed10.BackColor = Color.Yellow;
                            txtPed10.Text = "PEDClear";
                            txtPed10.ForeColor = Color.Yellow;
                            break;
                        case 11:
                            shpPed11.BackColor = Color.Yellow;
                            txtPed11.Text = "PEDClear";
                            txtPed11.ForeColor = Color.Yellow;
                            break;
                        case 12:
                            shpPed12.BackColor = Color.Yellow;
                            txtPed12.Text = "PEDClear";
                            txtPed12.ForeColor = Color.Yellow;
                            break;
                        case 13:
                            shpPed13.BackColor = Color.Yellow;
                            txtPed13.Text = "PEDClear";
                            txtPed13.ForeColor = Color.Yellow;
                            break;
                        case 14:
                            shpPed14.BackColor = Color.Yellow;
                            txtPed14.Text = "PEDClear";
                            txtPed14.ForeColor = Color.Yellow;
                            break;
                        case 15:
                            shpPed15.BackColor = Color.Yellow;
                            txtPed15.Text = "PEDClear";
                            txtPed15.ForeColor = Color.Yellow;
                            break;
                        case 16:
                            shpPed16.BackColor = Color.Yellow;
                            txtPed16.Text = "PEDClear";
                            txtPed16.ForeColor = Color.Yellow;
                            break;
                    }
                }
            }
        }

        private int GetNumberofMaximumPhases()
        {
            int tmpNoPhases = 0;
            int j = 0;
            string OIDType = string.Empty;
            byte[] BytesRcvd;
            byte[] BytesSent;

            /*-- 1.3.6.1.4.1.1206.4.2.1.1.1.0  maxPhases.0
            maxPhases   OBJECT-TYPE
                SYNTAX   INTEGER (0..255)
                ACCESS   read-only
            STATUS   mandatory
            DESCRIPTION
                "NTCIP 1202 maxPhases                    
                The Maximum Number of Phases this       
                Actuated Controller Unit supports. This 
                object indicates the maximum rows which 
                shall appear in the phaseTable object." 
            REFERENCE
                "NTCIP 1202 Clause 2.2.1"
            ::= { phase 1 }*/

            OID = "1.3.6.1.4.1.1206.4.2.1.1.1.0";

            LogTxtMsg(txtEnableSPATPush, "\r\n" + GetCurrentTimeStamp() + "--- Get the maximum number of PHASES supported by the controller.");
            LogTxtMsg(txtEnableSPATPush, "\tNTCIP maxPhases OID: " + OID);

            //Initialize values
            NTCIPData.GotResponse = false;
            IntializePhasePropertyArrayValues();

            TimeSpan STS = new TimeSpan(DateTime.Now.Ticks);
            //call the NTCIP Activex library function.
            axaxNtcipIO1.GetOID(OID);
            TimeSpan CurrTS = new TimeSpan();

            do
            {
                if (NTCIPData.GotResponse == true)
                {
                    string tmpOIDValues = string.Empty;
                    BytesRcvd = Encoding.ASCII.GetBytes(axaxNtcipIO1.InByteStream);
                    BytesSent = Encoding.ASCII.GetBytes(axaxNtcipIO1.OutBufStream);

                    LogTxtMsg(txtEnableSPATPush, "\t BytesSent : " + BitConverter.ToString(BytesSent, 0));

                    if (BytesRcvd != null)
                    {
                        LogTxtMsg(txtEnableSPATPush, "\t BytesRcvd: " + BitConverter.ToString(BytesRcvd, 0));
                    }
                    txtEnableSPATPush.Refresh();
                    if (NoReceivedValues > 0)
                    {
                        tmpNoPhases = intReceivedValues[1];
                        tmpOIDValues = tmpOIDValues + intReceivedValues[1].ToString();
                    }
                    CurrTS = new TimeSpan(DateTime.Now.Ticks);
                    Duration = (int)(CurrTS.TotalMilliseconds - STS.TotalMilliseconds);
                    LogTxtMsg(txtEnableSPATPush, "\tNo of Trials: " + j);
                    LogTxtMsg(txtEnableSPATPush, "\tNo of Received OID Values: " + NoReceivedValues + "\t\tOIDValue: " + tmpOIDValues);
                    LogTxtMsg(txtEnableSPATPush, "\tNTCIP maxPhases:: " + tmpNoPhases.ToString() + "\t\tTimeDuration: " + Duration);
                    return tmpNoPhases;
                }
                CurrTS = new TimeSpan(DateTime.Now.Ticks);
                Application.DoEvents();
            } while ((CurrTS.TotalMilliseconds - STS.TotalMilliseconds) < (GlobalVars.TimeOutPeriod * 1000));

            LogTxtMsg(txtTSCLog, "\r\nGet NTCIP maxPhases:: Timed Out");

            return tmpNoPhases;
        }

        private int GetNumberofMaximumOvlps()
        {
            int tmpNoOvlps = 0;
            int j = 0;
            string OIDType = string.Empty;
            byte[] BytesRcvd;
            byte[] BytesSent;

            /*-- 1.3.6.1.4.1.1206.4.2.1.1.1.0  maxPhases.0
            maxPhases   OBJECT-TYPE
                SYNTAX   INTEGER (0..255)
                ACCESS   read-only
            STATUS   mandatory
            DESCRIPTION
                "NTCIP 1202 maxPhases                    
                The Maximum Number of Phases this       
                Actuated Controller Unit supports. This 
                object indicates the maximum rows which 
                shall appear in the phaseTable object." 
            REFERENCE
                "NTCIP 1202 Clause 2.2.1"
            ::= { phase 1 }*/

            /*-- 1.3.6.1.4.1.1206.4.2.1.9.1.0  maxOverlaps.0
            maxOverlaps   OBJECT-TYPE
                SYNTAX   INTEGER (0..255)
                ACCESS   read-only
            STATUS   mandatory
            DESCRIPTION
                "NTCIP 1202 maxOverlaps                  
                The Maximum Number of Overlaps this ASC 
                CU supports. This object indicates the  
                maximum number of rows which shall      
                appear in the overlapTable object."     
            REFERENCE
                "NTCIP 1202 Clause 2.10.1"
            ::= { overlap 1 }*/

            OID = "1.3.6.1.4.1.1206.4.2.1.9.1.0";

            LogTxtMsg(txtEnableSPATPush, "\r\n" + GetCurrentTimeStamp() + "--- Get the maximum number of OVLPS supported by the controller.");
            LogTxtMsg(txtEnableSPATPush, "\tNTCIP maxOvlps OID: " + OID);

            //call the NTCIP Activex library function.
            NTCIPData.GotResponse = false;
            IntializePhasePropertyArrayValues();
            TimeSpan STS = new TimeSpan(DateTime.Now.Ticks);

            axaxNtcipIO1.GetOID(OID);

            TimeSpan CurrTS = new TimeSpan();
            do
            {
                if (NTCIPData.GotResponse == true)
                {
                    string tmpOIDValues = string.Empty;
                    BytesRcvd = Encoding.ASCII.GetBytes(axaxNtcipIO1.InByteStream);
                    BytesSent = Encoding.ASCII.GetBytes(axaxNtcipIO1.OutBufStream);
                    LogTxtMsg(txtEnableSPATPush, "\t BytesSent : " + BitConverter.ToString(BytesSent, 0));
                    if (BytesRcvd != null)
                    {
                        LogTxtMsg(txtEnableSPATPush, "\t BytesRcvd: " + BitConverter.ToString(BytesRcvd, 0));
                    }
                    txtEnableSPATPush.Refresh();
                    if (NoReceivedValues > 0)
                    {
                        tmpNoOvlps = intReceivedValues[1];
                        tmpOIDValues = tmpOIDValues + intReceivedValues[1].ToString();
                    }
                    CurrTS = new TimeSpan(DateTime.Now.Ticks);
                    Duration = (int)(CurrTS.TotalMilliseconds - STS.TotalMilliseconds);
                    LogTxtMsg(txtEnableSPATPush, "\tNo of Trials: " + j);
                    LogTxtMsg(txtEnableSPATPush, "\tNo of Received OID Values: " + NoReceivedValues + "\t\tOIDValue: " + tmpOIDValues);
                    LogTxtMsg(txtEnableSPATPush, "\tNTCIP maxPhases:: " + tmpNoOvlps.ToString() + "\t\tTimeDuration: " + Duration);
                    return tmpNoOvlps;
                }
                CurrTS = new TimeSpan(DateTime.Now.Ticks);
                Application.DoEvents();
            } while ((CurrTS.TotalMilliseconds - STS.TotalMilliseconds) < (GlobalVars.TimeOutPeriod * 1000));

            LogTxtMsg(txtTSCLog, "\r\nGet NTCIP maxPhases:: Timed Out");

            return tmpNoOvlps;
        }

        private int GetNumberofMaximumPhaseGroups()
        {
            int tmpNoPhaseGroups = 0;
            int j = 0;
            string OIDType = string.Empty;
            byte[] BytesRcvd;
            byte[] BytesSent;

            /*
            -- 1.3.6.1.4.1.1206.4.2.1.1.3.0  maxPhaseGroups.0
            maxPhaseGroups   OBJECT-TYPE
                SYNTAX   INTEGER (1..255)
                ACCESS   read-only
                STATUS   mandatory
                DESCRIPTION
                    "NTCIP 1202 maxPhaseGroups               
                    The Maximum Number of Phase Groups (8   
                    Phases per group) this Actuated CU      
                    supports."                              
                REFERENCE
                    "NTCIP 1202 Clause 2.2.3"
            ::= { phase 3 }*/

            OID = "1.3.6.1.4.1.1206.4.2.1.1.3.0";

            LogTxtMsg(txtEnableSPATPush, "\r\n" + GetCurrentTimeStamp() + "--- Get the maximum number of Phase Groups supported by the controller.");
            LogTxtMsg(txtEnableSPATPush, "\tNTCIP maxPhaseGroups OID: " + OID);

            //call the NTCIP Activex library function.
            NTCIPData.GotResponse = false;
            IntializePhasePropertyArrayValues();
            TimeSpan STS = new TimeSpan(DateTime.Now.Ticks);
            axaxNtcipIO1.GetOID(OID);

            TimeSpan CurrTS = new TimeSpan();
            do
            {
                if (NTCIPData.GotResponse == true)
                {
                    BytesRcvd = Encoding.ASCII.GetBytes(axaxNtcipIO1.InByteStream);
                    BytesSent = Encoding.ASCII.GetBytes(axaxNtcipIO1.OutBufStream);
                    LogTxtMsg(txtEnableSPATPush, "\t BytesSent : " + BitConverter.ToString(BytesSent, 0));
                    LogTxtMsg(txtEnableSPATPush, "\t BytesRcvd: " + BitConverter.ToString(BytesRcvd, 0));
                    txtEnableSPATPush.Refresh();
                    string tmpOIDValues = string.Empty;
                    if (NoReceivedValues > 0)
                    {
                        tmpNoPhaseGroups = intReceivedValues[1];
                        tmpOIDValues = tmpOIDValues + intReceivedValues[1].ToString();
                    }
                    CurrTS = new TimeSpan(DateTime.Now.Ticks);
                    Duration = (int)(CurrTS.TotalMilliseconds - STS.TotalMilliseconds);
                    LogTxtMsg(txtEnableSPATPush, "\tNo of Trials: " + j);
                    LogTxtMsg(txtEnableSPATPush, "\tNo of Received OID Values: " + NoReceivedValues + "\t\tOIDValue: " + tmpOIDValues);
                    LogTxtMsg(txtEnableSPATPush, "\tNTCIP maxPhaseGroups:: " + tmpNoPhaseGroups.ToString() + "\t\tTimeDuration: " + Duration);
                    txtEnableSPATPush.Refresh();
                    return tmpNoPhaseGroups;
                }
                CurrTS = new TimeSpan(DateTime.Now.Ticks);
                Application.DoEvents();
            } while ((CurrTS.TotalMilliseconds - STS.TotalMilliseconds) < (GlobalVars.TimeOutPeriod * 1000));

            LogTxtMsg(txtTSCLog, "\r\nGet NTCIP maxPhaseGroups:: Timed Out");

            return tmpNoPhaseGroups;
        }

        private void IntializePhasePropertyArrayValues()
        {
            NoReceivedValues = 1;
            ReceivedValuesType = OIDTypes.intOID;
            for (int i = 0; i < 128; i++)
            {
                intReceivedValues[i] = 0;
                strReceivedValues[i] = string.Empty;
            }
        }

        private bool GetPhasePedestrianClear(ref UInt16[] phasePedestrianClear)
        {
            int j = 0;
            byte[] BytesRcvd;
            byte[] BytesSent;

            /*
            -- 1.3.6.1.4.1.1206.4.2.1.1.2.1.3.x  phasePedestrianClear.x
            phasePedestrianClear   OBJECT-TYPE
                SYNTAX   INTEGER (0..255)
                ACCESS   read-write
                STATUS   mandatory
                DESCRIPTION
                    "NTCIP 1202 phasePedestrianClear         
                    Phase Pedestrian Clear time in seconds."
                REFERENCE
                    "NTCIP 1202 Clause 2.2.2.3"
            ::= { phaseEntry 3 }
             */

            //Assign the base OID for phasePedestrianClear
            OID = "1.3.6.1.4.1.1206.4.2.1.1.2.1.3.";

            //LogTxtMsg(txtPhaseProperties, "\r\n\r\nGetting PEDESTRIAN CLEAR for phases supported by the controller:: ");
            //LogTxtMsg(txtPhaseProperties, "\tNTCIP phasePedestrianClear starting OID: " + OID);
            LogTxtMsg(txtEnableSPATPush, "\r\n" + GetCurrentTimeStamp() + "--- Get PEDESTRIAN CLEAR for phases supported by the controller.");
            LogTxtMsg(txtEnableSPATPush, "\tNTCIP phasePedestrianClear starting OID: " + OID);

            //Bind the phasePedestrianClear OIDS for all the phases into one call
            for (int i = 1; i <= GlobalVars.maxPhases; i++)
            {
                axaxNtcipIO1.AddBindingToPacket(OID + i.ToString(), "0", axNtcipIOControl.TxsetOIDType.otOID);
            }

            TimeSpan STS = new TimeSpan(DateTime.Now.Ticks);

            NTCIPData.GotResponse = false;
            IntializePhasePropertyArrayValues();
            //call the NTCIP Activex library function.
            axaxNtcipIO1.GetOIDs();

            TimeSpan CurrTS = new TimeSpan();
            do
            {
                if (NTCIPData.GotResponse == true)
                {
                    BytesRcvd = Encoding.ASCII.GetBytes(axaxNtcipIO1.InByteStream);
                    BytesSent = Encoding.ASCII.GetBytes(axaxNtcipIO1.OutBufStream);
                    LogTxtMsg(txtEnableSPATPush, "\t BytesSent : " + BitConverter.ToString(BytesSent, 0));
                    LogTxtMsg(txtEnableSPATPush, "\t BytesRcvd: " + BitConverter.ToString(BytesRcvd, 0));
                    txtEnableSPATPush.Refresh();

                    string tmpOIDValues = string.Empty;
                    for (int i = 1; i < NoReceivedValues; i++)
                    {
                        phasePedestrianClear[i] = (UInt16)intReceivedValues[i];
                        tmpOIDValues = tmpOIDValues + intReceivedValues[i].ToString() + ", ";
                    }
                    CurrTS = new TimeSpan(DateTime.Now.Ticks);
                    Duration = (int)(CurrTS.TotalMilliseconds - STS.TotalMilliseconds);
                    LogTxtMsg(txtEnableSPATPush, "\tNo of Trials: " + j);
                    LogTxtMsg(txtEnableSPATPush, "\tNo of Received OID Values: " + NoReceivedValues + "\t\tOIDValue: " + tmpOIDValues);
                    return true;
                }
                CurrTS = new TimeSpan(DateTime.Now.Ticks);
                Application.DoEvents();
                j++;
            } while ((CurrTS.TotalMilliseconds - STS.TotalMilliseconds) < (GlobalVars.TimeOutPeriod * 1000));

            return false;
        }

        private bool GetPhaseYellowChange(ref UInt16[] phaseYellowChange)
        {
            int j = 0;
            byte[] BytesRcvd;
            byte[] BytesSent;

            /*
            -- 1.3.6.1.4.1.1206.4.2.1.1.2.1.8.x  phaseYellowChange.x
            phaseYellowChange   OBJECT-TYPE
                SYNTAX   INTEGER (30..255)
                ACCESS   read-write
                STATUS   mandatory
                DESCRIPTION
                    "NTCIP 1202 phaseYellowChange            
                    Phase Yellow Change time in tenth sec." 
                REFERENCE
                    "NTCIP 1202 Clause 2.2.2.8"
                ::= { phaseEntry 8 }
             */

            //Assign the base OID for phaseYellowChange
            OID = "1.3.6.1.4.1.1206.4.2.1.1.2.1.8.";

            LogTxtMsg(txtEnableSPATPush, "\r\n" + GetCurrentTimeStamp() + "--- Get YELLOW CHANGE for phases supported by the controller.");
            LogTxtMsg(txtEnableSPATPush, "\tNTCIP phaseYellowChange starting OID: " + OID);

            //Bind the phaseYellowChange OIDS for all the phases into one call
            for (int i = 1; i <= GlobalVars.maxPhases; i++)
            {
                axaxNtcipIO1.AddBindingToPacket(OID + i.ToString(), "0", axNtcipIOControl.TxsetOIDType.otOID);
            }

            TimeSpan STS = new TimeSpan(DateTime.Now.Ticks);

            NTCIPData.GotResponse = false;
            IntializePhasePropertyArrayValues();
            //call the NTCIP Activex library function.
            axaxNtcipIO1.GetOIDs();

            TimeSpan CurrTS = new TimeSpan();
            do
            {
                if (NTCIPData.GotResponse == true)
                {
                    BytesRcvd = Encoding.ASCII.GetBytes(axaxNtcipIO1.InByteStream);
                    BytesSent = Encoding.ASCII.GetBytes(axaxNtcipIO1.OutBufStream);
                    LogTxtMsg(txtEnableSPATPush, "\t BytesSent : " + BitConverter.ToString(BytesSent, 0));
                    LogTxtMsg(txtEnableSPATPush, "\t BytesRcvd: " + BitConverter.ToString(BytesRcvd, 0));
                    txtEnableSPATPush.Refresh();

                    string tmpOIDValues = string.Empty;
                    for (int i = 1; i < NoReceivedValues; i++)
                    {
                        phaseYellowChange[i] = (UInt16)intReceivedValues[i];
                        tmpOIDValues = tmpOIDValues + intReceivedValues[i].ToString() + ", ";
                    }
                    CurrTS = new TimeSpan(DateTime.Now.Ticks);
                    Duration = (int)(CurrTS.TotalMilliseconds - STS.TotalMilliseconds);
                    LogTxtMsg(txtEnableSPATPush, "\tNo of Trials: " + j);
                    LogTxtMsg(txtEnableSPATPush, "\tNo of Received OID Values: " + NoReceivedValues + "\t\tOIDValue: " + tmpOIDValues);
                    return true;
                }
                CurrTS = new TimeSpan(DateTime.Now.Ticks);
                Application.DoEvents();
                j++;
            } while ((CurrTS.TotalMilliseconds - STS.TotalMilliseconds) < (GlobalVars.TimeOutPeriod * 1000));

            return false;
        }

        private bool GetPhaseRedClear(ref int[] phaseRedClear)
        {
            int j = 0;
            byte[] BytesRcvd;
            byte[] BytesSent;

            /*
            -- 1.3.6.1.4.1.1206.4.2.1.1.2.1.9.x  phaseRedClear.x
            phaseRedClear   OBJECT-TYPE
                SYNTAX   INTEGER (0..255)
                ACCESS   read-write
                STATUS   mandatory
                DESCRIPTION
                    "NTCIP 1202 phaseRedClear                
                    Phase Red Clearance time in tenth sec." 
                REFERENCE
                    "NTCIP 1202 Clause 2.2.2.9"
            ::= { phaseEntry 9 }
             */

            //Assign the base OID for phaseRedClear
            OID = "1.3.6.1.4.1.1206.4.2.1.1.2.1.9.";

            LogTxtMsg(txtEnableSPATPush, "\r\n" + GetCurrentTimeStamp() + "--- Get Red Clear for phases supported by the controller.");
            LogTxtMsg(txtEnableSPATPush, "\tNTCIP phaseRedClear starting OID: " + OID);

            //Bind the phaseRedClear OIDS for all the phases into one call
            for (int i = 1; i <= GlobalVars.maxPhases; i++)
            {
                axaxNtcipIO1.AddBindingToPacket(OID + i.ToString(), "0", axNtcipIOControl.TxsetOIDType.otOID);
            }

            TimeSpan STS = new TimeSpan(DateTime.Now.Ticks);

            NTCIPData.GotResponse = false;
            IntializePhasePropertyArrayValues();
            //call the NTCIP Activex library function.
            axaxNtcipIO1.GetOIDs();

            TimeSpan CurrTS = new TimeSpan();
            do
            {
                if (NTCIPData.GotResponse == true)
                {
                    BytesRcvd = Encoding.ASCII.GetBytes(axaxNtcipIO1.InByteStream);
                    BytesSent = Encoding.ASCII.GetBytes(axaxNtcipIO1.OutBufStream);
                    LogTxtMsg(txtEnableSPATPush, "\t BytesSent : " + BitConverter.ToString(BytesSent, 0));
                    LogTxtMsg(txtEnableSPATPush, "\t BytesRcvd: " + BitConverter.ToString(BytesRcvd, 0));
                    txtEnableSPATPush.Refresh();

                    string tmpOIDValues = string.Empty;
                    for (int i = 1; i < NoReceivedValues; i++)
                    {
                        phaseRedClear[i] = intReceivedValues[i];
                        tmpOIDValues = tmpOIDValues + intReceivedValues[i].ToString() + ", ";
                    }
                    CurrTS = new TimeSpan(DateTime.Now.Ticks);
                    Duration = (int)(CurrTS.TotalMilliseconds - STS.TotalMilliseconds);
                    LogTxtMsg(txtEnableSPATPush, "\tNo of Trials: " + j);
                    LogTxtMsg(txtEnableSPATPush, "\tNo of Received OID Values: " + NoReceivedValues + "\t\tOIDValue: " + tmpOIDValues);
                    return true;
                }
                CurrTS = new TimeSpan(DateTime.Now.Ticks);
                Application.DoEvents();
                j++;
            } while ((CurrTS.TotalMilliseconds - STS.TotalMilliseconds) < (GlobalVars.TimeOutPeriod * 1000));

            return false;
        }

        private bool GetPhaseRedRevert(ref int[] phaseRedRevert)
        {
            byte[] BytesRcvd;
            byte[] BytesSent;
            int j = 0;

            /*
            -- 1.3.6.1.4.1.1206.4.2.1.1.2.1.10.x  phaseRedRevert.x
            -- phaseRedRevert OBJECT-TYPE
            --    SYNTAX   INTEGER (0..255) 
            --    ACCESS   read-write
            --    STATUS   optional
            --    DESCRIPTION
            --       "NTCIP 1202 phaseRedRevert            
            --        Phase Red Revert time in tenth sec." 
            --    REFERENCE
            --       "NTCIP 1202 Clause 2.2.2.10"
            -- ::= { phaseEntry 10 }
             */

            //Assign the base OID for phaseRedRevert
            OID = "1.3.6.1.4.1.1206.4.2.1.1.2.1.10.";

            LogTxtMsg(txtEnableSPATPush, "\r\n" + GetCurrentTimeStamp() + "--- Get RED REVERT for phases supported by the controller.");
            LogTxtMsg(txtEnableSPATPush, "\tNTCIP phaseRedRevert starting OID: " + OID);

            //Bind the phaseRedRevert OIDS for all the phases into one call
            for (int i = 1; i <= GlobalVars.maxPhases; i++)
            {
                axaxNtcipIO1.AddBindingToPacket(OID + i.ToString(), "0", axNtcipIOControl.TxsetOIDType.otOID);
            }

            TimeSpan STS = new TimeSpan(DateTime.Now.Ticks);

            NTCIPData.GotResponse = false;
            IntializePhasePropertyArrayValues();
            //call the NTCIP Activex library function.
            axaxNtcipIO1.GetOIDs();

            TimeSpan CurrTS = new TimeSpan();
            do
            {
                if (NTCIPData.GotResponse == true)
                {
                    BytesRcvd = Encoding.ASCII.GetBytes(axaxNtcipIO1.InByteStream);
                    BytesSent = Encoding.ASCII.GetBytes(axaxNtcipIO1.OutBufStream);
                    LogTxtMsg(txtEnableSPATPush, "\t BytesSent : " + BitConverter.ToString(BytesSent, 0));
                    LogTxtMsg(txtEnableSPATPush, "\t BytesRcvd: " + BitConverter.ToString(BytesRcvd, 0));
                    txtEnableSPATPush.Refresh();

                    string tmpOIDValues = string.Empty;
                    for (int i = 1; i < NoReceivedValues; i++)
                    {
                        phaseRedRevert[i] = intReceivedValues[i];
                        tmpOIDValues = tmpOIDValues + intReceivedValues[i].ToString() + ", ";
                    }
                    CurrTS = new TimeSpan(DateTime.Now.Ticks);
                    Duration = (int)(CurrTS.TotalMilliseconds - STS.TotalMilliseconds);
                    LogTxtMsg(txtEnableSPATPush, "\tNo of Trials: " + j);
                    LogTxtMsg(txtEnableSPATPush, "\tNo of Received OID Values: " + NoReceivedValues + "\t\tOIDValue: " + tmpOIDValues);
                    return true;
                }
                CurrTS = new TimeSpan(DateTime.Now.Ticks);
                Application.DoEvents();
                j++;
            } while ((CurrTS.TotalMilliseconds - STS.TotalMilliseconds) < (GlobalVars.TimeOutPeriod * 1000));

            return false;
        }

        private void LogTxtMsg(TextBox txtControl, string Text)
        {
            Text = "\r\n" + Text;
            //Text = Environment.NewLine + "\t" + Text;
            if (txtControl.Text.Length > 30000)
                txtControl.Text = "";

            txtControl.SelectionStart = txtControl.Text.Length;
            txtControl.SelectedText = Text;
            txtControl.SelectionStart = txtControl.Text.Length;
        }

        private string EnableSpatMessagePush(string SpatEnableOID, string OIDValue)
        {
            string retValue = string.Empty;
            byte[] BytesRcvd;
            byte[] BytesSent;

            BeginTime = (DateTime.Now.Hour * 3600 + DateTime.Now.Minute * 60 + DateTime.Now.Second) * 1000 + DateTime.Now.Millisecond;
            if (SpatEnableOID.Length > 0)
            {
                LogTxtMsg(txtEnableSPATPush, "\r\nSPaTMessageEnableOID: " + OID + "\tOID Value: " + OIDValue.ToString());

                if ((OIDValue.Length > 0) && ((Convert.ToInt32(OIDValue) == 0) || (Convert.ToInt32(OIDValue) == 2) || (Convert.ToInt32(OIDValue) == 6)))
                {
                    //SenderFunction = "EnableSpatMessagePush";
                    NTCIPData.GotResponse = false;
                    IntializePhasePropertyArrayValues();
                    BeginTime = (DateTime.Now.Hour * 3600 + DateTime.Now.Minute * 60 + DateTime.Now.Second) * 1000 + DateTime.Now.Millisecond;
                    axaxNtcipIO1.SetOID(SpatEnableOID, OIDValue, axNtcipIOControl.TxsetOIDType.otInteger);
                }
                else
                {
                    retValue = "\r\n--The values for SPATMessagePush must be either 0-for Disable, 2- for SPaT data, or 6- for SPaT + Ped Info. Please correct the value: " + OIDValue;
                    return retValue;
                }
                TimeSpan STS = new TimeSpan(DateTime.Now.Ticks);
                TimeSpan CurrTS = new TimeSpan();
                do
                {
                    CurrTS = new TimeSpan(DateTime.Now.Ticks);

                    if (NTCIPData.GotResponse == true)
                    {
                        BytesRcvd = Encoding.ASCII.GetBytes(axaxNtcipIO1.InByteStream);
                        BytesSent = Encoding.ASCII.GetBytes(axaxNtcipIO1.OutBufStream);
                        LogTxtMsg(txtEnableSPATPush, "\t BytesSent : " + BitConverter.ToString(BytesSent, 0));
                        LogTxtMsg(txtEnableSPATPush, "\t BytesRcvd: " + BitConverter.ToString(BytesRcvd, 0));
                        EndTime = (DateTime.Now.Hour * 3600 + DateTime.Now.Minute * 60 + DateTime.Now.Second) * 1000 + DateTime.Now.Millisecond;
                        txtEnableSPATPush.Refresh();
                        string data = string.Empty;
                        for (int k = 0; k < BytesRcvd.Length; k++)
                        {
                            data += BytesRcvd[k].ToString() + "-";
                            //LogTxtMsg(txtEnableSPATPush, "\r\n" + BytesRcvd[k].ToString());
                        }
                        LogTxtMsg(txtEnableSPATPush, "\t ByteValues: " + data);
                        LogTxtMsg(txtEnableSPATPush, "\t Duration: " + (EndTime - BeginTime) + " milliseconds.");

                        //SenderFunction = string.Empty;
                        return retValue;
                    }
                    Application.DoEvents();
                } while ((CurrTS.TotalMilliseconds - STS.TotalMilliseconds) < (GlobalVars.TimeOutPeriod * 1000));
            }
            else
            {
                retValue = "\r\n--The specified SPATMessagePush OID is empty. Please specify the proper SAPTMessagePush Enable/Disable OID: " + SpatEnableOID;
                return retValue;
            }
            return retValue;
        }

        private void frmMain_FormClosing(object sender, FormClosingEventArgs e)
        {

            string strRetValue = string.Empty;
            if (axaxNtcipIO1.Connected == true)
            {
                LogTxtMsg(txtEnableSPATPush, "\r\n" + GetCurrentTimeStamp() + "--- Disable SPaT TSC Data Push.");
                strRetValue = string.Empty;
                strRetValue = EnableSpatMessagePush("1.3.6.1.4.1.1206.3.5.2.9.44.1.0", "0");
                if (strRetValue.Length > 0)
                {
                    WriteMsgToLogFile(spatErrorsLog, GetCurrentTimeStamp() + strRetValue);
                }
            }

            if (chkEnableDataLogging.Checked == true)
            {
                dailyLogFile.Close();
                spatMsgFile.Close();
               
                //spatErrorsLog.Close();
            }
            if (System.Windows.Forms.Application.MessageLoop)
            {
                // Use this since we are a WinForms app
                System.Windows.Forms.Application.Exit();
            }
            else
            {
                // Use this since we are a console app
                System.Environment.Exit(1);
            }

            //this.Close();
        }

        private string UpdateTimeBaseActionStatus(int currtscactionnumber)
        {
            string retValue = string.Empty;

            //Read the SPAT Msg broadcast information
            //string DispatchInfoFile = Application.StartupPath + "\\Config\\" + GlobalVars.SPATDispatchInfoFile;
            string DispatchInfoFile = Application.StartupPath + "\\config.xml" ;
            LogTxtMsg(txtActivityLog, "\r\nUpdating the SPAT dispatch info file: " + DispatchInfoFile);

            string sTag;
            string sValue;
            bool modifiedTSCActionNumber = false;

            //      Load the Configuration File
            try
            {
                XDocument doc = XDocument.Load(DispatchInfoFile);
                XElement root = doc.Root;

                //      Parse the Configuration File Elements
                foreach (XElement element in root.Elements())
                {
                    sTag = element.Name.ToString();
                    sValue = element.Value.ToString();
                    switch (sTag.ToLower())
                    {
                        //              Parse the map Configuration Elements
                        case "map":
                            {
                                foreach (XElement child in element.Elements())
                                {
                                    sTag = child.Name.ToString();
                                    sValue = child.Value.ToString();
                                    switch (sTag.ToLower())
                                    {
                                        //case "default": { mobjSpatConfiguration.filename = sValue; break; }
                                        case "currenttscactionnumber":
                                            {
                                                child.SetValue((string)(currtscactionnumber.ToString()));
                                                modifiedTSCActionNumber = true;
                                                doc.Save(DispatchInfoFile);
                                                return retValue;
                                            }
                                    }
                                }
                                break;
                            }
                    }
                }
            }
            catch (Exception Exp)
            {
                retValue = "Error reading DispatchInfo configuration file: " + DispatchInfoFile + "\r\n\t" + Exp.Message;

                return retValue;
            }
            if (modifiedTSCActionNumber == false)
            {
                MessageBox.Show("Unable to find the currenttscactionnumber data element in the Dispatch information configuration file: " + DispatchInfoFile.ToString());
                retValue = "Unable to find the currenttscactionnumber data element in the Dispatch information configuration file: " + DispatchInfoFile.ToString();
            }
            return retValue;
        }

        private void tmrUDPClient_Tick(object sender, EventArgs e)
        {
            int j = 0;
            string stringValue = string.Empty;
            string data = string.Empty;
            string datastr = string.Empty;
            //IntSPATMsg[] intSPATMsg = new IntSPATMsg[GlobalVars.maxPhases + 1];
            GlobalVars.ByteSPATMsg[] bytesSPATMsg = new GlobalVars.ByteSPATMsg[GlobalVars.maxPhases + 1];
            byte byteIntersectionStatus = 0;
            byte J2735IntersectionStatus = 0x1f;

            for (int i = 0; i <= GlobalVars.maxPhases; i++)
            {
                bytesSPATMsg[i].VMinTime = new byte[4];
                bytesSPATMsg[i].VMaxTime = new byte[4];
                bytesSPATMsg[i].PedMinTime = new byte[4];
                bytesSPATMsg[i].PedMaxTime = new byte[4];
                bytesSPATMsg[i].OvlpMinTime = new byte[4];
                bytesSPATMsg[i].OvlpMaxTime = new byte[4];
            }
            byte[] tmpphasebytes = new byte[12];
            byte[] PhaseGreensBytes = new byte[4];
            byte[] PhaseYellowsBytes = new byte[4];
            byte[] PhaseRedsBytes = new byte[4];
            byte[] OvlpGreensBytes = new byte[4];
            byte[] OvlpYellowsBytes = new byte[4];
            byte[] OvlpRedsBytes = new byte[4];
            byte[] PedWalksBytes = new byte[4];
            byte[] PedDontWalksBytes = new byte[4];
            byte[] PedClearBytes = new byte[4];

            byte PhaseGreensGrp1Byte;
            byte PhaseYellowsGrp1Byte;
            byte PhaseRedsGrp1Byte;
            byte OvlpGreensGrp1Byte;
            byte OvlpYellowsGrp1Byte;
            byte OvlpRedsGrp1Byte;
            byte PedWalksGrp1Byte;
            byte PedDontWalksGrp1Byte;
            byte PedClearGrp1Byte;

            byte PhaseGreensGrp2Byte;
            byte PhaseYellowsGrp2Byte;
            byte PhaseRedsGrp2Byte;
            byte OvlpGreensGrp2Byte;
            byte OvlpYellowsGrp2Byte;
            byte OvlpRedsGrp2Byte;
            byte PedWalksGrp2Byte;
            byte PedDontWalksGrp2Byte;
            byte PedClearGrp2Byte;

            byte PhaseFlashingStatusGrp1Byte;
            byte PhaseFlashingStatusGrp2Byte;

            byte OvlpFlashingStatusGrp1Byte;
            byte OvlpFlashingStatusGrp2Byte;

            if (TSCListener.Available > 0)
            {
                //LogTxtMsg(txtTSCLog, "\r\n\r\n  ***** New SPAT data is available from: " + TSCListener.ToString());

                currTmrWakeUpTimeMsecs = (DateTime.Now.Hour * 3600 + DateTime.Now.Minute * 60 + DateTime.Now.Second) * 1000 + DateTime.Now.Millisecond;

                txtSysTime.Text = DateTime.Now.Hour.ToString() + ":" + DateTime.Now.Minute.ToString() + ":" +
                                    DateTime.Now.Second.ToString();// +"::" + DateTime.Now.Millisecond.ToString();

                txtSysMsec.Text = DateTime.Now.Millisecond.ToString();
                byte[] bytes = TSCListener.Receive(ref TSC);
                if (bytes.Length > 0)
                {
                    lblBytesRead.ForeColor = Color.Green;
                }
                else
                {
                    lblBytesRead.ForeColor = Color.Red;
                }
                lblBytesRead.Text = "TSC SPaT bytes read:= " + bytes.Length;

                if ((chkEnableDataLogging.Checked == true) && (chkTSCData.Checked == true))
                {
                    WriteMsgToLogFile(dailyLogFile, GetCurrentTimeStamp() + ",TSCSPaTData," + BitConverter.ToString(bytes, 0));
                }

                txtSPaTSysInterval.Text = (currTmrWakeUpTimeMsecs - prevTmrWakeUpTimeMsecs).ToString();

                if (chkEnableDataLogging.Checked == true)
                {
                    //WriteMsgToLogFile(dailyLogFile, GetCurrentTimeStamp()  + ",TSC-to-BB--SYS-Interval(Msec)," + (currTmrWakeUpTimeMsecs - prevTmrWakeUpTimeMsecs) + "," + 
                    //                                                                                        (currTmrWakeUpTimeMsecs - endWakeUpTime));
                }
                prevTmrWakeUpTimeMsecs = currTmrWakeUpTimeMsecs;
                LogTxtMsg(txtTSCLog, "TSC-SPaT Data: " + BitConverter.ToString(bytes, 0));


                if (bytes.Length >= 235)
                {
                    byteTimeBaseASCActionStatus = bytes[233];
                    intCurrTimeBaseAscActionStatus = (int)byteTimeBaseASCActionStatus;
                    if (intCurrTimeBaseAscActionStatus == intPrevTimeBaseAscActionStatus)
                    {
                        txtTimeBaseActionStatus.BackColor = Color.Black;
                    }
                    else
                    {
                        txtTimeBaseActionStatus.BackColor = Color.DarkOrange;
                        if (chkEnableDataLogging.Checked == true)
                        {
                            WriteMsgToLogFile(dailyLogFile, GetCurrentTimeStamp() + ",TimeBaseActionStatus#Changed," + 
                                                            ",New-TimeBaseActionStatus#, " + intCurrTimeBaseAscActionStatus +
                                                            ",Old-TimeBaseActionStatus#, " + intPrevTimeBaseAscActionStatus);
                        }
                        UpdateTimeBaseActionStatus(intCurrTimeBaseAscActionStatus);
                    }
                    txtTimeBaseActionStatus.Text = intCurrTimeBaseAscActionStatus.ToString();
                    intPrevTimeBaseAscActionStatus = intCurrTimeBaseAscActionStatus;

                    byteDiscontinuousFlag = bytes[234];
                    intCurrDiscontinuousFlag = (int)byteDiscontinuousFlag;
                    if (intCurrDiscontinuousFlag == intPrevDiscontinuousFlag)
                    {
                        txtDiscontinuousFlag.BackColor = Color.Black;
                        chkDiscontinuousFlag.BackColor = Color.LightGray;
                    }
                    else
                    {
                        txtDiscontinuousFlag.BackColor = Color.DarkOrange;
                        chkDiscontinuousFlag.BackColor = Color.DarkOrange;
                        if (chkEnableDataLogging.Checked == true)
                        {
                            WriteMsgToLogFile(dailyLogFile, GetCurrentTimeStamp() + ",DiscontinuousFlag--Status-Cahnge");
                        }
                    }
                    txtDiscontinuousFlag.Text = intCurrDiscontinuousFlag.ToString();
                    intPrevDiscontinuousFlag = intCurrDiscontinuousFlag;

                    byteMsgNo = bytes[235];
                    intMsgNo = (int)byteMsgNo;
                    txtTSCMsgNo.Text = intMsgNo.ToString();


                    int start = 3;

                    for (j = 1; j < GlobalVars.maxPhases + 1; j++)
                    {
                        /*tmpphasebytes[0] = bytes[start + (j - 1) * 13];
                        tmpphasebytes[1] = bytes[start + 1 + (j - 1) * 13];
                        tmpphasebytes[2] = bytes[start + 2 + (j - 1) * 13];
                        tmpphasebytes[3] = bytes[start + 3 + (j - 1) * 13];
                        tmpphasebytes[4] = bytes[start + 4 + (j - 1) * 13];
                        tmpphasebytes[5] = bytes[start + 5 + (j - 1) * 13];
                        tmpphasebytes[6] = bytes[start + 6 + (j - 1) * 13];
                        tmpphasebytes[7] = bytes[start + 7 + (j - 1) * 13];
                        tmpphasebytes[8] = bytes[start + 8 + (j - 1) * 13];
                        tmpphasebytes[9] = bytes[start + 9 + (j - 1) * 13];
                        tmpphasebytes[10] = bytes[start + 10 + (j - 1) * 13];
                        tmpphasebytes[11] = bytes[start + 11 + (j - 1) * 13];

                        if (chkEnableDataLogging.Checked == true)
                        {
                            dailyLogFile.WriteLine("Phase: " + j + "\t" + BitConverter.ToString(tmpphasebytes, 0));
                        }*/
                        bytesSPATMsg[j].VMinTime[0] = bytes[start + 1 + (j - 1) * 13];
                        bytesSPATMsg[j].VMinTime[1] = bytes[start + (j - 1) * 13];
                        Phases[j].VMinTime = BitConverter.ToUInt16(bytesSPATMsg[j].VMinTime, 0);

                        bytesSPATMsg[j].VMaxTime[0] = bytes[start + 3 + (j - 1) * 13];
                        bytesSPATMsg[j].VMaxTime[1] = bytes[start + 2 + (j - 1) * 13];
                        Phases[j].VMaxTime = BitConverter.ToUInt16(bytesSPATMsg[j].VMaxTime, 0);

                        bytesSPATMsg[j].PedMinTime[0] = bytes[start + 5 + (j - 1) * 13];
                        bytesSPATMsg[j].PedMinTime[1] = bytes[start + 4 + (j - 1) * 13];
                        Phases[j].PedMinTime = BitConverter.ToUInt16(bytesSPATMsg[j].PedMinTime, 0);

                        bytesSPATMsg[j].PedMaxTime[0] = bytes[start + 7 + (j - 1) * 13];
                        bytesSPATMsg[j].PedMaxTime[1] = bytes[start + 6 + (j - 1) * 13];
                        Phases[j].PedMaxTime = BitConverter.ToUInt16(bytesSPATMsg[j].PedMaxTime, 0);

                        bytesSPATMsg[j].OvlpMinTime[0] = bytes[start + 9 + (j - 1) * 13];
                        bytesSPATMsg[j].OvlpMinTime[1] = bytes[start + 8 + (j - 1) * 13];
                        Phases[j].OvlpMinTime = BitConverter.ToUInt16(bytesSPATMsg[j].OvlpMinTime, 0);

                        bytesSPATMsg[j].OvlpMaxTime[0] = bytes[start + 11 + (j - 1) * 13];
                        bytesSPATMsg[j].OvlpMaxTime[1] = bytes[start + 10 + (j - 1) * 13];
                        Phases[j].OvlpMaxTime = BitConverter.ToUInt16(bytesSPATMsg[j].OvlpMaxTime, 0);
                        //if (chkEnableDataLogging.Checked == true)
                        //{
                        //    WriteMsgToLogFile(dailyLogFile, GetCurrentTimeStamp() + "--" + j.ToString() + "\tVMinTime:" + Phases[j].VMinTime + "\tVMaxTime:" + Phases[j].VMaxTime +
                        //                                          "\tPedMinTime:" + Phases[j].PedMinTime + "\tPedMaxTime:" + Phases[j].PedMaxTime +
                        //                                          "\tOvlpMinTime:" + Phases[j].OvlpMinTime + "\tOvlpMaxTime:" + Phases[j].OvlpMaxTime);
                        //}
                    }

                    byte stateMask = 0;
                    int tmpGrp = 0;

                    PhaseRedsGrp1Byte = bytes[211];

                    stateMask = 128;
                    //string tmpPhaseRedsGrp1 = string.Empty;
                    tmpGrp = 1;
                    for (int i = 8; i > 0; i--)
                    {
                        if ((stateMask & PhaseRedsGrp1Byte) == stateMask)
                        {
                            Phases[i + (tmpGrp - 1) * 8].Red = true;
                            Phases[i + (tmpGrp - 1) * 8].Status = (byte)GlobalVars.enum_phase_status.Red;
                        }
                        else
                        {
                            Phases[i + (tmpGrp - 1) * 8].Red = false;
                        }
                        stateMask = (byte)(stateMask >> 1);
                    }

                    PhaseRedsGrp2Byte = bytes[210];

                    stateMask = 128;
                    //string tmpPhaseRedsGrp2 = string.Empty;
                    tmpGrp = 2;
                    for (int i = 8; i > 0; i--)
                    {
                        if ((stateMask & PhaseRedsGrp2Byte) == stateMask)
                        {
                            Phases[i + (tmpGrp - 1) * 8].Red = true;
                            Phases[i + (tmpGrp - 1) * 8].Status = (byte)GlobalVars.enum_phase_status.Red;
                        }
                        else
                        {
                            Phases[i + (tmpGrp - 1) * 8].Red = false;
                        }
                        stateMask = (byte)(stateMask >> 1);
                    }

                    PhaseYellowsGrp1Byte = bytes[213];

                    stateMask = 128;
                    //string tmpPhaseYellowsGrp1 = string.Empty;
                    tmpGrp = 1;
                    for (int i = 8; i > 0; i--)
                    {
                        if ((stateMask & PhaseYellowsGrp1Byte) == stateMask)
                        {
                            Phases[i + (tmpGrp - 1) * 8].Yellow = true;
                            Phases[i + (tmpGrp - 1) * 8].Status = (byte)GlobalVars.enum_phase_status.Yellow;
                        }
                        else
                        {
                            Phases[i + (tmpGrp - 1) * 8].Yellow = false;
                        }
                        stateMask = (byte)(stateMask >> 1);
                    }


                    PhaseYellowsGrp2Byte = bytes[212];

                    stateMask = 128;
                    //string tmpPhaseYellowsGrp2 = string.Empty;
                    tmpGrp = 2;
                    for (int i = 8; i > 0; i--)
                    {
                        if ((stateMask & PhaseYellowsGrp2Byte) == stateMask)
                        {
                            Phases[i + (tmpGrp - 1) * 8].Yellow = true;
                            Phases[i + (tmpGrp - 1) * 8].Status = (byte)GlobalVars.enum_phase_status.Yellow;
                        }
                        else
                        {
                            Phases[i + (tmpGrp - 1) * 8].Yellow = false;
                        }
                        stateMask = (byte)(stateMask >> 1);
                    }

                    PhaseGreensGrp1Byte = bytes[215];

                    stateMask = 128;
                    //string tmpPhaseGreensGrp1 = string.Empty;
                    tmpGrp = 1;
                    for (int i = 8; i > 0; i--)
                    {
                        if ((stateMask & PhaseGreensGrp1Byte) == stateMask)
                        {
                            Phases[i + (tmpGrp - 1) * 8].Green = true;
                            Phases[i + (tmpGrp - 1) * 8].Status = (byte)GlobalVars.enum_phase_status.Green;
                        }
                        else
                        {
                            Phases[i + (tmpGrp - 1) * 8].Green = false;
                        }
                        stateMask = (byte)(stateMask >> 1);
                    }

                    PhaseGreensGrp2Byte = bytes[214];

                    stateMask = 128;
                    //string tmpPhaseGreensGrp2 = string.Empty;
                    tmpGrp = 2;
                    for (int i = 8; i > 0; i--)
                    {
                        if ((stateMask & PhaseGreensGrp2Byte) == stateMask)
                        {
                            Phases[i + (tmpGrp - 1) * 8].Green = true;
                            Phases[i + (tmpGrp - 1) * 8].Status = (byte)GlobalVars.enum_phase_status.Green;
                        }
                        else
                        {
                            Phases[i + (tmpGrp - 1) * 8].Green = false;
                        }
                        stateMask = (byte)(stateMask >> 1);
                    }

                    PedDontWalksGrp1Byte = bytes[217];

                    stateMask = 128;
                    //string tmpPedDontWalksGrp1 = string.Empty;
                    tmpGrp = 1;
                    for (int i = 8; i > 0; i--)
                    {
                        if ((stateMask & PedDontWalksGrp1Byte) == stateMask)
                        {
                            Phases[i + (tmpGrp - 1) * 8].PedDontWalk = true;
                            Phases[i + (tmpGrp - 1) * 8].PedStatus = (byte)GlobalVars.enum_phase_status.DontWalk;
                        }
                        else
                        {
                            Phases[i + (tmpGrp - 1) * 8].PedDontWalk = false;
                        }
                        stateMask = (byte)(stateMask >> 1);
                    }

                    PedDontWalksGrp2Byte = bytes[216];

                    stateMask = 128;
                    //string tmpPedDontWalksGrp2 = string.Empty;
                    tmpGrp = 2;
                    for (int i = 8; i > 0; i--)
                    {
                        if ((stateMask & PedDontWalksGrp2Byte) == stateMask)
                        {
                            Phases[i + (tmpGrp - 1) * 8].PedDontWalk = true;
                            Phases[i + (tmpGrp - 1) * 8].PedStatus = (byte)GlobalVars.enum_phase_status.DontWalk;
                        }
                        else
                        {
                            Phases[i + (tmpGrp - 1) * 8].PedDontWalk = false;
                        }
                        stateMask = (byte)(stateMask >> 1);
                    }

                    PedClearGrp1Byte = bytes[219];

                    stateMask = 128;
                    //string tmpPedClearGrp1 = string.Empty;
                    tmpGrp = 1;
                    for (int i = 8; i > 0; i--)
                    {
                        if ((stateMask & PedClearGrp1Byte) == stateMask)
                        {
                            Phases[i + (tmpGrp - 1) * 8].PedClearState = true;
                            Phases[i + (tmpGrp - 1) * 8].PedStatus = (byte)GlobalVars.enum_phase_status.PedClear;
                        }
                        else
                        {
                            Phases[i + (tmpGrp - 1) * 8].PedClearState = false;
                        }
                        stateMask = (byte)(stateMask >> 1);
                    }

                    PedClearGrp2Byte = bytes[218];

                    stateMask = 128;
                    //string tmpPedClearGrp2 = string.Empty;
                    tmpGrp = 2;
                    for (int i = 8; i > 0; i--)
                    {
                        if ((stateMask & PedClearGrp2Byte) == stateMask)
                        {
                            Phases[i + (tmpGrp - 1) * 8].PedClearState = true;
                            Phases[i + (tmpGrp - 1) * 8].PedStatus = (byte)GlobalVars.enum_phase_status.PedClear;
                        }
                        else
                        {
                            Phases[i + (tmpGrp - 1) * 8].PedClearState = false;
                        }
                        stateMask = (byte)(stateMask >> 1);
                    }

                    PedWalksGrp1Byte = bytes[221];

                    stateMask = 128;
                    //string tmpPedWalksGrp1 = string.Empty;
                    tmpGrp = 1;
                    for (int i = 8; i > 0; i--)
                    {
                        if ((stateMask & PedWalksGrp1Byte) == stateMask)
                        {
                            Phases[i + (tmpGrp - 1) * 8].PedWalk = true;
                            Phases[i + (tmpGrp - 1) * 8].PedStatus = (byte)GlobalVars.enum_phase_status.Walk;
                        }
                        else
                        {
                            Phases[i + (tmpGrp - 1) * 8].PedWalk = false;
                        }
                        stateMask = (byte)(stateMask >> 1);
                    }

                    PedWalksGrp2Byte = bytes[220];

                    stateMask = 128;
                    //string tmpPedWalksGrp2 = string.Empty;
                    tmpGrp = 2;
                    for (int i = 8; i > 0; i--)
                    {
                        if ((stateMask & PedWalksGrp2Byte) == stateMask)
                        {
                            Phases[i + (tmpGrp - 1) * 8].PedWalk = true;
                            Phases[i + (tmpGrp - 1) * 8].PedStatus = (byte)GlobalVars.enum_phase_status.Walk;
                        }
                        else
                        {
                            Phases[i + (tmpGrp - 1) * 8].PedWalk = false;
                        }
                        stateMask = (byte)(stateMask >> 1);
                    }

                    OvlpRedsGrp1Byte = bytes[223];

                    stateMask = 128;
                    //string tmpOvlpRedsGrp1 = string.Empty;
                    tmpGrp = 1;
                    for (int i = 8; i > 0; i--)
                    {
                        if ((stateMask & OvlpRedsGrp1Byte) == stateMask)
                        {
                            Phases[i + (tmpGrp - 1) * 8].OvlpRed = true;
                            Phases[i + (tmpGrp - 1) * 8].OvlpStatus = (byte)GlobalVars.enum_phase_status.Red;
                        }
                        else
                        {
                            Phases[i + (tmpGrp - 1) * 8].OvlpRed = false;
                        }
                        stateMask = (byte)(stateMask >> 1);
                    }

                    OvlpRedsGrp2Byte = bytes[222];

                    stateMask = 128;
                    //string tmpOvlpRedsGrp2 = string.Empty;
                    tmpGrp = 2;
                    for (int i = 8; i > 0; i--)
                    {
                        if ((stateMask & OvlpRedsGrp2Byte) == stateMask)
                        {
                            Phases[i + (tmpGrp - 1) * 8].OvlpRed = true;
                            Phases[i + (tmpGrp - 1) * 8].OvlpStatus = (byte)GlobalVars.enum_phase_status.Red;
                        }
                        else
                        {
                            Phases[i + (tmpGrp - 1) * 8].OvlpRed = false;
                        }
                        stateMask = (byte)(stateMask >> 1);
                    }

                    OvlpYellowsGrp1Byte = bytes[225];

                    stateMask = 128;
                    //string tmpOvlpYellowsGrp1 = string.Empty;
                    tmpGrp = 1;
                    for (int i = 8; i > 0; i--)
                    {
                        if ((stateMask & OvlpYellowsGrp1Byte) == stateMask)
                        {
                            Phases[i + (tmpGrp - 1) * 8].OvlpYellow = true;
                            Phases[i + (tmpGrp - 1) * 8].OvlpStatus = (byte)GlobalVars.enum_phase_status.Yellow;
                        }
                        else
                        {
                            Phases[i + (tmpGrp - 1) * 8].OvlpYellow = false;
                        }
                        stateMask = (byte)(stateMask >> 1);
                    }

                    OvlpYellowsGrp2Byte = bytes[224];

                    stateMask = 128;
                    //string tmpOvlpYellowsGrp2 = string.Empty;
                    tmpGrp = 2;
                    for (int i = 8; i > 0; i--)
                    {
                        if ((stateMask & OvlpYellowsGrp2Byte) == stateMask)
                        {
                            Phases[i + (tmpGrp - 1) * 8].OvlpYellow = true;
                            Phases[i + (tmpGrp - 1) * 8].OvlpStatus = (byte)GlobalVars.enum_phase_status.Yellow;
                        }
                        else
                        {
                            Phases[i + (tmpGrp - 1) * 8].OvlpYellow = false;
                        }
                        stateMask = (byte)(stateMask >> 1);
                    }

                    OvlpGreensGrp1Byte = bytes[227];

                    stateMask = 128;
                    //string tmpOvlpGreensGrp1 = string.Empty;
                    tmpGrp = 1;
                    for (int i = 8; i > 0; i--)
                    {
                        if ((stateMask & OvlpGreensGrp1Byte) == stateMask)
                        {
                            Phases[i + (tmpGrp - 1) * 8].OvlpGreen = true;
                            Phases[i + (tmpGrp - 1) * 8].OvlpStatus = (byte)GlobalVars.enum_phase_status.Green;
                        }
                        else
                        {
                            Phases[i + (tmpGrp - 1) * 8].OvlpGreen = false;
                        }
                        stateMask = (byte)(stateMask >> 1);
                    }

                    OvlpGreensGrp2Byte = bytes[226];

                    stateMask = 128;
                    //string tmpOvlpGreensGrp2 = string.Empty;
                    tmpGrp = 2;
                    for (int i = 8; i > 0; i--)
                    {
                        if ((stateMask & OvlpGreensGrp2Byte) == stateMask)
                        {
                            Phases[i + (tmpGrp - 1) * 8].OvlpGreen = true;
                            Phases[i + (tmpGrp - 1) * 8].OvlpStatus = (byte)GlobalVars.enum_phase_status.Green;
                        }
                        else
                        {
                            Phases[i + (tmpGrp - 1) * 8].OvlpGreen = false;
                        }
                        stateMask = (byte)(stateMask >> 1);
                    }

                    PhaseFlashingStatusGrp1Byte = bytes[229];

                    stateMask = 128;
                    //string tmpPhaseFlashingGrp1 = string.Empty;
                    tmpGrp = 1;
                    for (int i = 8; i > 0; i--)
                    {
                        if ((stateMask & PhaseFlashingStatusGrp1Byte) == stateMask)
                        {
                            Phases[i + (tmpGrp - 1) * 8].PhsFlashing = true;
                        }
                        else
                        {
                            Phases[i + (tmpGrp - 1) * 8].PhsFlashing = false;
                        }
                        stateMask = (byte)(stateMask >> 1);
                    }

                    PhaseFlashingStatusGrp2Byte = bytes[228];

                    stateMask = 128;
                    //string tmpPhaseFlashingGrp2 = string.Empty;
                    tmpGrp = 2;
                    for (int i = 8; i > 0; i--)
                    {
                        if ((stateMask & PhaseFlashingStatusGrp2Byte) == stateMask)
                        {
                            Phases[i + (tmpGrp - 1) * 8].PhsFlashing = true;
                        }
                        else
                        {
                            Phases[i + (tmpGrp - 1) * 8].PhsFlashing = false;
                        }
                        stateMask = (byte)(stateMask >> 1);
                    }


                    OvlpFlashingStatusGrp1Byte = bytes[231];

                    stateMask = 128;
                    //string tmpOvlpFlashingGrp1 = string.Empty;
                    tmpGrp = 1;
                    for (int i = 8; i > 0; i--)
                    {
                        if ((stateMask & OvlpFlashingStatusGrp1Byte) == stateMask)
                        {
                            Phases[i + (tmpGrp - 1) * 8].OvlpFlashing = true;
                        }
                        else
                        {
                            Phases[i + (tmpGrp - 1) * 8].OvlpFlashing = false;
                        }
                        stateMask = (byte)(stateMask >> 1);
                    }

                    OvlpFlashingStatusGrp2Byte = bytes[230];

                    stateMask = 128;
                    //string tmpOvlpFlashingGrp2 = string.Empty;
                    tmpGrp = 2;
                    for (int i = 8; i > 0; i--)
                    {
                        if ((stateMask & OvlpFlashingStatusGrp2Byte) == stateMask)
                        {
                            Phases[i + (tmpGrp - 1) * 8].OvlpFlashing = true;
                        }
                        else
                        {
                            Phases[i + (tmpGrp - 1) * 8].OvlpFlashing = false;
                        }
                        stateMask = (byte)(stateMask >> 1);
                    }


                    byteIntersectionStatus = bytes[232];
                    //intIntersectionStatus = (int)byteIntersectionStatus;
                    GlobalVars.IntersectionStatus = SPAT.status.normal;
                    //byteIntersectionStatus = ProgrammedFlashMask;
                    //byteIntersectionStatus = (byte)(byteIntersectionStatus | FaultFlashMask);

                    IntersectionStatus.ManualControlActive = false;
                    IntersectionStatus.StopTimeActive = false;
                    IntersectionStatus.FaultFlashActive = false;
                    IntersectionStatus.PreemptActive = false;
                    IntersectionStatus.TSPActive = false;
                    IntersectionStatus.CoordinationActive = false;
                    IntersectionStatus.CoordinationInTransitionActive = false;
                    IntersectionStatus.ProgrammedFlashActive = false;

                    if ((ManualControlMask & byteIntersectionStatus) == ManualControlMask)
                    {
                        IntersectionStatus.ManualControlActive = true;
                        chkManualControl.Checked = true;
                        chkManualControl.BackColor = Color.DarkOrange;
                        chkManualControl1.Checked = true;
                        chkManualControl1.BackColor = Color.DarkOrange;
                        if (chkEnableDataLogging.Checked == true)
                        {
                            WriteMsgToLogFile(dailyLogFile, GetCurrentTimeStamp() + ",ManualControl--Active"); 
                        }
                        //J2735IntersectionStatus = (byte)(J2735IntersectionStatus | ManualControlMask);
                    }
                    else
                    {
                        chkManualControl.Checked = false;
                        chkManualControl.BackColor = Color.LightGray;
                        chkManualControl1.Checked = false;
                        chkManualControl1.BackColor = Color.LightGray;
                    }

                    if ((StopTimeMask & byteIntersectionStatus) == StopTimeMask)
                    {
                        IntersectionStatus.StopTimeActive = true;
                        chkStopTime.Checked = true;
                        chkStopTime.BackColor = Color.DarkOrange;
                        chkStopTime1.Checked = true;
                        chkStopTime1.BackColor = Color.DarkOrange;
                        if (chkEnableDataLogging.Checked == true)
                        {
                            WriteMsgToLogFile(dailyLogFile, GetCurrentTimeStamp() + ",StopTime--Active");
                        }
                        //J2735IntersectionStatus = (byte)(J2735IntersectionStatus | ManualControlMask);
                    }
                    else
                    {
                        chkStopTime.Checked = false;
                        chkStopTime.BackColor = Color.LightGray;
                        chkStopTime1.Checked = false;
                        chkStopTime1.BackColor = Color.LightGray;
                    }

                    //byteIntersectionStatus = FaultFlashMask;
                    if ((FaultFlashMask & byteIntersectionStatus) == FaultFlashMask)
                    {
                        IntersectionStatus.FaultFlashActive = true;
                        chkFaultFlash.Checked = true;
                        chkFaultFlash.BackColor = Color.DarkOrange;
                        chkFaultFlash1.Checked = true;
                        chkFaultFlash1.BackColor = Color.DarkOrange;
                        if (chkEnableDataLogging.Checked == true)
                        {
                            dailyLogFile.WriteLine(",FaultFlash--Active");
                        }
                        //J2735IntersectionStatus = (byte)(J2735IntersectionStatus | ManualControlMask);
                    }
                    else
                    {
                        chkFaultFlash.Checked = false;
                        chkFaultFlash.BackColor = Color.LightGray;
                        chkFaultFlash1.Checked = false;
                        chkFaultFlash1.BackColor = Color.LightGray;
                    }

                    if ((PreemptMask & byteIntersectionStatus) == PreemptMask)
                    {
                        IntersectionStatus.PreemptActive = true;
                        chkPreempt.Checked = true;
                        chkPreempt.BackColor = Color.DarkOrange;
                        chkPreempt1.Checked = true;
                        chkPreempt1.BackColor = Color.DarkOrange;
                        if (chkEnableDataLogging.Checked == true)
                        {
                            WriteMsgToLogFile(dailyLogFile, GetCurrentTimeStamp() + ",Preempt--Active");
                        }
                        //J2735IntersectionStatus = (byte)(J2735IntersectionStatus | byteIntersectionStatus);
                    }
                    else
                    {
                        chkPreempt.Checked = false;
                        chkPreempt.BackColor = Color.LightGray;
                        chkPreempt1.Checked = false;
                        chkPreempt1.BackColor = Color.LightGray;
                    }

                    if ((TSPMask & byteIntersectionStatus) == TSPMask)
                    {
                        IntersectionStatus.TSPActive = true;
                        chkTSP.Checked = true;
                        chkTSP.BackColor = Color.DarkOrange;
                        chkTSP1.Checked = true;
                        chkTSP1.BackColor = Color.DarkOrange;
                        if (chkEnableDataLogging.Checked == true)
                        {
                            WriteMsgToLogFile(dailyLogFile, GetCurrentTimeStamp() + ",TSP--Active");
                        }
                        //GlobalVars.IntersectionStatus = (SPAT.status)(J2735IntersectionStatus | TSPMask);
                    }
                    else
                    {
                        chkTSP.Checked = false;
                        chkTSP.BackColor = Color.LightGray;
                        chkTSP1.Checked = false;
                        chkTSP1.BackColor = Color.LightGray;
                    }

                    if ((CoordinationMask & byteIntersectionStatus) == CoordinationMask)
                    {
                        IntersectionStatus.CoordinationActive = true;
                        chkCoordination.Checked = true;
                        chkCoordination.BackColor = Color.DarkOrange;
                        chkCoordination1.Checked = true;
                        chkCoordination1.BackColor = Color.DarkOrange;
                        if (chkEnableDataLogging.Checked == true)
                        {
                            dailyLogFile.WriteLine(",Coordination--Active");
                        }
                        //GlobalVars.IntersectionStatus = (SPAT.status)(J2735IntersectionStatus | CoordinationMask);
                    }
                    else
                    {
                        chkCoordination.Checked = false;
                        chkCoordination.BackColor = Color.LightGray;
                        chkCoordination1.Checked = false;
                        chkCoordination1.BackColor = Color.LightGray;
                    }

                    if ((CoordinationinTransitionMask & byteIntersectionStatus) == CoordinationinTransitionMask)
                    {
                        IntersectionStatus.CoordinationInTransitionActive = true;
                        chkCoordinationInTransition.Checked = true;
                        chkCoordinationInTransition.BackColor = Color.DarkOrange;
                        chkCoordinationInTransition1.Checked = true;
                        chkCoordinationInTransition1.BackColor = Color.DarkOrange;
                        if (chkEnableDataLogging.Checked == true)
                        {
                            WriteMsgToLogFile(dailyLogFile, GetCurrentTimeStamp() + ",CoordinationInTransition--Active");
                        }
                        //GlobalVars.IntersectionStatus = (SPAT.status)(J2735IntersectionStatus | CoordinationinTransitionMask);
                    }
                    else
                    {
                        chkCoordinationInTransition.Checked = false;
                        chkCoordinationInTransition.BackColor = Color.LightGray;
                        chkCoordinationInTransition1.Checked = false;
                        chkCoordinationInTransition1.BackColor = Color.LightGray;
                    }
                    //byteIntersectionStatus = ProgrammedFlashMask;
                    if ((ProgrammedFlashMask & byteIntersectionStatus) == ProgrammedFlashMask)
                    {
                        IntersectionStatus.ProgrammedFlashActive = true;
                        chkProgrammedFlash.Checked = true;
                        chkProgrammedFlash.BackColor = Color.DarkOrange;
                        chkProgrammedFlash1.Checked = true;
                        chkProgrammedFlash1.BackColor = Color.DarkOrange;
                        if (chkEnableDataLogging.Checked == true)
                        {
                            WriteMsgToLogFile(dailyLogFile, GetCurrentTimeStamp() + ",ProgrammedFlash--Active");
                        }
                        //GlobalVars.IntersectionStatus = (SPAT.status)(J2735IntersectionStatus | ProgrammedFlashMask);
                    }
                    else
                    {
                        chkProgrammedFlash.Checked = false;
                        chkProgrammedFlash.BackColor = Color.LightGray;
                        chkProgrammedFlash1.Checked = false;
                        chkProgrammedFlash1.BackColor = Color.LightGray;
                    }
                    //GlobalVars.IntersectionStatus = (SPAT.status)(byteIntersectionStatus & J2735IntersectionStatus);
                    GlobalVars.IntersectionStatus = (SPAT.status)(byteIntersectionStatus);



                    if (bytes.Length >= 240)
                    {

                        //Process the SPaT Data Msg timestamp
                        byte[] SSM = new byte[4];
                        byte[] MSec = new byte[4];

                        prevTSCTimeMsec = currTSCTimeMsec;

                        int intSSM = 0;
                        int intMsec = 0;

                        SSM[0] = bytes[238];
                        SSM[1] = bytes[237];
                        SSM[2] = bytes[236];
                        intSSM = BitConverter.ToInt32(SSM, 0);

                        MSec[0] = bytes[240];
                        MSec[1] = bytes[239];
                        intMsec = BitConverter.ToInt32(MSec, 0);
                        currTSCTimeMsec = intSSM * 1000 + intMsec;

                        int hour = 0;
                        int minute = 0;
                        int second = 0;

                        hour = intSSM / 3600;
                        minute = (intSSM - (hour * 3600)) / 60;
                        second = (intSSM - (hour * 3600) - (minute * 60));

                        txtTSCMsgTime.Text = hour.ToString() + ":" + minute.ToString() + ":" + second.ToString();// +"::" + intMsec.ToString();
                        txtTSCMSec.Text = intMsec.ToString();
                        txtTSCMsgInterval.Text = (currTSCTimeMsec - prevTSCTimeMsec).ToString();

                        //LogTxtMsg (txtEnableSPATPush, "PrevTSCTime: " + prevTSCTimeMsec.ToString() + "\tCurrTSCTime: " + currTSCTimeMsec + "\t" + (currTSCTimeMsec-prevTSCTimeMsec) + "\r\nSSM: " + intSSM.ToString() + "\tMSec: " + intMsec + 
                        //                              "\tHour: " + hour.ToString() + 
                        //                              "\tMinute: " + minute.ToString() + 
                        //                              "\tSecond: " + second.ToString() + 
                        //                              "\tMsec: " + intMsec.ToString());
                        if (chkEnableDataLogging.Checked == true)
                        {
                            WriteMsgToLogFile(dailyLogFile, GetCurrentTimeStamp() + ",TSC-to-BB--TSC-Interval(Msec)," + (currTSCTimeMsec - prevTSCTimeMsec).ToString() + ",Time," + hour.ToString() + ":" + minute.ToString() + ":" + second.ToString() + ":" + intMsec.ToString());

                            spatMsgFile.WriteLine(DateTime.Now.Hour.ToString() + ":" + DateTime.Now.Minute.ToString() + ":" + DateTime.Now.Second.ToString() + ":" + DateTime.Now.Millisecond.ToString() + "," +
                                                  BitConverter.ToString(bytes, 0));
                            //spatMsgFile.WriteLine("SSM," + BitConverter.ToString(SSM, 0, 3) + "," + intSSM.ToString() + ",MSec," + BitConverter.ToString(MSec, 0, 2) + "," + intMsec.ToString() + ",Time," + hour.ToString() + ":" + minute.ToString() + ":" + second.ToString() + ":" + intMsec.ToString() +
                            //                      ",CurrentMSSM," + currTSCTimeMsec.ToString() + ",PreviousMSSM," + prevTSCTimeMsec.ToString() + ",Curr-Prev," + (currTSCTimeMsec - prevTSCTimeMsec).ToString());
                        }
                    }

                    //Process the TSC Ped information
                    int[] pedCallsMask = new int[17];
                    int[] pedDetectorsMask = new int[17];

                    for (int p = 1; p <= 16; p++)
                    {
                        GlobalVars.TSCPed[p].Call = false;
                        GlobalVars.TSCPed[p].Detect = false;
                        pedCallsMask[p] = (int)(Math.Pow(2, p-1));
                        pedDetectorsMask[p] = (int)(Math.Pow(2, p-1));
                    }
                    
                    if (bytes.Length >= 244)
                    {
                        string strPedCall = string.Empty;
                        string strPedDetect = string.Empty;
                        byte[] pedCall = new byte[4];
                        byte[] pedDetect = new byte[4];
                        int intPedCall = 0;
                        int intPedDetect = 0;


                        pedCall[0] = bytes[244];
                        pedCall[1] = bytes[243];
                        intPedCall = BitConverter.ToInt32(pedCall, 0);

                        pedDetect[0] = bytes[242];
                        pedDetect[1] = bytes[241];
                        intPedDetect = BitConverter.ToInt32(pedDetect, 0);

                        txtByte244.Text = pedCall[0].ToString();
                        txtByte243.Text = pedCall[1].ToString();
                        txtByte242.Text = pedDetect[0].ToString();
                        txtByte241.Text = pedDetect[1].ToString();

                        txtBytes243244.Text = intPedCall.ToString();
                        txtBytes241242.Text = intPedDetect.ToString();

                        for (int p = 1; p <= 16; p++)
                        {
                            if ((intPedCall & pedCallsMask[p]) == pedCallsMask[p])
                            {
                                GlobalVars.TSCPed[p].Call = true;
                                strPedCall = strPedCall + "1,";
                            }
                            else
                            {
                                GlobalVars.TSCPed[p].Call = false;
                                strPedCall = strPedCall + "0,";
                            }
                        }

                        txtPedCalls.Text = strPedCall;

                        for (int p = 1; p <= 16; p++)
                        {
                            if ((intPedDetect & pedDetectorsMask[p]) == pedDetectorsMask[p])
                            {
                                GlobalVars.TSCPed[p].Detect = true;
                                strPedDetect = strPedDetect + "1,";
                            }
                            else
                            {
                                GlobalVars.TSCPed[p].Detect = false;
                                strPedDetect = strPedDetect + "0,";
                            }
                        }
                        txtPedDet.Text = strPedDetect;

                        //if (chkEnableDataLogging.Checked == true)
                        //{
                        //    WriteMsgToLogFile(dailyLogFile, GetCurrentTimeStamp() + ",PedCall," + strPedCall);
                        //    WriteMsgToLogFile(dailyLogFile, GetCurrentTimeStamp() + ",PedDetect," + strPedDetect);
                        //}
                    }


                    endWakeUpTime = (DateTime.Now.Hour * 3600 + DateTime.Now.Minute * 60 + DateTime.Now.Second) * 1000 + DateTime.Now.Millisecond;
                    UpdatePhaseStatusDisplay();

                    /*************************************************************************************************************************************************/
                    //Prepare SPAt message content
                    int tmpPhsOvlpNo = 0;
                    byte tmpPhsOvlpStatus = 0;
                    bool tmpFlashing = false;
                    UInt16 tmpMinTime = 0;
                    UInt16 tmpMaxTime = 0;
                    UInt16 tmpYellowTime = 0;
                    //spatMsg.spat_load();

                    if ((chkEnableDataLogging.Checked == true) && (chkLaneMvmnt.Checked == true))
                    {
                        for (int p = 1; p <= GlobalVars.maxPhases; p++)
                        {
                            WriteMsgToLogFile(dailyLogFile, GetCurrentTimeStamp() + ",Phase," + p.ToString() + ",Grn," + Phases[p].Green + ",Yel," + Phases[p].Yellow + ",Red," + Phases[p].Red +
                                                                                ",Status," + (GlobalVars.enum_phase_status)Phases[p].Status + ",MinTime," + Phases[p].VMinTime + ",MaxTime," + Phases[p].VMaxTime +
                                                                                ",OGrn," + Phases[p].OvlpGreen + ",OYel," + Phases[p].OvlpYellow + ",ORed," + Phases[p].OvlpRed +
                                                                                ",OStatus," + (GlobalVars.enum_phase_status)Phases[p].OvlpStatus  + ",MinTime,"  + Phases[p].OvlpMinTime + ",MaxTime,"  + Phases[p].OvlpMaxTime +
                                                                                ",PedWalk," + Phases[p].PedWalk + ",PedDontWalk," + Phases[p].PedDontWalk + ",PedClear," + Phases[p].PedClear + 
                                                                                ",PedStatus," + Phases[p].PedStatus + ",PedMinTime," + Phases[p].PedMinTime + ",PedMaxTime," + Phases[p].PedMaxTime +
                                                                                ",PhsFlashing," + Phases[p].PhsFlashing + ",OFlashing," + Phases[p].OvlpFlashing);
                        }
                    }

                    string MvmntPedCallInfo = string.Empty;
                    string MvmntPedDetInfo = string.Empty;
                    string strMvmntPedInfo = string.Empty;
                    for (int m = 0; m < GlobalVars.PTLMRecords; m++)
                    {
                        bool pedCallActive = false;
                        int totalPedsDetected = 0;
                        UInt32 pedCallMask = 16;
                        byte SecondPedDetector = 32;


                        tmpPhsOvlpStatus = 0;
                        tmpFlashing = false;
                        tmpMinTime = 0;
                        tmpMaxTime = 0;
                        tmpYellowTime = 0;
                        tmpPhsOvlpNo = GlobalVars.PTLMTable[m].TSCPhsOvlp;
                        
                        //Process Ped calls and Ped Detect
                        //GlobalVars.PTLMTable[m].pedestrian = (byte)SPAT.pedestrian.unavailable;
                        GlobalVars.PTLMTable[m].count = 0;


                        #region "Process PedCalls"
                        
                        strMvmntPedInfo = string.Empty;
                        //string MvmntPedInfo = string.Empty;
                        if (GlobalVars.PTLMTable[m].LanesType == (byte)GlobalVars.enum_Lane_type.ped)
                        {
                            int[] pedCalls = new int [1];

                            //string MvmntPedInfo = "Mvmnt " + m.ToString();
                            if (GlobalVars.PTLMTable[m].PedCalls != null)
                            {
                                string[] pedCallsList = GlobalVars.PTLMTable[m].PedCalls.Split(',');
                                pedCalls = new int[pedCallsList.Length];

                                for (int l = 0; l < pedCallsList.Length; l++)
                                {
                                    pedCalls[l] = Convert.ToInt32(pedCallsList[l]);
                                }
                            }

                            if (GlobalVars.PedSimulatorEnabled == false)
                            {
                                foreach (int pedCall in pedCalls)
                                {
                                    if (GlobalVars.TSCPed[pedCall].Call == true)
                                    {
                                        pedCallActive = true;
                                        //GlobalVars.PTLMTable[m].state = (GlobalVars.PTLMTable[m].state | pedCallMask);
                                        MvmntPedCallInfo = MvmntPedCallInfo + "  M:" + m + "::C::" + pedCall.ToString() + "::" + pedCallActive.ToString();
                                    }
                                }
                            }
                            else
                            {
                                foreach (int pedCall in pedCalls)
                                {
                                    switch (pedCall)
                                    {
                                        case 1:
                                            {
                                                if (chkPedCall1.Checked == true)
                                                {
                                                    pedCallActive = true;
                                                    //GlobalVars.PTLMTable[m].count = (byte)(GlobalVars.PTLMTable[m].count + 1);
                                                    MvmntPedCallInfo = MvmntPedCallInfo + "  M:" + m + "::C::" + pedCall.ToString() + "::" + pedCallActive.ToString();
                                                }
                                                break;
                                            }
                                        case 2:
                                            {
                                                if (chkPedCall2.Checked == true)
                                                {
                                                    pedCallActive = true;
                                                    //GlobalVars.PTLMTable[m].count = (byte)(GlobalVars.PTLMTable[m].count + 1);
                                                    MvmntPedCallInfo = MvmntPedCallInfo + "  M:" + m + "::C::" + pedCall.ToString() + "::" + pedCallActive.ToString();
                                                }
                                                break;
                                            }
                                        case 3:
                                            {
                                                if (chkPedCall3.Checked == true)
                                                {
                                                    pedCallActive = true;
                                                    MvmntPedCallInfo = MvmntPedCallInfo + "  M:" + m + "::C::" + pedCall.ToString() + "::" + pedCallActive.ToString();
                                                }
                                                break;
                                            }
                                        case 4:
                                            {
                                                if (chkPedCall4.Checked == true)
                                                {
                                                    pedCallActive = true;
                                                    MvmntPedCallInfo = MvmntPedCallInfo + "  M:" + m + "::C::" + pedCall.ToString() + "::" + pedCallActive.ToString();
                                                }
                                                break;
                                            }
                                        case 5:
                                            {
                                                if (chkPedCall5.Checked == true)
                                                {
                                                    pedCallActive = true;
                                                    MvmntPedCallInfo = MvmntPedCallInfo + "  M:" + m + "::C::" + pedCall.ToString() + "::" + pedCallActive.ToString();
                                                }
                                                break;
                                            }
                                        case 6:
                                            {
                                                if (chkPedCall6.Checked == true)
                                                {
                                                    pedCallActive = true;
                                                    MvmntPedCallInfo = MvmntPedCallInfo + "  M:" + m + "::C::" + pedCall.ToString() + "::" + pedCallActive.ToString();
                                                }
                                                break;
                                            }
                                        case 7:
                                            {
                                                if (chkPedCall7.Checked == true)
                                                {
                                                    pedCallActive = true;
                                                    MvmntPedCallInfo = MvmntPedCallInfo + "  M:" + m + "::C::" + pedCall.ToString() + "::" + pedCallActive.ToString();
                                                }
                                                break;
                                            }
                                        case 8:
                                            {
                                                if (chkPedCall8.Checked == true)
                                                {
                                                    pedCallActive = true;
                                                    MvmntPedCallInfo = MvmntPedCallInfo + "  M:" + m + "::C::" + pedCall.ToString() + "::" + pedCallActive.ToString();
                                                }
                                                break;
                                            }
                                        case 9:
                                            {
                                                if (chkPedCall9.Checked == true)
                                                {
                                                    pedCallActive = true;
                                                    MvmntPedCallInfo = MvmntPedCallInfo + "  M:" + m + "::C::" + pedCall.ToString() + "::" + pedCallActive.ToString();
                                                }
                                                break;
                                            }
                                        case 10:
                                            {
                                                if (chkPedCall10.Checked == true)
                                                {
                                                    pedCallActive = true;
                                                    MvmntPedCallInfo = MvmntPedCallInfo + "  M:" + m + "::C::" + pedCall.ToString() + "::" + pedCallActive.ToString();
                                                }
                                                break;
                                            }
                                        case 11:
                                            {
                                                if (chkPedCall11.Checked == true)
                                                {
                                                    pedCallActive = true;
                                                    MvmntPedCallInfo = MvmntPedCallInfo + "  M:" + m + "::C::" + pedCall.ToString() + "::" + pedCallActive.ToString();
                                                }
                                                break;
                                            }
                                        case 12:
                                            {
                                                if (chkPedCall12.Checked == true)
                                                {
                                                    pedCallActive = true;
                                                    MvmntPedCallInfo = MvmntPedCallInfo + "  M:" + m + "::C::" + pedCall.ToString() + "::" + pedCallActive.ToString();
                                                }
                                                break;
                                            }
                                        case 13:
                                            {
                                                if (chkPedCall13.Checked == true)
                                                {
                                                    pedCallActive = true;
                                                    MvmntPedCallInfo = MvmntPedCallInfo + "  M:" + m + "::C::" + pedCall.ToString() + "::" + pedCallActive.ToString();
                                                }
                                                break;
                                            }
                                        case 14:
                                            {
                                                if (chkPedCall14.Checked == true)
                                                {
                                                    pedCallActive = true;
                                                    MvmntPedCallInfo = MvmntPedCallInfo + "  M:" + m + "::C::" + pedCall.ToString() + "::" + pedCallActive.ToString();
                                                }
                                                break;
                                            }
                                        case 15:
                                            {
                                                if (chkPedCall15.Checked == true)
                                                {
                                                    pedCallActive = true;
                                                    MvmntPedCallInfo = MvmntPedCallInfo + "  M:" + m + "::C::" + pedCall.ToString() + "::" + pedCallActive.ToString();
                                                }
                                                break;
                                            }
                                        case 16:
                                            {
                                                if (chkPedCall16.Checked == true)
                                                {
                                                    pedCallActive = true;
                                                    MvmntPedCallInfo = MvmntPedCallInfo + "  M:" + m + "::C::" + pedCall.ToString() + "::" + pedCallActive.ToString();
                                                }
                                                break;
                                            }
                                    }
                                }
                            }
                            //if (pedCallActive == true)
                            //{
                           //     chkPedActive.Checked = true;
                            //    chkPedActive.ForeColor = Color.Red;
                            //}
                            //else
                            //{
                            //    chkPedActive.Checked = false;
                            //    chkPedActive.ForeColor = Color.Black;
                            //}
                            txtMvmntPedCalls.Text = MvmntPedCallInfo;
                            if ((chkEnableDataLogging.Checked == true) && (chkLaneMvmnt.Checked == true))
                            {
                                WriteMsgToLogFile(dailyLogFile, GetCurrentTimeStamp() + " ---" + MvmntPedCallInfo);
                            }
                        }
                        
                        #endregion

                        #region "Process Ped Detection"
                        //if (GlobalVars.PedDetectionAvailable == true)
                        //{
                        //if (GlobalVars.TSCPed[GlobalVars.PTLMTable[m].TSCPhsOvlp].DetectionAvailable == true)
                        //{
                            if (GlobalVars.PTLMTable[m].LanesType == (byte)GlobalVars.enum_Lane_type.ped)
                            {
                                if (GlobalVars.PTLMTable[m].PedDetectors != null)
                                {
                                    GlobalVars.PTLMTable[m].pedestrian = (byte)SPAT.pedestrian.none;
                                    int[] pedDetectors = new int[1];

                                    string[] pedDetectList = GlobalVars.PTLMTable[m].PedDetectors.Split(',');
                                    pedDetectors = new int[pedDetectList.Length];

                                    for (int l = 0; l < pedDetectList.Length; l++)
                                    {
                                        pedDetectors[l] = Convert.ToInt32(pedDetectList[l]);
                                    }



                                    if (GlobalVars.PedSimulatorEnabled == false)
                                    {
                                        foreach (int pedDetector in pedDetectors)
                                        {
                                            if (GlobalVars.TSCPed[pedDetector].Detect == true)
                                            {
                                                totalPedsDetected = totalPedsDetected + 1;
                                                strMvmntPedInfo = strMvmntPedInfo + "  M::" + m + "::D::" + pedDetector.ToString() + "::" + GlobalVars.TSCPed[pedDetector].Detect;
                                            }
                                        }
                                    }
                                    else
                                    {
                                        foreach (int pedDetector in pedDetectors)
                                        {
                                            switch (pedDetector)
                                            {
                                                case 1:
                                                    {
                                                        if (chkPedDetect1.Checked == true)
                                                        {
                                                            totalPedsDetected = totalPedsDetected + 1;
                                                            strMvmntPedInfo = strMvmntPedInfo + "  M::" + m + "::D::" + pedDetector.ToString() + "::" + GlobalVars.TSCPed[pedDetector].Detect;
                                                            //GlobalVars.PTLMTable[m].pedestrian = SPAT.pedestrian.oneormore;
                                                        }
                                                        break;
                                                    }
                                                case 2:
                                                    {
                                                        if (chkPedDetect2.Checked == true)
                                                        {
                                                            totalPedsDetected = totalPedsDetected + 1;
                                                            strMvmntPedInfo = strMvmntPedInfo + "  M::" + m + "::D::" + pedDetector.ToString() + "::" + GlobalVars.TSCPed[pedDetector].Detect;
                                                            //GlobalVars.PTLMTable[m].pedestrian = SPAT.pedestrian.oneormore;
                                                        }
                                                        break;
                                                    }
                                                case 3:
                                                    {
                                                        if (chkPedDetect3.Checked == true)
                                                        {
                                                            totalPedsDetected = totalPedsDetected + 1;
                                                            strMvmntPedInfo = strMvmntPedInfo + "  M::" + m + "::D::" + pedDetector.ToString() + "::" + GlobalVars.TSCPed[pedDetector].Detect;
                                                        }
                                                        break;
                                                    }
                                                case 4:
                                                    {
                                                        if (chkPedDetect4.Checked == true)
                                                        {
                                                            totalPedsDetected = totalPedsDetected + 1;
                                                            strMvmntPedInfo = strMvmntPedInfo + "  M::" + m + "::D::" + pedDetector.ToString() + "::" + GlobalVars.TSCPed[pedDetector].Detect;
                                                        }
                                                        break;
                                                    }
                                                case 5:
                                                    {
                                                        if (chkPedDetect5.Checked == true)
                                                        {
                                                            totalPedsDetected = totalPedsDetected + 1;
                                                            strMvmntPedInfo = strMvmntPedInfo + "  M::" + m + "::D::" + pedDetector.ToString() + "::" + GlobalVars.TSCPed[pedDetector].Detect;
                                                        }
                                                        break;
                                                    }
                                                case 6:
                                                    {
                                                        if (chkPedDetect6.Checked == true)
                                                        {
                                                            totalPedsDetected = totalPedsDetected + 1;
                                                            strMvmntPedInfo = strMvmntPedInfo + "  M::" + m + "::D::" + pedDetector.ToString() + "::" + GlobalVars.TSCPed[pedDetector].Detect;
                                                        }
                                                        break;
                                                    }
                                                case 7:
                                                    {
                                                        if (chkPedDetect7.Checked == true)
                                                        {
                                                            totalPedsDetected = totalPedsDetected + 1;
                                                            strMvmntPedInfo = strMvmntPedInfo + "  M::" + m + "::D::" + pedDetector.ToString() + "::" + GlobalVars.TSCPed[pedDetector].Detect;
                                                        }
                                                        break;
                                                    }
                                                case 8:
                                                    {
                                                        if (chkPedDetect8.Checked == true)
                                                        {
                                                            totalPedsDetected = totalPedsDetected + 1;
                                                            strMvmntPedInfo = strMvmntPedInfo + "  M::" + m + "::D::" + pedDetector.ToString() + "::" + GlobalVars.TSCPed[pedDetector].Detect;
                                                        }
                                                        break;
                                                    }
                                                case 9:
                                                    {
                                                        if (chkPedDetect9.Checked == true)
                                                        {
                                                            totalPedsDetected = totalPedsDetected + 1;
                                                            strMvmntPedInfo = strMvmntPedInfo + "  M::" + m + "::D::" + pedDetector.ToString() + "::" + GlobalVars.TSCPed[pedDetector].Detect;
                                                        }
                                                        break;
                                                    }
                                                case 10:
                                                    {
                                                        if (chkPedDetect10.Checked == true)
                                                        {
                                                            totalPedsDetected = totalPedsDetected + 1;
                                                            strMvmntPedInfo = strMvmntPedInfo + "  M::" + m + "::D::" + pedDetector.ToString() + "::" + GlobalVars.TSCPed[pedDetector].Detect;
                                                        }
                                                        break;
                                                    }
                                                case 11:
                                                    {
                                                        if (chkPedDetect11.Checked == true)
                                                        {
                                                            totalPedsDetected = totalPedsDetected + 1;
                                                            strMvmntPedInfo = strMvmntPedInfo + "  M::" + m + "::D::" + pedDetector.ToString() + "::" + GlobalVars.TSCPed[pedDetector].Detect;
                                                        }
                                                        break;
                                                    }
                                                case 12:
                                                    {
                                                        if (chkPedDetect12.Checked == true)
                                                        {
                                                            totalPedsDetected = totalPedsDetected + 1;
                                                            strMvmntPedInfo = strMvmntPedInfo + "  M::" + m + "::D::" + pedDetector.ToString() + "::" + GlobalVars.TSCPed[pedDetector].Detect;
                                                        }
                                                        break;
                                                    }
                                                case 13:
                                                    {
                                                        if (chkPedDetect13.Checked == true)
                                                        {
                                                            totalPedsDetected = totalPedsDetected + 1;
                                                            strMvmntPedInfo = strMvmntPedInfo + "  M::" + m + "::D::" + pedDetector.ToString() + "::" + GlobalVars.TSCPed[pedDetector].Detect;
                                                        }
                                                        break;
                                                    }
                                                case 14:
                                                    {
                                                        if (chkPedDetect14.Checked == true)
                                                        {
                                                            totalPedsDetected = totalPedsDetected + 1;
                                                            strMvmntPedInfo = strMvmntPedInfo + "  M::" + m + "::D::" + pedDetector.ToString() + "::" + GlobalVars.TSCPed[pedDetector].Detect;
                                                        }
                                                        break;
                                                    }
                                                case 15:
                                                    {
                                                        if (chkPedDetect15.Checked == true)
                                                        {
                                                            totalPedsDetected = totalPedsDetected + 1;
                                                            strMvmntPedInfo = strMvmntPedInfo + "  M::" + m + "::D::" + pedDetector.ToString() + "::" + GlobalVars.TSCPed[pedDetector].Detect;
                                                        }
                                                        break;
                                                    }
                                                case 16:
                                                    {
                                                        if (chkPedDetect16.Checked == true)
                                                        {
                                                            totalPedsDetected = totalPedsDetected + 1;
                                                            strMvmntPedInfo = strMvmntPedInfo + "  M::" + m + "::D::" + pedDetector.ToString() + "::" + GlobalVars.TSCPed[pedDetector].Detect;
                                                        }
                                                        break;
                                                    }
                                            }

                                        }
                                    }
                                    txtNoCalls.Text = totalPedsDetected.ToString();
                                    txtMvmntPedDets.Text = strMvmntPedInfo;
                                    if ((chkEnableDataLogging.Checked == true) && (chkLaneMvmnt.Checked == true))
                                    {
                                        WriteMsgToLogFile(dailyLogFile, GetCurrentTimeStamp() + " ---" + strMvmntPedInfo);
                                    }
                                }
                                else
                                {
                                    GlobalVars.PTLMTable[m].pedestrian = (byte)SPAT.pedestrian.unavailable;
                                }
                            }
                        //}
                        #endregion


                        
                        if (IntersectionStatus.FaultFlashActive == true)
                        {
                            GlobalVars.PTLMTable[m].yellowTime = 0;
                            GlobalVars.PTLMTable[m].yellowState = 0;
                            GlobalVars.PTLMTable[m].minTime = 12002;
                            GlobalVars.PTLMTable[m].maxTime = 12002;

                            if (GlobalVars.PTLMTable[m].LanesType == (byte)GlobalVars.enum_Lane_type.ped)
                            {
                                GlobalVars.PTLMTable[m].state = 0x01;
                                if (pedCallActive == true)
                                {
                                    GlobalVars.PTLMTable[m].state = GlobalVars.PTLMTable[m].state | pedCallMask;
                                }
                                if (totalPedsDetected >= 1)
                                {
                                    GlobalVars.PTLMTable[m].pedestrian = (byte)SPAT.pedestrian.oneormore;
                                }
                                if (totalPedsDetected >= 2)
                                {
                                    //GlobalVars.PTLMTable[m].pedestrian = (byte)(GlobalVars.PTLMTable[m].pedestrian | SecondPedDetector);
                                    GlobalVars.PTLMTable[m].pedestrian = (byte)SPAT.pedestrian.oneormore;
                                }
                            }
                            else if (GlobalVars.PTLMTable[m].LanesType == (byte)GlobalVars.enum_Lane_type.vehicle)
                            {
                                if (GlobalVars.PTLMTable[m].Movement == SPAT.maneuvers.straight)
                                {
                                    GlobalVars.PTLMTable[m].state = (uint)GlobalVars.enum_lane_movement_status.FlashingRedBall;
                                }
                                else if (GlobalVars.PTLMTable[m].Movement == SPAT.maneuvers.leftturn)
                                {
                                    GlobalVars.PTLMTable[m].state = (uint)GlobalVars.enum_lane_movement_status.FlashingRedLeftArrow;
                                }
                                else if (GlobalVars.PTLMTable[m].Movement == SPAT.maneuvers.rightturn)
                                {
                                    GlobalVars.PTLMTable[m].state = (uint)GlobalVars.enum_lane_movement_status.FlashingRedRightArrow;
                                }
                            }
                        }
                        else if (IntersectionStatus.ProgrammedFlashActive == true)
                        {
                            GlobalVars.PTLMTable[m].yellowTime = 0;
                            GlobalVars.PTLMTable[m].yellowState = 0;
                            GlobalVars.PTLMTable[m].minTime = 12002;
                            GlobalVars.PTLMTable[m].maxTime = 12002;

                            if (GlobalVars.PTLMTable[m].LanesType == (byte)GlobalVars.enum_Lane_type.ped)
                            {
                                if (Phases[tmpPhsOvlpNo].PedStatus == (byte)GlobalVars.enum_phase_status.DontWalk)
                                {
                                    GlobalVars.PTLMTable[m].state = 0x01;
                                }
                                else if (Phases[tmpPhsOvlpNo].PedStatus == (byte)GlobalVars.enum_phase_status.PedClear)
                                {
                                    GlobalVars.PTLMTable[m].state = 0x02;
                                }
                                if (Phases[tmpPhsOvlpNo].PedStatus == (byte)GlobalVars.enum_phase_status.Walk)
                                {
                                    GlobalVars.PTLMTable[m].state = 0x03;
                                }

                                if (pedCallActive == true)
                                {
                                    GlobalVars.PTLMTable[m].state = GlobalVars.PTLMTable[m].state | pedCallMask;
                                }
                                if (totalPedsDetected >= 1)
                                {
                                    GlobalVars.PTLMTable[m].pedestrian = (byte)SPAT.pedestrian.oneormore;
                                }
                                if (totalPedsDetected >= 2)
                                {
                                    //GlobalVars.PTLMTable[m].pedestrian = (byte)(GlobalVars.PTLMTable[m].pedestrian | SecondPedDetector);
                                    GlobalVars.PTLMTable[m].pedestrian = (byte)SPAT.pedestrian.oneormore;
                                }
                            }
                            else if (GlobalVars.PTLMTable[m].LanesType == (byte)GlobalVars.enum_Lane_type.vehicle)
                            {
                                if (Phases[tmpPhsOvlpNo].Status == (byte)GlobalVars.enum_phase_status.Yellow)
                                {
                                    GlobalVars.PTLMTable[m].yellowTime = 0;
                                    GlobalVars.PTLMTable[m].yellowState = 0;

                                    if (GlobalVars.PTLMTable[m].Movement == SPAT.maneuvers.straight)
                                    {
                                        GlobalVars.PTLMTable[m].state = (uint)GlobalVars.enum_lane_movement_status.FlashingYellowBall;
                                    }
                                    else if (GlobalVars.PTLMTable[m].Movement == SPAT.maneuvers.leftturn)
                                    {
                                        GlobalVars.PTLMTable[m].state = (uint)GlobalVars.enum_lane_movement_status.FlashingYellowLeftArrow;
                                    }
                                    else if (GlobalVars.PTLMTable[m].Movement == SPAT.maneuvers.rightturn)
                                    {
                                        GlobalVars.PTLMTable[m].state = (uint)GlobalVars.enum_lane_movement_status.FlashingYellowRightArrow;
                                    }
                                }
                                else if (Phases[tmpPhsOvlpNo].Status == (byte)GlobalVars.enum_phase_status.Red)
                                {
                                    GlobalVars.PTLMTable[m].yellowTime = 0;
                                    GlobalVars.PTLMTable[m].yellowState = 0;

                                    if (GlobalVars.PTLMTable[m].Movement == SPAT.maneuvers.straight)
                                    {
                                        GlobalVars.PTLMTable[m].state = (uint)GlobalVars.enum_lane_movement_status.FlashingRedBall;
                                    }
                                    else if (GlobalVars.PTLMTable[m].Movement == SPAT.maneuvers.leftturn)
                                    {
                                        GlobalVars.PTLMTable[m].state = (uint)GlobalVars.enum_lane_movement_status.FlashingRedLeftArrow;
                                    }
                                    else if (GlobalVars.PTLMTable[m].Movement == SPAT.maneuvers.rightturn)
                                    {
                                        GlobalVars.PTLMTable[m].state = (uint)GlobalVars.enum_lane_movement_status.FlashingRedRightArrow;
                                    }
                                }
                                else
                                {
                                    GlobalVars.PTLMTable[m].state = (uint)GlobalVars.enum_lane_movement_status.Dark;
                                }
                            }
                        }
                        else if (GlobalVars.PTLMTable[m].LanesType == (byte)GlobalVars.enum_Lane_type.ped)
                        {
                            if ((IntersectionStatus.ManualControlActive == true) || (IntersectionStatus.StopTimeActive == true))
                            {
                                GlobalVars.PTLMTable[m].minTime = 12002;
                                GlobalVars.PTLMTable[m].maxTime = 12002;
                            }
                            else
                            {
                                GlobalVars.PTLMTable[m].minTime = Phases[tmpPhsOvlpNo].PedMinTime;
                                GlobalVars.PTLMTable[m].maxTime = Phases[tmpPhsOvlpNo].PedMaxTime;
                            }
                            GlobalVars.PTLMTable[m].yellowState = 0;
                            GlobalVars.PTLMTable[m].yellowTime = 0;
                            if (Phases[tmpPhsOvlpNo].PedStatus == (byte)GlobalVars.enum_phase_status.DontWalk)
                            {
                                GlobalVars.PTLMTable[m].state = 0x01;

                            }
                            else if (Phases[tmpPhsOvlpNo].PedStatus == (byte)GlobalVars.enum_phase_status.PedClear)
                            {
                                GlobalVars.PTLMTable[m].state = 0x02;
                            }
                            if (Phases[tmpPhsOvlpNo].PedStatus == (byte)GlobalVars.enum_phase_status.Walk)
                            {
                                GlobalVars.PTLMTable[m].state = 0x03;
                                //The ped Walk phase is similar to the vehicle Green Phase
                                // and the PedClear is similar to the Yellow phase, therefore the yellow time after the Walk is PedClear
                                GlobalVars.PTLMTable[m].yellowState = 0x02;
                                GlobalVars.PTLMTable[m].yellowTime = Phases[tmpPhsOvlpNo].PedClear;
                            }
                            if (pedCallActive == true)
                            {
                                GlobalVars.PTLMTable[m].state = GlobalVars.PTLMTable[m].state | pedCallMask;
                            }
                            if (totalPedsDetected >= 1)
                            {
                                GlobalVars.PTLMTable[m].pedestrian = (byte)SPAT.pedestrian.oneormore;
                            }
                            if (totalPedsDetected >= 2)
                            {
                                //GlobalVars.PTLMTable[m].pedestrian = (byte)(GlobalVars.PTLMTable[m].pedestrian | SecondPedDetector);
                                GlobalVars.PTLMTable[m].pedestrian = (byte)SPAT.pedestrian.oneormore;
                            }
                        }
                        else if (GlobalVars.PTLMTable[m].LanesType == (byte)GlobalVars.enum_Lane_type.vehicle)
                        {
                            if (GlobalVars.PTLMTable[m].TSCEntityType == (byte)GlobalVars.enum_TSC_control_entity.phase)
                            {
                                if ((IntersectionStatus.ManualControlActive == true) || (IntersectionStatus.StopTimeActive == true))
                                {
                                    tmpMinTime = 12002;
                                    tmpMaxTime = 12002;
                                }
                                else
                                {
                                    tmpMinTime = Phases[tmpPhsOvlpNo].VMinTime;
                                    tmpMaxTime = Phases[tmpPhsOvlpNo].VMaxTime;
                                }
                                tmpPhsOvlpStatus = Phases[tmpPhsOvlpNo].Status;
                                tmpFlashing = Phases[tmpPhsOvlpNo].PhsFlashing;
                                tmpYellowTime = Phases[tmpPhsOvlpNo].YellowChange;
                            }
                            else if (GlobalVars.PTLMTable[m].TSCEntityType == (byte)GlobalVars.enum_TSC_control_entity.ovlp)
                            {
                                if ((IntersectionStatus.ManualControlActive == true) || (IntersectionStatus.StopTimeActive == true))
                                {
                                    tmpMinTime = 12002;
                                    tmpMaxTime = 12002;
                                }
                                else
                                {
                                    tmpMinTime = Phases[tmpPhsOvlpNo].OvlpMinTime;
                                    tmpMaxTime = Phases[tmpPhsOvlpNo].OvlpMaxTime;
                                }
                                tmpPhsOvlpStatus = Phases[tmpPhsOvlpNo].OvlpStatus;
                                tmpFlashing = Phases[tmpPhsOvlpNo].OvlpFlashing;
                                tmpYellowTime = 0;
                            }
                            GlobalVars.PTLMTable[m].minTime = tmpMinTime;
                            GlobalVars.PTLMTable[m].maxTime = tmpMaxTime;
                            GlobalVars.PTLMTable[m].yellowState = 0;
                            GlobalVars.PTLMTable[m].yellowTime = tmpYellowTime;
                            GlobalVars.PTLMTable[m].pedestrian = 0;
                            GlobalVars.PTLMTable[m].count = 0;

                            if (tmpFlashing == true)
                            {
                                if (tmpPhsOvlpStatus == (byte)GlobalVars.enum_phase_status.Green)
                                {
                                    //This cannot happen, i.e., Flashing Green phase. Report as an error
                                    if (chkEnableDataLogging.Checked == true) 
                                    {
                                        dailyLogFile.WriteLine("Error: Flashing Green Phase." +
                                                               "\r\n\tPhaseNo: " + tmpPhsOvlpNo +
                                                               "\r\n\tMovement: " + GlobalVars.PTLMTable[m].Movement.ToString() +
                                                               "\r\n\tLanes: " + GlobalVars.PTLMTable[m].Lanes +
                                                               "\r\n\tPhaseType: " + GlobalVars.PTLMTable[m].PhaseType.ToString() +
                                                               "\r\n\tLanesType: " + GlobalVars.PTLMTable[m].LanesType.ToString() +
                                                               "\r\n\tMinTime: " + GlobalVars.PTLMTable[m].minTime.ToString() +
                                                               "\r\n\tMaxTime: " + GlobalVars.PTLMTable[m].maxTime.ToString());
                                    }
                                }
                                else if (Phases[tmpPhsOvlpNo].Status == (byte)GlobalVars.enum_phase_status.Yellow)
                                {
                                    GlobalVars.PTLMTable[m].yellowTime = 0;
                                    GlobalVars.PTLMTable[m].yellowState = 0;

                                    if (GlobalVars.PTLMTable[m].Movement == SPAT.maneuvers.straight)
                                    {
                                        GlobalVars.PTLMTable[m].state = (uint)GlobalVars.enum_lane_movement_status.FlashingYellowBall;
                                    }
                                    else if (GlobalVars.PTLMTable[m].Movement == SPAT.maneuvers.leftturn)
                                    {
                                        GlobalVars.PTLMTable[m].state = (uint)GlobalVars.enum_lane_movement_status.FlashingYellowLeftArrow;
                                    }
                                    else if (GlobalVars.PTLMTable[m].Movement == SPAT.maneuvers.rightturn)
                                    {
                                        GlobalVars.PTLMTable[m].state = (uint)GlobalVars.enum_lane_movement_status.FlashingYellowRightArrow;
                                    }
                                }
                                else if (Phases[tmpPhsOvlpNo].Status == (byte)GlobalVars.enum_phase_status.Red)
                                {
                                    GlobalVars.PTLMTable[m].yellowTime = 0;
                                    GlobalVars.PTLMTable[m].yellowState = 0;

                                    if (GlobalVars.PTLMTable[m].Movement == SPAT.maneuvers.straight)
                                    {
                                        GlobalVars.PTLMTable[m].state = (uint)GlobalVars.enum_lane_movement_status.FlashingRedBall;
                                    }
                                    else if (GlobalVars.PTLMTable[m].Movement == SPAT.maneuvers.leftturn)
                                    {
                                        GlobalVars.PTLMTable[m].state = (uint)GlobalVars.enum_lane_movement_status.FlashingRedLeftArrow;
                                    }
                                    else if (GlobalVars.PTLMTable[m].Movement == SPAT.maneuvers.rightturn)
                                    {
                                        GlobalVars.PTLMTable[m].state = (uint)GlobalVars.enum_lane_movement_status.FlashingRedRightArrow;
                                    }
                                }
                                else
                                {
                                    GlobalVars.PTLMTable[m].yellowTime = 0;
                                    GlobalVars.PTLMTable[m].yellowState = 0;

                                    GlobalVars.PTLMTable[m].state = (uint)GlobalVars.enum_lane_movement_status.Dark;
                                }
                            }
                            else if (tmpFlashing == false)
                            {
                                if (tmpPhsOvlpStatus == (byte)GlobalVars.enum_phase_status.Green)
                                {
                                    if (GlobalVars.PTLMTable[m].Movement == SPAT.maneuvers.straight)
                                    {
                                        GlobalVars.PTLMTable[m].state = (uint)GlobalVars.enum_lane_movement_status.GreenBall;
                                        GlobalVars.PTLMTable[m].yellowState = (uint)GlobalVars.enum_lane_movement_status.YellowBall;
                                    }
                                    else if (GlobalVars.PTLMTable[m].Movement == SPAT.maneuvers.leftturn)
                                    {
                                        if (GlobalVars.PTLMTable[m].PhaseType == (byte)GlobalVars.enum_phase_type.protectedPhase)
                                        {
                                            GlobalVars.PTLMTable[m].state = (uint)GlobalVars.enum_lane_movement_status.GreenLeftArrow;
                                            GlobalVars.PTLMTable[m].yellowState = (uint)GlobalVars.enum_lane_movement_status.YellowLeftArrow;
                                        }
                                        else if (GlobalVars.PTLMTable[m].PhaseType == (byte)GlobalVars.enum_phase_type.permittedPhase)
                                        {
                                            GlobalVars.PTLMTable[m].state = (uint)GlobalVars.enum_lane_movement_status.GreenBall;
                                            GlobalVars.PTLMTable[m].yellowState = (uint)GlobalVars.enum_lane_movement_status.YellowBall;
                                        }
                                    }
                                    else if (GlobalVars.PTLMTable[m].Movement == SPAT.maneuvers.rightturn)
                                    {
                                        if (GlobalVars.PTLMTable[m].PhaseType == (byte)GlobalVars.enum_phase_type.protectedPhase)
                                        {
                                            GlobalVars.PTLMTable[m].state = (uint)GlobalVars.enum_lane_movement_status.GreenRightArrow;
                                            GlobalVars.PTLMTable[m].yellowState = (uint)GlobalVars.enum_lane_movement_status.YellowRightArrow;
                                        }
                                        else if (GlobalVars.PTLMTable[m].PhaseType == (byte)GlobalVars.enum_phase_type.permittedPhase)
                                        {
                                            GlobalVars.PTLMTable[m].state = (uint)GlobalVars.enum_lane_movement_status.GreenBall;
                                            GlobalVars.PTLMTable[m].yellowState = (uint)GlobalVars.enum_lane_movement_status.YellowBall;
                                        }
                                    }
                                }
                                else if (Phases[tmpPhsOvlpNo].Status == (byte)GlobalVars.enum_phase_status.Yellow)
                                {
                                    GlobalVars.PTLMTable[m].yellowTime = 0;
                                    GlobalVars.PTLMTable[m].yellowState = 0;

                                    if (GlobalVars.PTLMTable[m].Movement == SPAT.maneuvers.straight)
                                    {
                                        GlobalVars.PTLMTable[m].state = (uint)GlobalVars.enum_lane_movement_status.YellowBall;
                                    }
                                    else if (GlobalVars.PTLMTable[m].Movement == SPAT.maneuvers.leftturn)
                                    {
                                        if (GlobalVars.PTLMTable[m].PhaseType == (byte)GlobalVars.enum_phase_type.protectedPhase)
                                        {
                                            GlobalVars.PTLMTable[m].state = (uint)GlobalVars.enum_lane_movement_status.YellowLeftArrow;
                                        }
                                        else if (GlobalVars.PTLMTable[m].PhaseType == (byte)GlobalVars.enum_phase_type.permittedPhase)
                                        {
                                            GlobalVars.PTLMTable[m].state = (uint)GlobalVars.enum_lane_movement_status.YellowBall;
                                        }
                                    }
                                    else if (GlobalVars.PTLMTable[m].Movement == SPAT.maneuvers.rightturn)
                                    {
                                        if (GlobalVars.PTLMTable[m].PhaseType == (byte)GlobalVars.enum_phase_type.protectedPhase)
                                        {
                                            GlobalVars.PTLMTable[m].state = (uint)GlobalVars.enum_lane_movement_status.YellowRightArrow;
                                        }
                                        else if (GlobalVars.PTLMTable[m].PhaseType == (byte)GlobalVars.enum_phase_type.permittedPhase)
                                        {
                                            GlobalVars.PTLMTable[m].state = (uint)GlobalVars.enum_lane_movement_status.YellowBall;
                                        }
                                    }
                                }
                                else if (Phases[tmpPhsOvlpNo].Status == (byte)GlobalVars.enum_phase_status.Red)
                                {
                                    GlobalVars.PTLMTable[m].yellowTime = 0;
                                    GlobalVars.PTLMTable[m].yellowState = 0;

                                    if (GlobalVars.PTLMTable[m].Movement == SPAT.maneuvers.straight)
                                    {
                                        GlobalVars.PTLMTable[m].state = (uint)GlobalVars.enum_lane_movement_status.RedBall;
                                    }
                                    else if (GlobalVars.PTLMTable[m].Movement == SPAT.maneuvers.leftturn)
                                    {
                                        if (GlobalVars.PTLMTable[m].PhaseType == (byte)GlobalVars.enum_phase_type.protectedPhase)
                                        {
                                            GlobalVars.PTLMTable[m].state = (uint)GlobalVars.enum_lane_movement_status.RedLeftArrow;
                                        }
                                        else if (GlobalVars.PTLMTable[m].PhaseType == (byte)GlobalVars.enum_phase_type.permittedPhase)
                                        {
                                            GlobalVars.PTLMTable[m].state = (uint)GlobalVars.enum_lane_movement_status.RedBall;
                                        }
                                    }
                                    else if (GlobalVars.PTLMTable[m].Movement == SPAT.maneuvers.rightturn)
                                    {
                                        if (GlobalVars.PTLMTable[m].PhaseType == (byte)GlobalVars.enum_phase_type.protectedPhase)
                                        {
                                            GlobalVars.PTLMTable[m].state = (uint)GlobalVars.enum_lane_movement_status.RedRightArrow;
                                        }
                                        else if (GlobalVars.PTLMTable[m].PhaseType == (byte)GlobalVars.enum_phase_type.permittedPhase)
                                        {
                                            GlobalVars.PTLMTable[m].state = (uint)GlobalVars.enum_lane_movement_status.RedBall;
                                        }
                                    }
                                }
                                else
                                {
                                    GlobalVars.PTLMTable[m].state = (uint)GlobalVars.enum_lane_movement_status.Dark;
                                }
                            }
                        }
                        if ((chkEnableDataLogging.Checked == true) && (chkLaneMvmnt.Checked == true))
                        {
                            WriteMsgToLogFile(dailyLogFile, GetCurrentTimeStamp() +
                                            ",Movement," + m +
                                            ",MovementType," + GlobalVars.PTLMTable[m].Movement.ToString() +
                                            ",Lanes," + GlobalVars.PTLMTable[m].Lanes.ToString() +
                                            ",LanesType," + (GlobalVars.enum_Lane_type)GlobalVars.PTLMTable[m].LanesType +
                                            ",Phs/Ovlp," + (GlobalVars.enum_TSC_control_entity)GlobalVars.PTLMTable[m].TSCEntityType +
                                            ",Phs/OvlpNo," + GlobalVars.PTLMTable[m].TSCPhsOvlp.ToString() +
                                            ",Phs/Ovlp Type," + (GlobalVars.enum_phase_type)GlobalVars.PTLMTable[m].PhaseType +
                                            ",MovementState," + (GlobalVars.enum_lane_movement_status)GlobalVars.PTLMTable[m].state +
                                            ",MovementState," + (uint)GlobalVars.PTLMTable[m].state +
                                            ",Mintime," + GlobalVars.PTLMTable[m].minTime.ToString() +
                                            ",Maxtime," + GlobalVars.PTLMTable[m].maxTime.ToString() +
                                            ",Yellowtime," + GlobalVars.PTLMTable[m].yellowTime.ToString() +
                                            ",YellowState," + (GlobalVars.enum_lane_movement_status)GlobalVars.PTLMTable[m].yellowState +
                                            ",Pedestrian," + GlobalVars.PTLMTable[m].pedestrian.ToString() +
                                            ",Count," + GlobalVars.PTLMTable[m].count.ToString());
                            /*WriteMsgToLogFile(dailyLogFile, GetCurrentTimeStamp() +
                                            ",Movement," + m +
                                            "\r\n\t\tMovementType:\t" + GlobalVars.PTLMTable[m].Movement.ToString() +
                                            "\r\n\t\tLanes:\t\t" + GlobalVars.PTLMTable[m].Lanes.ToString() +
                                            "\r\n\t\tLanesType:\t" + (GlobalVars.enum_Lane_type)GlobalVars.PTLMTable[m].LanesType +
                                            "\r\n\t\tPhs/Ovlp:\t" + (GlobalVars.enum_TSC_control_entity)GlobalVars.PTLMTable[m].TSCEntityType +
                                            "\r\n\t\tPhs/OvlpNo.:\t" + GlobalVars.PTLMTable[m].TSCPhsOvlp.ToString() +
                                            "\r\n\t\tPhs/Ovlp Type:\t" + (GlobalVars.enum_phase_type)GlobalVars.PTLMTable[m].PhaseType +
                                            "\r\n\t\tMovementState:\t" + (GlobalVars.enum_lane_movement_status)GlobalVars.PTLMTable[m].state +
                                            "\r\n\t\tMovementState:\t" + (uint)GlobalVars.PTLMTable[m].state +
                                            "\r\n\t\tMintime:\t" + GlobalVars.PTLMTable[m].minTime.ToString() +
                                            "\r\n\t\tMaxtime:\t" + GlobalVars.PTLMTable[m].maxTime.ToString() +
                                            "\r\n\t\tYellowtime:\t" + GlobalVars.PTLMTable[m].yellowTime.ToString() +
                                            "\r\n\t\tYellowState:\t" + (GlobalVars.enum_lane_movement_status)GlobalVars.PTLMTable[m].yellowState +
                                            "\r\n\t\tPedestrian:\t" + GlobalVars.PTLMTable[m].pedestrian.ToString() +
                                            "\r\n\t\tCount:\t" + GlobalVars.PTLMTable[m].count.ToString());*/
                        }
                    }

                    MvmntsList.Clear();

                    for (int m = 0; m < GlobalVars.PTLMRecords; m++)
                    {
                        GlobalVars.PTLMTable[m].Enabled = true;
                        MvmntInfo mvmnt = new MvmntInfo();
                        mvmnt.m_Number = m;
                        mvmnt.Movement = GlobalVars.PTLMTable[m].Movement;
                        mvmnt.state = GlobalVars.PTLMTable[m].state;
                        mvmnt.m_Info = GlobalVars.PTLMTable[m].Lanes.ToString() + GlobalVars.PTLMTable[m].LanesType.ToString() + GlobalVars.PTLMTable[m].Movement.ToString();
                        MvmntsList.Add(mvmnt);
                    }

                    MvmntsList.Sort((l, r) => l.m_Info.CompareTo(r.m_Info));

                    for (int i = 1; i < GlobalVars.PTLMRecords; i++)
                    {
                        if ((MvmntsList[i].m_Info == MvmntsList[i - 1].m_Info) && (MvmntsList[i].Movement == SPAT.maneuvers.leftturn)
                                                                               && ((MvmntsList[i].state == (uint)GlobalVars.enum_lane_movement_status.GreenLeftArrow) || (MvmntsList[i-1].state == (uint)GlobalVars.enum_lane_movement_status.GreenLeftArrow)))   // && ((MvmntsList[i].state != MvmntsList[i - 1].state)))
                        {
                            if (MvmntsList[i].state == (uint)GlobalVars.enum_lane_movement_status.GreenLeftArrow)
                            {
                                GlobalVars.PTLMTable[MvmntsList[i - 1].m_Number].Enabled = false;
                            }
                            else if (MvmntsList[i-1].state == (uint)GlobalVars.enum_lane_movement_status.GreenLeftArrow)
                            {
                                GlobalVars.PTLMTable[MvmntsList[i].m_Number].Enabled = false;
                            }
                        }
                        else if ((MvmntsList[i].m_Info == MvmntsList[i - 1].m_Info) && (MvmntsList[i].Movement == SPAT.maneuvers.leftturn)
                                                                               && ((MvmntsList[i].state == (uint)GlobalVars.enum_lane_movement_status.YellowLeftArrow) || (MvmntsList[i - 1].state == (uint)GlobalVars.enum_lane_movement_status.YellowLeftArrow)))   // && ((MvmntsList[i].state != MvmntsList[i - 1].state)))
                        {
                            if (MvmntsList[i].state == (uint)GlobalVars.enum_lane_movement_status.YellowLeftArrow)
                            {
                                GlobalVars.PTLMTable[MvmntsList[i - 1].m_Number].Enabled = false;
                            }
                            else if (MvmntsList[i - 1].state == (uint)GlobalVars.enum_lane_movement_status.YellowLeftArrow)
                            {
                                GlobalVars.PTLMTable[MvmntsList[i].m_Number].Enabled = false;
                            }
                        }
                        else if ((MvmntsList[i].m_Info == MvmntsList[i - 1].m_Info) && (MvmntsList[i].Movement == SPAT.maneuvers.leftturn)
                                                                               && ((MvmntsList[i].state == (uint)GlobalVars.enum_lane_movement_status.GreenBall) || (MvmntsList[i - 1].state == (uint)GlobalVars.enum_lane_movement_status.GreenBall)))   // && ((MvmntsList[i].state != MvmntsList[i - 1].state)))
                        {
                            if (MvmntsList[i].state == (uint)GlobalVars.enum_lane_movement_status.GreenBall)
                            {
                                GlobalVars.PTLMTable[MvmntsList[i - 1].m_Number].Enabled = false;
                            }
                            else if (MvmntsList[i - 1].state == (uint)GlobalVars.enum_lane_movement_status.GreenBall)
                            {
                                GlobalVars.PTLMTable[MvmntsList[i].m_Number].Enabled = false;
                            }
                        }
                        else if ((MvmntsList[i].m_Info == MvmntsList[i - 1].m_Info) && (MvmntsList[i].Movement == SPAT.maneuvers.leftturn)
                                                                               && ((MvmntsList[i].state == (uint)GlobalVars.enum_lane_movement_status.YellowBall) || (MvmntsList[i - 1].state == (uint)GlobalVars.enum_lane_movement_status.YellowBall)))   // && ((MvmntsList[i].state != MvmntsList[i - 1].state)))
                        {
                            if (MvmntsList[i].state == (uint)GlobalVars.enum_lane_movement_status.YellowBall)
                            {
                                GlobalVars.PTLMTable[MvmntsList[i - 1].m_Number].Enabled = false;
                            }
                            else if (MvmntsList[i - 1].state == (uint)GlobalVars.enum_lane_movement_status.YellowBall)
                            {
                                GlobalVars.PTLMTable[MvmntsList[i].m_Number].Enabled = false;
                            }
                        }
                        else if ((MvmntsList[i].m_Info == MvmntsList[i - 1].m_Info) && (MvmntsList[i].Movement == SPAT.maneuvers.leftturn)
                                                                               && ((MvmntsList[i].state == (uint)GlobalVars.enum_lane_movement_status.RedBall) || (MvmntsList[i - 1].state == (uint)GlobalVars.enum_lane_movement_status.RedBall)))   // && ((MvmntsList[i].state != MvmntsList[i - 1].state)))
                        {
                            if (MvmntsList[i].state == (uint)GlobalVars.enum_lane_movement_status.RedLeftArrow)
                            {
                                GlobalVars.PTLMTable[MvmntsList[i].m_Number].Enabled = false;
                                if (GlobalVars.PTLMTable[MvmntsList[i].m_Number].minTime < GlobalVars.PTLMTable[MvmntsList[i-1].m_Number].minTime)
                                {
                                    GlobalVars.PTLMTable[MvmntsList[i-1].m_Number].minTime = GlobalVars.PTLMTable[MvmntsList[i].m_Number].minTime;
                                    GlobalVars.PTLMTable[MvmntsList[i-1].m_Number].maxTime = GlobalVars.PTLMTable[MvmntsList[i].m_Number].maxTime;
                                }
                            }
                            else if (MvmntsList[i - 1].state == (uint)GlobalVars.enum_lane_movement_status.RedLeftArrow)
                            {
                                GlobalVars.PTLMTable[MvmntsList[i-1].m_Number].Enabled = false;
                                if (GlobalVars.PTLMTable[MvmntsList[i-1].m_Number].minTime < GlobalVars.PTLMTable[MvmntsList[i].m_Number].minTime)
                                {
                                    GlobalVars.PTLMTable[MvmntsList[i].m_Number].minTime = GlobalVars.PTLMTable[MvmntsList[i-1].m_Number].minTime;
                                    GlobalVars.PTLMTable[MvmntsList[i].m_Number].maxTime = GlobalVars.PTLMTable[MvmntsList[i-1].m_Number].maxTime;
                                }
                            }
                        }
                        if ((MvmntsList[i].m_Info == MvmntsList[i - 1].m_Info) && (MvmntsList[i].Movement == SPAT.maneuvers.rightturn)
                                                                               && ((MvmntsList[i].state == (uint)GlobalVars.enum_lane_movement_status.GreenRightArrow) || (MvmntsList[i - 1].state == (uint)GlobalVars.enum_lane_movement_status.GreenRightArrow)))   // && ((MvmntsList[i].state != MvmntsList[i - 1].state)))
                        {
                            if (MvmntsList[i].state == (uint)GlobalVars.enum_lane_movement_status.GreenRightArrow)
                            {
                                GlobalVars.PTLMTable[MvmntsList[i - 1].m_Number].Enabled = false;
                            }
                            else if (MvmntsList[i - 1].state == (uint)GlobalVars.enum_lane_movement_status.GreenRightArrow)
                            {
                                GlobalVars.PTLMTable[MvmntsList[i].m_Number].Enabled = false;
                            }
                        }
                        else if ((MvmntsList[i].m_Info == MvmntsList[i - 1].m_Info) && (MvmntsList[i].Movement == SPAT.maneuvers.rightturn)
                                                                               && ((MvmntsList[i].state == (uint)GlobalVars.enum_lane_movement_status.YellowRightArrow) || (MvmntsList[i - 1].state == (uint)GlobalVars.enum_lane_movement_status.YellowRightArrow)))   // && ((MvmntsList[i].state != MvmntsList[i - 1].state)))
                        {
                            if (MvmntsList[i].state == (uint)GlobalVars.enum_lane_movement_status.YellowRightArrow)
                            {
                                GlobalVars.PTLMTable[MvmntsList[i - 1].m_Number].Enabled = false;
                            }
                            else if (MvmntsList[i - 1].state == (uint)GlobalVars.enum_lane_movement_status.YellowRightArrow)
                            {
                                GlobalVars.PTLMTable[MvmntsList[i].m_Number].Enabled = false;
                            }
                        }
                        else if ((MvmntsList[i].m_Info == MvmntsList[i - 1].m_Info) && (MvmntsList[i].Movement == SPAT.maneuvers.rightturn)
                                                       && ((MvmntsList[i].state == (uint)GlobalVars.enum_lane_movement_status.GreenBall) || (MvmntsList[i - 1].state == (uint)GlobalVars.enum_lane_movement_status.GreenBall)))   // && ((MvmntsList[i].state != MvmntsList[i - 1].state)))
                        {
                            if (MvmntsList[i].state == (uint)GlobalVars.enum_lane_movement_status.GreenBall)
                            {
                                GlobalVars.PTLMTable[MvmntsList[i - 1].m_Number].Enabled = false;
                            }
                            else if (MvmntsList[i - 1].state == (uint)GlobalVars.enum_lane_movement_status.GreenBall)
                            {
                                GlobalVars.PTLMTable[MvmntsList[i].m_Number].Enabled = false;
                            }
                        }
                        else if ((MvmntsList[i].m_Info == MvmntsList[i - 1].m_Info) && (MvmntsList[i].Movement == SPAT.maneuvers.rightturn)
                                                                               && ((MvmntsList[i].state == (uint)GlobalVars.enum_lane_movement_status.YellowBall) || (MvmntsList[i - 1].state == (uint)GlobalVars.enum_lane_movement_status.YellowBall)))   // && ((MvmntsList[i].state != MvmntsList[i - 1].state)))
                        {
                            if (MvmntsList[i].state == (uint)GlobalVars.enum_lane_movement_status.YellowBall)
                            {
                                GlobalVars.PTLMTable[MvmntsList[i - 1].m_Number].Enabled = false;
                            }
                            else if (MvmntsList[i - 1].state == (uint)GlobalVars.enum_lane_movement_status.YellowBall)
                            {
                                GlobalVars.PTLMTable[MvmntsList[i].m_Number].Enabled = false;
                            }
                        }
                        else if ((MvmntsList[i].m_Info == MvmntsList[i - 1].m_Info) && (MvmntsList[i].Movement == SPAT.maneuvers.rightturn)
                                                                               && ((MvmntsList[i].state == (uint)GlobalVars.enum_lane_movement_status.RedBall) || (MvmntsList[i - 1].state == (uint)GlobalVars.enum_lane_movement_status.RedBall)))   // && ((MvmntsList[i].state != MvmntsList[i - 1].state)))
                        {
                            if (MvmntsList[i].state == (uint)GlobalVars.enum_lane_movement_status.RedRightArrow)
                            {
                                GlobalVars.PTLMTable[MvmntsList[i].m_Number].Enabled = false;
                                if (GlobalVars.PTLMTable[MvmntsList[i].m_Number].minTime < GlobalVars.PTLMTable[MvmntsList[i-1].m_Number].minTime)
                                {
                                    GlobalVars.PTLMTable[MvmntsList[i-1].m_Number].minTime = GlobalVars.PTLMTable[MvmntsList[i].m_Number].minTime;
                                    GlobalVars.PTLMTable[MvmntsList[i-1].m_Number].maxTime = GlobalVars.PTLMTable[MvmntsList[i].m_Number].maxTime;
                                }
                            }
                            else if (MvmntsList[i - 1].state == (uint)GlobalVars.enum_lane_movement_status.RedRightArrow)
                            {
                                GlobalVars.PTLMTable[MvmntsList[i-1].m_Number].Enabled = false;
                                if (GlobalVars.PTLMTable[MvmntsList[i-1].m_Number].minTime < GlobalVars.PTLMTable[MvmntsList[i].m_Number].minTime)
                                {
                                    GlobalVars.PTLMTable[MvmntsList[i].m_Number].minTime = GlobalVars.PTLMTable[MvmntsList[i-1].m_Number].minTime;
                                    GlobalVars.PTLMTable[MvmntsList[i].m_Number].maxTime = GlobalVars.PTLMTable[MvmntsList[i-1].m_Number].maxTime;
                                }
                            }
                        }
                    }

                    SPAT spat = new SPAT();
                    SPAT.movement movement;

                    DateTime currDT = DateTime.Now;
                    TimeSpan diffDate = currDT.Subtract(GlobalVars.ReferenceDate);
                    double diffDateSecs = (uint)diffDate.TotalSeconds;
                    double diffDateTenthSecs = ((diffDate.TotalMilliseconds - (diffDateSecs * (uint)1000)) / 100);

                    spat.Message.intersectionid = GlobalVars.IntersectionID;
                    spat.Message.intersectionstatus = (SPAT.status)GlobalVars.IntersectionStatus;
                    spat.Message.timestampseconds = (uint)diffDateSecs;
                    spat.Message.timestamptenths = (byte)diffDateTenthSecs;

                    for (int m = 0; m < GlobalVars.PTLMRecords; m++)
                    {
                        if (GlobalVars.PTLMTable[m].Enabled == true)
                        {
                            movement = SPAT.movement.Create();
                            movement.data.state = GlobalVars.PTLMTable[m].state;
                            movement.data.mintime = GlobalVars.PTLMTable[m].minTime;
                            movement.data.maxtime = GlobalVars.PTLMTable[m].maxTime;
                            movement.data.yellowstate = GlobalVars.PTLMTable[m].yellowState;
                            movement.data.yellowtime = GlobalVars.PTLMTable[m].yellowTime;
                            movement.type = GlobalVars.PTLMTable[m].Movement;
                            movement.data.pedestrian = GlobalVars.PTLMTable[m].pedestrian;
                            movement.data.count = GlobalVars.PTLMTable[m].count;

                            string[] Lanes = GlobalVars.PTLMTable[m].Lanes.Split(',');
                            foreach (string lane in Lanes)
                            {
                                movement.lane.Add(Convert.ToByte(lane));
                            }
                            spat.Message.movement.Add(movement);
                        }
                    }

                    List<byte> payload = spat.Compile(byteMsgNo);
                    string tmpasciimsg = string.Empty;
                    //string SPATDispatchMessage = SPATDispatchtInfo + "payload= ";
                    string SPATDispatchMessage = SPATDispatchtInfo + "Payload=";
                    foreach (byte Byte in payload)
                    {
                        tmpasciimsg = tmpasciimsg + Byte.ToString("X2");
                    }
                    SPATDispatchMessage = SPATDispatchMessage + tmpasciimsg;
                    LogTxtMsg(txtSPATMsgLog, "\r\n\r\n\t" + tmpasciimsg);

                    if (chkEnableSpatMessagePush.Checked == true)
                    {
                        byte[] SPATMessageBytes = Encoding.ASCII.GetBytes(SPATDispatchMessage);

                        if ((chkEnableDataLogging.Checked == true) && (chkSPaTMsg.Checked == true))
                        {
                            WriteMsgToLogFile(dailyLogFile, GetCurrentTimeStamp() + ",SPaTMsg," + BitConverter.ToString(SPATMessageBytes, 0));
                        }
                        string retValue1 = spatBroadcast.TX(SPATMessageBytes);
                        if (retValue1.Length > 0)
                        {
                            LogTxtMsg(txtSPATMsgLog, "Error in pushing SPAT message to RSE." + "\r\n\t" + retValue1);
                            if (chkEnableDataLogging.Checked == true)
                            {
                                WriteMsgToLogFile(spatErrorsLog, GetCurrentTimeStamp() + ",Broadcasting SPAT message to RSE Error." + "\t" + retValue1);
                            }

                        }
                    }

                    endWakeUpTime = (DateTime.Now.Hour * 3600 + DateTime.Now.Minute * 60 + DateTime.Now.Second) * 1000 + DateTime.Now.Millisecond;
                    txtSpatMsgGenerationTime.Text = (endWakeUpTime - currTmrWakeUpTimeMsecs).ToString();
                    if (chkEnableDataLogging.Checked == true)
                    {
                        //WriteMsgToLogFile(dailyLogFile, GetCurrentTimeStamp() + ",SPaTMsgGenerationTime(MSec)," + (endWakeUpTime - currTmrWakeUpTimeMsecs).ToString());
                    }
                }
            }
            else
            {
                //currTmrWakeUpTimeMsecs = (DateTime.Now.Hour * 3600 + DateTime.Now.Minute * 60 + DateTime.Now.Second) * 1000 + DateTime.Now.Millisecond;
                //dailyLogFile.WriteLine("\r\n\r\nTimer Time: " + DateTime.Now.Hour.ToString() + ":" + DateTime.Now.Minute.ToString() + ":" +
                //                       DateTime.Now.Second.ToString() + "::" + DateTime.Now.Millisecond.ToString() +
                //                       "\tDiffWakeUpTime: " + (currTmrWakeUpTimeMsecs - prevTmrWakeUpTimeMsecs) + "\tDiffFromEnd: " + (currTmrWakeUpTimeMsecs - endWakeUpTime) + "\r\n\t No Data Was Found");
                //LogTxtMsg(txtTSCLog, "\r\n\r\n No TSC SPAT data available.");
            }

            //Check for remaining disk space and terminate logging if less than 10 GB left
            long FreeSpace = 0;
            DriveInfo driveInfo = new DriveInfo(@"C:");
            if (driveInfo.IsReady == true)
            {
                FreeSpace = driveInfo.AvailableFreeSpace;
                if (FreeSpace < GlobalVars.DataLoggingDispSpaceLimit)
                {
                    if (chkEnableDataLogging.Checked == true)
                    {
                        chkEnableDataLogging.Checked = false;
                        try
                        {
                            dailyLogFile.Close();
                            spatMsgFile.Close(); 
                        }
                        catch (Exception ex)
                        {
                            LogTxtMsg(txtActivityLog, "Data log files are already closed." + "\r\n" + ex.Message);
                        }
                        LogTxtMsg(txtActivityLog, "Data logging was terminated because remaining disk space has fallen below " + (GlobalVars.DataLoggingDispSpaceLimit / GlobalVars.OneGB) + " GB.");
                    }
                }
            }
        }

        private string ProcessSRM()
        {
            string retValue = string.Empty;
            TimeSpan spanStart;
            TimeSpan spanEnd;
            string strRequest = string.Empty;
            string strStatus = string.Empty;
            List<string> displayList = new List<string>();

            int result;
            //LogTxtMsg(txtPRGActivity, "\r\nProcessing Active SRM list: ");
            try
            {
                for (int i = 0; i < ActiveSRMList.Count; i++)
                {
                    ASN_r36.SignalRequestMsg_t tmpSRM = ActiveSRMList[i];
                    strRequest = string.Empty;
                    strStatus = ActiveSRMs[i].status.ToString();

                    spanStart = tmpSRM.desiredTimeofService.Subtract(DateTime.Now);
                    spanEnd = tmpSRM.desiredEndofService.Subtract(DateTime.Now);
                    int sTimeDiff = (spanStart.Hours * 3600 + spanStart.Minutes * 60 + spanStart.Seconds);
                    int eTimeDiff = (spanEnd.Hours * 3600 + spanEnd.Minutes * 60 + spanEnd.Seconds);

                    /*LogTxtMsg(txtPRGActivity, "\r\n\tRequestID: " + tmpSRM.request.id.ToString() + "\r\n\tinLane: " + tmpSRM.request.inLane.ToString() +
                                              "\t\tType: " + tmpSRM.vehicleClassType.ToString() + "\t\tLevel: " + tmpSRM.vehicleClassLevel.ToString() +
                                              "\r\n\tStrategy#:" + tmpSRM.strategyNumber.ToString() + "\tPreempt#:" + tmpSRM.preemptNumber.ToString() + "\tstatus: " + ActiveSRMs[i].status.ToString() +
                                              "\r\n\tS-Service: " + tmpSRM.desiredTimeofService.ToString() + "\tE-Service-Secs: " + tmpSRM.desiredEndofService.ToString() + "\t\tNow: " + DateTime.Now +
                                              "\r\n\tTimetoStart-Secs: " + sTimeDiff.ToString() + "\tTimeToEnd-Secs: " + eTimeDiff.ToString());*/

                    result = DateTime.Compare(tmpSRM.desiredTimeofService, DateTime.Now);
                    strRequest = "requestID: " + tmpSRM.request.id + ", inLane: " + tmpSRM.request.inLane +
                                 ", VType: " + tmpSRM.vehicleClassType + ", VLevel: " + tmpSRM.vehicleClassLevel + ", strtgy: " + tmpSRM.strategyNumber +
                                 ", preempt: " + tmpSRM.preemptNumber + ", sTime: " + sTimeDiff + ", eTime: " + eTimeDiff;

                    if (sTimeDiff == 0)
                    {
                        //MessageBox.Show(tmpSRM.desiredEndofService.ToString() + "\t" + DateTime.Now,"ActivatePreempt", MessageBoxButtons.OK);
                        if ((ActiveSRMs[i].status == clsSRM.RequestStatus.Received) && (tmpSRM.preemptNumber > 0) && (tmpSRM.preemptNumber <= maxNumberofPreempts))
                        {
                            //MessageBox.Show(tmpSRM.desiredTimeofService + "\t" + DateTime.Now);
                            string tmpRetValue = ActivateDeactivatePreempt(txtPRGActivity, preemptControlStateOIDPrefix + tmpSRM.preemptNumber, "1");
                            if (tmpRetValue.Length == 0)
                            {
                                ActiveSRMs[i].status = clsSRM.RequestStatus.InQueue;
                                strStatus = "InQueue";
                                LogTxtMsg(txtPRGActivity, "\r\n\tActivated");
                            }
                            else
                            {
                                strStatus = "Received";
                            }
                        }
                    }

                    result = DateTime.Compare(tmpSRM.desiredEndofService, DateTime.Now);
                    if (eTimeDiff == 0)
                    {
                        if (ActiveSRMs[i].status == clsSRM.RequestStatus.InQueue)
                        {

                            string tmpRetValue = ActivateDeactivatePreempt(txtPRGActivity, preemptControlStateOIDPrefix + tmpSRM.preemptNumber, "0");
                            if (tmpRetValue.Length == 0)
                            {
                                //tmpSRM.status = SPaTDemo.ASN_r36.RequestStatus.Expired;
                                ActiveSRMs[i].status = clsSRM.RequestStatus.Expired;
                                LogTxtMsg(txtPRGActivity, "\r\n\tDeActivated");
                                strStatus = "Expired";
                            }
                            else
                            {
                                strStatus = "InQueue";
                            }
                        }
                        else
                        {
                            ActiveSRMs[i].status = clsSRM.RequestStatus.Expired;
                            //tmpSRM.status = SPaTDemo.ASN_r36.RequestStatus.Expired;
                            strStatus = "Expired";
                        }
                    }
                    strRequest = strRequest + ", status: " + strStatus;
                    displayList.Add(strRequest);
                }
            }
            catch (Exception ex)
            {
                retValue = "Error in processing the SRM list. " +
                           "\r\n\t" + ex.Message;
            }
            lstboxPRG.DataSource = null;
            lstboxPRG.DataSource = displayList;
            return retValue;
        }

        private string ProcessSSM()
        {
            string retValue = string.Empty;
            TimeSpan spanStart;
            TimeSpan spanEnd;

            LogTxtMsg(txtSSMActivity, "\r\nGenerating SSMs... ");
            try
            {
                for (int i = 0; i < ActiveSRMList.Count; i++)
                {
                    ASN_r36.SignalRequestMsg_t tmpSRM = ActiveSRMList[i];

                    spanStart = tmpSRM.desiredTimeofService.Subtract(DateTime.Now);

                    spanEnd = tmpSRM.desiredEndofService.Subtract(DateTime.Now);
                    int sTimeDiff = (spanStart.Hours * 3600 + spanStart.Minutes * 60 + spanStart.Seconds);
                    int eTimeDiff = (spanEnd.Hours * 3600 + spanEnd.Minutes * 60 + spanEnd.Seconds);

                    LogTxtMsg(txtSSMActivity, "\r\n\tRequestID: " + tmpSRM.request.id.ToString() + "\r\n\tinLane: " + tmpSRM.request.inLane.ToString() +
                                              "\t\tType: " + tmpSRM.vehicleClassType.ToString() + "\t\tLevel: " + tmpSRM.vehicleClassLevel.ToString() +
                                              "\r\n\tStrategy#:" + tmpSRM.strategyNumber.ToString() + "\tPreempt#:" + tmpSRM.preemptNumber.ToString() + "\tstatus: " + ActiveSRMs[i].status.ToString() +
                                              "\r\n\tS-Service: " + tmpSRM.desiredTimeofService.ToString() + "\tE-Service-Secs: " + tmpSRM.desiredEndofService.ToString() + "\t\tNow: " + DateTime.Now +
                                              "\r\n\tTimetoStart-Secs: " + sTimeDiff.ToString() + "\tTimeToEnd-Secs: " + eTimeDiff.ToString());

                    //      Create the SSM Message Structure
                    ASN_r36.SignalStatusMessage_t signalStatus = ASN_r36.SignalStatusMessage_t.Create();

                    //      Initialize the Structure with some Data
                    signalStatus.msgCnt = 0;
                    signalStatus.id = tmpSRM.request.id;
                    signalStatus.status = (byte)GlobalVars.IntersectionStatus;

                    //      Serialize the SSM Structure    
                    List<byte> BUFFER = signalStatus.Serialize();

                    //      Display the Serialized SSM Structure
                    LogTxtMsg(txtSSMActivity, "\tSSM Serialized Data...");
                    string tmpString = string.Empty;
                    foreach (byte Byte in BUFFER) { tmpString = tmpString + (((byte)Byte).ToString("X2")); }
                    LogTxtMsg(txtSSMActivity, "\t" + tmpString);

                    //      CALL THE ASNJ2735 SERVER TO ENCODE THE MESSAGE TO ASN
                    SRMobjStream.Write(BUFFER);
                    List<byte> ASN = SRMobjStream.Read();

                    //      Display the ASN Encode Message
                    LogTxtMsg(txtSSMActivity, "\tSSM ASN Encoded...");
                    string tmpStringASN = string.Empty;
                    foreach (byte Byte in ASN) { tmpStringASN = tmpStringASN + (((byte)Byte).ToString("X2")); }
                    LogTxtMsg(txtSSMActivity, "\t" + tmpStringASN);

                    string SSMDispatchMessage = SSMDispatchtInfo + "Payload=";

                    SSMDispatchMessage = SSMDispatchMessage + tmpStringASN;

                    LogTxtMsg(txtSSMActivity, "\r\n\r\n\tSSMMessage + DispatchInfo: " + SSMDispatchMessage);

                    if (chkEnableSSMMessagePush.Checked == true)
                    {
                        byte[] SSMMessageBytes = Encoding.ASCII.GetBytes(SSMDispatchMessage);
                        LogTxtMsg(txtSSMActivity, SSMMessageBytes.Length + "\t" + SSMMessageBytes.ToString());
                        if (chkEnableDataLogging.Checked == true)
                        {
                            dailyLogFile.WriteLine(DateTime.Now.ToString() + ",SSMMsg," + BitConverter.ToString(SSMMessageBytes, 0));

                            //write msg to spatmsg log file

                            //ssmMsgFile.WriteLine(DateTime.Now.ToString() + "\r\n\t--SPAT Msg with Dispatch Info: \r\n" + BitConverter.ToString(SSMMessageBytes, 0));

                        }
                        string retValue1 = ssmBroadcast.TX(SSMMessageBytes);
                        if (retValue1.Length > 0)
                        {
                            LogTxtMsg(txtSSMActivity, "Error in pushing SSM message to RSE." + "\r\n\t" + retValue1);
                            if (chkEnableDataLogging.Checked == true)
                            {
                                dailyLogFile.WriteLine(DateTime.Now.ToString() + ",Error in pushing SSM message to RSE." + "\t" + retValue1);
                                //ssmMsgFile.WriteLine(DateTime.Now.ToString() + "\r\n--Error in pushing SPAT message to RSE." + "\r\n\t" + retValue1);
                            }

                        }
                    }
                }
                for (int i = 0; i < ActiveSRMList.Count; i++)
                {
                    if (ActiveSRMs[i].status == clsSRM.RequestStatus.Expired)
                    {
                        ActiveSRMList.RemoveAt(i);
                        ActiveSRMs.RemoveAt(i);
                    }
                }
            }
            catch (Exception ex)
            {
                retValue = "Error in processing the SRM list. " +
                           "\r\n\t" + ex.Message;
            }
            return retValue;
        }

        private string ActivateDeactivatePreempt(TextBox txtActivityBox, string PreemptOID, string PreemptState)
        {
            string retValue = string.Empty;
            int intPreemptState = Convert.ToInt32(PreemptState);
            byte[] BytesRcvd;
            byte[] BytesSent;

            if (PreemptOID.Length > 0)
            {
                LogTxtMsg(txtActivityBox, "\r\nPreemptOID: " + OID + "\tPreemptState: " + PreemptState);

                if ((PreemptState.Length > 0) && ((intPreemptState >= 0) && (intPreemptState <= 1)))
                {
                    //SenderFunction = "EnableDisablePreempt";
                    NTCIPData.GotResponse = false;
                    IntializePhasePropertyArrayValues();
                    BeginTime = (DateTime.Now.Hour * 3600 + DateTime.Now.Minute * 60 + DateTime.Now.Second) * 1000 + DateTime.Now.Millisecond;
                    axaxNtcipIO1.SetOID(PreemptOID, PreemptState, axNtcipIOControl.TxsetOIDType.otInteger);
                }
                else
                {
                    retValue = "\r\n--The values for the preempt state must be > = zero: " + PreemptState;
                    return retValue;
                }
                TimeSpan STS = new TimeSpan(DateTime.Now.Ticks);
                TimeSpan CurrTS = new TimeSpan();
                do
                {
                    CurrTS = new TimeSpan(DateTime.Now.Ticks);

                    if (NTCIPData.GotResponse == true)
                    {
                        BytesRcvd = Encoding.ASCII.GetBytes(axaxNtcipIO1.InByteStream);
                        BytesSent = Encoding.ASCII.GetBytes(axaxNtcipIO1.OutBufStream);
                        EndTime = (DateTime.Now.Hour * 3600 + DateTime.Now.Minute * 60 + DateTime.Now.Second) * 1000 + DateTime.Now.Millisecond;
                        LogTxtMsg(txtActivityBox, "\t BytesSent : " + BitConverter.ToString(BytesSent, 0));
                        LogTxtMsg(txtActivityBox, "\t BytesRcvd: " + BitConverter.ToString(BytesRcvd, 0));
                        txtEnableSPATPush.Refresh();
                        string data = string.Empty;
                        for (int k = 0; k < BytesRcvd.Length; k++)
                        {
                            data += BytesRcvd[k].ToString() + "-";
                        }
                        LogTxtMsg(txtActivityBox, "\t BytesVals: " + data);
                        LogTxtMsg(txtActivityBox, "\t Duration: " + (EndTime - BeginTime) + " milliseconds.");

                        LogTxtMsg(txtActivityBox, "");
                        //SenderFunction = string.Empty;
                        return retValue;
                    }
                    Application.DoEvents();
                } while ((CurrTS.TotalMilliseconds - STS.TotalMilliseconds) < (GlobalVars.TimeOutPeriod * 1000));
            }
            else
            {
                retValue = "--The specified preempt OID is empty. Please specify the proper Preempt OID: " + PreemptOID;
                return retValue;
            }
            return retValue;
        }

        private void btnEnablePreempt1_Click(object sender, EventArgs e)
        {
            string tmpOID = preemptControlStateOIDPrefix + "1";
            ActivateDeactivatePreempt(txtEnableSPATPush, tmpOID, "1");
            chkPrmpt1.Checked = true;
        }

        private void btnEnablePreempt2_Click(object sender, EventArgs e)
        {
            string tmpOID = preemptControlStateOIDPrefix + "2";
            ActivateDeactivatePreempt(txtEnableSPATPush, tmpOID, "1");
            chkPrmpt2.Checked = true;
        }

        private void btnEnablePreempt3_Click(object sender, EventArgs e)
        {
            string tmpOID = preemptControlStateOIDPrefix + "3";
            ActivateDeactivatePreempt(txtEnableSPATPush, tmpOID, "1");
            chkPrmpt3.Checked = true;
        }

        private void btnDisablePreempt1_Click(object sender, EventArgs e)
        {
            string tmpOID = preemptControlStateOIDPrefix + "1";
            ActivateDeactivatePreempt(txtEnableSPATPush, tmpOID, "0");
            chkPrmpt1.Checked = false;
        }

        private void btnDisablePreempt2_Click(object sender, EventArgs e)
        {
            string tmpOID = preemptControlStateOIDPrefix + "2";
            ActivateDeactivatePreempt(txtEnableSPATPush, tmpOID, "0");
            chkPrmpt2.Checked = false;
        }

        private void btnDisablePreempt3_Click(object sender, EventArgs e)
        {
            string tmpOID = preemptControlStateOIDPrefix + "3";
            ActivateDeactivatePreempt(txtEnableSPATPush, tmpOID, "0");
            chkPrmpt3.Checked = false;
        }

        private void btnEnablePreempt4_Click_1(object sender, EventArgs e)
        {
            string tmpOID = preemptControlStateOIDPrefix + "4";
            ActivateDeactivatePreempt(txtEnableSPATPush, tmpOID, "1");
            chkPrmpt4.Checked = true;
        }

        private void btnEnablePreempt5_Click_1(object sender, EventArgs e)
        {
            string tmpOID = preemptControlStateOIDPrefix + "5";
            ActivateDeactivatePreempt(txtEnableSPATPush, tmpOID, "1");
            chkPrmpt5.Checked = true;
        }

        private void btnEnablePreempt6_Click_1(object sender, EventArgs e)
        {
            string tmpOID = preemptControlStateOIDPrefix + "6";
            ActivateDeactivatePreempt(txtEnableSPATPush, tmpOID, "1");
            chkPrmpt6.Checked = true;
        }

        private void btnDisablePreempt4_Click(object sender, EventArgs e)
        {
            string tmpOID = preemptControlStateOIDPrefix + "4";
            ActivateDeactivatePreempt(txtEnableSPATPush, tmpOID, "0");
            chkPrmpt4.Checked = false;
        }

        private void btnDisablePreempt5_Click(object sender, EventArgs e)
        {
            string tmpOID = preemptControlStateOIDPrefix + "5";
            ActivateDeactivatePreempt(txtEnableSPATPush, tmpOID, "0");
            chkPrmpt5.Checked = false;
        }

        private void btnDisablePreempt6_Click(object sender, EventArgs e)
        {
            string tmpOID = preemptControlStateOIDPrefix + "6";
            ActivateDeactivatePreempt(txtEnableSPATPush, tmpOID, "0");
            chkPrmpt6.Checked = false;
        }

        private void axaxNtcipIO1_OnNTCIPData(object sender, EventArgs e)
        {

            byte[] BytesRcvd;
            byte[] BytesSent;
            //this event is raised by the ActiveX control when a valid packet is received.
            //copy control properties to variables in this loop to ensure they are maintained after
            //the loop terminates

            //update variables with the event that has just occurred
            NTCIPData.InAddress = axaxNtcipIO1.InAddress;
            NTCIPData.InCommunity = axaxNtcipIO1.InCommunity;
            NTCIPData.InReqType = (int)axaxNtcipIO1.InReqType;
            NTCIPData.InReqID = axaxNtcipIO1.InReqID;
            NTCIPData.InErrorStatus = (int)axaxNtcipIO1.InErrorStatus;
            NTCIPData.InErrorIndex = axaxNtcipIO1.InErrorIndex;
            NTCIPData.InOID = axaxNtcipIO1.InOID;
            NTCIPData.InOIDValue = axaxNtcipIO1.InOIDValue;
            NTCIPData.InOIDType = (int)axaxNtcipIO1.InOIDType;

            //set response flag
            NTCIPData.GotResponse = true;

            //LogTxtMsg(txtEnableSPATPush, "\t axaxNtcipIO1_OnNTCIPData::" + SenderFunction);
            /*if (axaxNtcipIO1.InByteStream != null)
            {
                BytesRcvd = Encoding.ASCII.GetBytes(axaxNtcipIO1.InByteStream);
                LogTxtMsg(txtEnableSPATPush, "\t BytesRcvd: " + BitConverter.ToString(BytesRcvd, 0));
            }
            else
            {
                LogTxtMsg(txtEnableSPATPush, "\t BytesRcvd: None");
            }
            BytesSent = Encoding.ASCII.GetBytes(axaxNtcipIO1.OutBufStream);
            LogTxtMsg(txtEnableSPATPush, "\t BytesSent : " + BitConverter.ToString(BytesSent, 0));*/

            //string stringResponse = Encoding.ASCII.GetString(BytesRcvd);
            //string stringResponse1 = ASCIIEncoding.ASCII.GetString(BytesRcvd);
            txtEnableSPATPush.Refresh();


            if (NTCIPData.InOIDValue is int)
            {
                if (ReceivedValuesType == OIDTypes.intOID)
                {
                    intReceivedValues[NoReceivedValues++] = (int)NTCIPData.InOIDValue;
                    LogTxtMsg(txtEnableSPATPush, "\r\n\t1-IntegerValue: " + NoReceivedValues + "\t" + intReceivedValues[NoReceivedValues - 1].ToString());
                }
                else if (ReceivedValuesType == OIDTypes.stringOID)
                {
                    strReceivedValues[NoReceivedValues++] = (string)(NTCIPData.InOIDValue);
                    LogTxtMsg(txtEnableSPATPush, "\r\n\t1-IntegerValue-to-string-: " + NoReceivedValues + "\t" + strReceivedValues[NoReceivedValues - 1]);
                }
            }
            else if (NTCIPData.InOIDValue is string)
            {
                if (ReceivedValuesType == OIDTypes.intOID)
                {
                    try
                    {
                        intReceivedValues[NoReceivedValues++] = Convert.ToInt32((string)NTCIPData.InOIDValue);
                    }
                    catch (Exception ex)
                    {
                        Application.DoEvents();
                    }
                }
                else if (ReceivedValuesType == OIDTypes.stringOID)
                {
                    strReceivedValues[NoReceivedValues++] = (string)(NTCIPData.InOIDValue);
                    LogTxtMsg(txtEnableSPATPush, "\r\n\t2-IntegerValue-to-string-: " + NoReceivedValues + "\t" + strReceivedValues[NoReceivedValues - 1]);
                }
            }
        }

        private void btnSaveSPATConfiguration_Click(object sender, EventArgs e)
        {
            string retValue = SaveSPATConfiguration();
            if (retValue.Length > 0)
            {
                MessageBox.Show("Error in saving the SPAT Configuration parameters. " + "\r\n\t" + retValue);
                return;
            }
            MessageBox.Show("Please click the EXIT SPAT System button to terminate the SPAT System and restart the system again for the modified parameters to take effect.");
            //this.Close();
        }

        private string SaveSPATConfiguration()
        {
            string retValue = string.Empty;

            string configFile = Application.StartupPath + "\\config.xml";
            LogTxtMsg(txtActivityLog, "\r\nUpdating the SPAT config file: " + configFile);

            string sTag;
            string sValue;

            //      Load the Configuration File
            try
            {
                XDocument doc = XDocument.Load(configFile);
                XElement root = doc.Root;

                //      Parse the Configuration File Elements
                foreach (XElement element in root.Elements())
                {
                    sTag = element.Name.ToString();
                    sValue = element.Value.ToString();
                    switch (sTag.ToLower())
                    {
                        case "gpsport":
                        {
                            foreach (XElement child in element.Elements())
                            {
                                sTag = child.Name.ToString();
                                sValue = child.Value.ToString();
                                switch (sTag.ToLower())
                                {
                                    case "portname":
                                        {
                                            if (cmbPortName.Text.Trim().Length > 0)
                                            {
                                                child.SetValue((string)(cmbPortName.Text.Trim()));
                                            }
                                            break;
                                        }
                                    case "baudrate":
                                        if (cmbBaudRate.Text.Trim().Length > 0)
                                        {
                                            child.SetValue((string)(cmbBaudRate.Text.Trim()));
                                        }
                                        break;
                                    case "databits":
                                        if (cmbDataBits.Text.Trim().Length > 0)
                                        {
                                            child.SetValue((string)(cmbDataBits.Text.Trim()));
                                        }
                                        break;
                                    case "stopbits":
                                        if (cmbStopBits.Text.Trim().Length > 0)
                                        {
                                            child.SetValue((string)(cmbStopBits.Text.Trim()));
                                        }
                                        break;
                                    case "parity":
                                        if (cmbParity.Text.Trim().Length > 0)
                                        {
                                            child.SetValue((string)(cmbParity.Text.Trim()));
                                        }
                                        break;
                                    case "handshake":
                                        if (cmbHandShake.Text.Trim().Length > 0)
                                        {
                                            child.SetValue((string)(cmbHandShake.Text.Trim()));
                                        }
                                        break;
                                }
                            }
                            break;
                        }
                        case "peddetection":
                        {
                            foreach (XElement child in element.Elements())
                            {
                                sTag = child.Name.ToString();
                                sValue = child.Value.ToString();
                                switch (sTag.ToLower())
                                {
                                    case "pedphase1":
                                        {
                                            child.SetValue((bool)(chkPedDetectPhase1.Checked));
                                            break;
                                        }
                                    case "pedphase2":
                                        {
                                            child.SetValue((bool)(chkPedDetectPhase2.Checked));
                                            break;
                                        }
                                    case "pedphase3":
                                        {
                                            child.SetValue((bool)(chkPedDetectPhase3.Checked));
                                            break;
                                        }
                                    case "pedphase4":
                                        {
                                            child.SetValue((bool)(chkPedDetectPhase4.Checked));
                                            break;
                                        }
                                    case "pedphase5":
                                        {
                                            child.SetValue((bool)(chkPedDetectPhase5.Checked));
                                            break;
                                        }
                                    case "pedphase6":
                                        {
                                            child.SetValue((bool)(chkPedDetectPhase6.Checked));
                                            break;
                                        }
                                    case "pedphase7":
                                        {
                                            child.SetValue((bool)(chkPedDetectPhase7.Checked));
                                            break;
                                        }
                                    case "pedphase8":
                                        {
                                            child.SetValue((bool)(chkPedDetectPhase8.Checked));
                                            break;
                                        }
                                    case "pedphase9":
                                        {
                                            child.SetValue((bool)(chkPedDetectPhase9.Checked));
                                            break;
                                        }
                                    case "pedphase10":
                                        {
                                            child.SetValue((bool)(chkPedDetectPhase10.Checked));
                                            break;
                                        }
                                    case "pedphase11":
                                        {
                                            child.SetValue((bool)(chkPedDetectPhase11.Checked));
                                            break;
                                        }
                                    case "pedphase12":
                                        {
                                            child.SetValue((bool)(chkPedDetectPhase12.Checked));
                                            break;
                                        }
                                    case "pedphase13":
                                        {
                                            child.SetValue((bool)(chkPedDetectPhase13.Checked));
                                            break;
                                        }
                                    case "pedphase14":
                                        {
                                            child.SetValue((bool)(chkPedDetectPhase14.Checked));
                                            break;
                                        }
                                    case "pedphase15":
                                        {
                                            child.SetValue((bool)(chkPedDetectPhase15.Checked));
                                            break;
                                        }
                                    case "pedphase16":
                                        {
                                            child.SetValue((bool)(chkPedDetectPhase16.Checked));
                                            break;
                                        }
                                }
                            }
                            break;
                        }
                        case "tscipv4address":
                        {
                            element.SetValue((string)(txtTSCIPV4Address.Text.Trim()));
                            break;
                        }
                        case "targetip":
                        {
                            element.SetValue((string)(txtRSEIPV6Address.Text.Trim()));
                            break;
                        }
                        case "spatsystemipv4address":
                        {
                            element.SetValue((string)(txtSPATSystemIPV4Address.Text.Trim()));
                            break;
                        }
                        case "localip":
                        {
                            element.SetValue((string)(txtSPATSystemIPV6Address.Text.Trim()));
                            break;
                        }
                        case "tscntcipport":
                        {
                            element.SetValue((string)(txtTSCNTCIPPort.Text.Trim()));
                            break;
                        }
                        case "spatsystemspatport":
                        {
                            element.SetValue((string)(txtSPATSystemSPATPort.Text.Trim()));
                            break;
                        }
                        case "intersectionname":
                        {
                            element.SetValue((string)(txtIntersectionName.Text.Trim()));
                            break;
                        }
                        case "intersectionid":
                        {
                            element.SetValue((string)(txtIntersectionID.Text.Trim()));
                            break;
                        }
                        case "intersectioncity":
                        {
                            element.SetValue((string)(txtCity.Text.Trim()));
                            break;
                        }
                        case "intersectionstate":
                        {
                            element.SetValue((string)(txtState.Text.Trim()));
                            break;
                        }
                        case "spatpushcode":
                        {
                            element.SetValue((string)(txtSPaTPushCode.Text.Trim()));
                            break;
                        }
                        case "ptlmmappingfile":
                        {
                            element.SetValue((string)(txtPTLMFile.Text.Trim()));
                            break;
                        }
                        case "logdatadir":
                        {
                            element.SetValue((string)(txtSPATDailyLogFolder.Text.Trim()));
                            break;
                        }
                        //Update the map Configuration Elements
                        case "map":
                        {
                                foreach (XElement child in element.Elements())
                                {
                                    sTag = child.Name.ToString();
                                    sValue = child.Value.ToString();
                                    switch (sTag.ToLower())
                                    {
                                        case "localport":
                                            {
                                                child.SetValue((string)(txtMapMsgLocalPort.Text.Trim()));
                                                break;
                                            }
                                        case "targetport":
                                            {
                                                child.SetValue((string)(txtMapMsgTargetPort.Text.Trim()));
                                                break;
                                            }
                                    }
                                }
                                break;
                        }
                        //Update the spat Configuration Elements
                        case "spat":
                        {
                                foreach (XElement child in element.Elements())
                                {
                                    sTag = child.Name.ToString();
                                    sValue = child.Value.ToString();
                                    switch (sTag.ToLower())
                                    {
                                        case "localport":
                                            {
                                                child.SetValue((string)(txtSpatMsgLocalPort.Text.Trim()));
                                                break;
                                            }
                                        case "targetport":
                                            {
                                                child.SetValue((string)(txtSpatMsgTargetPort.Text.Trim()));
                                                break;
                                            }
                                    }
                                }
                                break;
                        }
                        //Update the SRM Configuration Elements
                        case "srm":
                        {
                                foreach (XElement child in element.Elements())
                                {
                                    sTag = child.Name.ToString();
                                    sValue = child.Value.ToString();
                                    switch (sTag.ToLower())
                                    {
                                        case "localport":
                                            {
                                                child.SetValue((string)(txtSRMMsgLocalPort.Text.Trim()));
                                                break;
                                            }
                                        case "targetport":
                                            {
                                                child.SetValue((string)(txtSRMMsgTargetPort.Text.Trim()));
                                                break;
                                            }
                                    }
                                }
                                break;
                        }
                        //Update the SSM Configuration Elements
                        case "ssm":
                        {
                                foreach (XElement child in element.Elements())
                                {
                                    sTag = child.Name.ToString();
                                    sValue = child.Value.ToString();
                                    switch (sTag.ToLower())
                                    {
                                        case "localport":
                                            {
                                                child.SetValue((string)(txtSSMMsgLocalPort.Text.Trim()));
                                                break;
                                            }
                                        case "targetport":
                                            {
                                                child.SetValue((string)(txtSSMMsgTargetPort.Text.Trim()));
                                                break;
                                            }
                                    }
                                }
                                break;
                        }
                        //Update the RTCM Configuration Elements
                        case "rtcm":
                        {
                                foreach (XElement child in element.Elements())
                                {
                                    sTag = child.Name.ToString();
                                    sValue = child.Value.ToString();
                                    switch (sTag.ToLower())
                                    {
                                        case "localport":
                                            {
                                                child.SetValue((string)(txtRTCMMsgLocalPort.Text.Trim()));
                                                break;
                                            }
                                        case "targetport":
                                            {
                                                child.SetValue((string)(txtRTCMMsgTargetPort.Text.Trim()));
                                                break;
                                            }
                                    }
                                }
                                break;
                        }
                    }
                }
                doc.Save(configFile);
            }
            catch (Exception Exp)
            {
                retValue = "Error reading DispatchInfo configuration file: " + configFile + "\r\n\t" + Exp.Message;

                return retValue;
            }
            return retValue;
        }

        private void btnCancel_Click_1(object sender, EventArgs e)
        {
            IButtonControl control = (IButtonControl)sender;
            control.DialogResult = DialogResult.Cancel;
            //this.Close();
        }

        private void btnSetOID_Click(object sender, EventArgs e)
        {
            string retValue = string.Empty;

            string tmpOID = string.Empty;
            tmpOID = txtOID.Text.Trim();
            string tmpOIDValue = string.Empty;
            tmpOIDValue = txtOIDValue.Text.Trim();
            retValue = EnableSpatMessagePush(tmpOID, tmpOIDValue);
            if (retValue.Length > 0)
            {
                MessageBox.Show(retValue);
                LogTxtMsg(txtEnableSPATPush, retValue);
            }
        }

        private void btnHaltSPATSystem_Click(object sender, EventArgs e)
        {
            string strRetValue;
            string Filename = string.Empty;

            if (GlobalVars.SPATSystemRunning == true)
            {
                strRetValue = EnableSpatMessagePush("1.3.6.1.4.1.1206.3.5.2.9.44.1.0", "0");
                if (strRetValue.Length > 0)
                {
                    LogTxtMsg(txtEnableSPATPush, strRetValue);
                }

                tmrUDPClient.Enabled = false;
                tmrGPS.Enabled = false;
                tmrSRM.Enabled = false;

                btnHaltSPATSystem.Text = "Start SPAT System";
                GlobalVars.SPATSystemRunning = false;
                if (chkEnableDataLogging.Checked == true)
                {
                    dailyLogFile.Close();
                    spatMsgFile.Close();
                }
                TSCListener.Close();
                TSCListener = null;
                if (spGPS.IsOpen)
                {
                    spGPS.Close();
                }
            }
            else
            {
                strRetValue = StartSPATSystem();
                if (strRetValue.Length > 0)
                {
                    MessageBox.Show("An error was detected during the SPaT system startup. \r\n" +
                                        "Please check the SPaT System Activity Log window under the SPaT Activity Logs tab page for the errors detected.");
                    return;
                }
            }
        }

        private void chkEnableDisableSPAT_CheckedChanged(object sender, EventArgs e)
        {
            if (chkEnableDisableSPAT.Checked == true)
            {
                tmrUDPClient.Enabled = true;
                if (GlobalVars.IncludeSRMSSM == true)
                {
                    tmrSRM.Enabled = true;
                }
                else
                {
                    tmrSRM.Enabled = false;
                }
            }
            else
            {
                tmrUDPClient.Enabled = false;
                tmrSRM.Enabled = false;
            }
        }

        private void btnModifySPATMsgDir_Click(object sender, EventArgs e)
        {
            //folderBrowserDialog1.RootFolder = Application.StartupPath();
            DialogResult result = folderBrowserDialog1.ShowDialog();
            if (result == DialogResult.OK)
            {
                //
                // The user selected a folder and pressed the OK button.
                GlobalVars.SPATDailyLogFolderPath = folderBrowserDialog1.SelectedPath.ToString();
                txtSPATDailyLogFolder.Text = GlobalVars.SPATDailyLogFolderPath;
                //string[] files = Directory.GetFiles(folderBrowserDialog1.SelectedPath);
            }

        }

        private void tmrGPS_Tick(object sender, EventArgs e)
        {
            string msg = string.Empty;
            string Sentence = string.Empty;

            try
            {

                if (spGPS.IsOpen == true)
                {
                    GlobalVars.GPSTmrCounter = GlobalVars.GPSTmrCounter + 1;
                    LogTxtMsg(txtGPSActivity, GetCurrentTimeStamp() + " --- Next SPaT System Time update from GPS Time is in: " + (GlobalVars.GPSUpdateFrequency - GlobalVars.GPSTmrCounter).ToString() + " minutes");

                    if (spGPS.BytesToRead > 0)
                    {
                        txtBuffer = spGPS.ReadExisting();
                    }
                    int GPRMCLocation = 0;
                    while ((GPRMCLocation = txtBuffer.LastIndexOf("$GPRMC")) >= 0)
                    {
                        Sentence = txtBuffer.Substring(GPRMCLocation);
                        //if ((NLLocation = Sentence.LastIndexOf("\n")) > 0)
                        //{
                        if ((Sentence.IndexOf("\n") > 0) || (Sentence.IndexOf("\r") > 0))
                        {
                            GPSDevice.ParseGPRMC(Sentence);
                            break;
                        }
                        else
                        {
                            txtBuffer = txtBuffer.Substring(0, GPRMCLocation);
                        }
                    }
                    //string tmpret = GPSDevice.ReadSerialPort();
                    txtGPSRawTime.Text = GPSDevice.RawUTCTime;
                    txtGPSUTCTime.Text = GPSDevice.UTCTime;
                    txtSatelliteTime.Text = GPSDevice.SatelliteTime.ToString();
                    txtGPSLocalTime.Text = GPSDevice.GPSLocalTime.ToString();
                    txtSysBeforeTime.Text = GPSDevice.SystemLocalTimeBefore;
                    txtNewTime.Text = GPSDevice.NewTime;
                    txtSysAfterTime.Text = GPSDevice.SystemLocalTimeAfter;
                    txtGPSDate.Text = GPSDevice.Date;
                    txtLat.Text = GPSDevice.Latitude;
                    txtLon.Text = GPSDevice.Longitude;

                    if (GPSDevice.Fix == "A")
                    {
                        txtGPSFix.Text = "Received GPS Fix";
                        txtGPSFix.BackColor = Color.Green;
                    }
                    else
                    {
                        txtGPSFix.Text = "Lost GPS Fix";
                        txtGPSFix.BackColor = Color.Red;
                    }
                    LogTxtMsg(txtGPSActivity, GetCurrentTimeStamp() + " ---" + GPSDevice.GPRMCSentence);
                    if (GlobalVars.GPSTmrCounter >= GlobalVars.GPSUpdateFrequency)
                    {
                        GlobalVars.GPSTmrCounter = 0;
                    }
                    Application.DoEvents();
                    Application.DoEvents();
                    Application.DoEvents();
                }
                else
                {
                    LogTxtMsg(txtGPSActivity, GetCurrentTimeStamp() + " ---The GPS device is disconnected or the serial port: " + spGPS.PortName + " is closed.");
                    LogTxtMsg(txtGPSActivity, GetCurrentTimeStamp() + " Trying to open the port again:");
                    try
                    {
                        string strRetValue = string.Empty;
                        strRetValue = GPSDevice.OpenGPSDeviceSerialPort(spGPS);
                        if (strRetValue.Length > 0)
                        {
                            LogTxtMsg(txtGPSActivity, GetCurrentTimeStamp() + " --- " + strRetValue);
                        }
                        else
                        {
                            LogTxtMsg(txtGPSActivity, GetCurrentTimeStamp() + " Opening GPS serial port again was successful.");
                        }
                    }
                    catch (Exception ex)
                    {
                        LogTxtMsg(txtGPSActivity, GetCurrentTimeStamp() + " failed to open GPS serial port again. " + "\r\n\t" + ex.Message);
                    }
                }
            }
            catch (Exception ex)
            {
                LogTxtMsg(txtGPSActivity, GetCurrentTimeStamp() + " ---" + ex.Message);
            }
        }

        private void tmrSRM_Tick(object sender, EventArgs e)
        {
            if (SRMListener.Available > 0)
            {
                LogTxtMsg(txtPRGActivity, "\r\n\r\n  ***** New SRM data is available from: " + SRMListener.ToString());

                currTmrWakeUpTimeMsecs = (DateTime.Now.Hour * 3600 + DateTime.Now.Minute * 60 + DateTime.Now.Second) * 1000 + DateTime.Now.Millisecond;
                txtSysTime.Text = DateTime.Now.Hour.ToString() + ":" + DateTime.Now.Minute.ToString() + ":" +
                                    DateTime.Now.Second.ToString() + "::" + DateTime.Now.Millisecond.ToString();

                //if (chkEnableDataLogging.Checked == true)
                //{
                //    dailyLogFile.WriteLine("\r\n" + DateTime.Now.Hour.ToString() + ":" + DateTime.Now.Minute.ToString() + ":" +
                //                           DateTime.Now.Second.ToString() + "::" + DateTime.Now.Millisecond.ToString() +
                //                           "--NewSRMRequest \tTimeSinceLastMsgRcvd: " + (currTmrWakeUpTimeMsecs - prevTmrWakeUpTimeMsecs) + "  :::  " + (currTmrWakeUpTimeMsecs - endWakeUpTime));
                //}

                prevTmrWakeUpTimeMsecs = currTmrWakeUpTimeMsecs;
                
                LogTxtMsg(txtPRGActivity, "\r\n\r\nAvaialable: " + SRMListener.Available.ToString());
                
                byte[] bytes = SRMListener.Receive(ref SRM);
                List<byte> bytesList = new List<byte>(bytes);
                SRMobjStream.Write(bytesList);
                List<byte> SRMBUFFER = new List<byte>();
                SRMBUFFER = SRMobjStream.Read();

                ASN_r36.SignalRequestMsg_t srmMsg = ASN_r36.SignalRequestMsg_t.Create();
                clsSRM newSRM = new clsSRM();

                srmMsg.Deserialize(SRMBUFFER);
                byte vehicleClassTypeMask = 240;
                byte vehicleClassLevel = 15;
                srmMsg.preemptNumber = 0;
                srmMsg.strategyNumber = 0;
                srmMsg.vehicleClassLevel = (byte)(srmMsg.request.type & vehicleClassLevel);
                srmMsg.vehicleClassType = (byte)((srmMsg.request.type & vehicleClassTypeMask) >> 4);
                srmMsg.requestID = srmMsg.request.id;

                srmMsg.startServiceTime = (ushort)(srmMsg.timeOfService.hour * 3600 + srmMsg.timeOfService.minute * 60 + srmMsg.timeOfService.second);
                srmMsg.endServiceTime   = (ushort)(srmMsg.endOfService.hour * 3600 + srmMsg.endOfService.minute * 60 + srmMsg.endOfService.second);
                if (srmMsg.startServiceTime == 0)
                {
                    srmMsg.startServiceTime = 2;
                }
                if (srmMsg.endServiceTime == 0)
                {
                    srmMsg.endServiceTime = preemptTimeToLive;
                }
                srmMsg.desiredTimeofService = (DateTime.Now).AddSeconds(srmMsg.startServiceTime);

                srmMsg.desiredEndofService = (DateTime.Now).AddSeconds(srmMsg.endServiceTime);
                srmMsg.status = SPaTSystem.ASN_r36.RequestStatus.Received;

                foreach (GlobalVars.PriorityStrategy strategy in PriorityStrategytable)
                {
                    string inlane = "," + srmMsg.request.inLane.ToString() + ",";
                    if ((srmMsg.vehicleClassType == strategy.vehicleClassType) && (srmMsg.vehicleClassLevel == strategy.vehicleClassLevel) && (strategy.inLanes.IndexOf(inlane) >= 0))
                    {
                        srmMsg.strategyNumber = strategy.strategyNumber;
                        srmMsg.preemptNumber = strategy.preemptNumber;
                        break;
                    }
                }
                newSRM.msgID = (clsSRM.DSRCmsgID_t)srmMsg.msgID;
                newSRM.msgCnt = (Int32)srmMsg.msgCnt;
                newSRM.preemptNumber = srmMsg.preemptNumber;
                newSRM.strategyNumber = srmMsg.strategyNumber;
                newSRM.vehicleClassType = srmMsg.vehicleClassType;
                newSRM.vehicleClassLevel = srmMsg.vehicleClassLevel;
                newSRM.desiredTimeofService = srmMsg.desiredTimeofService;
                newSRM.desiredEndofService = srmMsg.desiredEndofService;
                newSRM.status = (clsSRM.RequestStatus)srmMsg.status;
                newSRM.requestID = srmMsg.requestID;


                ActiveSRMList.Add(srmMsg);
                ActiveSRMs.Add(newSRM);
                string rvalue = PriorityRequestMessage(txtPRGActivity, srmMsg);
            }
            ProcessSRM();
            ProcessSSM();
        }

        private string GetBlockControl(TextBox txtActivityBox)
        {
            string retValue = string.Empty;
            string strData = "";
            string ascBlockData = "1.3.6.1.4.1.1206.4.2.1.11.2.0";
            string ascBlockGetControl = "1.3.6.1.4.1.1206.4.2.1.11.1.0";
            byte[] BytesRcvd;
            byte[] BytesSent;

            BeginTime = (DateTime.Now.Hour * 3600 + DateTime.Now.Minute * 60 + DateTime.Now.Second) * 1000 + DateTime.Now.Millisecond;
            LogTxtMsg(txtActivityBox, "\r\nGetBlockControl ..............");

            //SenderFunction = "GetBlockControl";
            NTCIPData.GotResponse = false;
            IntializePhasePropertyArrayValues();
            BeginTime = (DateTime.Now.Hour * 3600 + DateTime.Now.Minute * 60 + DateTime.Now.Second) * 1000 + DateTime.Now.Millisecond;

            //ascBlockGetControl.0 ============================================
            //AscPedDetectorBlock
            //00 ascBlockDataType (standard block)
            strData += (char)0;
            //02 ascBlockDataID (ped detector data)
            strData += (char)2;
            //02 ascBlockIndex1 (start with pedestrianDetectorNumber=2)
            strData += (char)2;
            //02 ascBlockQuantity1 (## of ped det=2)
            strData += (char)2;
            LogTxtMsg(txtPRGActivity, "StrData: " + strData);
            axaxNtcipIO1.AddBindingToPacket(ascBlockGetControl, strData, axNtcipIOControl.TxsetOIDType.otOctet);
            axaxNtcipIO1.SetOIDs();

            //RaiseResponseError(WaitForResponse(25));

            //ascBlockData.0 ==============================================
            axaxNtcipIO1.AddBindingToPacket(ascBlockData, "", axNtcipIOControl.TxsetOIDType.otNull);
            axaxNtcipIO1.GetOIDs();


            TimeSpan STS = new TimeSpan(DateTime.Now.Ticks);
            TimeSpan CurrTS = new TimeSpan();
            do
            {
                CurrTS = new TimeSpan(DateTime.Now.Ticks);

                if (NTCIPData.GotResponse == true)
                {
                    BytesRcvd = Encoding.ASCII.GetBytes(axaxNtcipIO1.InByteStream);
                    BytesSent = Encoding.ASCII.GetBytes(axaxNtcipIO1.OutBufStream);
                    LogTxtMsg(txtActivityBox, "\t BytesSent : " + BitConverter.ToString(BytesSent, 0));
                    LogTxtMsg(txtActivityBox, "\t BytesRcvd: " + BitConverter.ToString(BytesRcvd, 0));
                    EndTime = (DateTime.Now.Hour * 3600 + DateTime.Now.Minute * 60 + DateTime.Now.Second) * 1000 + DateTime.Now.Millisecond;
                    txtEnableSPATPush.Refresh();
                    string data = string.Empty;
                    for (int k = 0; k < BytesRcvd.Length; k++)
                    {
                        data += BytesRcvd[k].ToString() + "-";
                        //LogTxtMsg(txtEnableSPATPush, "\r\n" + BytesRcvd[k].ToString());
                    }
                    LogTxtMsg(txtActivityBox, "\t BytesVals: " + data);
                    LogTxtMsg(txtActivityBox, "\t Duration: " + (EndTime - BeginTime) + " milliseconds.");

                    LogTxtMsg(txtActivityBox, "");
                    //SenderFunction = string.Empty;
                    return retValue;
                }
                Application.DoEvents();
                //LogTxtMsg(txtEnableSPATPush, "\r\n In The Phase No Loop");

            } while ((CurrTS.TotalMilliseconds - STS.TotalMilliseconds) < (GlobalVars.TimeOutPeriod * 1000));
            return retValue;
        }

        private string PriorityRequestMessage(TextBox txtActivityBox, ASN_r36.SignalRequestMsg_t SRM)
        {
            string retValue = string.Empty;
            string strData = "";
            string ascBlockGetControl = "1.3.6.1.4.1.1206.4.2.1.11.1.0";
            byte[] BytesRcvd;
            byte[] BytesSent;
            LogTxtMsg(txtActivityBox, "\r\nSending Priority Request Message ..............");

            //SenderFunction = "PriorityRequestMessage";
            NTCIPData.GotResponse = false;
            IntializePhasePropertyArrayValues();
            BeginTime = (DateTime.Now.Hour * 3600 + DateTime.Now.Minute * 60 + DateTime.Now.Second) * 1000 + DateTime.Now.Millisecond;

            List<byte> prmData = new List<byte>();
            
            byte[] bRequestID;
            bRequestID = BitConverter.GetBytes(SRM.requestID);
            LogTxtMsg(txtPRGActivity, "RequestID: \t\t\t" + BitConverter.ToString(bRequestID));
            prmData.Add(bRequestID[0]);
            
            byte[] bVehicleID;
            bVehicleID = BitConverter.GetBytes(SRM.vehicleVIN.id);
            LogTxtMsg(txtPRGActivity, "VehicleID: \t\t\t" + BitConverter.ToString(bVehicleID));
            
            for (int i = 0; i< (17-bVehicleID.Length); i++)
            {
                prmData.Add(0);
            }


            foreach (byte b in BitConverter.GetBytes(SRM.vehicleVIN.id))
            {
                prmData.Add(b); 
            }

            byte[] bVehicleClassType;
            bVehicleClassType = BitConverter.GetBytes(SRM.vehicleClassType);
            LogTxtMsg(txtPRGActivity, "ClassType: \t\t\t" + BitConverter.ToString(bVehicleClassType));
            
            prmData.Add(bVehicleClassType[0]);

            byte[] bVehicleClassLevel;
            bVehicleClassLevel = BitConverter.GetBytes(SRM.vehicleClassLevel);
            LogTxtMsg(txtPRGActivity, "ClassLevel: \t\t\t" + BitConverter.ToString(bVehicleClassLevel));
            
            prmData.Add(bVehicleClassLevel[0]);

            byte[] bStrategyNumber;
            bStrategyNumber = BitConverter.GetBytes(SRM.strategyNumber);
            LogTxtMsg(txtPRGActivity, "StrategyNumber: \t\t\t" + BitConverter.ToString(bStrategyNumber));
            
            prmData.Add(bStrategyNumber[0]);

            byte[] bDesiredTimeofService;
            bDesiredTimeofService = BitConverter.GetBytes(SRM.startServiceTime);
            LogTxtMsg(txtPRGActivity, "StartTime: \t\t\t" + BitConverter.ToString(bDesiredTimeofService));
            
            foreach (byte b in BitConverter.GetBytes(SRM.startServiceTime))
            {
                prmData.Add(b); 
            }

            byte[] bDesiredEndofService;
            bDesiredEndofService = BitConverter.GetBytes(SRM.endServiceTime);
            LogTxtMsg(txtPRGActivity, "EndTime \t\t\t\t" + BitConverter.ToString(bDesiredEndofService));
            
            foreach (byte b in BitConverter.GetBytes(SRM.endServiceTime))
            {
                prmData.Add(b); 
            }


            for (int j= 0; j < prmData.Count; j++)
            {
                strData += (char)(prmData[j]);
            }
            
            txtActivityBox.Refresh();

            LogTxtMsg(txtPRGActivity, "StrData: " + strData);
            axaxNtcipIO1.AddBindingToPacket(ascBlockGetControl, strData, axNtcipIOControl.TxsetOIDType.otOctet);
            axaxNtcipIO1.SetOIDs();

            //RaiseResponseError(WaitForResponse(25));

            //ascBlockData.0 ==============================================
            /*LogTxtMsg(txtActivityBox, "\r\nSending ascBlockData ..............");
            string ascBlockData = "1.3.6.1.4.1.1206.4.2.1.11.2.0";
            axaxNtcipIO1.AddBindingToPacket(ascBlockData, "", axNtcipIOControl.TxsetOIDType.otNull);
            axaxNtcipIO1.GetOIDs();*/


            TimeSpan STS = new TimeSpan(DateTime.Now.Ticks);
            TimeSpan CurrTS = new TimeSpan();
            do
            {
                CurrTS = new TimeSpan(DateTime.Now.Ticks);

                if (NTCIPData.GotResponse == true)
                {
                    BytesRcvd = Encoding.ASCII.GetBytes(axaxNtcipIO1.InByteStream);
                    BytesSent = Encoding.ASCII.GetBytes(axaxNtcipIO1.OutBufStream);
                    LogTxtMsg(txtActivityBox, "\t BytesSent : " + BitConverter.ToString(BytesSent, 0));
                    LogTxtMsg(txtActivityBox, "\t BytesRcvd: " + BitConverter.ToString(BytesRcvd, 0));
                    EndTime = (DateTime.Now.Hour * 3600 + DateTime.Now.Minute * 60 + DateTime.Now.Second) * 1000 + DateTime.Now.Millisecond;
                    txtEnableSPATPush.Refresh();
                    string data = string.Empty;
                    for (int k = 0; k < BytesRcvd.Length; k++)
                    {
                        data += BytesRcvd[k].ToString() + "-";
                        //LogTxtMsg(txtEnableSPATPush, "\r\n" + BytesRcvd[k].ToString());
                    }
                    LogTxtMsg(txtActivityBox, "\t BytesVals: " + data);
                    LogTxtMsg(txtActivityBox, "\t Duration: " + (EndTime - BeginTime) + " milliseconds.");

                    LogTxtMsg(txtActivityBox, "");
                    //SenderFunction = string.Empty;
                    return retValue;
                }
                Application.DoEvents();
                //LogTxtMsg(txtEnableSPATPush, "\r\n In The Phase No Loop");

            } while ((CurrTS.TotalMilliseconds - STS.TotalMilliseconds) < (GlobalVars.TimeOutPeriod * 1000));
            return retValue;
        }

        private string PriorityUpdateMessage(TextBox txtActivityBox)
        {
            string retValue = string.Empty;
            string strData = "";
            string ascBlockData = "1.3.6.1.4.1.1206.4.2.1.11.2.0";
            string ascBlockGetControl = "1.3.6.1.4.1.1206.4.2.1.11.1.0";
            byte[] BytesRcvd;
            byte[] BytesSent;

            BeginTime = (DateTime.Now.Hour * 3600 + DateTime.Now.Minute * 60 + DateTime.Now.Second) * 1000 + DateTime.Now.Millisecond;
            LogTxtMsg(txtActivityBox, "\r\nGetBlockControl ..............");

            //SenderFunction = "GetBlockControl";
            NTCIPData.GotResponse = false;
            IntializePhasePropertyArrayValues();
            BeginTime = (DateTime.Now.Hour * 3600 + DateTime.Now.Minute * 60 + DateTime.Now.Second) * 1000 + DateTime.Now.Millisecond;

            //ascBlockGetControl.0 ============================================
            //AscPedDetectorBlock
            //00 ascBlockDataType (standard block)
            strData += (char)0;
            //02 ascBlockDataID (ped detector data)
            strData += (char)2;
            //02 ascBlockIndex1 (start with pedestrianDetectorNumber=2)
            strData += (char)2;
            //02 ascBlockQuantity1 (## of ped det=2)
            strData += (char)2;
            LogTxtMsg(txtPRGActivity, "StrData: " + strData);
            axaxNtcipIO1.AddBindingToPacket(ascBlockGetControl, strData, axNtcipIOControl.TxsetOIDType.otOctet);
            axaxNtcipIO1.SetOIDs();

            //RaiseResponseError(WaitForResponse(25));

            //ascBlockData.0 ==============================================
            axaxNtcipIO1.AddBindingToPacket(ascBlockData, "", axNtcipIOControl.TxsetOIDType.otNull);
            axaxNtcipIO1.GetOIDs();


            TimeSpan STS = new TimeSpan(DateTime.Now.Ticks);
            TimeSpan CurrTS = new TimeSpan();
            do
            {
                CurrTS = new TimeSpan(DateTime.Now.Ticks);

                if (NTCIPData.GotResponse == true)
                {
                    BytesRcvd = Encoding.ASCII.GetBytes(axaxNtcipIO1.InByteStream);
                    BytesSent = Encoding.ASCII.GetBytes(axaxNtcipIO1.OutBufStream);
                    LogTxtMsg(txtActivityBox, "\t BytesSent : " + BitConverter.ToString(BytesSent, 0));
                    LogTxtMsg(txtActivityBox, "\t BytesRcvd: " + BitConverter.ToString(BytesRcvd, 0));
                    EndTime = (DateTime.Now.Hour * 3600 + DateTime.Now.Minute * 60 + DateTime.Now.Second) * 1000 + DateTime.Now.Millisecond;
                    txtEnableSPATPush.Refresh();
                    string data = string.Empty;
                    for (int k = 0; k < BytesRcvd.Length; k++)
                    {
                        data += BytesRcvd[k].ToString() + "-";
                        //LogTxtMsg(txtEnableSPATPush, "\r\n" + BytesRcvd[k].ToString());
                    }
                    LogTxtMsg(txtActivityBox, "\t BytesVals: " + data);
                    LogTxtMsg(txtActivityBox, "\t Duration: " + (EndTime - BeginTime) + " milliseconds.");

                    LogTxtMsg(txtActivityBox, "");
                    //SenderFunction = string.Empty;
                    return retValue;
                }
                Application.DoEvents();
                //LogTxtMsg(txtEnableSPATPush, "\r\n In The Phase No Loop");

            } while ((CurrTS.TotalMilliseconds - STS.TotalMilliseconds) < (GlobalVars.TimeOutPeriod * 1000));
            return retValue;
        }

        private string PriorityClearMessage(TextBox txtActivityBox)
        {
            string retValue = string.Empty;
            string strData = "";
            string ascBlockData = "1.3.6.1.4.1.1206.4.2.1.11.2.0";
            string ascBlockGetControl = "1.3.6.1.4.1.1206.4.2.1.11.1.0";
            byte[] BytesRcvd;
            byte[] BytesSent;

            BeginTime = (DateTime.Now.Hour * 3600 + DateTime.Now.Minute * 60 + DateTime.Now.Second) * 1000 + DateTime.Now.Millisecond;
            LogTxtMsg(txtActivityBox, "\r\nGetBlockControl ..............");

            //SenderFunction = "GetBlockControl";
            NTCIPData.GotResponse = false;
            IntializePhasePropertyArrayValues();
            BeginTime = (DateTime.Now.Hour * 3600 + DateTime.Now.Minute * 60 + DateTime.Now.Second) * 1000 + DateTime.Now.Millisecond;

            //ascBlockGetControl.0 ============================================
            //AscPedDetectorBlock
            //00 ascBlockDataType (standard block)
            strData += (char)0;
            //02 ascBlockDataID (ped detector data)
            strData += (char)2;
            //02 ascBlockIndex1 (start with pedestrianDetectorNumber=2)
            strData += (char)2;
            //02 ascBlockQuantity1 (## of ped det=2)
            strData += (char)2;
            LogTxtMsg(txtPRGActivity, "StrData: " + strData);
            axaxNtcipIO1.AddBindingToPacket(ascBlockGetControl, strData, axNtcipIOControl.TxsetOIDType.otOctet);
            axaxNtcipIO1.SetOIDs();

            //RaiseResponseError(WaitForResponse(25));

            //ascBlockData.0 ==============================================
            axaxNtcipIO1.AddBindingToPacket(ascBlockData, "", axNtcipIOControl.TxsetOIDType.otNull);
            axaxNtcipIO1.GetOIDs();


            TimeSpan STS = new TimeSpan(DateTime.Now.Ticks);
            TimeSpan CurrTS = new TimeSpan();
            do
            {
                CurrTS = new TimeSpan(DateTime.Now.Ticks);

                if (NTCIPData.GotResponse == true)
                {
                    BytesRcvd = Encoding.ASCII.GetBytes(axaxNtcipIO1.InByteStream);
                    BytesSent = Encoding.ASCII.GetBytes(axaxNtcipIO1.OutBufStream);
                    LogTxtMsg(txtActivityBox, "\t BytesSent : " + BitConverter.ToString(BytesSent, 0));
                    LogTxtMsg(txtActivityBox, "\t BytesRcvd: " + BitConverter.ToString(BytesRcvd, 0));
                    EndTime = (DateTime.Now.Hour * 3600 + DateTime.Now.Minute * 60 + DateTime.Now.Second) * 1000 + DateTime.Now.Millisecond;
                    txtEnableSPATPush.Refresh();
                    string data = string.Empty;
                    for (int k = 0; k < BytesRcvd.Length; k++)
                    {
                        data += BytesRcvd[k].ToString() + "-";
                        //LogTxtMsg(txtEnableSPATPush, "\r\n" + BytesRcvd[k].ToString());
                    }
                    LogTxtMsg(txtActivityBox, "\t BytesVals: " + data);
                    LogTxtMsg(txtActivityBox, "\t Duration: " + (EndTime - BeginTime) + " milliseconds.");

                    LogTxtMsg(txtActivityBox, "");
                    //SenderFunction = string.Empty;
                    return retValue;
                }
                Application.DoEvents();
                //LogTxtMsg(txtEnableSPATPush, "\r\n In The Phase No Loop");

            } while ((CurrTS.TotalMilliseconds - STS.TotalMilliseconds) < (GlobalVars.TimeOutPeriod * 1000));
            return retValue;
        }

        /*private void spGPS_DataReceived(object sender, SerialDataReceivedEventArgs e)
        {
            
            txtBuffer =  txtBuffer + spGPS.BytesToRead +  "\t" + spGPS.ReadExisting();
            //LogTxtMsg(txtGPSActivity, txtBuffer);
            //LogTxtMsg(textBox1, txtBuffer);
            //textBox1.Text = textBox1.Text + "\r\n" + txtBuffer;
            //spGPS.DiscardInBuffer();
        }*/

        private void chkEnableDataLogging_CheckedChanged_1(object sender, EventArgs e)
        {
            string strRetValue = string.Empty;
            string FileName = string.Empty;

            if (chkEnableDataLogging.Checked == false)
            {
                try
                {
                    dailyLogFile.Close();
                    spatMsgFile.Close();
                }
                catch (Exception ex)
                {
                    LogTxtMsg(txtActivityLog, "Data log files are already closed." + "\r\n" + ex.Message);
                }
            }
            else
            {
                //Check for remaining disk space and terminate logging if less than 10 GB left
                long FreeSpace = 0;
                DriveInfo driveInfo = new DriveInfo(@"C:");
                if (driveInfo.IsReady == true)
                {
                    FreeSpace = driveInfo.AvailableFreeSpace;
                    if (FreeSpace < GlobalVars.DataLoggingDispSpaceLimit)
                    {
                        chkEnableDataLogging.Checked = false;
                        MessageBox.Show("Data logging Can not be started because remaining disk space is below " + (GlobalVars.DataLoggingDispSpaceLimit/GlobalVars.OneGB) + " GB.\r\n" +
                                                  "Delete log files to allow data logging again.");
                        LogTxtMsg(txtActivityLog, "Data logging Can not be started because remaining disk space is below " + (GlobalVars.DataLoggingDispSpaceLimit / GlobalVars.OneGB) + " GB.\r\n" +
                                                  "Delete log files to allow data logging again.");
                    }

                    else
                    {
                        //open a new daily logfile
                        strRetValue = OpenDailyLogFile(GlobalVars.enum_log_file_type.DailyLog, ref FileName);
                        LogTxtMsg(txtActivityLog, "\r\n--Opening a new daily logfile: " + FileName);
                        if (strRetValue.Length > 0)
                        {
                            strRetValue = "\r\n--Opening a new daily logfile ERROR. Daily logFile name: " + FileName +
                                            "\r\n\t" + strRetValue;
                            LogTxtMsg(txtActivityLog, strRetValue);
                            chkEnableDataLogging.Checked = false;
                            return;
                        }

                        //open a new daily SPAT Msg logfile
                        strRetValue = OpenDailyLogFile(GlobalVars.enum_log_file_type.SPATBroadcastMsg, ref FileName);
                        LogTxtMsg(txtActivityLog, "\r\n--Opening a new daily SPAT Msg logfile: " + FileName);
                        if (strRetValue.Length > 0)
                        {
                            strRetValue = "\r\n--Opening a new daily SPAT Msg logfile ERROR. Daily SPAT Msg logfile name: " + FileName +
                                            "\r\n\t" + strRetValue;
                            LogTxtMsg(txtActivityLog, strRetValue);
                            chkEnableDataLogging.Checked = false;
                            return;
                        }
                    }
                }
            }
        }

        private void btnHideTSCTime_Click(object sender, EventArgs e)
        {
            if (btnHideTSCTime.Text.ToUpper() == "Hide TSC Time".ToUpper())
            {
                lblTSCTime.Visible = false;
                txtTSCMsgTime.Visible = false;
                txtTSCMsgInterval.Visible = false;
                lblTSCInterval.Visible = false;
                lblTSCMsgNo.Visible = false;
                txtTSCMsgNo.Visible = false;
                lblTSCMsec.Visible = false;
                txtTSCMSec.Visible = false;
                btnHideTSCTime.Text = "Show TSC Time";
            }
            else if (btnHideTSCTime.Text.ToUpper() == "Show TSC Time".ToUpper())
            {
                lblTSCTime.Visible = true;
                txtTSCMsgTime.Visible = true;
                txtTSCMsgInterval.Visible = true;
                lblTSCInterval.Visible = true;
                lblTSCMsgNo.Visible = true;
                txtTSCMsgNo.Visible = true;
                lblTSCMsec.Visible = true;
                txtTSCMSec.Visible = true;
                btnHideTSCTime.Text = "Hide TSC Time";
            }
        }

        private void btnHideSysTime_Click(object sender, EventArgs e)
        {
            if (btnHideSysTime.Text.ToUpper() == "Hide System Time".ToUpper())
            {
                lblSysTime.Visible = false;
                txtSysTime.Visible = false;
                txtSPaTSysInterval.Visible = false;
                lblSysInterval.Visible = false;
                lblSpatTime.Visible = false;
                txtSpatMsgGenerationTime.Visible = false;
                lblSysMSec.Visible = false;
                txtSysMsec.Visible = false;
                btnHideSysTime.Text = "Show System Time";
            }
            else if (btnHideSysTime.Text.ToUpper() == "Show System Time".ToUpper())
            {
                lblSysTime.Visible = true;
                txtSysTime.Visible = true;
                txtSPaTSysInterval.Visible = true;
                lblSysInterval.Visible = true;
                lblSpatTime.Visible = true;
                txtSpatMsgGenerationTime.Visible = true;
                lblSysMSec.Visible = true;
                txtSysMsec.Visible = true;
                btnHideSysTime.Text = "Hide System Time";
            }
        }

        private void folderBrowserDialog1_HelpRequest(object sender, EventArgs e)
        {

        }

        private void btnGPSUpdateFrequency_Click(object sender, EventArgs e)
        {
            if (txtGPSUpdateFrequency.Text.Trim().Length > 0)
            {
                try
                {
                    GlobalVars.GPSUpdateFrequency = Convert.ToInt32(txtGPSUpdateFrequency.Text);
                }
                catch (Exception ex)
                {
                    return;
                }
            }
        }

        private void btnSelectPTLMFile_Click(object sender, EventArgs e)
        {
            try
            {
                openFileDialog1.InitialDirectory = Application.StartupPath + "\\config";
                DialogResult result = openFileDialog1.ShowDialog();
                if (result == DialogResult.OK)
                {
                    string ptlmFilepath = openFileDialog1.FileName;
                    string ptlmFile = System.IO.Path.GetFileName(ptlmFilepath);
                    GlobalVars.PTLMMappingFile = ptlmFile;
                    txtPTLMFile.Text = ptlmFile;
                }
            }
            catch (Exception ex)
            {
                return;
            }
        }

        /*private void btnPedSimulator_Click(object sender, EventArgs e)
        {
            if (btnPedSimulator.Text.Trim().ToUpper() == "Show Ped Call/Detect Tester".ToUpper())
            {
                btnPedSimulator.Text = "Hide Ped Call/Detect Tester";
                grpPedSimulator.Visible = true;
                GlobalVars.PedSimulatorEnabled = true;
                ClearPedCalssandDetections();
            }
            else if (btnPedSimulator.Text.Trim().ToUpper() == "Hide Ped Call/Detect Tester".ToUpper())
            {
                btnPedSimulator.Text = "Show Ped Call/Detect Tester";
                grpPedSimulator.Visible = false;
                GlobalVars.PedSimulatorEnabled = false;
            }
        }*/
        private void ClearPedCalssandDetections()
        {
            chkPedCall1.Checked = false;
            chkPedCall2.Checked = false;
            chkPedCall3.Checked = false;
            chkPedCall4.Checked = false;
            chkPedCall5.Checked = false;
            chkPedCall6.Checked = false;
            chkPedCall7.Checked = false;
            chkPedCall8.Checked = false;
            chkPedCall9.Checked = false;
            chkPedCall10.Checked = false;
            chkPedCall11.Checked = false;
            chkPedCall12.Checked = false;
            chkPedCall13.Checked = false;
            chkPedCall14.Checked = false;
            chkPedCall15.Checked = false;
            chkPedCall16.Checked = false;

            chkPedDetect1.Checked = false;
            chkPedDetect2.Checked = false;
            chkPedDetect3.Checked = false;
            chkPedDetect4.Checked = false;
            chkPedDetect5.Checked = false;
            chkPedDetect6.Checked = false;
            chkPedDetect7.Checked = false;
            chkPedDetect8.Checked = false;
            chkPedDetect9.Checked = false;
            chkPedDetect10.Checked = false;
            chkPedDetect11.Checked = false;
            chkPedDetect12.Checked = false;
            chkPedDetect13.Checked = false;
            chkPedDetect14.Checked = false;
            chkPedDetect15.Checked = false;
            chkPedDetect16.Checked = false;
        }

        private void chkPedDetectPhase1_CheckedChanged(object sender, EventArgs e)
        {
            GlobalVars.TSCPed[1].DetectionAvailable = chkPedDetectPhase1.Checked;
        }

        private void chkPedDetectPhase2_CheckedChanged(object sender, EventArgs e)
        {
            GlobalVars.TSCPed[2].DetectionAvailable = chkPedDetectPhase2.Checked;
        }

        private void chkPedDetectPhase3_CheckedChanged(object sender, EventArgs e)
        {
            GlobalVars.TSCPed[3].DetectionAvailable = chkPedDetectPhase3.Checked;
        }

        private void chkPedDetectPhase4_CheckedChanged(object sender, EventArgs e)
        {
            GlobalVars.TSCPed[4].DetectionAvailable = chkPedDetectPhase4.Checked;
        }

        private void chkPedDetectPhase5_CheckedChanged(object sender, EventArgs e)
        {
            GlobalVars.TSCPed[5].DetectionAvailable = chkPedDetectPhase5.Checked;
        }

        private void chkPedDetectPhase6_CheckedChanged(object sender, EventArgs e)
        {
            GlobalVars.TSCPed[6].DetectionAvailable = chkPedDetectPhase6.Checked;
        }

        private void chkPedDetectPhase7_CheckedChanged(object sender, EventArgs e)
        {
            GlobalVars.TSCPed[7].DetectionAvailable = chkPedDetectPhase7.Checked;
        }

        private void chkPedDetectPhase8_CheckedChanged(object sender, EventArgs e)
        {
            GlobalVars.TSCPed[8].DetectionAvailable = chkPedDetectPhase8.Checked;
        }

        private void chkPedDetectPhase9_CheckedChanged(object sender, EventArgs e)
        {
            GlobalVars.TSCPed[9].DetectionAvailable = chkPedDetectPhase9.Checked;
        }

        private void chkPedDetectPhase10_CheckedChanged(object sender, EventArgs e)
        {
            GlobalVars.TSCPed[10].DetectionAvailable = chkPedDetectPhase10.Checked;
        }

        private void chkPedDetectPhase11_CheckedChanged(object sender, EventArgs e)
        {
            GlobalVars.TSCPed[11].DetectionAvailable = chkPedDetectPhase11.Checked;
        }

        private void chkPedDetectPhase12_CheckedChanged(object sender, EventArgs e)
        {
            GlobalVars.TSCPed[12].DetectionAvailable = chkPedDetectPhase12.Checked;
        }

        private void chkPedDetectPhase13_CheckedChanged(object sender, EventArgs e)
        {
            GlobalVars.TSCPed[13].DetectionAvailable = chkPedDetectPhase13.Checked;
        }

        private void chkPedDetectPhase14_CheckedChanged(object sender, EventArgs e)
        {
            GlobalVars.TSCPed[14].DetectionAvailable = chkPedDetectPhase14.Checked;
        }

        private void chkPedDetectPhase15_CheckedChanged(object sender, EventArgs e)
        {
            GlobalVars.TSCPed[15].DetectionAvailable = chkPedDetectPhase15.Checked;
        }

        private void chkPedDetectPhase16_CheckedChanged(object sender, EventArgs e)
        {
            GlobalVars.TSCPed[16].DetectionAvailable = chkPedDetectPhase16.Checked;
        }

        private void btnQuitSPaTSystem_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btnExitSPATSystem_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Int64 tmpDiskSpace = 0;
            if (txtDiskSpace.Text.Trim().Length > 0)
            {
                tmpDiskSpace = Convert.ToInt64(txtDiskSpace.Text.Trim());
                if (tmpDiskSpace > 5)
                {
                    try
                    {
                        GlobalVars.DataLoggingDispSpaceLimit = tmpDiskSpace * (1024) * (1024) * (1024);
                    }
                    catch (Exception ex)
                    {
                        LogTxtMsg(txtActivityLog, ex.Message);
                    }
                }
                else
                {
                    MessageBox.Show("The minimum disk space for allowing data logging can not be less than 5 GB." + "\r\n" +
                                    "Please re-enter a value > 5 GB");
                }
            }
        }

        private void btnPedSimulator_Click_1(object sender, EventArgs e)
        {
            if (btnPedSimulator.Text.Trim().ToUpper() == "Show Ped Call/Detect Tester".ToUpper())
            {
                btnPedSimulator.Text = "Hide Ped Call/Detect Tester";
                grpPedSimulator.Visible = true;
                GlobalVars.PedSimulatorEnabled = true;
                ClearPedCalssandDetections();
            }
            else if (btnPedSimulator.Text.Trim().ToUpper() == "Hide Ped Call/Detect Tester".ToUpper())
            {
                btnPedSimulator.Text = "Show Ped Call/Detect Tester";
                grpPedSimulator.Visible = false;
                GlobalVars.PedSimulatorEnabled = false;
            }
        }

        private void chkEnableSpatMessagePush_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void chkSPaTMsg_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void chkTSCData_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void chkLaneMvmnt_CheckedChanged(object sender, EventArgs e)
        {

        }
    }
}

/*if (chkEnableDataLogging.Checked == true)
{
    //open a new daily logfile
    strRetValue = OpenDailyLogFile(GlobalVars.enum_log_file_type.DailyLog, ref FileName);
    LogTxtMsg(txtActivityLog, "\r\n--Opening a new daily logfile: " + FileName);
    if (strRetValue.Length > 0)
    {
        strRetValue = "\r\n--Opening a new daily logfile ERROR. Daily logFile name: " + FileName +
                      "\r\n\t" + strRetValue;
        LogTxtMsg(txtActivityLog, strRetValue +
                                  "\r\n\r\n--Please capture this message and send to Hassan Charara at the following e-mail address:" +
                                  "\r\n\th-charara@tamu.edu");
        MessageBox.Show(strRetValue +
                                  "\r\n\r\n--Please capture this message and send to Hassan Charara at the following e-mail address:" +
                                  "\r\n\th-charara@tamu.edu");
        return;
    }

    //open a new daily SPAT Msg logfile
    strRetValue = OpenDailyLogFile(GlobalVars.enum_log_file_type.SPATBroadcastMsg, ref FileName);
    LogTxtMsg(txtActivityLog, "\r\n--Opening a new daily SPAT Msg logfile: " + FileName);
    if (strRetValue.Length > 0)
    {
        strRetValue = "\r\n--Opening a new daily SPAT Msg logfile ERROR. Daily SPAT Msg logfile name: " + FileName +
                      "\r\n\t" + strRetValue;
        LogTxtMsg(txtActivityLog, strRetValue +
                                  "\r\n\r\n--Please capture this message and send to Hassan Charara at the following e-mail address:" +
                                  "\r\n\th-charara@tamu.edu");
        MessageBox.Show(strRetValue +
                                  "\r\n\r\n--Please capture this message and send to Hassan Charara at the following e-mail address:" +
                                  "\r\n\th-charara@tamu.edu");
        return;
    }


    //open a new daily TSC activity logfile
    strRetValue = OpenDailyLogFile(GlobalVars.enum_log_file_type.TSCSPATData, ref FileName);
    LogTxtMsg(txtActivityLog, "\r\n--Opening a new daily TSC activity logfile: " + FileName);
    if (strRetValue.Length > 0)
    {
        strRetValue = "\r\n--Opening a new daily TSC activity logfile ERROR. Daily TSC SPAT logfile name: " + FileName +
                      "\r\n\t" + strRetValue;
        LogTxtMsg(txtActivityLog, strRetValue +
                                  "\r\n\r\n--Please capture this message and send to Hassan Charara at the following e-mail address:" +
                                  "\r\n\th-charara@tamu.edu");
        MessageBox.Show(strRetValue +
                                  "\r\n\r\n--Please capture this message and send to Hassan Charara at the following e-mail address:" +
                                  "\r\n\th-charara@tamu.edu");
        return;
    }
}*/

//btnHaltSPATSystem.Text = "Stop SPAT System";
//tmrUDPClient.Enabled = true;
//EnableSpatMessagePush("1.3.6.1.4.1.1206.3.5.2.9.44.1.0", "2");
//GlobalVars.SPATSystemRunning = true;
/*      public string DetectGPSSerialPort(string CommPort)
      {
          int num;
          string retValue = string.Empty;
          string error = string.Empty;
          bool FoundGPRMCSentence = false;

          string[] ports = SerialPort.GetPortNames().OrderBy(a => a.Length > 3 && int.TryParse(a.Substring(3), out num) ? num : 0).ToArray();

          if (gpsPort.IsOpen == true)
          {
              try
              {
                  gpsPort.Close();
                  Thread.Sleep(300);
              }
              catch (UnauthorizedAccessException unauthEx)
              {
                  error = unauthEx.Message;
              }
              catch (IOException ioEx)
              {
                  error = ioEx.Message;
              }
              catch (ArgumentException ArgEx)
              {
                  error = ArgEx.Message;
              }
          }

          if (error.Length > 0)
          {
              retValue = "\r\nError in verifying the GPS device connectivity. The GPS port is laready in use by some other device." +
                         "\r\n\t" + error;
              return retValue;
          }


          gpsPort.DataBits = int.Parse("8");
          gpsPort.Parity = Parity.None;
          gpsPort.StopBits = StopBits.One;
          gpsPort.Handshake = Handshake.None;

          foreach (string port in ports)
          {
              gpsPort.PortName = port;
              for (int i = 1; i <= 8; i++)
              {
                  switch (i)
                  {
                      case 1:
                          gpsPort.BaudRate = 1200;
                          break;
                      case 2:
                          gpsPort.BaudRate = 2400;
                          break;
                      case 3:
                          gpsPort.BaudRate = 4800;
                          break;
                      case 4:
                          gpsPort.BaudRate = 9600;
                          break;
                      case 5:
                          gpsPort.BaudRate = 19200;
                          break;
                      case 6:
                          gpsPort.BaudRate = 38400;
                          break;
                      case 7:
                          gpsPort.BaudRate = 57600;
                          break;
                      case 8:
                          gpsPort.BaudRate = 115200;
                          break;
                  }

                  if (gpsPort.IsOpen == false)
                  {
                      try
                      {
                          // Open the port
                          //Thread.Sleep(300);
                          gpsPort.Open();
                      }
                      catch (UnauthorizedAccessException unauthEx)
                      {
                          error = unauthEx.Message;
                      }
                      catch (IOException ioEx)
                      {
                          error = ioEx.Message;
                      }
                      catch (ArgumentException ArgEx)
                      {
                          error = ArgEx.Message;
                      }
                  }

                  if (error.Length > 0)
                  {
                      retValue = "\r\nError in opening the GPS device serial port: " + gpsPort.PortName +
                                 "\tSettings: " + gpsPort.Parity.ToString() + "," + gpsPort.DataBits.ToString() + "," + gpsPort.StopBits.ToString() + "," + gpsPort.BaudRate.ToString() + "\tHandShake: " + gpsPort.Handshake.ToString() +
                                 "\r\n\t" + error;
                      return retValue;
                  }
                  else
                  {
                      //// Show the initial pin states
                      //UpdatePinState();
                      //chkDTR.Checked = comport.DtrEnable;
                      //chkRTS.Checked = comport.RtsEnable;

                      for (int j = 1; j <= 10; j++)
                      {
                          retValue = ReadSerialPort(ref gpsPort);
                          if ((retValue.Length == 0) && (m_UTCTime.Length > 0) && (m_Date.Length > 0))
                          {
                              //txtLog.Clear();
                              retValue = "GPS device is prsent on CommPort: " + gpsPort.PortName + " and communicating properly.";
                              return retValue;
                          }
                          else if ((retValue.Length == 0) && (m_UTCTime.Length == 0) && (m_Date.Length == 0))
                          {
                              Thread.Sleep(100);
                          }
                      }
                      if (!FoundGPRMCSentence)
                      {
                          gpsPort.Close();
                          Thread.Sleep(200);
                      }
                  }
                  //if (FoundGPSDevice)
                  //{
                  //    break;
                  //}
              }
              //if (FoundGPSDevice)
              //{
              //    break;
              //}
          }
          return retValue;
      }
*/

/*
        public string WriteSPATConfigFile()
        {
            string ret = string.Empty;
            XmlTextWriter XmlOut = null;
            string ConfigFilePath = Application.StartupPath + "\\Config\\SPaTConfigFile.xml";
            try
            {
                XmlOut = new XmlTextWriter(ConfigFilePath, Encoding.UTF8);
                XmlOut.Formatting = Formatting.Indented;

                XmlOut.WriteStartDocument();

                XmlOut.WriteStartElement("SPATConfigurationInformation");
                //XmlOut.WriteElementString("RSEIPV4Address", txtRSEIPV4Address.Text.Trim());
                //XmlOut.WriteElementString("RSEIPV4Port", txtRSEIPV4Port.Text.Trim());
                XmlOut.WriteElementString("RSEIPV6Address", txtRSEIPV6Address.Text.Trim());
                //XmlOut.WriteElementString("RSEIPV6Port", txtRSEIPV6Port.Text.Trim());
                XmlOut.WriteElementString("SPATSystemIPV4Address", txtSPATSystemIPV4Address.Text.Trim());
                XmlOut.WriteElementString("SPATSystemSPATPort", txtSPATSystemSPATPort.Text.Trim());
                XmlOut.WriteElementString("SPATSystemSRMPort", txtSPATSystemSPATPort.Text.Trim());
                XmlOut.WriteElementString("SPATSystemSSMPort", txtSPATSystemSPATPort.Text.Trim());
                XmlOut.WriteElementString("SPATSystemIPV6Address", txtSPATSystemIPV6Address.Text.Trim());
                //XmlOut.WriteElementString("SPATSystemIPV6Port", txtSPATSystemIPV6Port.Text.Trim());
                XmlOut.WriteElementString("TSCIPV4Address", txtTSCIPV4Address.Text.Trim());
                XmlOut.WriteElementString("TSCNTCIPPort", txtTSCNTCIPPort.Text.Trim());
                XmlOut.WriteElementString("LogDataDir", txtSPATDailyLogFolder.Text.Trim());
                XmlOut.WriteElementString("PTLMMappingFile", txtPTLMFile.Text.Trim());
                XmlOut.WriteElementString("IntersectionName", txtIntersectionName.Text.Trim());
                XmlOut.WriteElementString("IntersectionID", txtIntersectionID.Text.Trim());
                XmlOut.WriteElementString("IntersectionCity", txtCity.Text.Trim());
                XmlOut.WriteElementString("IntersectionState", txtState.Text.Trim());
                XmlOut.WriteElementString("GPSFrequency", GPSDevice.GPSFrequency.ToString());
                //XmlOut.WriteElementString("GPSPort", spGPS.PortName);
                XmlOut.WriteStartElement("GPSPort", spGPS.PortName);
                XmlOut.WriteAttributeString("baudrate", spGPS.BaudRate.ToString());
                XmlOut.WriteAttributeString("parity", spGPS.Parity.ToString());
                XmlOut.WriteAttributeString("stopbits", spGPS.StopBits.ToString());
                XmlOut.WriteAttributeString("databits", spGPS.DataBits.ToString());
                XmlOut.WriteAttributeString("handshake", spGPS.Handshake.ToString());
                XmlOut.WriteEndElement();
                if (PriorityStrategytable.Count > 0)
                {
                    
                    XmlOut.WriteStartElement("PriorityStrategies");
                    //XElement XmlRecord = new XElement("PriorityStrategies");
                    for (int i = 0; i < PriorityStrategytable.Count; i++)
                    {
                        XmlOut.WriteStartElement("Strategy", PriorityStrategytable[i].strategyNumber.ToString());
                        //XElement xmlStrategy = new XElement("Strategy",  PriorityStrategytable[i].strategyNumber.ToString());
                        XmlOut.WriteAttributeString("inlanes", PriorityStrategytable[i].inLanes);
                        XmlOut.WriteAttributeString("vclasstype", PriorityStrategytable[i].vehicleClassLevel.ToString());
                        XmlOut.WriteAttributeString("vclasslevel", PriorityStrategytable[i].vehicleClassLevel.ToString());
                        XmlOut.WriteAttributeString("preempt", PriorityStrategytable[i].preemptNumber.ToString());
                        XmlOut.WriteEndElement();
                        //XmlRecord.Add(new XElement("to_time", q.EndTime.ToString("hh:mm tt")));
                        //XmlRecord.Add(new XElement("expect_queue", q.QueLength.ToString()));
                        //XmlRecord.Add(new XElement("expect_delay", q.Delay.ToString()));
                        //q = qdat.QdatOutputList(AnaCase.Worse)[i];
                        //XmlRecord.Add(new XElement("worse_queue", q.QueLength.ToString()));
                        //XmlRecord.Add(new XElement("worse_delay", q.Delay.ToString()));
                        //XmlQdat.Add(XmlRecord);
                        //XmlRecord.Add(new XElement("Strategy",  PriorityStrategytable[i].strategyNumber.ToString()));
                    }
                    XmlOut.WriteEndElement();                   
                }

                XmlOut.WriteEndElement();
                XmlOut.Flush();
            }
            catch (Exception ex)
            {
                return ("Saving SPAT Parameters Error: " + ex.Message);
            }
            finally
            {
                if (XmlOut != null)
                    XmlOut.Close();
            }
            return string.Empty;
        }
        
       private void btnSaveSPATConfiguration_Click(object sender, EventArgs e)
        {
            string retValue = WriteSPATConfigFile();
            if (retValue.Length > 0)
            {
                MessageBox.Show("Error in saving the SPAT Configuration parameters. " + "\r\n\t" + retValue);
                return;
            }
            MessageBox.Show("Please click the EXIT button to terminate the SPAT System and restart the system again for the parameters changed to take effect.");
            //this.Close();
        }*/
