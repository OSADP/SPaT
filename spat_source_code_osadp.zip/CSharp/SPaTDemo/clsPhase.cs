﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace SPaTSystem
{
    class clsPhase
    {
        //Properties
        public int Number;
        public UInt16 PedClear;
        public UInt16 YellowChange;
        public int RedClear;
        public int RedRevert;

        //Status
        //public bool VehPhase;
        public bool Red;
        public bool Yellow;
        public bool Green;

        public bool PedDontWalk;
        public bool PedWalk;
        public bool PedClearState;

        public bool OvlpRed;
        public bool OvlpYellow;
        public bool OvlpGreen;

        public byte Status;
        public byte PedStatus;
        public byte OvlpStatus;

        public bool PhsFlashing;
        public bool OvlpFlashing;

        //SPaT Data
        public UInt16 VMinTime;
        public UInt16 VMaxTime;

        public UInt16 PedMinTime;
        public UInt16 PedMaxTime;

        public UInt16 OvlpMinTime;
        public UInt16 OvlpMaxTime;
    }
}
