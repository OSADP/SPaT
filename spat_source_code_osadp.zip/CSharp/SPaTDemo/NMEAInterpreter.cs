﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Globalization;
using System.IO;
using System.IO.Ports;
using System.Threading;
using System.Runtime.InteropServices;
using System.ComponentModel;
using System.Xml;
using System.Xml.Linq;

namespace SPaTSystem
{
    public class NMEAInterpreter
    {
        struct SerialPortInfo
        {
            public string name;
            public int baudrate;
            public int databits;
            public string parity;
            public string stopbits;
            public string handshake;
        }

        public struct SYSTEMTIME
        {
            public ushort wYear;
            public ushort wMonth;
            public ushort wDayOfWeek;
            public ushort wDay;
            public ushort wHour;
            public ushort wMinute;
            public ushort wSecond;
            public ushort wMilliseconds;

            /// <summary>
            /// Convert form System.DateTime
            /// </summary>
            /// <param name="time"></param>
            public void FromDateTime(DateTime time)
            {
                wYear = (ushort)time.Year;
                wMonth = (ushort)time.Month;
                wDayOfWeek = (ushort)time.DayOfWeek;
                wDay = (ushort)time.Day;
                wHour = (ushort)time.Hour;
                wMinute = (ushort)time.Minute;
                wSecond = (ushort)time.Second;
                wMilliseconds = (ushort)time.Millisecond;
            }

            /// <summary>
            /// Convert to System.DateTime
            /// </summary>
            /// <returns></returns>
            public DateTime ToDateTime()
            {
                return new DateTime(wYear, wMonth, wDay, wHour, wMinute, wSecond, wMilliseconds);
            }
            /// <summary>
            /// STATIC: Convert to System.DateTime
            /// </summary>
            /// <param name="time"></param>
            /// <returns></returns>
            public static DateTime ToDateTime(SYSTEMTIME time)
            {
                return time.ToDateTime();
            }
        }

        [DllImport("kernel32.dll")]
        public static extern bool SetLocalTime([In] ref SYSTEMTIME lpLocalTime);

        // Represents the EN-US culture, used for numers in NMEA sentences
        public static CultureInfo NmeaCultureInfo = new CultureInfo("en-US");
        // Used to convert knots into miles per hour
        public static double MPHPerKnot = double.Parse("1.150779", NmeaCultureInfo);

        private SerialPortInfo m_Port = new SerialPortInfo();
        public SerialPort spGPS1 = new SerialPort();

        private static string m_GPRMCSentence = string.Empty;
        private static double m_Lat = 0.0;                          //Current GPS RMC Sentence Latitude
        private static double m_Lon = 0.0;                          //Current GPS RMC Sentence Longitude
        private static string m_Latitude = string.Empty;            //Current GPS RMC Sentence Latitude
        private static string m_Longitude = string.Empty;           //Current GPS RMC Sentence Latitude
        private static string m_NSHemisphere = "";                  //Current GPS RMC Sentence N/S hemisphere 
        private static string m_EWHemisphere = "";                  //Current GPS RMC Sentence E/W hemisphere 
        private static double m_Bearing = 0.0;                      //Current GPS RMC Sentence bearing
        private static string m_Dir = string.Empty;                 // Direction
        private static string m_UTCRawTime = "";                    //Current GPS RMC Sentence Raw UTC Time
        private static string m_UTCTime = "";                       //Current GPS RMC Sentence processed text UTC time
        private static DateTime m_SatelliteTime;                    //Current GPS RMC Sentence UTCtime converted to a datetime format
        private static DateTime m_GPSLocalTime;                     //Current GPS RMC Sentence UTCTime converted to Local time datetime format 
        private static string m_StrGPSLocalTime = "";               //Current GPS RMC Sentence UTCTime converted to a text Local time format
        private static string m_SystemLocalTimeBefore = "";         //Current System Local time before update
        private static string m_SystemLocalTimeAfter = "";          //Current System Local time after update 
        private static string m_SystemUTCTime = "";                 //Current System Local time
        private static string m_Fix = "";                           //Current GPS RMC Sentence Fix status
        private static double m_SpeedKnots = 0.0;                   //Current GPS RMC Sentence speed in knots
        private static double m_SpeedMph = 0.0;                     //Current GPS RMC Sentence speed in mph
        private static string m_Date = string.Empty;                //Current GPS RMC Sentence date
        private static SYSTEMTIME m_newtime;
        private static string m_tmpvalue = string.Empty;

        public string GPRMCSentence
        {
            get { return m_GPRMCSentence; }
            set { m_GPRMCSentence = value; }
        }

        public string Direction
        {
            get { return m_Dir; }
            set { m_Dir = value; }
        }

        public string Latitude
        {
            get { return m_Latitude; }
            set { m_Latitude = value; }
        }

        public string Longitude
        {
            get { return m_Longitude; }
            set { m_Longitude = value; }
        }
        
        public double Lat
        {
            get { return m_Lat; }
            set { m_Lat = value; }
        }
        
        public double Lon
        {
            get { return m_Lon; }
            set { m_Lon = value; }
        }
        
        public string NSHemisphere
        {
            get { return m_NSHemisphere; }
            set { m_NSHemisphere = value; }
        }
        
        public string EWHemisphere
        {
            get { return m_EWHemisphere; }
            set { m_EWHemisphere = value; }
        }

        public string RawUTCTime
        {
            get { return m_UTCRawTime; }
            //set { m_UTCTime = value; }
        }

        public string UTCTime
        {
            get { return m_UTCTime; }
            //set { m_UTCTime = value; }
        }

        public DateTime GPSLocalTime
        {
            get { return m_GPSLocalTime; }
            //set { m_GPSLocalTime = value; }
        }

        public DateTime SatelliteTime
        {
            get { return m_SatelliteTime; }
            //set { m_SatelliteTime = value; }
        }
        
        public string StrGPSLocalTime
        {
            get { return m_StrGPSLocalTime; }
            //set { m_StrGPSLocalTime = value; }
        }

        public string SystemLocalTimeBefore
        {
            get { return m_SystemLocalTimeBefore; }
            //set { m_SystemLocalTimeBefore = value; }
        }

        public string NewTime
        {
            get { return m_newtime.wMonth.ToString() + "/" + m_newtime.wDay.ToString() + "/" + m_newtime.wYear.ToString() + " " + m_newtime.wHour.ToString() + ":" + m_newtime.wMinute.ToString() + ":" + m_newtime.wSecond.ToString() + ":" + m_newtime.wMilliseconds.ToString(); }
            set { m_tmpvalue = value; }
        }

        public string SystemLocalTimeAfter
        {
            get { return m_SystemLocalTimeAfter; }
            //set { m_SystemLocalTimeAfter = value; }
        }

        public string Fix
        {
            get { return m_Fix; }
            set { m_Fix = value; }
        }
        
        public double Bearing
        {
            get { return m_Bearing; }
            set { m_Bearing = value; }
        }

        public double SpeedKnots
        {
            get { return m_SpeedKnots; }
            set { m_SpeedKnots = value; }
        }
        public double SpeedMph
        {
            get { return m_SpeedMph; }
            set { m_SpeedMph = value; }
        }
        public string Date
        {
            get { return m_Date; }
            set { m_Date = value; }
        }

        // Returns True if a sentence's checksum matches the calculated checksum
        public bool IsValid(string sentence)
        {
            // Compare the characters after the asterisk to the calculation
            return sentence.Substring(sentence.IndexOf("*") + 1) == GetChecksum(sentence);
        }

        // Calculates the checksum for a sentence
        public string GetChecksum(string sentence)
        {
            int Checksum = 0;
            foreach (char Character in sentence)
            {
                if (Character == '$')
                {
                    // Ignore the dollar sign
                }
                else if (Character == '*')
                {
                    // Stop processing before the asterisk
                    break;
                }
                else
                {
                    // Is this the first value for the checksum?
                    if (Checksum == 0)
                    {
                        // Yes. Set the checksum to the value
                        Checksum = Convert.ToByte(Character);
                    }
                    else
                    {
                        // No. XOR the checksum with this character's value
                        Checksum = Checksum ^ Convert.ToByte(Character);
                    }
                }
            }
            // Return the checksum formatted as a two-character hexadecimal
            return Checksum.ToString("X2");
        }
        // Processes information from the GPS receiver
        public bool Parse(string sentence)
        {
            // Discard the sentence if its checksum does not match the calculated checksum
            /*if (!IsValid(sentence))
            {
                return false;
            }*/
            // Look at the first word to determine sentence type
            switch (GetWords(sentence)[0])
            {
                case "$GPRMC":
                    // A "Recommended Minimum" sentence was found!
                    return ParseGPRMC(sentence);
                default:
                    //Unrecognized sentence
                    return false;
            }
        }

        // Divides a sentence into individual words
        public string[] GetWords(string sentence)
        {
            return sentence.Split(',');
        }

        // Interprets a $GPRMC message
        public bool ParseGPRMC(string sentence)
        {
            m_GPRMCSentence = sentence;

            try
            {

                // Divide the sentence into words
                string[] Words = GetWords(sentence);
                // Do we have enough values to describe our location?

                m_Lat = double.Parse(Words[3], NmeaCultureInfo);
                m_Lon = double.Parse(Words[5], NmeaCultureInfo);
                /*m_NSHemisphere = Words[4];
                m_EWHemisphere = Words[6];*/

                if (Words[3] != "" & Words[4] != "" & Words[5] != "" & Words[6] != "")
                {
                    //Extract latitude and longitude
                    m_Latitude = Words[3].Substring(0, 2) + "°"; // Append hours
                    m_Latitude = m_Latitude + Words[3].Substring(2) + "\""; // Append minutes
                    m_Latitude = m_Latitude + Words[4]; // Append the hemisphere

                    m_Longitude = Words[5].Substring(0, 3) + "°"; // Append hours
                    m_Longitude = m_Longitude + Words[5].Substring(3) + "\""; // Append minutes
                    m_Longitude = m_Longitude + Words[6]; // Append the hemisphere                
                }

                int UtcDay = 0;
                int UtcMonth = 0;
                int UtcYear = 0;
                // parse date?
                if (Words[9] != "")
                {
                    //Extract Year, Month, and day
                    UtcDay = Convert.ToInt32(Words[9].Substring(0, 2));
                    UtcMonth = Convert.ToInt32(Words[9].Substring(2, 2));
                    UtcYear = Convert.ToInt32(Words[9].Substring(4, 2));

                    m_Date = Convert.ToString(UtcMonth) + "/" + Convert.ToString(UtcDay) + "/" +
                                          Convert.ToString(UtcYear);
                }

                // parse satellite-derived time?

                int UtcHours = 0;
                int UtcMinutes = 0;
                int UtcSeconds = 0;
                int UtcMilliseconds = 0;

                if (Words[1] != "")
                {
                    // Extract hours, minutes, seconds and milliseconds
                    m_UTCRawTime = Words[1].ToString();
                    UtcHours = Convert.ToInt32(Words[1].Substring(0, 2));
                    UtcMinutes = Convert.ToInt32(Words[1].Substring(2, 2));
                    UtcSeconds = Convert.ToInt32(Words[1].Substring(4, 2));
                    UtcMilliseconds = 0;
                    // Extract milliseconds if it is available
                    if (Words[1].Length > 7)
                    {
                        UtcMilliseconds = Convert.ToInt32(Words[1].Substring(7));
                    }

                    // Build a DateTime object with all values
                    m_UTCTime = Convert.ToString(UtcHours) + ":" + Convert.ToString(UtcMinutes) + ":" +
                                          Convert.ToString(UtcSeconds) + "::" + Convert.ToString(UtcMilliseconds);
                    System.DateTime Today = System.DateTime.Now.ToUniversalTime();
                    m_SatelliteTime = new System.DateTime(Today.Year, Today.Month, Today.Day, UtcHours, UtcMinutes, UtcSeconds, UtcMilliseconds);

                    if (!(Words[1].Length > 7))
                    {
                        UtcMilliseconds = DateTime.Now.Millisecond;
                    }

                    // Adjust new satellite time to the local time zone
                    m_GPSLocalTime = m_SatelliteTime.ToLocalTime();
                    m_StrGPSLocalTime = Convert.ToString(m_SatelliteTime.ToLocalTime());

                    m_SystemLocalTimeBefore = DateTime.Now.Month + "/" + DateTime.Now.Day + "/" + DateTime.Now.Year + " " + DateTime.Now.Hour + ":" + DateTime.Now.Minute + ":" + DateTime.Now.Second + "::" + DateTime.Now.Millisecond;

                    if (GlobalVars.GPSTmrCounter >= GlobalVars.GPSUpdateFrequency)
                    {
                        //GlobalVars.GPSTmrCounter = 0;
                        m_newtime = new SYSTEMTIME();
                        m_newtime.FromDateTime(m_GPSLocalTime);
                        m_newtime.wMilliseconds = (ushort)UtcMilliseconds;
                        SetLocalTime(ref m_newtime);
                        //m_StrGPSLocalTime = newtime.wMonth + "/" + newtime.wDay + "/" + newtime.wYear + " " + newtime.wHour + ":" + newtime.wMinute + ":" + newtime.wSecond + "::" + newtime.wMilliseconds;
                    }
                    else
                    {
                        m_newtime = new SYSTEMTIME();
                    }
                    m_SystemLocalTimeAfter = DateTime.Now.Month + "/" + DateTime.Now.Day + "/" + DateTime.Now.Year + " " + DateTime.Now.Hour + ":" + DateTime.Now.Minute + ":" + DateTime.Now.Second + "::" + DateTime.Now.Millisecond;
                }

                // parse satellite fix?

                if (Words[2] != "")
                {
                    m_Fix = Words[2];
                }
            }
            catch (Exception ex)
            {
                return false;
            }
//           // Indicate that the sentence was recognized
            return true;
        }

        public string OpenGPSDeviceSerialPort(SerialPort gpsPort)
        //public string OpenGPSDeviceSerialPort()
        {
            string retValue = string.Empty;
            string error = string.Empty;

            if (gpsPort.IsOpen == true)
            {
                try
                {
                    gpsPort.Close();
                    Thread.Sleep(300);
                }
                catch (UnauthorizedAccessException unauthEx)
                {
                    error = unauthEx.Message;
                }
                catch (IOException ioEx)
                {
                    error = ioEx.Message;
                }
                catch (ArgumentException ArgEx)
                {
                    error = ArgEx.Message;
                }

                if (error.Length > 0)
                {
                    retValue = "\r\nError in closing the GPS device serial port. The GPS port is already in use by another device:" + gpsPort.PortName +
                               "\r\n\t" + error;
                    return retValue;
                }
            }
            else if (gpsPort.IsOpen == false)
            {
                try
                {
                    // Open the port
                    gpsPort.Open();
                    Thread.Sleep(1000);
                }
                catch (UnauthorizedAccessException unauthEx)
                {
                    error = unauthEx.Message;
                }
                catch (IOException ioEx)
                {
                    error = ioEx.Message;
                }
                catch (ArgumentException argEx)
                {
                    error = argEx.Message;
                }

                if (error.Length > 0)
                {
                    retValue = "\r\nError in opening the GPS device at serial port: " + gpsPort.PortName +
                               "\twith parity: " + gpsPort.BaudRate.ToString() + "," + gpsPort.Parity.ToString() + "," + gpsPort.DataBits.ToString() + "," + gpsPort.BaudRate.ToString() + "\tHandShake: " + gpsPort.Handshake.ToString() +
                               "\r\n\t" + error;
                    return retValue;
                }
            }
            return retValue;
        }

        public string VerifyGPSDeviceOnSerialPort(SerialPort gpsPort, ref bool FoundGPSDevice)
        {
            string retValue = string.Empty;
            string error = string.Empty;
            string msg = string.Empty;

            TimeSpan starttime;
            TimeSpan endtime;
            double diff = 0.0;

            FoundGPSDevice = false;

            retValue = OpenGPSDeviceSerialPort(gpsPort);

            if (retValue.Length > 0)
            {
                return retValue;
            }
            else
            {
                starttime = new TimeSpan(DateTime.Now.Ticks);
                for (int j = 1; j <= 5; j++)
                {   
                    retValue = ReadSerialPort(gpsPort);
                    if ((m_UTCTime.Length > 0) && (m_Date.Length > 0))
                    {
                        //"GPS device is prsent on CommPort: " + gpsPort.PortName + " and communicating properly.";
                        FoundGPSDevice = true;
                        retValue = string.Empty;
                        return retValue;
                    }
                    //else if ((retValue.Length == 0) && (m_UTCTime.Length == 0) && (m_Date.Length == 0))
                    else if ((m_UTCTime.Length == 0) && (m_Date.Length == 0))
                    {
                        Thread.Sleep(1000);
                    }
                }
                if (!FoundGPSDevice)
                {
                    endtime = new TimeSpan(DateTime.Now.Ticks);
                    diff = endtime.TotalMilliseconds - starttime.TotalMilliseconds;

                    retValue = "No valid GPRMC sentence was received in 5 seconds from the GPS device on port: " + gpsPort.PortName;
                }
            }
            return retValue;
        }


        public string ReadSerialPort(SerialPort gpsPort)       //Used for timer reads from the GPS port
        {
            string retValue = string.Empty;
            string GPSData = string.Empty;
            string GPSMsg = string.Empty;
            string CurrTime;
            string Sentence = string.Empty;
            bool RMCSentenceFound = false;
            int noAvailableBytes = 0;

            try
            {
                if (gpsPort.IsOpen == true)
                {
                    if (gpsPort.BytesToRead > 0)
                    {
                        GPSData = gpsPort.ReadExisting();
                        GPSMsg = GPSData;
                    }

                    int GPRMCLocation = 0;
                    while ((GPRMCLocation = GPSData.LastIndexOf("$GPRMC")) >= 0)
                    {
                        Sentence = GPSData.Substring(GPRMCLocation);
                        //if ((NLLocation = Sentence.LastIndexOf("\n")) > 0)
                        //{
                        if ((Sentence.IndexOf("\n") > 0) || (Sentence.IndexOf("\r") > 0))
                        {
                            if (Parse(Sentence) == true)
                            {
                                RMCSentenceFound = true;
                            }
                            else
                            {
                                RMCSentenceFound = false;
                                retValue = "Error in Parsing GPRMC sentence." + "\t" + Sentence;
                            }
                        }
                        else
                        {
                            GPSData = GPSData.Substring(0, GPRMCLocation);
                        }
                    }



                    if (RMCSentenceFound == false)
                    {
                        retValue = "No complete GPRMC sentence was found." + "\t" + GPSMsg;
                    }
                }
                else
                {
                    retValue = "GPS device on Port: " + gpsPort.PortName + "\tis not Open";
                }
            }
            catch (TimeoutException ex)
            {
                retValue = ex.Message;
            }
            return retValue;
            /*while ((NLLocation = GPSMsg.LastIndexOf("\n")) > 0)
            {
                GPRMCLocation = GPSMsg.LastIndexOf("$GPRMC");
                if ((NLLocation > GPRMCLocation) && (GPRMCLocation > 0))
                {
                    RMCSentenceFound = true;
                    Sentence = GPSMsg.Substring(GPRMCLocation, NLLocation - GPRMCLocation-1);
                    break;
                }
                else
                {
                    if (GPRMCLocation > 0)
                    {
                        GPSMsg = GPSMsg.Substring(0, GPRMCLocation);
                    }
                    else
                    {
                        GPSMsg = "";
                        return "Incomplete GPS GPRMC sentence.";
                    }
                }
            }*/

        }
        public string PopulateGPSPortInfo()
        {
            string retValue = string.Empty;

            try
            {
                
                spGPS1.PortName = m_Port.name;
                spGPS1.BaudRate = m_Port.baudrate;
                spGPS1.BaudRate = m_Port.databits;
                spGPS1.DtrEnable = true;
                spGPS1.ReceivedBytesThreshold = 1;

                switch (m_Port.stopbits)
                {
                    case "1":
                        spGPS1.StopBits = StopBits.One;
                        break;
                    case "1.5":
                        spGPS1.StopBits = StopBits.OnePointFive;
                        break;
                    case "2":
                        spGPS1.StopBits = StopBits.Two;
                        break;
                    case "NONE":
                        spGPS1.StopBits = StopBits.None;
                        break;
                }
                switch (m_Port.parity.ToUpper())
                {
                    case "NONE":
                        spGPS1.Parity = Parity.None;
                        break;
                    case "EVEN":
                        spGPS1.Parity = Parity.Even;
                        break;
                    case "ODD":
                        spGPS1.Parity = Parity.Odd;
                        break;
                    case "MARK":
                        spGPS1.Parity = Parity.Mark;
                        break;
                    case "SPACE":
                        spGPS1.Parity = Parity.Space;
                        break;
                }
                switch (m_Port.handshake.ToUpper())
                {
                    case "NONE":
                        spGPS1.Handshake = Handshake.None;
                        break;
                    case "SEND":
                        spGPS1.Handshake = Handshake.RequestToSend;
                        break;
                    case "SENDXONXOFF":
                        spGPS1.Handshake = Handshake.RequestToSendXOnXOff;
                        break;
                    case "XONXOFF":
                        spGPS1.Handshake = Handshake.XOnXOff;
                        break;
                }
            }
            catch (Exception ex)
            {
                retValue = "Error in populating GPS serial port properties.\t" + ex.Message;
            }

            return retValue;
        }
        public string ReadGPSPortInfo(string SpatConfigFile)
        {
            string retValue = string.Empty;

            try
            {
                XDocument doc = XDocument.Load(SpatConfigFile);
                XElement root = doc.Root;

                string strTagName = string.Empty;
                string strTagValue = string.Empty;

                foreach (XElement element in root.Elements())
                {
                    strTagName = element.Name.ToString();
                    strTagValue = element.Value.ToString();

                    if (strTagName.ToUpper() == "GPSPort".ToUpper())
                    {
                        foreach (XElement child in element.Elements())
                        {
                            strTagName = child.Name.ToString();
                            strTagValue = child.Value.ToString();
                            switch (strTagName)
                            {
                                case "portname": { m_Port.name = strTagValue; break; }
                                case "baudrate": { m_Port.baudrate = Convert.ToInt32(strTagValue); break; }
                                case "databits": { m_Port.databits = Convert.ToInt32(strTagValue); break; }
                                case "stopbits": { m_Port.stopbits = strTagValue; break; }
                                case "handshake": { m_Port.handshake = strTagValue; break; }
                                case "parity": { m_Port.parity = strTagValue; break; }
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                retValue = "\r\n--Error in reading the GPS port configuration information: " + SpatConfigFile + "\t" + ex.Message;
            }
            return retValue;
        }
        public string DetectGPSDeviceSerialPort(ref SerialPort gpsPort, ref bool FoundGPSDevice)
        {
            int num;
            string retValue = string.Empty;
            string error = string.Empty;
            string msg = string.Empty;

            FoundGPSDevice = false;

            gpsPort.DataBits = int.Parse("8");
            gpsPort.Parity = Parity.None;
            gpsPort.StopBits = StopBits.One;
            gpsPort.Handshake = Handshake.None;
            string[] ports = SerialPort.GetPortNames().OrderBy(a => a.Length > 3 && int.TryParse(a.Substring(3), out num) ? num : 0).ToArray();

            foreach (string port in ports)
            {
                gpsPort.PortName = port;
                for (int i = 1; i <= 8; i++)
                {
                    switch (i)
                    {
                        case 1:
                            gpsPort.BaudRate = 1200;
                            break;
                        case 2:
                            gpsPort.BaudRate = 2400;
                            break;
                        case 3:
                            gpsPort.BaudRate = 4800;
                            break;
                        case 4:
                            gpsPort.BaudRate = 9600;
                            break;
                        case 5:
                            gpsPort.BaudRate = 19200;
                            break;
                        case 6:
                            gpsPort.BaudRate = 38400;
                            break;
                        case 7:
                            gpsPort.BaudRate = 57600;
                            break;
                        case 8:
                            gpsPort.BaudRate = 115200;
                            break;
                    }

                    retValue = OpenGPSDeviceSerialPort(spGPS1);
                    if (retValue.Length > 0)
                    {
                        return retValue;
                    }
                    else
                    {
                        //// Show the initial pin states
                        //UpdatePinState();
                        //chkDTR.Checked = comport.DtrEnable;
                        //chkRTS.Checked = comport.RtsEnable;
                        for (int j = 1; j <= 20; j++)
                        {
                            retValue = ReadSerialPort(gpsPort);
                            if ((retValue.Length == 0) && (m_UTCTime.Length > 0) && (m_Date.Length > 0))
                            {
                                FoundGPSDevice = true;
                                // "GPS device is prsent on CommPort: " + gpsPort.PortName + " and communicating properly.";
                                retValue = string.Empty;
                                return retValue;
                            }
                            else if ((retValue.Length == 0) && (m_UTCTime.Length == 0) && (m_Date.Length == 0))
                            {
                                Thread.Sleep(100);
                            }
                        }
                        if (!FoundGPSDevice)
                        {
                            retValue = "No valid GPRMC sentence was received in 5 seconds from the GPS device on port: " + gpsPort.PortName +
                                        "\twith the following settings: " + gpsPort.Parity.ToString() + "," + gpsPort.DataBits.ToString() + "," + gpsPort.StopBits.ToString() + "," + gpsPort.BaudRate.ToString() + "\tHandShake: " + gpsPort.Handshake.ToString();
                        }
                    }
                }
            }
            gpsPort.Close();
            return retValue;
        }

    }
}

