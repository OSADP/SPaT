﻿namespace SPaTSystem
{
    partial class frmMain
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmMain));
            this.tabCntrlSAPTSystem = new System.Windows.Forms.TabControl();
            this.tabpgSPATMsg = new System.Windows.Forms.TabPage();
            this.chkLaneMvmnt = new System.Windows.Forms.CheckBox();
            this.chkSPaTMsg = new System.Windows.Forms.CheckBox();
            this.chkTSCData = new System.Windows.Forms.CheckBox();
            this.chkEnableDataLogging = new System.Windows.Forms.CheckBox();
            this.txtDiscontinuousFlag = new System.Windows.Forms.TextBox();
            this.chkEnableSSMMessagePush = new System.Windows.Forms.CheckBox();
            this.label32 = new System.Windows.Forms.Label();
            this.txtTimeBaseActionStatus = new System.Windows.Forms.TextBox();
            this.chkEnableSpatMessagePush = new System.Windows.Forms.CheckBox();
            this.chkEnableDisableSPAT = new System.Windows.Forms.CheckBox();
            this.btnExitSPATSystem = new System.Windows.Forms.Button();
            this.btnHaltSPATSystem = new System.Windows.Forms.Button();
            this.grpStatusDisplay = new System.Windows.Forms.GroupBox();
            this.lblSysMSec = new System.Windows.Forms.Label();
            this.lblTSCMsec = new System.Windows.Forms.Label();
            this.txtSysMsec = new System.Windows.Forms.TextBox();
            this.txtTSCMSec = new System.Windows.Forms.TextBox();
            this.btnHideSysTime = new System.Windows.Forms.Button();
            this.btnHideTSCTime = new System.Windows.Forms.Button();
            this.txtSysTime = new System.Windows.Forms.TextBox();
            this.txtTSCMsgNo = new System.Windows.Forms.TextBox();
            this.lblTSCMsgNo = new System.Windows.Forms.Label();
            this.lblTSCTime = new System.Windows.Forms.Label();
            this.txtTSCMsgTime = new System.Windows.Forms.TextBox();
            this.txtSpatMsgGenerationTime = new System.Windows.Forms.TextBox();
            this.lblSpatTime = new System.Windows.Forms.Label();
            this.txtTSCMsgInterval = new System.Windows.Forms.TextBox();
            this.lblTSCInterval = new System.Windows.Forms.Label();
            this.txtSPaTSysInterval = new System.Windows.Forms.TextBox();
            this.lblSysInterval = new System.Windows.Forms.Label();
            this.lblPhase1 = new System.Windows.Forms.Label();
            this.lblOvlp16 = new System.Windows.Forms.Label();
            this.lblOvlp15 = new System.Windows.Forms.Label();
            this.lblOvlp14 = new System.Windows.Forms.Label();
            this.lblOvlp13 = new System.Windows.Forms.Label();
            this.lblOvlp12 = new System.Windows.Forms.Label();
            this.lblOvlp11 = new System.Windows.Forms.Label();
            this.lblOvlp10 = new System.Windows.Forms.Label();
            this.lblOvlp9 = new System.Windows.Forms.Label();
            this.lblOvlp8 = new System.Windows.Forms.Label();
            this.lblOvlp7 = new System.Windows.Forms.Label();
            this.lblOvlp6 = new System.Windows.Forms.Label();
            this.lblOvlp5 = new System.Windows.Forms.Label();
            this.lblOvlp4 = new System.Windows.Forms.Label();
            this.lblOvlp3 = new System.Windows.Forms.Label();
            this.lblOvlp2 = new System.Windows.Forms.Label();
            this.lblOvlp1 = new System.Windows.Forms.Label();
            this.lblPhase16 = new System.Windows.Forms.Label();
            this.lblPhase15 = new System.Windows.Forms.Label();
            this.lblPhase14 = new System.Windows.Forms.Label();
            this.lblPhase13 = new System.Windows.Forms.Label();
            this.lblPhase12 = new System.Windows.Forms.Label();
            this.lblPhase11 = new System.Windows.Forms.Label();
            this.lblPhase10 = new System.Windows.Forms.Label();
            this.lblPhase9 = new System.Windows.Forms.Label();
            this.lblPhase8 = new System.Windows.Forms.Label();
            this.lblPhase7 = new System.Windows.Forms.Label();
            this.lblPhase6 = new System.Windows.Forms.Label();
            this.lblPhase5 = new System.Windows.Forms.Label();
            this.lblPhase4 = new System.Windows.Forms.Label();
            this.lblPhase3 = new System.Windows.Forms.Label();
            this.lblPhase2 = new System.Windows.Forms.Label();
            this.label48 = new System.Windows.Forms.Label();
            this.lblSysTime = new System.Windows.Forms.Label();
            this.axaxNtcipIO1 = new AxaxNtcipIOControl.AxaxNtcipIO();
            this.label41 = new System.Windows.Forms.Label();
            this.txtPed2 = new System.Windows.Forms.TextBox();
            this.txtPed1 = new System.Windows.Forms.TextBox();
            this.txtPed16 = new System.Windows.Forms.TextBox();
            this.txtPed3 = new System.Windows.Forms.TextBox();
            this.txtPed15 = new System.Windows.Forms.TextBox();
            this.txtPed4 = new System.Windows.Forms.TextBox();
            this.txtPed14 = new System.Windows.Forms.TextBox();
            this.txtPed5 = new System.Windows.Forms.TextBox();
            this.txtPed13 = new System.Windows.Forms.TextBox();
            this.txtPed6 = new System.Windows.Forms.TextBox();
            this.txtPed12 = new System.Windows.Forms.TextBox();
            this.txtPed7 = new System.Windows.Forms.TextBox();
            this.txtPed11 = new System.Windows.Forms.TextBox();
            this.txtPed8 = new System.Windows.Forms.TextBox();
            this.txtPed10 = new System.Windows.Forms.TextBox();
            this.txtPed9 = new System.Windows.Forms.TextBox();
            this.label26 = new System.Windows.Forms.Label();
            this.txtOMaxTime2 = new System.Windows.Forms.TextBox();
            this.txtOMaxTime16 = new System.Windows.Forms.TextBox();
            this.txtOMaxTime15 = new System.Windows.Forms.TextBox();
            this.txtOMaxTime14 = new System.Windows.Forms.TextBox();
            this.txtOMaxTime13 = new System.Windows.Forms.TextBox();
            this.txtOMaxTime12 = new System.Windows.Forms.TextBox();
            this.txtOMaxTime11 = new System.Windows.Forms.TextBox();
            this.txtOMaxTime10 = new System.Windows.Forms.TextBox();
            this.txtOMaxTime9 = new System.Windows.Forms.TextBox();
            this.txtOMaxTime8 = new System.Windows.Forms.TextBox();
            this.txtOMaxTime7 = new System.Windows.Forms.TextBox();
            this.txtOMaxTime6 = new System.Windows.Forms.TextBox();
            this.txtOMaxTime5 = new System.Windows.Forms.TextBox();
            this.txtOMaxTime4 = new System.Windows.Forms.TextBox();
            this.txtOMaxTime3 = new System.Windows.Forms.TextBox();
            this.txtOMaxTime1 = new System.Windows.Forms.TextBox();
            this.txtOMinTime2 = new System.Windows.Forms.TextBox();
            this.txtOMinTime16 = new System.Windows.Forms.TextBox();
            this.txtOMinTime15 = new System.Windows.Forms.TextBox();
            this.txtOMinTime14 = new System.Windows.Forms.TextBox();
            this.txtOMinTime13 = new System.Windows.Forms.TextBox();
            this.txtOMinTime12 = new System.Windows.Forms.TextBox();
            this.txtOMinTime11 = new System.Windows.Forms.TextBox();
            this.txtOMinTime10 = new System.Windows.Forms.TextBox();
            this.txtOMinTime9 = new System.Windows.Forms.TextBox();
            this.txtOMinTime8 = new System.Windows.Forms.TextBox();
            this.txtOMinTime7 = new System.Windows.Forms.TextBox();
            this.txtOMinTime6 = new System.Windows.Forms.TextBox();
            this.txtOMinTime5 = new System.Windows.Forms.TextBox();
            this.txtOMinTime4 = new System.Windows.Forms.TextBox();
            this.txtOMinTime3 = new System.Windows.Forms.TextBox();
            this.label27 = new System.Windows.Forms.Label();
            this.txtOMinTime1 = new System.Windows.Forms.TextBox();
            this.label24 = new System.Windows.Forms.Label();
            this.txtPMaxTime2 = new System.Windows.Forms.TextBox();
            this.txtPMaxTime16 = new System.Windows.Forms.TextBox();
            this.txtPMaxTime15 = new System.Windows.Forms.TextBox();
            this.txtPMaxTime14 = new System.Windows.Forms.TextBox();
            this.txtPMaxTime13 = new System.Windows.Forms.TextBox();
            this.txtPMaxTime12 = new System.Windows.Forms.TextBox();
            this.txtPMaxTime11 = new System.Windows.Forms.TextBox();
            this.txtPMaxTime10 = new System.Windows.Forms.TextBox();
            this.txtPMaxTime9 = new System.Windows.Forms.TextBox();
            this.txtPMaxTime8 = new System.Windows.Forms.TextBox();
            this.txtPMaxTime7 = new System.Windows.Forms.TextBox();
            this.txtPMaxTime6 = new System.Windows.Forms.TextBox();
            this.txtPMaxTime5 = new System.Windows.Forms.TextBox();
            this.txtPMaxTime4 = new System.Windows.Forms.TextBox();
            this.txtPMaxTime3 = new System.Windows.Forms.TextBox();
            this.txtPMaxTime1 = new System.Windows.Forms.TextBox();
            this.txtPMinTime2 = new System.Windows.Forms.TextBox();
            this.txtPMinTime16 = new System.Windows.Forms.TextBox();
            this.txtPMinTime15 = new System.Windows.Forms.TextBox();
            this.txtPMinTime14 = new System.Windows.Forms.TextBox();
            this.txtPMinTime13 = new System.Windows.Forms.TextBox();
            this.txtPMinTime12 = new System.Windows.Forms.TextBox();
            this.txtPMinTime11 = new System.Windows.Forms.TextBox();
            this.txtPMinTime10 = new System.Windows.Forms.TextBox();
            this.txtPMinTime9 = new System.Windows.Forms.TextBox();
            this.txtPMinTime8 = new System.Windows.Forms.TextBox();
            this.txtPMinTime7 = new System.Windows.Forms.TextBox();
            this.txtPMinTime6 = new System.Windows.Forms.TextBox();
            this.txtPMinTime5 = new System.Windows.Forms.TextBox();
            this.txtPMinTime4 = new System.Windows.Forms.TextBox();
            this.txtPMinTime3 = new System.Windows.Forms.TextBox();
            this.label25 = new System.Windows.Forms.Label();
            this.txtPMinTime1 = new System.Windows.Forms.TextBox();
            this.label23 = new System.Windows.Forms.Label();
            this.txtVMaxTime2 = new System.Windows.Forms.TextBox();
            this.txtVMaxTime16 = new System.Windows.Forms.TextBox();
            this.txtVMaxTime15 = new System.Windows.Forms.TextBox();
            this.txtVMaxTime14 = new System.Windows.Forms.TextBox();
            this.txtVMaxTime13 = new System.Windows.Forms.TextBox();
            this.txtVMaxTime12 = new System.Windows.Forms.TextBox();
            this.txtVMaxTime11 = new System.Windows.Forms.TextBox();
            this.txtVMaxTime10 = new System.Windows.Forms.TextBox();
            this.txtVMaxTime9 = new System.Windows.Forms.TextBox();
            this.txtVMaxTime8 = new System.Windows.Forms.TextBox();
            this.txtVMaxTime6 = new System.Windows.Forms.TextBox();
            this.txtVMaxTime5 = new System.Windows.Forms.TextBox();
            this.txtVMaxTime4 = new System.Windows.Forms.TextBox();
            this.txtVMaxTime3 = new System.Windows.Forms.TextBox();
            this.txtVMaxTime1 = new System.Windows.Forms.TextBox();
            this.txtVMinTime2 = new System.Windows.Forms.TextBox();
            this.txtVMinTime16 = new System.Windows.Forms.TextBox();
            this.txtVMinTime15 = new System.Windows.Forms.TextBox();
            this.txtVMinTime14 = new System.Windows.Forms.TextBox();
            this.txtVMinTime13 = new System.Windows.Forms.TextBox();
            this.txtVMinTime12 = new System.Windows.Forms.TextBox();
            this.txtVMinTime11 = new System.Windows.Forms.TextBox();
            this.txtVMinTime10 = new System.Windows.Forms.TextBox();
            this.txtVMinTime9 = new System.Windows.Forms.TextBox();
            this.txtVMinTime8 = new System.Windows.Forms.TextBox();
            this.txtVMinTime7 = new System.Windows.Forms.TextBox();
            this.txtVMinTime6 = new System.Windows.Forms.TextBox();
            this.txtVMinTime5 = new System.Windows.Forms.TextBox();
            this.txtVMinTime4 = new System.Windows.Forms.TextBox();
            this.txtVMinTime3 = new System.Windows.Forms.TextBox();
            this.label22 = new System.Windows.Forms.Label();
            this.txtVMinTime1 = new System.Windows.Forms.TextBox();
            this.label34 = new System.Windows.Forms.Label();
            this.label33 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.shapeContainer1 = new Microsoft.VisualBasic.PowerPacks.ShapeContainer();
            this.shpOvlp16 = new Microsoft.VisualBasic.PowerPacks.OvalShape();
            this.shpOvlp15 = new Microsoft.VisualBasic.PowerPacks.OvalShape();
            this.shpOvlp14 = new Microsoft.VisualBasic.PowerPacks.OvalShape();
            this.shpOvlp13 = new Microsoft.VisualBasic.PowerPacks.OvalShape();
            this.shpOvlp12 = new Microsoft.VisualBasic.PowerPacks.OvalShape();
            this.shpOvlp11 = new Microsoft.VisualBasic.PowerPacks.OvalShape();
            this.shpOvlp10 = new Microsoft.VisualBasic.PowerPacks.OvalShape();
            this.shpOvlp9 = new Microsoft.VisualBasic.PowerPacks.OvalShape();
            this.shpOvlp8 = new Microsoft.VisualBasic.PowerPacks.OvalShape();
            this.shpOvlp7 = new Microsoft.VisualBasic.PowerPacks.OvalShape();
            this.shpOvlp6 = new Microsoft.VisualBasic.PowerPacks.OvalShape();
            this.shpOvlp5 = new Microsoft.VisualBasic.PowerPacks.OvalShape();
            this.shpOvlp4 = new Microsoft.VisualBasic.PowerPacks.OvalShape();
            this.shpOvlp3 = new Microsoft.VisualBasic.PowerPacks.OvalShape();
            this.shpOvlp2 = new Microsoft.VisualBasic.PowerPacks.OvalShape();
            this.shpOvlp1 = new Microsoft.VisualBasic.PowerPacks.OvalShape();
            this.shpPed1 = new Microsoft.VisualBasic.PowerPacks.OvalShape();
            this.shpPed2 = new Microsoft.VisualBasic.PowerPacks.OvalShape();
            this.shpPed3 = new Microsoft.VisualBasic.PowerPacks.OvalShape();
            this.shpPed4 = new Microsoft.VisualBasic.PowerPacks.OvalShape();
            this.shpPed5 = new Microsoft.VisualBasic.PowerPacks.OvalShape();
            this.shpPed6 = new Microsoft.VisualBasic.PowerPacks.OvalShape();
            this.shpPed7 = new Microsoft.VisualBasic.PowerPacks.OvalShape();
            this.shpPed8 = new Microsoft.VisualBasic.PowerPacks.OvalShape();
            this.shpPed9 = new Microsoft.VisualBasic.PowerPacks.OvalShape();
            this.shpPed10 = new Microsoft.VisualBasic.PowerPacks.OvalShape();
            this.shpPed11 = new Microsoft.VisualBasic.PowerPacks.OvalShape();
            this.shpPed12 = new Microsoft.VisualBasic.PowerPacks.OvalShape();
            this.shpPed13 = new Microsoft.VisualBasic.PowerPacks.OvalShape();
            this.shpPed14 = new Microsoft.VisualBasic.PowerPacks.OvalShape();
            this.shpPed15 = new Microsoft.VisualBasic.PowerPacks.OvalShape();
            this.shpPed16 = new Microsoft.VisualBasic.PowerPacks.OvalShape();
            this.shpPhase16 = new Microsoft.VisualBasic.PowerPacks.OvalShape();
            this.shpPhase15 = new Microsoft.VisualBasic.PowerPacks.OvalShape();
            this.shpPhase14 = new Microsoft.VisualBasic.PowerPacks.OvalShape();
            this.shpPhase13 = new Microsoft.VisualBasic.PowerPacks.OvalShape();
            this.shpPhase12 = new Microsoft.VisualBasic.PowerPacks.OvalShape();
            this.shpPhase11 = new Microsoft.VisualBasic.PowerPacks.OvalShape();
            this.shpPhase10 = new Microsoft.VisualBasic.PowerPacks.OvalShape();
            this.shpPhase9 = new Microsoft.VisualBasic.PowerPacks.OvalShape();
            this.shpPhase8 = new Microsoft.VisualBasic.PowerPacks.OvalShape();
            this.shpPhase7 = new Microsoft.VisualBasic.PowerPacks.OvalShape();
            this.shpPhase6 = new Microsoft.VisualBasic.PowerPacks.OvalShape();
            this.shpPhase5 = new Microsoft.VisualBasic.PowerPacks.OvalShape();
            this.shpPhase4 = new Microsoft.VisualBasic.PowerPacks.OvalShape();
            this.shpPhase3 = new Microsoft.VisualBasic.PowerPacks.OvalShape();
            this.shpPhase2 = new Microsoft.VisualBasic.PowerPacks.OvalShape();
            this.shpPhase1 = new Microsoft.VisualBasic.PowerPacks.OvalShape();
            this.txtVMaxTime7 = new System.Windows.Forms.TextBox();
            this.chkProgrammedFlash = new System.Windows.Forms.CheckBox();
            this.chkDiscontinuousFlag = new System.Windows.Forms.CheckBox();
            this.chkCoordinationInTransition = new System.Windows.Forms.CheckBox();
            this.chkCoordination = new System.Windows.Forms.CheckBox();
            this.chkTSP = new System.Windows.Forms.CheckBox();
            this.chkPreempt = new System.Windows.Forms.CheckBox();
            this.chkFaultFlash = new System.Windows.Forms.CheckBox();
            this.chkStopTime = new System.Windows.Forms.CheckBox();
            this.chkManualControl = new System.Windows.Forms.CheckBox();
            this.lblControllerConnection = new System.Windows.Forms.Label();
            this.tabpgActivityLog = new System.Windows.Forms.TabPage();
            this.splitContainer1 = new System.Windows.Forms.SplitContainer();
            this.splitContainer2 = new System.Windows.Forms.SplitContainer();
            this.splitContainer3 = new System.Windows.Forms.SplitContainer();
            this.label100 = new System.Windows.Forms.Label();
            this.lblBytesRead = new System.Windows.Forms.Label();
            this.txtTSCLog = new System.Windows.Forms.TextBox();
            this.splitContainer4 = new System.Windows.Forms.SplitContainer();
            this.label18 = new System.Windows.Forms.Label();
            this.txtSPATMsgLog = new System.Windows.Forms.TextBox();
            this.splitContainer5 = new System.Windows.Forms.SplitContainer();
            this.label19 = new System.Windows.Forms.Label();
            this.txtActivityLog = new System.Windows.Forms.TextBox();
            this.tabpgEnableSPATMsgPush = new System.Windows.Forms.TabPage();
            this.splitContainer7 = new System.Windows.Forms.SplitContainer();
            this.groupBox5 = new System.Windows.Forms.GroupBox();
            this.chkPrmpt6 = new System.Windows.Forms.CheckBox();
            this.chkPrmpt5 = new System.Windows.Forms.CheckBox();
            this.chkPrmpt4 = new System.Windows.Forms.CheckBox();
            this.chkPrmpt3 = new System.Windows.Forms.CheckBox();
            this.chkPrmpt2 = new System.Windows.Forms.CheckBox();
            this.chkPrmpt1 = new System.Windows.Forms.CheckBox();
            this.btnDisablePreempt6 = new System.Windows.Forms.Button();
            this.btnDisablePreempt5 = new System.Windows.Forms.Button();
            this.btnDisablePreempt4 = new System.Windows.Forms.Button();
            this.btnEnablePreempt6 = new System.Windows.Forms.Button();
            this.btnEnablePreempt5 = new System.Windows.Forms.Button();
            this.btnEnablePreempt4 = new System.Windows.Forms.Button();
            this.btnDisablePreempt3 = new System.Windows.Forms.Button();
            this.btnEnablePreempt3 = new System.Windows.Forms.Button();
            this.btnDisablePreempt2 = new System.Windows.Forms.Button();
            this.btnEnablePreempt2 = new System.Windows.Forms.Button();
            this.btnDisablePreempt1 = new System.Windows.Forms.Button();
            this.btnEnablePreempt1 = new System.Windows.Forms.Button();
            this.groupBox8 = new System.Windows.Forms.GroupBox();
            this.label55 = new System.Windows.Forms.Label();
            this.label45 = new System.Windows.Forms.Label();
            this.txtOIDValue = new System.Windows.Forms.TextBox();
            this.btnSetOID = new System.Windows.Forms.Button();
            this.txtOID = new System.Windows.Forms.TextBox();
            this.label46 = new System.Windows.Forms.Label();
            this.txtEnableSPATPush = new System.Windows.Forms.TextBox();
            this.tabpgGPS = new System.Windows.Forms.TabPage();
            this.splitContainer6 = new System.Windows.Forms.SplitContainer();
            this.txtGPSRawTime = new System.Windows.Forms.TextBox();
            this.label68 = new System.Windows.Forms.Label();
            this.txtGPSLocalTime = new System.Windows.Forms.TextBox();
            this.btnGPSUpdateFrequency = new System.Windows.Forms.Button();
            this.txtSysBeforeTime = new System.Windows.Forms.TextBox();
            this.label67 = new System.Windows.Forms.Label();
            this.txtSysAfterTime = new System.Windows.Forms.TextBox();
            this.txtGPSUpdateFrequency = new System.Windows.Forms.TextBox();
            this.label52 = new System.Windows.Forms.Label();
            this.label66 = new System.Windows.Forms.Label();
            this.label56 = new System.Windows.Forms.Label();
            this.txtNewTime = new System.Windows.Forms.TextBox();
            this.label57 = new System.Windows.Forms.Label();
            this.label65 = new System.Windows.Forms.Label();
            this.txtLat = new System.Windows.Forms.TextBox();
            this.txtSatelliteTime = new System.Windows.Forms.TextBox();
            this.txtLon = new System.Windows.Forms.TextBox();
            this.label64 = new System.Windows.Forms.Label();
            this.txtGPSDate = new System.Windows.Forms.TextBox();
            this.label63 = new System.Windows.Forms.Label();
            this.label61 = new System.Windows.Forms.Label();
            this.label60 = new System.Windows.Forms.Label();
            this.txtGPSUTCTime = new System.Windows.Forms.TextBox();
            this.label62 = new System.Windows.Forms.Label();
            this.txtGPSActivity = new System.Windows.Forms.TextBox();
            this.txtGPSFix = new System.Windows.Forms.TextBox();
            this.tabpgSPATConfiguration = new System.Windows.Forms.TabPage();
            this.pnlSPATConfiguration = new System.Windows.Forms.Panel();
            this.button1 = new System.Windows.Forms.Button();
            this.label112 = new System.Windows.Forms.Label();
            this.label111 = new System.Windows.Forms.Label();
            this.txtDiskSpace = new System.Windows.Forms.TextBox();
            this.btnQuitSPaTSystem = new System.Windows.Forms.Button();
            this.groupBox6 = new System.Windows.Forms.GroupBox();
            this.label94 = new System.Windows.Forms.Label();
            this.label101 = new System.Windows.Forms.Label();
            this.label95 = new System.Windows.Forms.Label();
            this.chkPedDetectPhase1 = new System.Windows.Forms.CheckBox();
            this.label96 = new System.Windows.Forms.Label();
            this.chkPedDetectPhase2 = new System.Windows.Forms.CheckBox();
            this.label97 = new System.Windows.Forms.Label();
            this.chkPedDetectPhase3 = new System.Windows.Forms.CheckBox();
            this.label98 = new System.Windows.Forms.Label();
            this.chkPedDetectPhase4 = new System.Windows.Forms.CheckBox();
            this.label99 = new System.Windows.Forms.Label();
            this.chkPedDetectPhase5 = new System.Windows.Forms.CheckBox();
            this.chkPedDetectPhase6 = new System.Windows.Forms.CheckBox();
            this.label102 = new System.Windows.Forms.Label();
            this.chkPedDetectPhase7 = new System.Windows.Forms.CheckBox();
            this.label103 = new System.Windows.Forms.Label();
            this.chkPedDetectPhase8 = new System.Windows.Forms.CheckBox();
            this.label104 = new System.Windows.Forms.Label();
            this.chkPedDetectPhase9 = new System.Windows.Forms.CheckBox();
            this.label105 = new System.Windows.Forms.Label();
            this.chkPedDetectPhase10 = new System.Windows.Forms.CheckBox();
            this.label106 = new System.Windows.Forms.Label();
            this.chkPedDetectPhase11 = new System.Windows.Forms.CheckBox();
            this.label107 = new System.Windows.Forms.Label();
            this.chkPedDetectPhase12 = new System.Windows.Forms.CheckBox();
            this.label108 = new System.Windows.Forms.Label();
            this.chkPedDetectPhase13 = new System.Windows.Forms.CheckBox();
            this.label109 = new System.Windows.Forms.Label();
            this.chkPedDetectPhase14 = new System.Windows.Forms.CheckBox();
            this.label110 = new System.Windows.Forms.Label();
            this.chkPedDetectPhase15 = new System.Windows.Forms.CheckBox();
            this.chkPedDetectPhase16 = new System.Windows.Forms.CheckBox();
            this.label93 = new System.Windows.Forms.Label();
            this.label92 = new System.Windows.Forms.Label();
            this.txtSPaTPushCode = new System.Windows.Forms.TextBox();
            this.gbPortSettings = new System.Windows.Forms.GroupBox();
            this.label58 = new System.Windows.Forms.Label();
            this.cmbHandShake = new System.Windows.Forms.ComboBox();
            this.cmbPortName = new System.Windows.Forms.ComboBox();
            this.cmbBaudRate = new System.Windows.Forms.ComboBox();
            this.cmbStopBits = new System.Windows.Forms.ComboBox();
            this.cmbParity = new System.Windows.Forms.ComboBox();
            this.cmbDataBits = new System.Windows.Forms.ComboBox();
            this.lblComPort = new System.Windows.Forms.Label();
            this.lblStopBits = new System.Windows.Forms.Label();
            this.lblBaudRate = new System.Windows.Forms.Label();
            this.lblDataBits = new System.Windows.Forms.Label();
            this.label59 = new System.Windows.Forms.Label();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.btnSelectPTLMFile = new System.Windows.Forms.Button();
            this.txtPTLMFile = new System.Windows.Forms.TextBox();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.label51 = new System.Windows.Forms.Label();
            this.label47 = new System.Windows.Forms.Label();
            this.txtSpatMsgTargetPort = new System.Windows.Forms.TextBox();
            this.txtSpatMsgLocalPort = new System.Windows.Forms.TextBox();
            this.label36 = new System.Windows.Forms.Label();
            this.txtRTCMMsgTargetPort = new System.Windows.Forms.TextBox();
            this.label37 = new System.Windows.Forms.Label();
            this.txtRTCMMsgLocalPort = new System.Windows.Forms.TextBox();
            this.label28 = new System.Windows.Forms.Label();
            this.txtSSMMsgTargetPort = new System.Windows.Forms.TextBox();
            this.label29 = new System.Windows.Forms.Label();
            this.txtSSMMsgLocalPort = new System.Windows.Forms.TextBox();
            this.label44 = new System.Windows.Forms.Label();
            this.txtSRMMsgTargetPort = new System.Windows.Forms.TextBox();
            this.label43 = new System.Windows.Forms.Label();
            this.txtSRMMsgLocalPort = new System.Windows.Forms.TextBox();
            this.label42 = new System.Windows.Forms.Label();
            this.txtMapMsgTargetPort = new System.Windows.Forms.TextBox();
            this.label40 = new System.Windows.Forms.Label();
            this.txtMapMsgLocalPort = new System.Windows.Forms.TextBox();
            this.label39 = new System.Windows.Forms.Label();
            this.label38 = new System.Windows.Forms.Label();
            this.label35 = new System.Windows.Forms.Label();
            this.label31 = new System.Windows.Forms.Label();
            this.txtSPATSystemSPATPort = new System.Windows.Forms.TextBox();
            this.txtTSCNTCIPPort = new System.Windows.Forms.TextBox();
            this.groupBox9 = new System.Windows.Forms.GroupBox();
            this.label54 = new System.Windows.Forms.Label();
            this.txtState = new System.Windows.Forms.TextBox();
            this.label53 = new System.Windows.Forms.Label();
            this.txtCity = new System.Windows.Forms.TextBox();
            this.label49 = new System.Windows.Forms.Label();
            this.label50 = new System.Windows.Forms.Label();
            this.txtIntersectionName = new System.Windows.Forms.TextBox();
            this.txtIntersectionID = new System.Windows.Forms.TextBox();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.label30 = new System.Windows.Forms.Label();
            this.label21 = new System.Windows.Forms.Label();
            this.label20 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.txtSPATSystemIPV6Address = new System.Windows.Forms.TextBox();
            this.txtTSCIPV4Address = new System.Windows.Forms.TextBox();
            this.txtRSEIPV6Address = new System.Windows.Forms.TextBox();
            this.txtSPATSystemIPV4Address = new System.Windows.Forms.TextBox();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.btnModifySPATMsgDir = new System.Windows.Forms.Button();
            this.txtSPATDailyLogFolder = new System.Windows.Forms.TextBox();
            this.btnSaveSPATConfiguration = new System.Windows.Forms.Button();
            this.tabpgPeds = new System.Windows.Forms.TabPage();
            this.groupBox12 = new System.Windows.Forms.GroupBox();
            this.label127 = new System.Windows.Forms.Label();
            this.txtMvmntPedDets = new System.Windows.Forms.TextBox();
            this.txtNoCalls = new System.Windows.Forms.TextBox();
            this.chkPedActive = new System.Windows.Forms.CheckBox();
            this.groupBox11 = new System.Windows.Forms.GroupBox();
            this.label120 = new System.Windows.Forms.Label();
            this.txtMvmntPedCalls = new System.Windows.Forms.TextBox();
            this.groupBox10 = new System.Windows.Forms.GroupBox();
            this.txtPedDet = new System.Windows.Forms.TextBox();
            this.txtByte242 = new System.Windows.Forms.TextBox();
            this.label118 = new System.Windows.Forms.Label();
            this.label124 = new System.Windows.Forms.Label();
            this.txtByte241 = new System.Windows.Forms.TextBox();
            this.txtBytes241242 = new System.Windows.Forms.TextBox();
            this.label125 = new System.Windows.Forms.Label();
            this.label126 = new System.Windows.Forms.Label();
            this.groupBox7 = new System.Windows.Forms.GroupBox();
            this.txtByte244 = new System.Windows.Forms.TextBox();
            this.label113 = new System.Windows.Forms.Label();
            this.label114 = new System.Windows.Forms.Label();
            this.txtByte243 = new System.Windows.Forms.TextBox();
            this.txtBytes243244 = new System.Windows.Forms.TextBox();
            this.label117 = new System.Windows.Forms.Label();
            this.txtPedCalls = new System.Windows.Forms.TextBox();
            this.label119 = new System.Windows.Forms.Label();
            this.grpPedSimulator = new System.Windows.Forms.GroupBox();
            this.chkPedDetect15 = new System.Windows.Forms.CheckBox();
            this.label91 = new System.Windows.Forms.Label();
            this.label90 = new System.Windows.Forms.Label();
            this.label89 = new System.Windows.Forms.Label();
            this.label88 = new System.Windows.Forms.Label();
            this.label87 = new System.Windows.Forms.Label();
            this.label86 = new System.Windows.Forms.Label();
            this.label85 = new System.Windows.Forms.Label();
            this.label84 = new System.Windows.Forms.Label();
            this.label83 = new System.Windows.Forms.Label();
            this.label82 = new System.Windows.Forms.Label();
            this.label81 = new System.Windows.Forms.Label();
            this.label80 = new System.Windows.Forms.Label();
            this.label79 = new System.Windows.Forms.Label();
            this.label78 = new System.Windows.Forms.Label();
            this.label77 = new System.Windows.Forms.Label();
            this.label76 = new System.Windows.Forms.Label();
            this.label75 = new System.Windows.Forms.Label();
            this.label69 = new System.Windows.Forms.Label();
            this.chkPedDetect16 = new System.Windows.Forms.CheckBox();
            this.chkPedDetect14 = new System.Windows.Forms.CheckBox();
            this.chkPedDetect13 = new System.Windows.Forms.CheckBox();
            this.chkPedDetect12 = new System.Windows.Forms.CheckBox();
            this.chkPedDetect11 = new System.Windows.Forms.CheckBox();
            this.chkPedDetect10 = new System.Windows.Forms.CheckBox();
            this.chkPedDetect9 = new System.Windows.Forms.CheckBox();
            this.chkPedDetect8 = new System.Windows.Forms.CheckBox();
            this.chkPedDetect7 = new System.Windows.Forms.CheckBox();
            this.chkPedDetect6 = new System.Windows.Forms.CheckBox();
            this.chkPedDetect5 = new System.Windows.Forms.CheckBox();
            this.chkPedDetect4 = new System.Windows.Forms.CheckBox();
            this.chkPedDetect3 = new System.Windows.Forms.CheckBox();
            this.chkPedDetect2 = new System.Windows.Forms.CheckBox();
            this.chkPedDetect1 = new System.Windows.Forms.CheckBox();
            this.chkPedCall16 = new System.Windows.Forms.CheckBox();
            this.chkPedCall15 = new System.Windows.Forms.CheckBox();
            this.chkPedCall14 = new System.Windows.Forms.CheckBox();
            this.chkPedCall13 = new System.Windows.Forms.CheckBox();
            this.chkPedCall12 = new System.Windows.Forms.CheckBox();
            this.chkPedCall11 = new System.Windows.Forms.CheckBox();
            this.chkPedCall10 = new System.Windows.Forms.CheckBox();
            this.chkPedCall9 = new System.Windows.Forms.CheckBox();
            this.chkPedCall8 = new System.Windows.Forms.CheckBox();
            this.chkPedCall7 = new System.Windows.Forms.CheckBox();
            this.chkPedCall6 = new System.Windows.Forms.CheckBox();
            this.chkPedCall5 = new System.Windows.Forms.CheckBox();
            this.chkPedCall4 = new System.Windows.Forms.CheckBox();
            this.chkPedCall3 = new System.Windows.Forms.CheckBox();
            this.chkPedCall2 = new System.Windows.Forms.CheckBox();
            this.chkPedCall1 = new System.Windows.Forms.CheckBox();
            this.btnPedSimulator = new System.Windows.Forms.Button();
            this.tabpgPRG = new System.Windows.Forms.TabPage();
            this.splitContainer8 = new System.Windows.Forms.SplitContainer();
            this.lstboxPRG = new System.Windows.Forms.ListBox();
            this.chkProgrammedFlash1 = new System.Windows.Forms.CheckBox();
            this.chkCoordinationInTransition1 = new System.Windows.Forms.CheckBox();
            this.chkCoordination1 = new System.Windows.Forms.CheckBox();
            this.chkTSP1 = new System.Windows.Forms.CheckBox();
            this.chkPreempt1 = new System.Windows.Forms.CheckBox();
            this.chkFaultFlash1 = new System.Windows.Forms.CheckBox();
            this.chkStopTime1 = new System.Windows.Forms.CheckBox();
            this.chkManualControl1 = new System.Windows.Forms.CheckBox();
            this.splitContainer9 = new System.Windows.Forms.SplitContainer();
            this.txtPRGActivity = new System.Windows.Forms.TextBox();
            this.txtSSMActivity = new System.Windows.Forms.TextBox();
            this.tabpgPriorityStrategies = new System.Windows.Forms.TabPage();
            this.splitContainer10 = new System.Windows.Forms.SplitContainer();
            this.button4 = new System.Windows.Forms.Button();
            this.label74 = new System.Windows.Forms.Label();
            this.textBox14 = new System.Windows.Forms.TextBox();
            this.label73 = new System.Windows.Forms.Label();
            this.label72 = new System.Windows.Forms.Label();
            this.label71 = new System.Windows.Forms.Label();
            this.label70 = new System.Windows.Forms.Label();
            this.comboBox12 = new System.Windows.Forms.ComboBox();
            this.comboBox9 = new System.Windows.Forms.ComboBox();
            this.comboBox4 = new System.Windows.Forms.ComboBox();
            this.textBox13 = new System.Windows.Forms.TextBox();
            this.splitContainer11 = new System.Windows.Forms.SplitContainer();
            this.checkedListBox1 = new System.Windows.Forms.CheckedListBox();
            this.button6 = new System.Windows.Forms.Button();
            this.button5 = new System.Windows.Forms.Button();
            this.tmrUDPClient = new System.Windows.Forms.Timer(this.components);
            this.folderBrowserDialog1 = new System.Windows.Forms.FolderBrowserDialog();
            this.spGPS = new System.IO.Ports.SerialPort(this.components);
            this.tmrGPS = new System.Windows.Forms.Timer(this.components);
            this.tmrSRM = new System.Windows.Forms.Timer(this.components);
            this.openFileDialog1 = new System.Windows.Forms.OpenFileDialog();
            this.tabCntrlSAPTSystem.SuspendLayout();
            this.tabpgSPATMsg.SuspendLayout();
            this.grpStatusDisplay.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.axaxNtcipIO1)).BeginInit();
            this.tabpgActivityLog.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer1)).BeginInit();
            this.splitContainer1.Panel1.SuspendLayout();
            this.splitContainer1.Panel2.SuspendLayout();
            this.splitContainer1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer2)).BeginInit();
            this.splitContainer2.Panel1.SuspendLayout();
            this.splitContainer2.Panel2.SuspendLayout();
            this.splitContainer2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer3)).BeginInit();
            this.splitContainer3.Panel1.SuspendLayout();
            this.splitContainer3.Panel2.SuspendLayout();
            this.splitContainer3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer4)).BeginInit();
            this.splitContainer4.Panel1.SuspendLayout();
            this.splitContainer4.Panel2.SuspendLayout();
            this.splitContainer4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer5)).BeginInit();
            this.splitContainer5.Panel1.SuspendLayout();
            this.splitContainer5.Panel2.SuspendLayout();
            this.splitContainer5.SuspendLayout();
            this.tabpgEnableSPATMsgPush.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer7)).BeginInit();
            this.splitContainer7.Panel1.SuspendLayout();
            this.splitContainer7.Panel2.SuspendLayout();
            this.splitContainer7.SuspendLayout();
            this.groupBox5.SuspendLayout();
            this.groupBox8.SuspendLayout();
            this.tabpgGPS.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer6)).BeginInit();
            this.splitContainer6.Panel1.SuspendLayout();
            this.splitContainer6.Panel2.SuspendLayout();
            this.splitContainer6.SuspendLayout();
            this.tabpgSPATConfiguration.SuspendLayout();
            this.pnlSPATConfiguration.SuspendLayout();
            this.groupBox6.SuspendLayout();
            this.gbPortSettings.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.groupBox9.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.groupBox4.SuspendLayout();
            this.tabpgPeds.SuspendLayout();
            this.groupBox12.SuspendLayout();
            this.groupBox11.SuspendLayout();
            this.groupBox10.SuspendLayout();
            this.groupBox7.SuspendLayout();
            this.grpPedSimulator.SuspendLayout();
            this.tabpgPRG.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer8)).BeginInit();
            this.splitContainer8.Panel1.SuspendLayout();
            this.splitContainer8.Panel2.SuspendLayout();
            this.splitContainer8.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer9)).BeginInit();
            this.splitContainer9.Panel1.SuspendLayout();
            this.splitContainer9.Panel2.SuspendLayout();
            this.splitContainer9.SuspendLayout();
            this.tabpgPriorityStrategies.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer10)).BeginInit();
            this.splitContainer10.Panel1.SuspendLayout();
            this.splitContainer10.Panel2.SuspendLayout();
            this.splitContainer10.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer11)).BeginInit();
            this.splitContainer11.Panel1.SuspendLayout();
            this.splitContainer11.Panel2.SuspendLayout();
            this.splitContainer11.SuspendLayout();
            this.SuspendLayout();
            // 
            // tabCntrlSAPTSystem
            // 
            this.tabCntrlSAPTSystem.Appearance = System.Windows.Forms.TabAppearance.Buttons;
            this.tabCntrlSAPTSystem.Controls.Add(this.tabpgSPATMsg);
            this.tabCntrlSAPTSystem.Controls.Add(this.tabpgActivityLog);
            this.tabCntrlSAPTSystem.Controls.Add(this.tabpgEnableSPATMsgPush);
            this.tabCntrlSAPTSystem.Controls.Add(this.tabpgGPS);
            this.tabCntrlSAPTSystem.Controls.Add(this.tabpgSPATConfiguration);
            this.tabCntrlSAPTSystem.Controls.Add(this.tabpgPeds);
            this.tabCntrlSAPTSystem.Controls.Add(this.tabpgPRG);
            this.tabCntrlSAPTSystem.Controls.Add(this.tabpgPriorityStrategies);
            this.tabCntrlSAPTSystem.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tabCntrlSAPTSystem.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tabCntrlSAPTSystem.Location = new System.Drawing.Point(0, 0);
            this.tabCntrlSAPTSystem.Name = "tabCntrlSAPTSystem";
            this.tabCntrlSAPTSystem.SelectedIndex = 0;
            this.tabCntrlSAPTSystem.Size = new System.Drawing.Size(1017, 691);
            this.tabCntrlSAPTSystem.TabIndex = 0;
            // 
            // tabpgSPATMsg
            // 
            this.tabpgSPATMsg.Controls.Add(this.chkLaneMvmnt);
            this.tabpgSPATMsg.Controls.Add(this.chkSPaTMsg);
            this.tabpgSPATMsg.Controls.Add(this.chkTSCData);
            this.tabpgSPATMsg.Controls.Add(this.chkEnableDataLogging);
            this.tabpgSPATMsg.Controls.Add(this.txtDiscontinuousFlag);
            this.tabpgSPATMsg.Controls.Add(this.chkEnableSSMMessagePush);
            this.tabpgSPATMsg.Controls.Add(this.label32);
            this.tabpgSPATMsg.Controls.Add(this.txtTimeBaseActionStatus);
            this.tabpgSPATMsg.Controls.Add(this.chkEnableSpatMessagePush);
            this.tabpgSPATMsg.Controls.Add(this.chkEnableDisableSPAT);
            this.tabpgSPATMsg.Controls.Add(this.btnExitSPATSystem);
            this.tabpgSPATMsg.Controls.Add(this.btnHaltSPATSystem);
            this.tabpgSPATMsg.Controls.Add(this.grpStatusDisplay);
            this.tabpgSPATMsg.Controls.Add(this.chkProgrammedFlash);
            this.tabpgSPATMsg.Controls.Add(this.chkDiscontinuousFlag);
            this.tabpgSPATMsg.Controls.Add(this.chkCoordinationInTransition);
            this.tabpgSPATMsg.Controls.Add(this.chkCoordination);
            this.tabpgSPATMsg.Controls.Add(this.chkTSP);
            this.tabpgSPATMsg.Controls.Add(this.chkPreempt);
            this.tabpgSPATMsg.Controls.Add(this.chkFaultFlash);
            this.tabpgSPATMsg.Controls.Add(this.chkStopTime);
            this.tabpgSPATMsg.Controls.Add(this.chkManualControl);
            this.tabpgSPATMsg.Controls.Add(this.lblControllerConnection);
            this.tabpgSPATMsg.Location = new System.Drawing.Point(4, 32);
            this.tabpgSPATMsg.Name = "tabpgSPATMsg";
            this.tabpgSPATMsg.Padding = new System.Windows.Forms.Padding(3);
            this.tabpgSPATMsg.Size = new System.Drawing.Size(1009, 655);
            this.tabpgSPATMsg.TabIndex = 0;
            this.tabpgSPATMsg.Text = "SPATMsg";
            this.tabpgSPATMsg.UseVisualStyleBackColor = true;
            // 
            // chkLaneMvmnt
            // 
            this.chkLaneMvmnt.BackColor = System.Drawing.Color.Yellow;
            this.chkLaneMvmnt.ForeColor = System.Drawing.Color.Black;
            this.chkLaneMvmnt.Location = new System.Drawing.Point(779, 544);
            this.chkLaneMvmnt.Name = "chkLaneMvmnt";
            this.chkLaneMvmnt.Size = new System.Drawing.Size(193, 24);
            this.chkLaneMvmnt.TabIndex = 144;
            this.chkLaneMvmnt.Text = "Lane Movement Info";
            this.chkLaneMvmnt.UseVisualStyleBackColor = false;
            this.chkLaneMvmnt.CheckedChanged += new System.EventHandler(this.chkLaneMvmnt_CheckedChanged);
            // 
            // chkSPaTMsg
            // 
            this.chkSPaTMsg.BackColor = System.Drawing.Color.Yellow;
            this.chkSPaTMsg.ForeColor = System.Drawing.Color.Black;
            this.chkSPaTMsg.Location = new System.Drawing.Point(779, 487);
            this.chkSPaTMsg.Name = "chkSPaTMsg";
            this.chkSPaTMsg.Size = new System.Drawing.Size(193, 24);
            this.chkSPaTMsg.TabIndex = 143;
            this.chkSPaTMsg.Text = "SPaT Message";
            this.chkSPaTMsg.UseVisualStyleBackColor = false;
            this.chkSPaTMsg.CheckedChanged += new System.EventHandler(this.chkSPaTMsg_CheckedChanged);
            // 
            // chkTSCData
            // 
            this.chkTSCData.BackColor = System.Drawing.Color.Yellow;
            this.chkTSCData.ForeColor = System.Drawing.Color.Black;
            this.chkTSCData.Location = new System.Drawing.Point(779, 515);
            this.chkTSCData.Name = "chkTSCData";
            this.chkTSCData.Size = new System.Drawing.Size(193, 24);
            this.chkTSCData.TabIndex = 142;
            this.chkTSCData.Text = "TSC SPaT Data";
            this.chkTSCData.UseVisualStyleBackColor = false;
            this.chkTSCData.CheckedChanged += new System.EventHandler(this.chkTSCData_CheckedChanged);
            // 
            // chkEnableDataLogging
            // 
            this.chkEnableDataLogging.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.chkEnableDataLogging.ForeColor = System.Drawing.Color.Black;
            this.chkEnableDataLogging.Location = new System.Drawing.Point(748, 454);
            this.chkEnableDataLogging.Name = "chkEnableDataLogging";
            this.chkEnableDataLogging.Size = new System.Drawing.Size(235, 24);
            this.chkEnableDataLogging.TabIndex = 141;
            this.chkEnableDataLogging.Text = "Enable Data Logging";
            this.chkEnableDataLogging.UseVisualStyleBackColor = false;
            this.chkEnableDataLogging.CheckedChanged += new System.EventHandler(this.chkEnableDataLogging_CheckedChanged_1);
            // 
            // txtDiscontinuousFlag
            // 
            this.txtDiscontinuousFlag.BackColor = System.Drawing.Color.Black;
            this.txtDiscontinuousFlag.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtDiscontinuousFlag.ForeColor = System.Drawing.Color.White;
            this.txtDiscontinuousFlag.Location = new System.Drawing.Point(931, 129);
            this.txtDiscontinuousFlag.Name = "txtDiscontinuousFlag";
            this.txtDiscontinuousFlag.Size = new System.Drawing.Size(64, 26);
            this.txtDiscontinuousFlag.TabIndex = 132;
            // 
            // chkEnableSSMMessagePush
            // 
            this.chkEnableSSMMessagePush.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.chkEnableSSMMessagePush.Location = new System.Drawing.Point(748, 581);
            this.chkEnableSSMMessagePush.Name = "chkEnableSSMMessagePush";
            this.chkEnableSSMMessagePush.Size = new System.Drawing.Size(235, 24);
            this.chkEnableSSMMessagePush.TabIndex = 140;
            this.chkEnableSSMMessagePush.Text = "Enable SSM Broadcast";
            this.chkEnableSSMMessagePush.UseVisualStyleBackColor = false;
            // 
            // label32
            // 
            this.label32.ForeColor = System.Drawing.Color.Black;
            this.label32.Location = new System.Drawing.Point(775, 98);
            this.label32.Name = "label32";
            this.label32.Size = new System.Drawing.Size(153, 26);
            this.label32.TabIndex = 139;
            this.label32.Text = "TimeBaseAction#:";
            // 
            // txtTimeBaseActionStatus
            // 
            this.txtTimeBaseActionStatus.BackColor = System.Drawing.Color.Black;
            this.txtTimeBaseActionStatus.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtTimeBaseActionStatus.ForeColor = System.Drawing.Color.White;
            this.txtTimeBaseActionStatus.Location = new System.Drawing.Point(931, 98);
            this.txtTimeBaseActionStatus.Name = "txtTimeBaseActionStatus";
            this.txtTimeBaseActionStatus.Size = new System.Drawing.Size(64, 26);
            this.txtTimeBaseActionStatus.TabIndex = 138;
            // 
            // chkEnableSpatMessagePush
            // 
            this.chkEnableSpatMessagePush.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.chkEnableSpatMessagePush.Location = new System.Drawing.Point(748, 426);
            this.chkEnableSpatMessagePush.Name = "chkEnableSpatMessagePush";
            this.chkEnableSpatMessagePush.Size = new System.Drawing.Size(235, 24);
            this.chkEnableSpatMessagePush.TabIndex = 137;
            this.chkEnableSpatMessagePush.Text = "Enable SPAT Broadcast";
            this.chkEnableSpatMessagePush.UseVisualStyleBackColor = false;
            this.chkEnableSpatMessagePush.CheckedChanged += new System.EventHandler(this.chkEnableSpatMessagePush_CheckedChanged);
            // 
            // chkEnableDisableSPAT
            // 
            this.chkEnableDisableSPAT.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.chkEnableDisableSPAT.Location = new System.Drawing.Point(748, 399);
            this.chkEnableDisableSPAT.Name = "chkEnableDisableSPAT";
            this.chkEnableDisableSPAT.Size = new System.Drawing.Size(235, 24);
            this.chkEnableDisableSPAT.TabIndex = 136;
            this.chkEnableDisableSPAT.Text = "Enable SPAT Reception";
            this.chkEnableDisableSPAT.UseVisualStyleBackColor = false;
            this.chkEnableDisableSPAT.CheckedChanged += new System.EventHandler(this.chkEnableDisableSPAT_CheckedChanged);
            // 
            // btnExitSPATSystem
            // 
            this.btnExitSPATSystem.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.btnExitSPATSystem.Location = new System.Drawing.Point(459, 607);
            this.btnExitSPATSystem.Name = "btnExitSPATSystem";
            this.btnExitSPATSystem.Size = new System.Drawing.Size(171, 40);
            this.btnExitSPATSystem.TabIndex = 135;
            this.btnExitSPATSystem.Text = "Exit SPAT System";
            this.btnExitSPATSystem.UseVisualStyleBackColor = false;
            this.btnExitSPATSystem.Click += new System.EventHandler(this.btnExitSPATSystem_Click);
            // 
            // btnHaltSPATSystem
            // 
            this.btnHaltSPATSystem.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.btnHaltSPATSystem.Enabled = false;
            this.btnHaltSPATSystem.Location = new System.Drawing.Point(234, 607);
            this.btnHaltSPATSystem.Name = "btnHaltSPATSystem";
            this.btnHaltSPATSystem.Size = new System.Drawing.Size(171, 40);
            this.btnHaltSPATSystem.TabIndex = 134;
            this.btnHaltSPATSystem.Text = "Halt SPAT System";
            this.btnHaltSPATSystem.UseVisualStyleBackColor = false;
            this.btnHaltSPATSystem.Click += new System.EventHandler(this.btnHaltSPATSystem_Click);
            // 
            // grpStatusDisplay
            // 
            this.grpStatusDisplay.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.grpStatusDisplay.BackColor = System.Drawing.Color.LightGray;
            this.grpStatusDisplay.Controls.Add(this.lblSysMSec);
            this.grpStatusDisplay.Controls.Add(this.lblTSCMsec);
            this.grpStatusDisplay.Controls.Add(this.txtSysMsec);
            this.grpStatusDisplay.Controls.Add(this.txtTSCMSec);
            this.grpStatusDisplay.Controls.Add(this.btnHideSysTime);
            this.grpStatusDisplay.Controls.Add(this.btnHideTSCTime);
            this.grpStatusDisplay.Controls.Add(this.txtSysTime);
            this.grpStatusDisplay.Controls.Add(this.txtTSCMsgNo);
            this.grpStatusDisplay.Controls.Add(this.lblTSCMsgNo);
            this.grpStatusDisplay.Controls.Add(this.lblTSCTime);
            this.grpStatusDisplay.Controls.Add(this.txtTSCMsgTime);
            this.grpStatusDisplay.Controls.Add(this.txtSpatMsgGenerationTime);
            this.grpStatusDisplay.Controls.Add(this.lblSpatTime);
            this.grpStatusDisplay.Controls.Add(this.txtTSCMsgInterval);
            this.grpStatusDisplay.Controls.Add(this.lblTSCInterval);
            this.grpStatusDisplay.Controls.Add(this.txtSPaTSysInterval);
            this.grpStatusDisplay.Controls.Add(this.lblSysInterval);
            this.grpStatusDisplay.Controls.Add(this.lblPhase1);
            this.grpStatusDisplay.Controls.Add(this.lblOvlp16);
            this.grpStatusDisplay.Controls.Add(this.lblOvlp15);
            this.grpStatusDisplay.Controls.Add(this.lblOvlp14);
            this.grpStatusDisplay.Controls.Add(this.lblOvlp13);
            this.grpStatusDisplay.Controls.Add(this.lblOvlp12);
            this.grpStatusDisplay.Controls.Add(this.lblOvlp11);
            this.grpStatusDisplay.Controls.Add(this.lblOvlp10);
            this.grpStatusDisplay.Controls.Add(this.lblOvlp9);
            this.grpStatusDisplay.Controls.Add(this.lblOvlp8);
            this.grpStatusDisplay.Controls.Add(this.lblOvlp7);
            this.grpStatusDisplay.Controls.Add(this.lblOvlp6);
            this.grpStatusDisplay.Controls.Add(this.lblOvlp5);
            this.grpStatusDisplay.Controls.Add(this.lblOvlp4);
            this.grpStatusDisplay.Controls.Add(this.lblOvlp3);
            this.grpStatusDisplay.Controls.Add(this.lblOvlp2);
            this.grpStatusDisplay.Controls.Add(this.lblOvlp1);
            this.grpStatusDisplay.Controls.Add(this.lblPhase16);
            this.grpStatusDisplay.Controls.Add(this.lblPhase15);
            this.grpStatusDisplay.Controls.Add(this.lblPhase14);
            this.grpStatusDisplay.Controls.Add(this.lblPhase13);
            this.grpStatusDisplay.Controls.Add(this.lblPhase12);
            this.grpStatusDisplay.Controls.Add(this.lblPhase11);
            this.grpStatusDisplay.Controls.Add(this.lblPhase10);
            this.grpStatusDisplay.Controls.Add(this.lblPhase9);
            this.grpStatusDisplay.Controls.Add(this.lblPhase8);
            this.grpStatusDisplay.Controls.Add(this.lblPhase7);
            this.grpStatusDisplay.Controls.Add(this.lblPhase6);
            this.grpStatusDisplay.Controls.Add(this.lblPhase5);
            this.grpStatusDisplay.Controls.Add(this.lblPhase4);
            this.grpStatusDisplay.Controls.Add(this.lblPhase3);
            this.grpStatusDisplay.Controls.Add(this.lblPhase2);
            this.grpStatusDisplay.Controls.Add(this.label48);
            this.grpStatusDisplay.Controls.Add(this.lblSysTime);
            this.grpStatusDisplay.Controls.Add(this.axaxNtcipIO1);
            this.grpStatusDisplay.Controls.Add(this.label41);
            this.grpStatusDisplay.Controls.Add(this.txtPed2);
            this.grpStatusDisplay.Controls.Add(this.txtPed1);
            this.grpStatusDisplay.Controls.Add(this.txtPed16);
            this.grpStatusDisplay.Controls.Add(this.txtPed3);
            this.grpStatusDisplay.Controls.Add(this.txtPed15);
            this.grpStatusDisplay.Controls.Add(this.txtPed4);
            this.grpStatusDisplay.Controls.Add(this.txtPed14);
            this.grpStatusDisplay.Controls.Add(this.txtPed5);
            this.grpStatusDisplay.Controls.Add(this.txtPed13);
            this.grpStatusDisplay.Controls.Add(this.txtPed6);
            this.grpStatusDisplay.Controls.Add(this.txtPed12);
            this.grpStatusDisplay.Controls.Add(this.txtPed7);
            this.grpStatusDisplay.Controls.Add(this.txtPed11);
            this.grpStatusDisplay.Controls.Add(this.txtPed8);
            this.grpStatusDisplay.Controls.Add(this.txtPed10);
            this.grpStatusDisplay.Controls.Add(this.txtPed9);
            this.grpStatusDisplay.Controls.Add(this.label26);
            this.grpStatusDisplay.Controls.Add(this.txtOMaxTime2);
            this.grpStatusDisplay.Controls.Add(this.txtOMaxTime16);
            this.grpStatusDisplay.Controls.Add(this.txtOMaxTime15);
            this.grpStatusDisplay.Controls.Add(this.txtOMaxTime14);
            this.grpStatusDisplay.Controls.Add(this.txtOMaxTime13);
            this.grpStatusDisplay.Controls.Add(this.txtOMaxTime12);
            this.grpStatusDisplay.Controls.Add(this.txtOMaxTime11);
            this.grpStatusDisplay.Controls.Add(this.txtOMaxTime10);
            this.grpStatusDisplay.Controls.Add(this.txtOMaxTime9);
            this.grpStatusDisplay.Controls.Add(this.txtOMaxTime8);
            this.grpStatusDisplay.Controls.Add(this.txtOMaxTime7);
            this.grpStatusDisplay.Controls.Add(this.txtOMaxTime6);
            this.grpStatusDisplay.Controls.Add(this.txtOMaxTime5);
            this.grpStatusDisplay.Controls.Add(this.txtOMaxTime4);
            this.grpStatusDisplay.Controls.Add(this.txtOMaxTime3);
            this.grpStatusDisplay.Controls.Add(this.txtOMaxTime1);
            this.grpStatusDisplay.Controls.Add(this.txtOMinTime2);
            this.grpStatusDisplay.Controls.Add(this.txtOMinTime16);
            this.grpStatusDisplay.Controls.Add(this.txtOMinTime15);
            this.grpStatusDisplay.Controls.Add(this.txtOMinTime14);
            this.grpStatusDisplay.Controls.Add(this.txtOMinTime13);
            this.grpStatusDisplay.Controls.Add(this.txtOMinTime12);
            this.grpStatusDisplay.Controls.Add(this.txtOMinTime11);
            this.grpStatusDisplay.Controls.Add(this.txtOMinTime10);
            this.grpStatusDisplay.Controls.Add(this.txtOMinTime9);
            this.grpStatusDisplay.Controls.Add(this.txtOMinTime8);
            this.grpStatusDisplay.Controls.Add(this.txtOMinTime7);
            this.grpStatusDisplay.Controls.Add(this.txtOMinTime6);
            this.grpStatusDisplay.Controls.Add(this.txtOMinTime5);
            this.grpStatusDisplay.Controls.Add(this.txtOMinTime4);
            this.grpStatusDisplay.Controls.Add(this.txtOMinTime3);
            this.grpStatusDisplay.Controls.Add(this.label27);
            this.grpStatusDisplay.Controls.Add(this.txtOMinTime1);
            this.grpStatusDisplay.Controls.Add(this.label24);
            this.grpStatusDisplay.Controls.Add(this.txtPMaxTime2);
            this.grpStatusDisplay.Controls.Add(this.txtPMaxTime16);
            this.grpStatusDisplay.Controls.Add(this.txtPMaxTime15);
            this.grpStatusDisplay.Controls.Add(this.txtPMaxTime14);
            this.grpStatusDisplay.Controls.Add(this.txtPMaxTime13);
            this.grpStatusDisplay.Controls.Add(this.txtPMaxTime12);
            this.grpStatusDisplay.Controls.Add(this.txtPMaxTime11);
            this.grpStatusDisplay.Controls.Add(this.txtPMaxTime10);
            this.grpStatusDisplay.Controls.Add(this.txtPMaxTime9);
            this.grpStatusDisplay.Controls.Add(this.txtPMaxTime8);
            this.grpStatusDisplay.Controls.Add(this.txtPMaxTime7);
            this.grpStatusDisplay.Controls.Add(this.txtPMaxTime6);
            this.grpStatusDisplay.Controls.Add(this.txtPMaxTime5);
            this.grpStatusDisplay.Controls.Add(this.txtPMaxTime4);
            this.grpStatusDisplay.Controls.Add(this.txtPMaxTime3);
            this.grpStatusDisplay.Controls.Add(this.txtPMaxTime1);
            this.grpStatusDisplay.Controls.Add(this.txtPMinTime2);
            this.grpStatusDisplay.Controls.Add(this.txtPMinTime16);
            this.grpStatusDisplay.Controls.Add(this.txtPMinTime15);
            this.grpStatusDisplay.Controls.Add(this.txtPMinTime14);
            this.grpStatusDisplay.Controls.Add(this.txtPMinTime13);
            this.grpStatusDisplay.Controls.Add(this.txtPMinTime12);
            this.grpStatusDisplay.Controls.Add(this.txtPMinTime11);
            this.grpStatusDisplay.Controls.Add(this.txtPMinTime10);
            this.grpStatusDisplay.Controls.Add(this.txtPMinTime9);
            this.grpStatusDisplay.Controls.Add(this.txtPMinTime8);
            this.grpStatusDisplay.Controls.Add(this.txtPMinTime7);
            this.grpStatusDisplay.Controls.Add(this.txtPMinTime6);
            this.grpStatusDisplay.Controls.Add(this.txtPMinTime5);
            this.grpStatusDisplay.Controls.Add(this.txtPMinTime4);
            this.grpStatusDisplay.Controls.Add(this.txtPMinTime3);
            this.grpStatusDisplay.Controls.Add(this.label25);
            this.grpStatusDisplay.Controls.Add(this.txtPMinTime1);
            this.grpStatusDisplay.Controls.Add(this.label23);
            this.grpStatusDisplay.Controls.Add(this.txtVMaxTime2);
            this.grpStatusDisplay.Controls.Add(this.txtVMaxTime16);
            this.grpStatusDisplay.Controls.Add(this.txtVMaxTime15);
            this.grpStatusDisplay.Controls.Add(this.txtVMaxTime14);
            this.grpStatusDisplay.Controls.Add(this.txtVMaxTime13);
            this.grpStatusDisplay.Controls.Add(this.txtVMaxTime12);
            this.grpStatusDisplay.Controls.Add(this.txtVMaxTime11);
            this.grpStatusDisplay.Controls.Add(this.txtVMaxTime10);
            this.grpStatusDisplay.Controls.Add(this.txtVMaxTime9);
            this.grpStatusDisplay.Controls.Add(this.txtVMaxTime8);
            this.grpStatusDisplay.Controls.Add(this.txtVMaxTime6);
            this.grpStatusDisplay.Controls.Add(this.txtVMaxTime5);
            this.grpStatusDisplay.Controls.Add(this.txtVMaxTime4);
            this.grpStatusDisplay.Controls.Add(this.txtVMaxTime3);
            this.grpStatusDisplay.Controls.Add(this.txtVMaxTime1);
            this.grpStatusDisplay.Controls.Add(this.txtVMinTime2);
            this.grpStatusDisplay.Controls.Add(this.txtVMinTime16);
            this.grpStatusDisplay.Controls.Add(this.txtVMinTime15);
            this.grpStatusDisplay.Controls.Add(this.txtVMinTime14);
            this.grpStatusDisplay.Controls.Add(this.txtVMinTime13);
            this.grpStatusDisplay.Controls.Add(this.txtVMinTime12);
            this.grpStatusDisplay.Controls.Add(this.txtVMinTime11);
            this.grpStatusDisplay.Controls.Add(this.txtVMinTime10);
            this.grpStatusDisplay.Controls.Add(this.txtVMinTime9);
            this.grpStatusDisplay.Controls.Add(this.txtVMinTime8);
            this.grpStatusDisplay.Controls.Add(this.txtVMinTime7);
            this.grpStatusDisplay.Controls.Add(this.txtVMinTime6);
            this.grpStatusDisplay.Controls.Add(this.txtVMinTime5);
            this.grpStatusDisplay.Controls.Add(this.txtVMinTime4);
            this.grpStatusDisplay.Controls.Add(this.txtVMinTime3);
            this.grpStatusDisplay.Controls.Add(this.label22);
            this.grpStatusDisplay.Controls.Add(this.txtVMinTime1);
            this.grpStatusDisplay.Controls.Add(this.label34);
            this.grpStatusDisplay.Controls.Add(this.label33);
            this.grpStatusDisplay.Controls.Add(this.label16);
            this.grpStatusDisplay.Controls.Add(this.label15);
            this.grpStatusDisplay.Controls.Add(this.label14);
            this.grpStatusDisplay.Controls.Add(this.label13);
            this.grpStatusDisplay.Controls.Add(this.label12);
            this.grpStatusDisplay.Controls.Add(this.label11);
            this.grpStatusDisplay.Controls.Add(this.label10);
            this.grpStatusDisplay.Controls.Add(this.label9);
            this.grpStatusDisplay.Controls.Add(this.label8);
            this.grpStatusDisplay.Controls.Add(this.label7);
            this.grpStatusDisplay.Controls.Add(this.label6);
            this.grpStatusDisplay.Controls.Add(this.label5);
            this.grpStatusDisplay.Controls.Add(this.label4);
            this.grpStatusDisplay.Controls.Add(this.label3);
            this.grpStatusDisplay.Controls.Add(this.label2);
            this.grpStatusDisplay.Controls.Add(this.label1);
            this.grpStatusDisplay.Controls.Add(this.shapeContainer1);
            this.grpStatusDisplay.Controls.Add(this.txtVMaxTime7);
            this.grpStatusDisplay.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.grpStatusDisplay.ForeColor = System.Drawing.Color.White;
            this.grpStatusDisplay.Location = new System.Drawing.Point(8, 66);
            this.grpStatusDisplay.Name = "grpStatusDisplay";
            this.grpStatusDisplay.Size = new System.Drawing.Size(708, 535);
            this.grpStatusDisplay.TabIndex = 23;
            this.grpStatusDisplay.TabStop = false;
            // 
            // lblSysMSec
            // 
            this.lblSysMSec.AutoSize = true;
            this.lblSysMSec.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSysMSec.ForeColor = System.Drawing.Color.Black;
            this.lblSysMSec.Location = new System.Drawing.Point(304, 72);
            this.lblSysMSec.Name = "lblSysMSec";
            this.lblSysMSec.Size = new System.Drawing.Size(22, 24);
            this.lblSysMSec.TabIndex = 183;
            this.lblSysMSec.Text = "::";
            this.lblSysMSec.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // lblTSCMsec
            // 
            this.lblTSCMsec.AutoSize = true;
            this.lblTSCMsec.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTSCMsec.ForeColor = System.Drawing.Color.Black;
            this.lblTSCMsec.Location = new System.Drawing.Point(304, 43);
            this.lblTSCMsec.Name = "lblTSCMsec";
            this.lblTSCMsec.Size = new System.Drawing.Size(22, 24);
            this.lblTSCMsec.TabIndex = 182;
            this.lblTSCMsec.Text = "::";
            this.lblTSCMsec.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // txtSysMsec
            // 
            this.txtSysMsec.BackColor = System.Drawing.Color.Black;
            this.txtSysMsec.ForeColor = System.Drawing.Color.White;
            this.txtSysMsec.Location = new System.Drawing.Point(327, 71);
            this.txtSysMsec.Name = "txtSysMsec";
            this.txtSysMsec.Size = new System.Drawing.Size(45, 26);
            this.txtSysMsec.TabIndex = 181;
            // 
            // txtTSCMSec
            // 
            this.txtTSCMSec.BackColor = System.Drawing.Color.Black;
            this.txtTSCMSec.ForeColor = System.Drawing.Color.White;
            this.txtTSCMSec.Location = new System.Drawing.Point(327, 42);
            this.txtTSCMSec.Name = "txtTSCMSec";
            this.txtTSCMSec.Size = new System.Drawing.Size(45, 26);
            this.txtTSCMSec.TabIndex = 180;
            // 
            // btnHideSysTime
            // 
            this.btnHideSysTime.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.btnHideSysTime.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnHideSysTime.ForeColor = System.Drawing.Color.Black;
            this.btnHideSysTime.Location = new System.Drawing.Point(10, 69);
            this.btnHideSysTime.Name = "btnHideSysTime";
            this.btnHideSysTime.Size = new System.Drawing.Size(167, 30);
            this.btnHideSysTime.TabIndex = 179;
            this.btnHideSysTime.Text = "Hide System Time";
            this.btnHideSysTime.UseVisualStyleBackColor = false;
            this.btnHideSysTime.Click += new System.EventHandler(this.btnHideSysTime_Click);
            // 
            // btnHideTSCTime
            // 
            this.btnHideTSCTime.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.btnHideTSCTime.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnHideTSCTime.ForeColor = System.Drawing.Color.Black;
            this.btnHideTSCTime.Location = new System.Drawing.Point(10, 40);
            this.btnHideTSCTime.Name = "btnHideTSCTime";
            this.btnHideTSCTime.Size = new System.Drawing.Size(167, 30);
            this.btnHideTSCTime.TabIndex = 178;
            this.btnHideTSCTime.Text = "Hide TSC Time";
            this.btnHideTSCTime.UseVisualStyleBackColor = false;
            this.btnHideTSCTime.Click += new System.EventHandler(this.btnHideTSCTime_Click);
            // 
            // txtSysTime
            // 
            this.txtSysTime.BackColor = System.Drawing.Color.Black;
            this.txtSysTime.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtSysTime.ForeColor = System.Drawing.Color.White;
            this.txtSysTime.Location = new System.Drawing.Point(226, 71);
            this.txtSysTime.Name = "txtSysTime";
            this.txtSysTime.Size = new System.Drawing.Size(77, 26);
            this.txtSysTime.TabIndex = 128;
            // 
            // txtTSCMsgNo
            // 
            this.txtTSCMsgNo.BackColor = System.Drawing.Color.Black;
            this.txtTSCMsgNo.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtTSCMsgNo.ForeColor = System.Drawing.Color.White;
            this.txtTSCMsgNo.Location = new System.Drawing.Point(663, 42);
            this.txtTSCMsgNo.Name = "txtTSCMsgNo";
            this.txtTSCMsgNo.Size = new System.Drawing.Size(39, 26);
            this.txtTSCMsgNo.TabIndex = 131;
            // 
            // lblTSCMsgNo
            // 
            this.lblTSCMsgNo.ForeColor = System.Drawing.Color.Black;
            this.lblTSCMsgNo.Location = new System.Drawing.Point(599, 44);
            this.lblTSCMsgNo.Name = "lblTSCMsgNo";
            this.lblTSCMsgNo.Size = new System.Drawing.Size(58, 23);
            this.lblTSCMsgNo.TabIndex = 132;
            this.lblTSCMsgNo.Text = "Msg#";
            this.lblTSCMsgNo.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // lblTSCTime
            // 
            this.lblTSCTime.ForeColor = System.Drawing.Color.Black;
            this.lblTSCTime.Location = new System.Drawing.Point(168, 44);
            this.lblTSCTime.Name = "lblTSCTime";
            this.lblTSCTime.Size = new System.Drawing.Size(54, 23);
            this.lblTSCTime.TabIndex = 174;
            this.lblTSCTime.Text = "Time";
            this.lblTSCTime.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // txtTSCMsgTime
            // 
            this.txtTSCMsgTime.BackColor = System.Drawing.Color.Black;
            this.txtTSCMsgTime.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtTSCMsgTime.ForeColor = System.Drawing.Color.White;
            this.txtTSCMsgTime.Location = new System.Drawing.Point(226, 42);
            this.txtTSCMsgTime.Name = "txtTSCMsgTime";
            this.txtTSCMsgTime.Size = new System.Drawing.Size(77, 26);
            this.txtTSCMsgTime.TabIndex = 173;
            // 
            // txtSpatMsgGenerationTime
            // 
            this.txtSpatMsgGenerationTime.BackColor = System.Drawing.Color.Black;
            this.txtSpatMsgGenerationTime.ForeColor = System.Drawing.Color.White;
            this.txtSpatMsgGenerationTime.Location = new System.Drawing.Point(663, 71);
            this.txtSpatMsgGenerationTime.Name = "txtSpatMsgGenerationTime";
            this.txtSpatMsgGenerationTime.Size = new System.Drawing.Size(39, 26);
            this.txtSpatMsgGenerationTime.TabIndex = 172;
            // 
            // lblSpatTime
            // 
            this.lblSpatTime.ForeColor = System.Drawing.Color.Black;
            this.lblSpatTime.Location = new System.Drawing.Point(545, 73);
            this.lblSpatTime.Name = "lblSpatTime";
            this.lblSpatTime.Size = new System.Drawing.Size(114, 23);
            this.lblSpatTime.TabIndex = 171;
            this.lblSpatTime.Text = "SPaT (msec)";
            this.lblSpatTime.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // txtTSCMsgInterval
            // 
            this.txtTSCMsgInterval.BackColor = System.Drawing.Color.Black;
            this.txtTSCMsgInterval.ForeColor = System.Drawing.Color.White;
            this.txtTSCMsgInterval.Location = new System.Drawing.Point(500, 42);
            this.txtTSCMsgInterval.Name = "txtTSCMsgInterval";
            this.txtTSCMsgInterval.Size = new System.Drawing.Size(45, 26);
            this.txtTSCMsgInterval.TabIndex = 170;
            // 
            // lblTSCInterval
            // 
            this.lblTSCInterval.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTSCInterval.ForeColor = System.Drawing.Color.Black;
            this.lblTSCInterval.Location = new System.Drawing.Point(369, 44);
            this.lblTSCInterval.Name = "lblTSCInterval";
            this.lblTSCInterval.Size = new System.Drawing.Size(125, 23);
            this.lblTSCInterval.TabIndex = 169;
            this.lblTSCInterval.Text = "Interval(msec)";
            this.lblTSCInterval.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // txtSPaTSysInterval
            // 
            this.txtSPaTSysInterval.BackColor = System.Drawing.Color.Black;
            this.txtSPaTSysInterval.ForeColor = System.Drawing.Color.White;
            this.txtSPaTSysInterval.Location = new System.Drawing.Point(500, 71);
            this.txtSPaTSysInterval.Name = "txtSPaTSysInterval";
            this.txtSPaTSysInterval.Size = new System.Drawing.Size(45, 26);
            this.txtSPaTSysInterval.TabIndex = 168;
            // 
            // lblSysInterval
            // 
            this.lblSysInterval.AccessibleDescription = "Msg";
            this.lblSysInterval.ForeColor = System.Drawing.Color.Black;
            this.lblSysInterval.Location = new System.Drawing.Point(369, 73);
            this.lblSysInterval.Name = "lblSysInterval";
            this.lblSysInterval.Size = new System.Drawing.Size(125, 23);
            this.lblSysInterval.TabIndex = 167;
            this.lblSysInterval.Text = "Interval(msec)";
            this.lblSysInterval.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // lblPhase1
            // 
            this.lblPhase1.BackColor = System.Drawing.Color.Transparent;
            this.lblPhase1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPhase1.ForeColor = System.Drawing.Color.Black;
            this.lblPhase1.Location = new System.Drawing.Point(65, 150);
            this.lblPhase1.Name = "lblPhase1";
            this.lblPhase1.Size = new System.Drawing.Size(14, 14);
            this.lblPhase1.TabIndex = 1;
            this.lblPhase1.Text = "F";
            this.lblPhase1.Visible = false;
            // 
            // lblOvlp16
            // 
            this.lblOvlp16.BackColor = System.Drawing.Color.Transparent;
            this.lblOvlp16.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblOvlp16.ForeColor = System.Drawing.Color.Black;
            this.lblOvlp16.Location = new System.Drawing.Point(123, 510);
            this.lblOvlp16.Name = "lblOvlp16";
            this.lblOvlp16.Size = new System.Drawing.Size(14, 14);
            this.lblOvlp16.TabIndex = 166;
            this.lblOvlp16.Text = "F";
            this.lblOvlp16.Visible = false;
            // 
            // lblOvlp15
            // 
            this.lblOvlp15.BackColor = System.Drawing.Color.Transparent;
            this.lblOvlp15.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblOvlp15.ForeColor = System.Drawing.Color.Black;
            this.lblOvlp15.Location = new System.Drawing.Point(123, 486);
            this.lblOvlp15.Name = "lblOvlp15";
            this.lblOvlp15.Size = new System.Drawing.Size(14, 14);
            this.lblOvlp15.TabIndex = 165;
            this.lblOvlp15.Text = "F";
            this.lblOvlp15.Visible = false;
            // 
            // lblOvlp14
            // 
            this.lblOvlp14.BackColor = System.Drawing.Color.Transparent;
            this.lblOvlp14.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblOvlp14.ForeColor = System.Drawing.Color.Black;
            this.lblOvlp14.Location = new System.Drawing.Point(123, 462);
            this.lblOvlp14.Name = "lblOvlp14";
            this.lblOvlp14.Size = new System.Drawing.Size(14, 14);
            this.lblOvlp14.TabIndex = 164;
            this.lblOvlp14.Text = "F";
            this.lblOvlp14.Visible = false;
            // 
            // lblOvlp13
            // 
            this.lblOvlp13.BackColor = System.Drawing.Color.Transparent;
            this.lblOvlp13.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblOvlp13.ForeColor = System.Drawing.Color.Black;
            this.lblOvlp13.Location = new System.Drawing.Point(123, 438);
            this.lblOvlp13.Name = "lblOvlp13";
            this.lblOvlp13.Size = new System.Drawing.Size(14, 14);
            this.lblOvlp13.TabIndex = 163;
            this.lblOvlp13.Text = "F";
            this.lblOvlp13.Visible = false;
            // 
            // lblOvlp12
            // 
            this.lblOvlp12.BackColor = System.Drawing.Color.Transparent;
            this.lblOvlp12.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblOvlp12.ForeColor = System.Drawing.Color.Black;
            this.lblOvlp12.Location = new System.Drawing.Point(123, 414);
            this.lblOvlp12.Name = "lblOvlp12";
            this.lblOvlp12.Size = new System.Drawing.Size(14, 14);
            this.lblOvlp12.TabIndex = 162;
            this.lblOvlp12.Text = "F";
            this.lblOvlp12.Visible = false;
            // 
            // lblOvlp11
            // 
            this.lblOvlp11.BackColor = System.Drawing.Color.Transparent;
            this.lblOvlp11.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblOvlp11.ForeColor = System.Drawing.Color.Black;
            this.lblOvlp11.Location = new System.Drawing.Point(123, 390);
            this.lblOvlp11.Name = "lblOvlp11";
            this.lblOvlp11.Size = new System.Drawing.Size(14, 14);
            this.lblOvlp11.TabIndex = 161;
            this.lblOvlp11.Text = "F";
            this.lblOvlp11.Visible = false;
            // 
            // lblOvlp10
            // 
            this.lblOvlp10.BackColor = System.Drawing.Color.Transparent;
            this.lblOvlp10.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblOvlp10.ForeColor = System.Drawing.Color.Black;
            this.lblOvlp10.Location = new System.Drawing.Point(123, 366);
            this.lblOvlp10.Name = "lblOvlp10";
            this.lblOvlp10.Size = new System.Drawing.Size(14, 14);
            this.lblOvlp10.TabIndex = 160;
            this.lblOvlp10.Text = "F";
            this.lblOvlp10.Visible = false;
            // 
            // lblOvlp9
            // 
            this.lblOvlp9.BackColor = System.Drawing.Color.Transparent;
            this.lblOvlp9.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblOvlp9.ForeColor = System.Drawing.Color.Black;
            this.lblOvlp9.Location = new System.Drawing.Point(123, 342);
            this.lblOvlp9.Name = "lblOvlp9";
            this.lblOvlp9.Size = new System.Drawing.Size(14, 14);
            this.lblOvlp9.TabIndex = 159;
            this.lblOvlp9.Text = "F";
            this.lblOvlp9.Visible = false;
            // 
            // lblOvlp8
            // 
            this.lblOvlp8.BackColor = System.Drawing.Color.Transparent;
            this.lblOvlp8.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblOvlp8.ForeColor = System.Drawing.Color.Black;
            this.lblOvlp8.Location = new System.Drawing.Point(123, 318);
            this.lblOvlp8.Name = "lblOvlp8";
            this.lblOvlp8.Size = new System.Drawing.Size(14, 14);
            this.lblOvlp8.TabIndex = 158;
            this.lblOvlp8.Text = "F";
            this.lblOvlp8.Visible = false;
            // 
            // lblOvlp7
            // 
            this.lblOvlp7.BackColor = System.Drawing.Color.Transparent;
            this.lblOvlp7.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblOvlp7.ForeColor = System.Drawing.Color.Black;
            this.lblOvlp7.Location = new System.Drawing.Point(123, 294);
            this.lblOvlp7.Name = "lblOvlp7";
            this.lblOvlp7.Size = new System.Drawing.Size(14, 14);
            this.lblOvlp7.TabIndex = 157;
            this.lblOvlp7.Text = "F";
            this.lblOvlp7.Visible = false;
            // 
            // lblOvlp6
            // 
            this.lblOvlp6.BackColor = System.Drawing.Color.Transparent;
            this.lblOvlp6.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblOvlp6.ForeColor = System.Drawing.Color.Black;
            this.lblOvlp6.Location = new System.Drawing.Point(123, 270);
            this.lblOvlp6.Name = "lblOvlp6";
            this.lblOvlp6.Size = new System.Drawing.Size(14, 14);
            this.lblOvlp6.TabIndex = 156;
            this.lblOvlp6.Text = "F";
            this.lblOvlp6.Visible = false;
            // 
            // lblOvlp5
            // 
            this.lblOvlp5.BackColor = System.Drawing.Color.Transparent;
            this.lblOvlp5.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblOvlp5.ForeColor = System.Drawing.Color.Black;
            this.lblOvlp5.Location = new System.Drawing.Point(123, 246);
            this.lblOvlp5.Name = "lblOvlp5";
            this.lblOvlp5.Size = new System.Drawing.Size(14, 14);
            this.lblOvlp5.TabIndex = 155;
            this.lblOvlp5.Text = "F";
            this.lblOvlp5.Visible = false;
            // 
            // lblOvlp4
            // 
            this.lblOvlp4.BackColor = System.Drawing.Color.Transparent;
            this.lblOvlp4.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblOvlp4.ForeColor = System.Drawing.Color.Black;
            this.lblOvlp4.Location = new System.Drawing.Point(123, 222);
            this.lblOvlp4.Name = "lblOvlp4";
            this.lblOvlp4.Size = new System.Drawing.Size(14, 14);
            this.lblOvlp4.TabIndex = 154;
            this.lblOvlp4.Text = "F";
            this.lblOvlp4.Visible = false;
            // 
            // lblOvlp3
            // 
            this.lblOvlp3.BackColor = System.Drawing.Color.Transparent;
            this.lblOvlp3.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblOvlp3.ForeColor = System.Drawing.Color.Black;
            this.lblOvlp3.Location = new System.Drawing.Point(123, 198);
            this.lblOvlp3.Name = "lblOvlp3";
            this.lblOvlp3.Size = new System.Drawing.Size(14, 14);
            this.lblOvlp3.TabIndex = 153;
            this.lblOvlp3.Text = "F";
            this.lblOvlp3.Visible = false;
            // 
            // lblOvlp2
            // 
            this.lblOvlp2.BackColor = System.Drawing.Color.Transparent;
            this.lblOvlp2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblOvlp2.ForeColor = System.Drawing.Color.Black;
            this.lblOvlp2.Location = new System.Drawing.Point(123, 174);
            this.lblOvlp2.Name = "lblOvlp2";
            this.lblOvlp2.Size = new System.Drawing.Size(14, 14);
            this.lblOvlp2.TabIndex = 152;
            this.lblOvlp2.Text = "F";
            this.lblOvlp2.Visible = false;
            // 
            // lblOvlp1
            // 
            this.lblOvlp1.BackColor = System.Drawing.Color.Transparent;
            this.lblOvlp1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblOvlp1.ForeColor = System.Drawing.Color.Black;
            this.lblOvlp1.Location = new System.Drawing.Point(123, 150);
            this.lblOvlp1.Name = "lblOvlp1";
            this.lblOvlp1.Size = new System.Drawing.Size(14, 14);
            this.lblOvlp1.TabIndex = 151;
            this.lblOvlp1.Text = "F";
            this.lblOvlp1.Visible = false;
            // 
            // lblPhase16
            // 
            this.lblPhase16.BackColor = System.Drawing.Color.Transparent;
            this.lblPhase16.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPhase16.ForeColor = System.Drawing.Color.Black;
            this.lblPhase16.Location = new System.Drawing.Point(66, 510);
            this.lblPhase16.Name = "lblPhase16";
            this.lblPhase16.Size = new System.Drawing.Size(14, 14);
            this.lblPhase16.TabIndex = 150;
            this.lblPhase16.Text = "F";
            this.lblPhase16.Visible = false;
            // 
            // lblPhase15
            // 
            this.lblPhase15.BackColor = System.Drawing.Color.Transparent;
            this.lblPhase15.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPhase15.ForeColor = System.Drawing.Color.Black;
            this.lblPhase15.Location = new System.Drawing.Point(66, 486);
            this.lblPhase15.Name = "lblPhase15";
            this.lblPhase15.Size = new System.Drawing.Size(14, 14);
            this.lblPhase15.TabIndex = 149;
            this.lblPhase15.Text = "F";
            this.lblPhase15.Visible = false;
            // 
            // lblPhase14
            // 
            this.lblPhase14.BackColor = System.Drawing.Color.Transparent;
            this.lblPhase14.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPhase14.ForeColor = System.Drawing.Color.Black;
            this.lblPhase14.Location = new System.Drawing.Point(66, 462);
            this.lblPhase14.Name = "lblPhase14";
            this.lblPhase14.Size = new System.Drawing.Size(14, 14);
            this.lblPhase14.TabIndex = 148;
            this.lblPhase14.Text = "F";
            this.lblPhase14.Visible = false;
            // 
            // lblPhase13
            // 
            this.lblPhase13.BackColor = System.Drawing.Color.Transparent;
            this.lblPhase13.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPhase13.ForeColor = System.Drawing.Color.Black;
            this.lblPhase13.Location = new System.Drawing.Point(66, 438);
            this.lblPhase13.Name = "lblPhase13";
            this.lblPhase13.Size = new System.Drawing.Size(14, 14);
            this.lblPhase13.TabIndex = 147;
            this.lblPhase13.Text = "F";
            this.lblPhase13.Visible = false;
            // 
            // lblPhase12
            // 
            this.lblPhase12.BackColor = System.Drawing.Color.Transparent;
            this.lblPhase12.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPhase12.ForeColor = System.Drawing.Color.Black;
            this.lblPhase12.Location = new System.Drawing.Point(66, 414);
            this.lblPhase12.Name = "lblPhase12";
            this.lblPhase12.Size = new System.Drawing.Size(14, 14);
            this.lblPhase12.TabIndex = 146;
            this.lblPhase12.Text = "F";
            this.lblPhase12.Visible = false;
            // 
            // lblPhase11
            // 
            this.lblPhase11.BackColor = System.Drawing.Color.Transparent;
            this.lblPhase11.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPhase11.ForeColor = System.Drawing.Color.Black;
            this.lblPhase11.Location = new System.Drawing.Point(66, 390);
            this.lblPhase11.Name = "lblPhase11";
            this.lblPhase11.Size = new System.Drawing.Size(14, 14);
            this.lblPhase11.TabIndex = 145;
            this.lblPhase11.Text = "F";
            this.lblPhase11.Visible = false;
            // 
            // lblPhase10
            // 
            this.lblPhase10.BackColor = System.Drawing.Color.Transparent;
            this.lblPhase10.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPhase10.ForeColor = System.Drawing.Color.Black;
            this.lblPhase10.Location = new System.Drawing.Point(66, 366);
            this.lblPhase10.Name = "lblPhase10";
            this.lblPhase10.Size = new System.Drawing.Size(14, 14);
            this.lblPhase10.TabIndex = 144;
            this.lblPhase10.Text = "F";
            this.lblPhase10.Visible = false;
            // 
            // lblPhase9
            // 
            this.lblPhase9.BackColor = System.Drawing.Color.Transparent;
            this.lblPhase9.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPhase9.ForeColor = System.Drawing.Color.Black;
            this.lblPhase9.Location = new System.Drawing.Point(66, 342);
            this.lblPhase9.Name = "lblPhase9";
            this.lblPhase9.Size = new System.Drawing.Size(14, 14);
            this.lblPhase9.TabIndex = 143;
            this.lblPhase9.Text = "F";
            this.lblPhase9.Visible = false;
            // 
            // lblPhase8
            // 
            this.lblPhase8.BackColor = System.Drawing.Color.Transparent;
            this.lblPhase8.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPhase8.ForeColor = System.Drawing.Color.Black;
            this.lblPhase8.Location = new System.Drawing.Point(66, 318);
            this.lblPhase8.Name = "lblPhase8";
            this.lblPhase8.Size = new System.Drawing.Size(14, 14);
            this.lblPhase8.TabIndex = 142;
            this.lblPhase8.Text = "F";
            this.lblPhase8.Visible = false;
            // 
            // lblPhase7
            // 
            this.lblPhase7.BackColor = System.Drawing.Color.Transparent;
            this.lblPhase7.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPhase7.ForeColor = System.Drawing.Color.Black;
            this.lblPhase7.Location = new System.Drawing.Point(66, 294);
            this.lblPhase7.Name = "lblPhase7";
            this.lblPhase7.Size = new System.Drawing.Size(14, 14);
            this.lblPhase7.TabIndex = 141;
            this.lblPhase7.Text = "F";
            this.lblPhase7.Visible = false;
            // 
            // lblPhase6
            // 
            this.lblPhase6.BackColor = System.Drawing.Color.Transparent;
            this.lblPhase6.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPhase6.ForeColor = System.Drawing.Color.Black;
            this.lblPhase6.Location = new System.Drawing.Point(66, 270);
            this.lblPhase6.Name = "lblPhase6";
            this.lblPhase6.Size = new System.Drawing.Size(14, 14);
            this.lblPhase6.TabIndex = 140;
            this.lblPhase6.Text = "F";
            this.lblPhase6.Visible = false;
            // 
            // lblPhase5
            // 
            this.lblPhase5.BackColor = System.Drawing.Color.Transparent;
            this.lblPhase5.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPhase5.ForeColor = System.Drawing.Color.Black;
            this.lblPhase5.Location = new System.Drawing.Point(66, 246);
            this.lblPhase5.Name = "lblPhase5";
            this.lblPhase5.Size = new System.Drawing.Size(14, 14);
            this.lblPhase5.TabIndex = 139;
            this.lblPhase5.Text = "F";
            this.lblPhase5.Visible = false;
            // 
            // lblPhase4
            // 
            this.lblPhase4.BackColor = System.Drawing.Color.Transparent;
            this.lblPhase4.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPhase4.ForeColor = System.Drawing.Color.Black;
            this.lblPhase4.Location = new System.Drawing.Point(66, 222);
            this.lblPhase4.Name = "lblPhase4";
            this.lblPhase4.Size = new System.Drawing.Size(14, 14);
            this.lblPhase4.TabIndex = 138;
            this.lblPhase4.Text = "F";
            this.lblPhase4.Visible = false;
            // 
            // lblPhase3
            // 
            this.lblPhase3.BackColor = System.Drawing.Color.Transparent;
            this.lblPhase3.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPhase3.ForeColor = System.Drawing.Color.Black;
            this.lblPhase3.Location = new System.Drawing.Point(66, 198);
            this.lblPhase3.Name = "lblPhase3";
            this.lblPhase3.Size = new System.Drawing.Size(14, 14);
            this.lblPhase3.TabIndex = 137;
            this.lblPhase3.Text = "F";
            this.lblPhase3.Visible = false;
            // 
            // lblPhase2
            // 
            this.lblPhase2.BackColor = System.Drawing.Color.Transparent;
            this.lblPhase2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPhase2.ForeColor = System.Drawing.Color.Black;
            this.lblPhase2.Location = new System.Drawing.Point(66, 174);
            this.lblPhase2.Name = "lblPhase2";
            this.lblPhase2.Size = new System.Drawing.Size(14, 14);
            this.lblPhase2.TabIndex = 136;
            this.lblPhase2.Text = "F";
            this.lblPhase2.Visible = false;
            // 
            // label48
            // 
            this.label48.BackColor = System.Drawing.Color.Gold;
            this.label48.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label48.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label48.ForeColor = System.Drawing.Color.Black;
            this.label48.Location = new System.Drawing.Point(101, 106);
            this.label48.Name = "label48";
            this.label48.Size = new System.Drawing.Size(63, 38);
            this.label48.TabIndex = 134;
            this.label48.Text = "OVLP Status";
            this.label48.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblSysTime
            // 
            this.lblSysTime.ForeColor = System.Drawing.Color.Black;
            this.lblSysTime.Location = new System.Drawing.Point(171, 73);
            this.lblSysTime.Name = "lblSysTime";
            this.lblSysTime.Size = new System.Drawing.Size(51, 23);
            this.lblSysTime.TabIndex = 133;
            this.lblSysTime.Text = "Time";
            this.lblSysTime.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // axaxNtcipIO1
            // 
            this.axaxNtcipIO1.Location = new System.Drawing.Point(578, -41);
            this.axaxNtcipIO1.Name = "axaxNtcipIO1";
            this.axaxNtcipIO1.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("axaxNtcipIO1.OcxState")));
            this.axaxNtcipIO1.Size = new System.Drawing.Size(75, 35);
            this.axaxNtcipIO1.TabIndex = 1;
            this.axaxNtcipIO1.OnNTCIPData += new System.EventHandler(this.axaxNtcipIO1_OnNTCIPData);
            // 
            // label41
            // 
            this.label41.BackColor = System.Drawing.Color.Gold;
            this.label41.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label41.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label41.ForeColor = System.Drawing.Color.Black;
            this.label41.Location = new System.Drawing.Point(219, 106);
            this.label41.Name = "label41";
            this.label41.Size = new System.Drawing.Size(102, 38);
            this.label41.TabIndex = 127;
            this.label41.Text = "Ped Mvmt";
            this.label41.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // txtPed2
            // 
            this.txtPed2.BackColor = System.Drawing.Color.Black;
            this.txtPed2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtPed2.Location = new System.Drawing.Point(222, 170);
            this.txtPed2.Name = "txtPed2";
            this.txtPed2.Size = new System.Drawing.Size(96, 26);
            this.txtPed2.TabIndex = 57;
            // 
            // txtPed1
            // 
            this.txtPed1.BackColor = System.Drawing.Color.Black;
            this.txtPed1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtPed1.Location = new System.Drawing.Point(222, 146);
            this.txtPed1.Name = "txtPed1";
            this.txtPed1.Size = new System.Drawing.Size(96, 26);
            this.txtPed1.TabIndex = 42;
            // 
            // txtPed16
            // 
            this.txtPed16.BackColor = System.Drawing.Color.Black;
            this.txtPed16.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtPed16.Location = new System.Drawing.Point(222, 506);
            this.txtPed16.Name = "txtPed16";
            this.txtPed16.Size = new System.Drawing.Size(96, 26);
            this.txtPed16.TabIndex = 56;
            // 
            // txtPed3
            // 
            this.txtPed3.BackColor = System.Drawing.Color.Black;
            this.txtPed3.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtPed3.Location = new System.Drawing.Point(222, 194);
            this.txtPed3.Name = "txtPed3";
            this.txtPed3.Size = new System.Drawing.Size(96, 26);
            this.txtPed3.TabIndex = 43;
            // 
            // txtPed15
            // 
            this.txtPed15.BackColor = System.Drawing.Color.Black;
            this.txtPed15.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtPed15.Location = new System.Drawing.Point(222, 482);
            this.txtPed15.Name = "txtPed15";
            this.txtPed15.Size = new System.Drawing.Size(96, 26);
            this.txtPed15.TabIndex = 55;
            // 
            // txtPed4
            // 
            this.txtPed4.BackColor = System.Drawing.Color.Black;
            this.txtPed4.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtPed4.Location = new System.Drawing.Point(222, 218);
            this.txtPed4.Name = "txtPed4";
            this.txtPed4.Size = new System.Drawing.Size(96, 26);
            this.txtPed4.TabIndex = 44;
            // 
            // txtPed14
            // 
            this.txtPed14.BackColor = System.Drawing.Color.Black;
            this.txtPed14.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtPed14.Location = new System.Drawing.Point(222, 458);
            this.txtPed14.Name = "txtPed14";
            this.txtPed14.Size = new System.Drawing.Size(96, 26);
            this.txtPed14.TabIndex = 54;
            // 
            // txtPed5
            // 
            this.txtPed5.BackColor = System.Drawing.Color.Black;
            this.txtPed5.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtPed5.Location = new System.Drawing.Point(222, 242);
            this.txtPed5.Name = "txtPed5";
            this.txtPed5.Size = new System.Drawing.Size(96, 26);
            this.txtPed5.TabIndex = 45;
            // 
            // txtPed13
            // 
            this.txtPed13.BackColor = System.Drawing.Color.Black;
            this.txtPed13.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtPed13.Location = new System.Drawing.Point(222, 434);
            this.txtPed13.Name = "txtPed13";
            this.txtPed13.Size = new System.Drawing.Size(96, 26);
            this.txtPed13.TabIndex = 53;
            // 
            // txtPed6
            // 
            this.txtPed6.BackColor = System.Drawing.Color.Black;
            this.txtPed6.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtPed6.Location = new System.Drawing.Point(222, 266);
            this.txtPed6.Name = "txtPed6";
            this.txtPed6.Size = new System.Drawing.Size(96, 26);
            this.txtPed6.TabIndex = 46;
            // 
            // txtPed12
            // 
            this.txtPed12.BackColor = System.Drawing.Color.Black;
            this.txtPed12.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtPed12.Location = new System.Drawing.Point(222, 410);
            this.txtPed12.Name = "txtPed12";
            this.txtPed12.Size = new System.Drawing.Size(96, 26);
            this.txtPed12.TabIndex = 52;
            // 
            // txtPed7
            // 
            this.txtPed7.BackColor = System.Drawing.Color.Black;
            this.txtPed7.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtPed7.Location = new System.Drawing.Point(222, 290);
            this.txtPed7.Name = "txtPed7";
            this.txtPed7.Size = new System.Drawing.Size(96, 26);
            this.txtPed7.TabIndex = 47;
            // 
            // txtPed11
            // 
            this.txtPed11.BackColor = System.Drawing.Color.Black;
            this.txtPed11.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtPed11.Location = new System.Drawing.Point(222, 386);
            this.txtPed11.Name = "txtPed11";
            this.txtPed11.Size = new System.Drawing.Size(96, 26);
            this.txtPed11.TabIndex = 51;
            // 
            // txtPed8
            // 
            this.txtPed8.BackColor = System.Drawing.Color.Black;
            this.txtPed8.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtPed8.Location = new System.Drawing.Point(222, 314);
            this.txtPed8.Name = "txtPed8";
            this.txtPed8.Size = new System.Drawing.Size(96, 26);
            this.txtPed8.TabIndex = 48;
            // 
            // txtPed10
            // 
            this.txtPed10.BackColor = System.Drawing.Color.Black;
            this.txtPed10.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtPed10.Location = new System.Drawing.Point(222, 362);
            this.txtPed10.Name = "txtPed10";
            this.txtPed10.Size = new System.Drawing.Size(96, 26);
            this.txtPed10.TabIndex = 50;
            // 
            // txtPed9
            // 
            this.txtPed9.BackColor = System.Drawing.Color.Black;
            this.txtPed9.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtPed9.Location = new System.Drawing.Point(222, 338);
            this.txtPed9.Name = "txtPed9";
            this.txtPed9.Size = new System.Drawing.Size(96, 26);
            this.txtPed9.TabIndex = 49;
            // 
            // label26
            // 
            this.label26.BackColor = System.Drawing.Color.Gold;
            this.label26.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label26.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label26.ForeColor = System.Drawing.Color.Black;
            this.label26.Location = new System.Drawing.Point(641, 106);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(64, 38);
            this.label26.TabIndex = 126;
            this.label26.Text = "O-Max Time";
            this.label26.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // txtOMaxTime2
            // 
            this.txtOMaxTime2.BackColor = System.Drawing.Color.Black;
            this.txtOMaxTime2.ForeColor = System.Drawing.Color.White;
            this.txtOMaxTime2.Location = new System.Drawing.Point(645, 170);
            this.txtOMaxTime2.Name = "txtOMaxTime2";
            this.txtOMaxTime2.Size = new System.Drawing.Size(60, 26);
            this.txtOMaxTime2.TabIndex = 125;
            // 
            // txtOMaxTime16
            // 
            this.txtOMaxTime16.BackColor = System.Drawing.Color.Black;
            this.txtOMaxTime16.ForeColor = System.Drawing.Color.White;
            this.txtOMaxTime16.Location = new System.Drawing.Point(645, 506);
            this.txtOMaxTime16.Name = "txtOMaxTime16";
            this.txtOMaxTime16.Size = new System.Drawing.Size(60, 26);
            this.txtOMaxTime16.TabIndex = 124;
            // 
            // txtOMaxTime15
            // 
            this.txtOMaxTime15.BackColor = System.Drawing.Color.Black;
            this.txtOMaxTime15.ForeColor = System.Drawing.Color.White;
            this.txtOMaxTime15.Location = new System.Drawing.Point(645, 482);
            this.txtOMaxTime15.Name = "txtOMaxTime15";
            this.txtOMaxTime15.Size = new System.Drawing.Size(60, 26);
            this.txtOMaxTime15.TabIndex = 123;
            // 
            // txtOMaxTime14
            // 
            this.txtOMaxTime14.BackColor = System.Drawing.Color.Black;
            this.txtOMaxTime14.ForeColor = System.Drawing.Color.White;
            this.txtOMaxTime14.Location = new System.Drawing.Point(645, 458);
            this.txtOMaxTime14.Name = "txtOMaxTime14";
            this.txtOMaxTime14.Size = new System.Drawing.Size(60, 26);
            this.txtOMaxTime14.TabIndex = 122;
            // 
            // txtOMaxTime13
            // 
            this.txtOMaxTime13.BackColor = System.Drawing.Color.Black;
            this.txtOMaxTime13.ForeColor = System.Drawing.Color.White;
            this.txtOMaxTime13.Location = new System.Drawing.Point(645, 434);
            this.txtOMaxTime13.Name = "txtOMaxTime13";
            this.txtOMaxTime13.Size = new System.Drawing.Size(60, 26);
            this.txtOMaxTime13.TabIndex = 121;
            // 
            // txtOMaxTime12
            // 
            this.txtOMaxTime12.BackColor = System.Drawing.Color.Black;
            this.txtOMaxTime12.ForeColor = System.Drawing.Color.White;
            this.txtOMaxTime12.Location = new System.Drawing.Point(645, 410);
            this.txtOMaxTime12.Name = "txtOMaxTime12";
            this.txtOMaxTime12.Size = new System.Drawing.Size(60, 26);
            this.txtOMaxTime12.TabIndex = 120;
            // 
            // txtOMaxTime11
            // 
            this.txtOMaxTime11.BackColor = System.Drawing.Color.Black;
            this.txtOMaxTime11.ForeColor = System.Drawing.Color.White;
            this.txtOMaxTime11.Location = new System.Drawing.Point(645, 386);
            this.txtOMaxTime11.Name = "txtOMaxTime11";
            this.txtOMaxTime11.Size = new System.Drawing.Size(60, 26);
            this.txtOMaxTime11.TabIndex = 119;
            // 
            // txtOMaxTime10
            // 
            this.txtOMaxTime10.BackColor = System.Drawing.Color.Black;
            this.txtOMaxTime10.ForeColor = System.Drawing.Color.White;
            this.txtOMaxTime10.Location = new System.Drawing.Point(645, 362);
            this.txtOMaxTime10.Name = "txtOMaxTime10";
            this.txtOMaxTime10.Size = new System.Drawing.Size(60, 26);
            this.txtOMaxTime10.TabIndex = 118;
            // 
            // txtOMaxTime9
            // 
            this.txtOMaxTime9.BackColor = System.Drawing.Color.Black;
            this.txtOMaxTime9.ForeColor = System.Drawing.Color.White;
            this.txtOMaxTime9.Location = new System.Drawing.Point(645, 338);
            this.txtOMaxTime9.Name = "txtOMaxTime9";
            this.txtOMaxTime9.Size = new System.Drawing.Size(60, 26);
            this.txtOMaxTime9.TabIndex = 117;
            // 
            // txtOMaxTime8
            // 
            this.txtOMaxTime8.BackColor = System.Drawing.Color.Black;
            this.txtOMaxTime8.ForeColor = System.Drawing.Color.White;
            this.txtOMaxTime8.Location = new System.Drawing.Point(645, 314);
            this.txtOMaxTime8.Name = "txtOMaxTime8";
            this.txtOMaxTime8.Size = new System.Drawing.Size(60, 26);
            this.txtOMaxTime8.TabIndex = 116;
            // 
            // txtOMaxTime7
            // 
            this.txtOMaxTime7.BackColor = System.Drawing.Color.Black;
            this.txtOMaxTime7.ForeColor = System.Drawing.Color.White;
            this.txtOMaxTime7.Location = new System.Drawing.Point(645, 290);
            this.txtOMaxTime7.Name = "txtOMaxTime7";
            this.txtOMaxTime7.Size = new System.Drawing.Size(60, 26);
            this.txtOMaxTime7.TabIndex = 115;
            // 
            // txtOMaxTime6
            // 
            this.txtOMaxTime6.BackColor = System.Drawing.Color.Black;
            this.txtOMaxTime6.ForeColor = System.Drawing.Color.White;
            this.txtOMaxTime6.Location = new System.Drawing.Point(645, 266);
            this.txtOMaxTime6.Name = "txtOMaxTime6";
            this.txtOMaxTime6.Size = new System.Drawing.Size(60, 26);
            this.txtOMaxTime6.TabIndex = 114;
            // 
            // txtOMaxTime5
            // 
            this.txtOMaxTime5.BackColor = System.Drawing.Color.Black;
            this.txtOMaxTime5.ForeColor = System.Drawing.Color.White;
            this.txtOMaxTime5.Location = new System.Drawing.Point(645, 242);
            this.txtOMaxTime5.Name = "txtOMaxTime5";
            this.txtOMaxTime5.Size = new System.Drawing.Size(60, 26);
            this.txtOMaxTime5.TabIndex = 113;
            // 
            // txtOMaxTime4
            // 
            this.txtOMaxTime4.BackColor = System.Drawing.Color.Black;
            this.txtOMaxTime4.ForeColor = System.Drawing.Color.White;
            this.txtOMaxTime4.Location = new System.Drawing.Point(645, 218);
            this.txtOMaxTime4.Name = "txtOMaxTime4";
            this.txtOMaxTime4.Size = new System.Drawing.Size(60, 26);
            this.txtOMaxTime4.TabIndex = 112;
            // 
            // txtOMaxTime3
            // 
            this.txtOMaxTime3.BackColor = System.Drawing.Color.Black;
            this.txtOMaxTime3.ForeColor = System.Drawing.Color.White;
            this.txtOMaxTime3.Location = new System.Drawing.Point(645, 194);
            this.txtOMaxTime3.Name = "txtOMaxTime3";
            this.txtOMaxTime3.Size = new System.Drawing.Size(60, 26);
            this.txtOMaxTime3.TabIndex = 111;
            // 
            // txtOMaxTime1
            // 
            this.txtOMaxTime1.BackColor = System.Drawing.Color.Black;
            this.txtOMaxTime1.ForeColor = System.Drawing.Color.White;
            this.txtOMaxTime1.Location = new System.Drawing.Point(645, 146);
            this.txtOMaxTime1.Name = "txtOMaxTime1";
            this.txtOMaxTime1.Size = new System.Drawing.Size(60, 26);
            this.txtOMaxTime1.TabIndex = 110;
            // 
            // txtOMinTime2
            // 
            this.txtOMinTime2.BackColor = System.Drawing.Color.Black;
            this.txtOMinTime2.ForeColor = System.Drawing.Color.White;
            this.txtOMinTime2.Location = new System.Drawing.Point(579, 169);
            this.txtOMinTime2.Name = "txtOMinTime2";
            this.txtOMinTime2.Size = new System.Drawing.Size(60, 26);
            this.txtOMinTime2.TabIndex = 109;
            // 
            // txtOMinTime16
            // 
            this.txtOMinTime16.BackColor = System.Drawing.Color.Black;
            this.txtOMinTime16.ForeColor = System.Drawing.Color.White;
            this.txtOMinTime16.Location = new System.Drawing.Point(579, 505);
            this.txtOMinTime16.Name = "txtOMinTime16";
            this.txtOMinTime16.Size = new System.Drawing.Size(60, 26);
            this.txtOMinTime16.TabIndex = 108;
            // 
            // txtOMinTime15
            // 
            this.txtOMinTime15.BackColor = System.Drawing.Color.Black;
            this.txtOMinTime15.ForeColor = System.Drawing.Color.White;
            this.txtOMinTime15.Location = new System.Drawing.Point(579, 481);
            this.txtOMinTime15.Name = "txtOMinTime15";
            this.txtOMinTime15.Size = new System.Drawing.Size(60, 26);
            this.txtOMinTime15.TabIndex = 107;
            // 
            // txtOMinTime14
            // 
            this.txtOMinTime14.BackColor = System.Drawing.Color.Black;
            this.txtOMinTime14.ForeColor = System.Drawing.Color.White;
            this.txtOMinTime14.Location = new System.Drawing.Point(579, 457);
            this.txtOMinTime14.Name = "txtOMinTime14";
            this.txtOMinTime14.Size = new System.Drawing.Size(60, 26);
            this.txtOMinTime14.TabIndex = 106;
            // 
            // txtOMinTime13
            // 
            this.txtOMinTime13.BackColor = System.Drawing.Color.Black;
            this.txtOMinTime13.ForeColor = System.Drawing.Color.White;
            this.txtOMinTime13.Location = new System.Drawing.Point(579, 433);
            this.txtOMinTime13.Name = "txtOMinTime13";
            this.txtOMinTime13.Size = new System.Drawing.Size(60, 26);
            this.txtOMinTime13.TabIndex = 105;
            // 
            // txtOMinTime12
            // 
            this.txtOMinTime12.BackColor = System.Drawing.Color.Black;
            this.txtOMinTime12.ForeColor = System.Drawing.Color.White;
            this.txtOMinTime12.Location = new System.Drawing.Point(579, 409);
            this.txtOMinTime12.Name = "txtOMinTime12";
            this.txtOMinTime12.Size = new System.Drawing.Size(60, 26);
            this.txtOMinTime12.TabIndex = 104;
            // 
            // txtOMinTime11
            // 
            this.txtOMinTime11.BackColor = System.Drawing.Color.Black;
            this.txtOMinTime11.ForeColor = System.Drawing.Color.White;
            this.txtOMinTime11.Location = new System.Drawing.Point(579, 385);
            this.txtOMinTime11.Name = "txtOMinTime11";
            this.txtOMinTime11.Size = new System.Drawing.Size(60, 26);
            this.txtOMinTime11.TabIndex = 103;
            // 
            // txtOMinTime10
            // 
            this.txtOMinTime10.BackColor = System.Drawing.Color.Black;
            this.txtOMinTime10.ForeColor = System.Drawing.Color.White;
            this.txtOMinTime10.Location = new System.Drawing.Point(579, 361);
            this.txtOMinTime10.Name = "txtOMinTime10";
            this.txtOMinTime10.Size = new System.Drawing.Size(60, 26);
            this.txtOMinTime10.TabIndex = 102;
            // 
            // txtOMinTime9
            // 
            this.txtOMinTime9.BackColor = System.Drawing.Color.Black;
            this.txtOMinTime9.ForeColor = System.Drawing.Color.White;
            this.txtOMinTime9.Location = new System.Drawing.Point(579, 337);
            this.txtOMinTime9.Name = "txtOMinTime9";
            this.txtOMinTime9.Size = new System.Drawing.Size(60, 26);
            this.txtOMinTime9.TabIndex = 101;
            // 
            // txtOMinTime8
            // 
            this.txtOMinTime8.BackColor = System.Drawing.Color.Black;
            this.txtOMinTime8.ForeColor = System.Drawing.Color.White;
            this.txtOMinTime8.Location = new System.Drawing.Point(579, 313);
            this.txtOMinTime8.Name = "txtOMinTime8";
            this.txtOMinTime8.Size = new System.Drawing.Size(60, 26);
            this.txtOMinTime8.TabIndex = 100;
            // 
            // txtOMinTime7
            // 
            this.txtOMinTime7.BackColor = System.Drawing.Color.Black;
            this.txtOMinTime7.ForeColor = System.Drawing.Color.White;
            this.txtOMinTime7.Location = new System.Drawing.Point(579, 289);
            this.txtOMinTime7.Name = "txtOMinTime7";
            this.txtOMinTime7.Size = new System.Drawing.Size(60, 26);
            this.txtOMinTime7.TabIndex = 99;
            // 
            // txtOMinTime6
            // 
            this.txtOMinTime6.BackColor = System.Drawing.Color.Black;
            this.txtOMinTime6.ForeColor = System.Drawing.Color.White;
            this.txtOMinTime6.Location = new System.Drawing.Point(579, 265);
            this.txtOMinTime6.Name = "txtOMinTime6";
            this.txtOMinTime6.Size = new System.Drawing.Size(60, 26);
            this.txtOMinTime6.TabIndex = 98;
            // 
            // txtOMinTime5
            // 
            this.txtOMinTime5.BackColor = System.Drawing.Color.Black;
            this.txtOMinTime5.ForeColor = System.Drawing.Color.White;
            this.txtOMinTime5.Location = new System.Drawing.Point(579, 241);
            this.txtOMinTime5.Name = "txtOMinTime5";
            this.txtOMinTime5.Size = new System.Drawing.Size(60, 26);
            this.txtOMinTime5.TabIndex = 97;
            // 
            // txtOMinTime4
            // 
            this.txtOMinTime4.BackColor = System.Drawing.Color.Black;
            this.txtOMinTime4.ForeColor = System.Drawing.Color.White;
            this.txtOMinTime4.Location = new System.Drawing.Point(579, 217);
            this.txtOMinTime4.Name = "txtOMinTime4";
            this.txtOMinTime4.Size = new System.Drawing.Size(60, 26);
            this.txtOMinTime4.TabIndex = 96;
            // 
            // txtOMinTime3
            // 
            this.txtOMinTime3.BackColor = System.Drawing.Color.Black;
            this.txtOMinTime3.ForeColor = System.Drawing.Color.White;
            this.txtOMinTime3.Location = new System.Drawing.Point(579, 193);
            this.txtOMinTime3.Name = "txtOMinTime3";
            this.txtOMinTime3.Size = new System.Drawing.Size(60, 26);
            this.txtOMinTime3.TabIndex = 95;
            // 
            // label27
            // 
            this.label27.BackColor = System.Drawing.Color.Gold;
            this.label27.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label27.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label27.ForeColor = System.Drawing.Color.Black;
            this.label27.Location = new System.Drawing.Point(577, 106);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(64, 38);
            this.label27.TabIndex = 94;
            this.label27.Text = "O-Min Time";
            this.label27.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // txtOMinTime1
            // 
            this.txtOMinTime1.BackColor = System.Drawing.Color.Black;
            this.txtOMinTime1.ForeColor = System.Drawing.Color.White;
            this.txtOMinTime1.Location = new System.Drawing.Point(579, 145);
            this.txtOMinTime1.Name = "txtOMinTime1";
            this.txtOMinTime1.Size = new System.Drawing.Size(60, 26);
            this.txtOMinTime1.TabIndex = 93;
            // 
            // label24
            // 
            this.label24.BackColor = System.Drawing.Color.Gold;
            this.label24.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label24.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label24.ForeColor = System.Drawing.Color.Black;
            this.label24.Location = new System.Drawing.Point(513, 106);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(64, 38);
            this.label24.TabIndex = 92;
            this.label24.Text = "P-Max Time";
            this.label24.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // txtPMaxTime2
            // 
            this.txtPMaxTime2.BackColor = System.Drawing.Color.Black;
            this.txtPMaxTime2.ForeColor = System.Drawing.Color.White;
            this.txtPMaxTime2.Location = new System.Drawing.Point(517, 170);
            this.txtPMaxTime2.Name = "txtPMaxTime2";
            this.txtPMaxTime2.Size = new System.Drawing.Size(60, 26);
            this.txtPMaxTime2.TabIndex = 91;
            // 
            // txtPMaxTime16
            // 
            this.txtPMaxTime16.BackColor = System.Drawing.Color.Black;
            this.txtPMaxTime16.ForeColor = System.Drawing.Color.White;
            this.txtPMaxTime16.Location = new System.Drawing.Point(517, 506);
            this.txtPMaxTime16.Name = "txtPMaxTime16";
            this.txtPMaxTime16.Size = new System.Drawing.Size(60, 26);
            this.txtPMaxTime16.TabIndex = 90;
            // 
            // txtPMaxTime15
            // 
            this.txtPMaxTime15.BackColor = System.Drawing.Color.Black;
            this.txtPMaxTime15.ForeColor = System.Drawing.Color.White;
            this.txtPMaxTime15.Location = new System.Drawing.Point(517, 482);
            this.txtPMaxTime15.Name = "txtPMaxTime15";
            this.txtPMaxTime15.Size = new System.Drawing.Size(60, 26);
            this.txtPMaxTime15.TabIndex = 89;
            // 
            // txtPMaxTime14
            // 
            this.txtPMaxTime14.BackColor = System.Drawing.Color.Black;
            this.txtPMaxTime14.ForeColor = System.Drawing.Color.White;
            this.txtPMaxTime14.Location = new System.Drawing.Point(517, 458);
            this.txtPMaxTime14.Name = "txtPMaxTime14";
            this.txtPMaxTime14.Size = new System.Drawing.Size(60, 26);
            this.txtPMaxTime14.TabIndex = 88;
            // 
            // txtPMaxTime13
            // 
            this.txtPMaxTime13.BackColor = System.Drawing.Color.Black;
            this.txtPMaxTime13.ForeColor = System.Drawing.Color.White;
            this.txtPMaxTime13.Location = new System.Drawing.Point(517, 434);
            this.txtPMaxTime13.Name = "txtPMaxTime13";
            this.txtPMaxTime13.Size = new System.Drawing.Size(60, 26);
            this.txtPMaxTime13.TabIndex = 87;
            // 
            // txtPMaxTime12
            // 
            this.txtPMaxTime12.BackColor = System.Drawing.Color.Black;
            this.txtPMaxTime12.ForeColor = System.Drawing.Color.White;
            this.txtPMaxTime12.Location = new System.Drawing.Point(517, 410);
            this.txtPMaxTime12.Name = "txtPMaxTime12";
            this.txtPMaxTime12.Size = new System.Drawing.Size(60, 26);
            this.txtPMaxTime12.TabIndex = 86;
            // 
            // txtPMaxTime11
            // 
            this.txtPMaxTime11.BackColor = System.Drawing.Color.Black;
            this.txtPMaxTime11.ForeColor = System.Drawing.Color.White;
            this.txtPMaxTime11.Location = new System.Drawing.Point(517, 386);
            this.txtPMaxTime11.Name = "txtPMaxTime11";
            this.txtPMaxTime11.Size = new System.Drawing.Size(60, 26);
            this.txtPMaxTime11.TabIndex = 85;
            // 
            // txtPMaxTime10
            // 
            this.txtPMaxTime10.BackColor = System.Drawing.Color.Black;
            this.txtPMaxTime10.ForeColor = System.Drawing.Color.White;
            this.txtPMaxTime10.Location = new System.Drawing.Point(517, 362);
            this.txtPMaxTime10.Name = "txtPMaxTime10";
            this.txtPMaxTime10.Size = new System.Drawing.Size(60, 26);
            this.txtPMaxTime10.TabIndex = 84;
            // 
            // txtPMaxTime9
            // 
            this.txtPMaxTime9.BackColor = System.Drawing.Color.Black;
            this.txtPMaxTime9.ForeColor = System.Drawing.Color.White;
            this.txtPMaxTime9.Location = new System.Drawing.Point(517, 338);
            this.txtPMaxTime9.Name = "txtPMaxTime9";
            this.txtPMaxTime9.Size = new System.Drawing.Size(60, 26);
            this.txtPMaxTime9.TabIndex = 83;
            // 
            // txtPMaxTime8
            // 
            this.txtPMaxTime8.BackColor = System.Drawing.Color.Black;
            this.txtPMaxTime8.ForeColor = System.Drawing.Color.White;
            this.txtPMaxTime8.Location = new System.Drawing.Point(517, 314);
            this.txtPMaxTime8.Name = "txtPMaxTime8";
            this.txtPMaxTime8.Size = new System.Drawing.Size(60, 26);
            this.txtPMaxTime8.TabIndex = 82;
            // 
            // txtPMaxTime7
            // 
            this.txtPMaxTime7.BackColor = System.Drawing.Color.Black;
            this.txtPMaxTime7.ForeColor = System.Drawing.Color.White;
            this.txtPMaxTime7.Location = new System.Drawing.Point(517, 290);
            this.txtPMaxTime7.Name = "txtPMaxTime7";
            this.txtPMaxTime7.Size = new System.Drawing.Size(60, 26);
            this.txtPMaxTime7.TabIndex = 81;
            // 
            // txtPMaxTime6
            // 
            this.txtPMaxTime6.BackColor = System.Drawing.Color.Black;
            this.txtPMaxTime6.ForeColor = System.Drawing.Color.White;
            this.txtPMaxTime6.Location = new System.Drawing.Point(517, 266);
            this.txtPMaxTime6.Name = "txtPMaxTime6";
            this.txtPMaxTime6.Size = new System.Drawing.Size(60, 26);
            this.txtPMaxTime6.TabIndex = 80;
            // 
            // txtPMaxTime5
            // 
            this.txtPMaxTime5.BackColor = System.Drawing.Color.Black;
            this.txtPMaxTime5.ForeColor = System.Drawing.Color.White;
            this.txtPMaxTime5.Location = new System.Drawing.Point(517, 242);
            this.txtPMaxTime5.Name = "txtPMaxTime5";
            this.txtPMaxTime5.Size = new System.Drawing.Size(60, 26);
            this.txtPMaxTime5.TabIndex = 79;
            // 
            // txtPMaxTime4
            // 
            this.txtPMaxTime4.BackColor = System.Drawing.Color.Black;
            this.txtPMaxTime4.ForeColor = System.Drawing.Color.White;
            this.txtPMaxTime4.Location = new System.Drawing.Point(517, 218);
            this.txtPMaxTime4.Name = "txtPMaxTime4";
            this.txtPMaxTime4.Size = new System.Drawing.Size(60, 26);
            this.txtPMaxTime4.TabIndex = 78;
            // 
            // txtPMaxTime3
            // 
            this.txtPMaxTime3.BackColor = System.Drawing.Color.Black;
            this.txtPMaxTime3.ForeColor = System.Drawing.Color.White;
            this.txtPMaxTime3.Location = new System.Drawing.Point(517, 194);
            this.txtPMaxTime3.Name = "txtPMaxTime3";
            this.txtPMaxTime3.Size = new System.Drawing.Size(60, 26);
            this.txtPMaxTime3.TabIndex = 77;
            // 
            // txtPMaxTime1
            // 
            this.txtPMaxTime1.BackColor = System.Drawing.Color.Black;
            this.txtPMaxTime1.ForeColor = System.Drawing.Color.White;
            this.txtPMaxTime1.Location = new System.Drawing.Point(517, 146);
            this.txtPMaxTime1.Name = "txtPMaxTime1";
            this.txtPMaxTime1.Size = new System.Drawing.Size(60, 26);
            this.txtPMaxTime1.TabIndex = 76;
            // 
            // txtPMinTime2
            // 
            this.txtPMinTime2.BackColor = System.Drawing.Color.Black;
            this.txtPMinTime2.ForeColor = System.Drawing.Color.White;
            this.txtPMinTime2.Location = new System.Drawing.Point(451, 169);
            this.txtPMinTime2.Name = "txtPMinTime2";
            this.txtPMinTime2.Size = new System.Drawing.Size(60, 26);
            this.txtPMinTime2.TabIndex = 75;
            // 
            // txtPMinTime16
            // 
            this.txtPMinTime16.BackColor = System.Drawing.Color.Black;
            this.txtPMinTime16.ForeColor = System.Drawing.Color.White;
            this.txtPMinTime16.Location = new System.Drawing.Point(451, 505);
            this.txtPMinTime16.Name = "txtPMinTime16";
            this.txtPMinTime16.Size = new System.Drawing.Size(60, 26);
            this.txtPMinTime16.TabIndex = 74;
            // 
            // txtPMinTime15
            // 
            this.txtPMinTime15.BackColor = System.Drawing.Color.Black;
            this.txtPMinTime15.ForeColor = System.Drawing.Color.White;
            this.txtPMinTime15.Location = new System.Drawing.Point(451, 481);
            this.txtPMinTime15.Name = "txtPMinTime15";
            this.txtPMinTime15.Size = new System.Drawing.Size(60, 26);
            this.txtPMinTime15.TabIndex = 73;
            // 
            // txtPMinTime14
            // 
            this.txtPMinTime14.BackColor = System.Drawing.Color.Black;
            this.txtPMinTime14.ForeColor = System.Drawing.Color.White;
            this.txtPMinTime14.Location = new System.Drawing.Point(451, 457);
            this.txtPMinTime14.Name = "txtPMinTime14";
            this.txtPMinTime14.Size = new System.Drawing.Size(60, 26);
            this.txtPMinTime14.TabIndex = 72;
            // 
            // txtPMinTime13
            // 
            this.txtPMinTime13.BackColor = System.Drawing.Color.Black;
            this.txtPMinTime13.ForeColor = System.Drawing.Color.White;
            this.txtPMinTime13.Location = new System.Drawing.Point(451, 433);
            this.txtPMinTime13.Name = "txtPMinTime13";
            this.txtPMinTime13.Size = new System.Drawing.Size(60, 26);
            this.txtPMinTime13.TabIndex = 71;
            // 
            // txtPMinTime12
            // 
            this.txtPMinTime12.BackColor = System.Drawing.Color.Black;
            this.txtPMinTime12.ForeColor = System.Drawing.Color.White;
            this.txtPMinTime12.Location = new System.Drawing.Point(451, 409);
            this.txtPMinTime12.Name = "txtPMinTime12";
            this.txtPMinTime12.Size = new System.Drawing.Size(60, 26);
            this.txtPMinTime12.TabIndex = 70;
            // 
            // txtPMinTime11
            // 
            this.txtPMinTime11.BackColor = System.Drawing.Color.Black;
            this.txtPMinTime11.ForeColor = System.Drawing.Color.White;
            this.txtPMinTime11.Location = new System.Drawing.Point(451, 385);
            this.txtPMinTime11.Name = "txtPMinTime11";
            this.txtPMinTime11.Size = new System.Drawing.Size(60, 26);
            this.txtPMinTime11.TabIndex = 69;
            // 
            // txtPMinTime10
            // 
            this.txtPMinTime10.BackColor = System.Drawing.Color.Black;
            this.txtPMinTime10.ForeColor = System.Drawing.Color.White;
            this.txtPMinTime10.Location = new System.Drawing.Point(451, 361);
            this.txtPMinTime10.Name = "txtPMinTime10";
            this.txtPMinTime10.Size = new System.Drawing.Size(60, 26);
            this.txtPMinTime10.TabIndex = 68;
            // 
            // txtPMinTime9
            // 
            this.txtPMinTime9.BackColor = System.Drawing.Color.Black;
            this.txtPMinTime9.ForeColor = System.Drawing.Color.White;
            this.txtPMinTime9.Location = new System.Drawing.Point(451, 337);
            this.txtPMinTime9.Name = "txtPMinTime9";
            this.txtPMinTime9.Size = new System.Drawing.Size(60, 26);
            this.txtPMinTime9.TabIndex = 67;
            // 
            // txtPMinTime8
            // 
            this.txtPMinTime8.BackColor = System.Drawing.Color.Black;
            this.txtPMinTime8.ForeColor = System.Drawing.Color.White;
            this.txtPMinTime8.Location = new System.Drawing.Point(451, 313);
            this.txtPMinTime8.Name = "txtPMinTime8";
            this.txtPMinTime8.Size = new System.Drawing.Size(60, 26);
            this.txtPMinTime8.TabIndex = 66;
            // 
            // txtPMinTime7
            // 
            this.txtPMinTime7.BackColor = System.Drawing.Color.Black;
            this.txtPMinTime7.ForeColor = System.Drawing.Color.White;
            this.txtPMinTime7.Location = new System.Drawing.Point(451, 289);
            this.txtPMinTime7.Name = "txtPMinTime7";
            this.txtPMinTime7.Size = new System.Drawing.Size(60, 26);
            this.txtPMinTime7.TabIndex = 65;
            // 
            // txtPMinTime6
            // 
            this.txtPMinTime6.BackColor = System.Drawing.Color.Black;
            this.txtPMinTime6.ForeColor = System.Drawing.Color.White;
            this.txtPMinTime6.Location = new System.Drawing.Point(451, 265);
            this.txtPMinTime6.Name = "txtPMinTime6";
            this.txtPMinTime6.Size = new System.Drawing.Size(60, 26);
            this.txtPMinTime6.TabIndex = 64;
            // 
            // txtPMinTime5
            // 
            this.txtPMinTime5.BackColor = System.Drawing.Color.Black;
            this.txtPMinTime5.ForeColor = System.Drawing.Color.White;
            this.txtPMinTime5.Location = new System.Drawing.Point(451, 241);
            this.txtPMinTime5.Name = "txtPMinTime5";
            this.txtPMinTime5.Size = new System.Drawing.Size(60, 26);
            this.txtPMinTime5.TabIndex = 63;
            // 
            // txtPMinTime4
            // 
            this.txtPMinTime4.BackColor = System.Drawing.Color.Black;
            this.txtPMinTime4.ForeColor = System.Drawing.Color.White;
            this.txtPMinTime4.Location = new System.Drawing.Point(451, 217);
            this.txtPMinTime4.Name = "txtPMinTime4";
            this.txtPMinTime4.Size = new System.Drawing.Size(60, 26);
            this.txtPMinTime4.TabIndex = 62;
            // 
            // txtPMinTime3
            // 
            this.txtPMinTime3.BackColor = System.Drawing.Color.Black;
            this.txtPMinTime3.ForeColor = System.Drawing.Color.White;
            this.txtPMinTime3.Location = new System.Drawing.Point(451, 193);
            this.txtPMinTime3.Name = "txtPMinTime3";
            this.txtPMinTime3.Size = new System.Drawing.Size(60, 26);
            this.txtPMinTime3.TabIndex = 61;
            // 
            // label25
            // 
            this.label25.BackColor = System.Drawing.Color.Gold;
            this.label25.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label25.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label25.ForeColor = System.Drawing.Color.Black;
            this.label25.Location = new System.Drawing.Point(449, 106);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(64, 38);
            this.label25.TabIndex = 60;
            this.label25.Text = "P-Min Time";
            this.label25.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // txtPMinTime1
            // 
            this.txtPMinTime1.BackColor = System.Drawing.Color.Black;
            this.txtPMinTime1.ForeColor = System.Drawing.Color.White;
            this.txtPMinTime1.Location = new System.Drawing.Point(451, 145);
            this.txtPMinTime1.Name = "txtPMinTime1";
            this.txtPMinTime1.Size = new System.Drawing.Size(60, 26);
            this.txtPMinTime1.TabIndex = 59;
            // 
            // label23
            // 
            this.label23.BackColor = System.Drawing.Color.Gold;
            this.label23.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label23.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label23.ForeColor = System.Drawing.Color.Black;
            this.label23.Location = new System.Drawing.Point(385, 106);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(64, 38);
            this.label23.TabIndex = 58;
            this.label23.Text = "V-Max Time";
            this.label23.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // txtVMaxTime2
            // 
            this.txtVMaxTime2.BackColor = System.Drawing.Color.Black;
            this.txtVMaxTime2.ForeColor = System.Drawing.Color.White;
            this.txtVMaxTime2.Location = new System.Drawing.Point(389, 170);
            this.txtVMaxTime2.Name = "txtVMaxTime2";
            this.txtVMaxTime2.Size = new System.Drawing.Size(60, 26);
            this.txtVMaxTime2.TabIndex = 57;
            // 
            // txtVMaxTime16
            // 
            this.txtVMaxTime16.BackColor = System.Drawing.Color.Black;
            this.txtVMaxTime16.ForeColor = System.Drawing.Color.White;
            this.txtVMaxTime16.Location = new System.Drawing.Point(389, 506);
            this.txtVMaxTime16.Name = "txtVMaxTime16";
            this.txtVMaxTime16.Size = new System.Drawing.Size(60, 26);
            this.txtVMaxTime16.TabIndex = 56;
            // 
            // txtVMaxTime15
            // 
            this.txtVMaxTime15.BackColor = System.Drawing.Color.Black;
            this.txtVMaxTime15.ForeColor = System.Drawing.Color.White;
            this.txtVMaxTime15.Location = new System.Drawing.Point(389, 482);
            this.txtVMaxTime15.Name = "txtVMaxTime15";
            this.txtVMaxTime15.Size = new System.Drawing.Size(60, 26);
            this.txtVMaxTime15.TabIndex = 55;
            // 
            // txtVMaxTime14
            // 
            this.txtVMaxTime14.BackColor = System.Drawing.Color.Black;
            this.txtVMaxTime14.ForeColor = System.Drawing.Color.White;
            this.txtVMaxTime14.Location = new System.Drawing.Point(389, 458);
            this.txtVMaxTime14.Name = "txtVMaxTime14";
            this.txtVMaxTime14.Size = new System.Drawing.Size(60, 26);
            this.txtVMaxTime14.TabIndex = 54;
            // 
            // txtVMaxTime13
            // 
            this.txtVMaxTime13.BackColor = System.Drawing.Color.Black;
            this.txtVMaxTime13.ForeColor = System.Drawing.Color.White;
            this.txtVMaxTime13.Location = new System.Drawing.Point(389, 434);
            this.txtVMaxTime13.Name = "txtVMaxTime13";
            this.txtVMaxTime13.Size = new System.Drawing.Size(60, 26);
            this.txtVMaxTime13.TabIndex = 53;
            // 
            // txtVMaxTime12
            // 
            this.txtVMaxTime12.BackColor = System.Drawing.Color.Black;
            this.txtVMaxTime12.ForeColor = System.Drawing.Color.White;
            this.txtVMaxTime12.Location = new System.Drawing.Point(389, 410);
            this.txtVMaxTime12.Name = "txtVMaxTime12";
            this.txtVMaxTime12.Size = new System.Drawing.Size(60, 26);
            this.txtVMaxTime12.TabIndex = 52;
            // 
            // txtVMaxTime11
            // 
            this.txtVMaxTime11.BackColor = System.Drawing.Color.Black;
            this.txtVMaxTime11.ForeColor = System.Drawing.Color.White;
            this.txtVMaxTime11.Location = new System.Drawing.Point(389, 386);
            this.txtVMaxTime11.Name = "txtVMaxTime11";
            this.txtVMaxTime11.Size = new System.Drawing.Size(60, 26);
            this.txtVMaxTime11.TabIndex = 51;
            // 
            // txtVMaxTime10
            // 
            this.txtVMaxTime10.BackColor = System.Drawing.Color.Black;
            this.txtVMaxTime10.ForeColor = System.Drawing.Color.White;
            this.txtVMaxTime10.Location = new System.Drawing.Point(389, 362);
            this.txtVMaxTime10.Name = "txtVMaxTime10";
            this.txtVMaxTime10.Size = new System.Drawing.Size(60, 26);
            this.txtVMaxTime10.TabIndex = 50;
            // 
            // txtVMaxTime9
            // 
            this.txtVMaxTime9.BackColor = System.Drawing.Color.Black;
            this.txtVMaxTime9.ForeColor = System.Drawing.Color.White;
            this.txtVMaxTime9.Location = new System.Drawing.Point(389, 338);
            this.txtVMaxTime9.Name = "txtVMaxTime9";
            this.txtVMaxTime9.Size = new System.Drawing.Size(60, 26);
            this.txtVMaxTime9.TabIndex = 49;
            // 
            // txtVMaxTime8
            // 
            this.txtVMaxTime8.BackColor = System.Drawing.Color.Black;
            this.txtVMaxTime8.ForeColor = System.Drawing.Color.White;
            this.txtVMaxTime8.Location = new System.Drawing.Point(389, 314);
            this.txtVMaxTime8.Name = "txtVMaxTime8";
            this.txtVMaxTime8.Size = new System.Drawing.Size(60, 26);
            this.txtVMaxTime8.TabIndex = 48;
            // 
            // txtVMaxTime6
            // 
            this.txtVMaxTime6.BackColor = System.Drawing.Color.Black;
            this.txtVMaxTime6.ForeColor = System.Drawing.Color.White;
            this.txtVMaxTime6.Location = new System.Drawing.Point(389, 266);
            this.txtVMaxTime6.Name = "txtVMaxTime6";
            this.txtVMaxTime6.Size = new System.Drawing.Size(60, 26);
            this.txtVMaxTime6.TabIndex = 46;
            // 
            // txtVMaxTime5
            // 
            this.txtVMaxTime5.BackColor = System.Drawing.Color.Black;
            this.txtVMaxTime5.ForeColor = System.Drawing.Color.White;
            this.txtVMaxTime5.Location = new System.Drawing.Point(389, 242);
            this.txtVMaxTime5.Name = "txtVMaxTime5";
            this.txtVMaxTime5.Size = new System.Drawing.Size(60, 26);
            this.txtVMaxTime5.TabIndex = 45;
            // 
            // txtVMaxTime4
            // 
            this.txtVMaxTime4.BackColor = System.Drawing.Color.Black;
            this.txtVMaxTime4.ForeColor = System.Drawing.Color.White;
            this.txtVMaxTime4.Location = new System.Drawing.Point(389, 218);
            this.txtVMaxTime4.Name = "txtVMaxTime4";
            this.txtVMaxTime4.Size = new System.Drawing.Size(60, 26);
            this.txtVMaxTime4.TabIndex = 44;
            // 
            // txtVMaxTime3
            // 
            this.txtVMaxTime3.BackColor = System.Drawing.Color.Black;
            this.txtVMaxTime3.ForeColor = System.Drawing.Color.White;
            this.txtVMaxTime3.Location = new System.Drawing.Point(389, 194);
            this.txtVMaxTime3.Name = "txtVMaxTime3";
            this.txtVMaxTime3.Size = new System.Drawing.Size(60, 26);
            this.txtVMaxTime3.TabIndex = 43;
            // 
            // txtVMaxTime1
            // 
            this.txtVMaxTime1.BackColor = System.Drawing.Color.Black;
            this.txtVMaxTime1.ForeColor = System.Drawing.Color.White;
            this.txtVMaxTime1.Location = new System.Drawing.Point(389, 146);
            this.txtVMaxTime1.Name = "txtVMaxTime1";
            this.txtVMaxTime1.Size = new System.Drawing.Size(60, 26);
            this.txtVMaxTime1.TabIndex = 42;
            // 
            // txtVMinTime2
            // 
            this.txtVMinTime2.BackColor = System.Drawing.Color.Black;
            this.txtVMinTime2.ForeColor = System.Drawing.Color.White;
            this.txtVMinTime2.Location = new System.Drawing.Point(323, 169);
            this.txtVMinTime2.Name = "txtVMinTime2";
            this.txtVMinTime2.Size = new System.Drawing.Size(60, 26);
            this.txtVMinTime2.TabIndex = 41;
            // 
            // txtVMinTime16
            // 
            this.txtVMinTime16.BackColor = System.Drawing.Color.Black;
            this.txtVMinTime16.ForeColor = System.Drawing.Color.White;
            this.txtVMinTime16.Location = new System.Drawing.Point(323, 505);
            this.txtVMinTime16.Name = "txtVMinTime16";
            this.txtVMinTime16.Size = new System.Drawing.Size(60, 26);
            this.txtVMinTime16.TabIndex = 40;
            // 
            // txtVMinTime15
            // 
            this.txtVMinTime15.BackColor = System.Drawing.Color.Black;
            this.txtVMinTime15.ForeColor = System.Drawing.Color.White;
            this.txtVMinTime15.Location = new System.Drawing.Point(323, 481);
            this.txtVMinTime15.Name = "txtVMinTime15";
            this.txtVMinTime15.Size = new System.Drawing.Size(60, 26);
            this.txtVMinTime15.TabIndex = 39;
            // 
            // txtVMinTime14
            // 
            this.txtVMinTime14.BackColor = System.Drawing.Color.Black;
            this.txtVMinTime14.ForeColor = System.Drawing.Color.White;
            this.txtVMinTime14.Location = new System.Drawing.Point(323, 457);
            this.txtVMinTime14.Name = "txtVMinTime14";
            this.txtVMinTime14.Size = new System.Drawing.Size(60, 26);
            this.txtVMinTime14.TabIndex = 38;
            // 
            // txtVMinTime13
            // 
            this.txtVMinTime13.BackColor = System.Drawing.Color.Black;
            this.txtVMinTime13.ForeColor = System.Drawing.Color.White;
            this.txtVMinTime13.Location = new System.Drawing.Point(323, 433);
            this.txtVMinTime13.Name = "txtVMinTime13";
            this.txtVMinTime13.Size = new System.Drawing.Size(60, 26);
            this.txtVMinTime13.TabIndex = 37;
            // 
            // txtVMinTime12
            // 
            this.txtVMinTime12.BackColor = System.Drawing.Color.Black;
            this.txtVMinTime12.ForeColor = System.Drawing.Color.White;
            this.txtVMinTime12.Location = new System.Drawing.Point(323, 409);
            this.txtVMinTime12.Name = "txtVMinTime12";
            this.txtVMinTime12.Size = new System.Drawing.Size(60, 26);
            this.txtVMinTime12.TabIndex = 36;
            // 
            // txtVMinTime11
            // 
            this.txtVMinTime11.BackColor = System.Drawing.Color.Black;
            this.txtVMinTime11.ForeColor = System.Drawing.Color.White;
            this.txtVMinTime11.Location = new System.Drawing.Point(323, 385);
            this.txtVMinTime11.Name = "txtVMinTime11";
            this.txtVMinTime11.Size = new System.Drawing.Size(60, 26);
            this.txtVMinTime11.TabIndex = 35;
            // 
            // txtVMinTime10
            // 
            this.txtVMinTime10.BackColor = System.Drawing.Color.Black;
            this.txtVMinTime10.ForeColor = System.Drawing.Color.White;
            this.txtVMinTime10.Location = new System.Drawing.Point(323, 361);
            this.txtVMinTime10.Name = "txtVMinTime10";
            this.txtVMinTime10.Size = new System.Drawing.Size(60, 26);
            this.txtVMinTime10.TabIndex = 34;
            // 
            // txtVMinTime9
            // 
            this.txtVMinTime9.BackColor = System.Drawing.Color.Black;
            this.txtVMinTime9.ForeColor = System.Drawing.Color.White;
            this.txtVMinTime9.Location = new System.Drawing.Point(323, 337);
            this.txtVMinTime9.Name = "txtVMinTime9";
            this.txtVMinTime9.Size = new System.Drawing.Size(60, 26);
            this.txtVMinTime9.TabIndex = 33;
            // 
            // txtVMinTime8
            // 
            this.txtVMinTime8.BackColor = System.Drawing.Color.Black;
            this.txtVMinTime8.ForeColor = System.Drawing.Color.White;
            this.txtVMinTime8.Location = new System.Drawing.Point(323, 313);
            this.txtVMinTime8.Name = "txtVMinTime8";
            this.txtVMinTime8.Size = new System.Drawing.Size(60, 26);
            this.txtVMinTime8.TabIndex = 32;
            // 
            // txtVMinTime7
            // 
            this.txtVMinTime7.BackColor = System.Drawing.Color.Black;
            this.txtVMinTime7.ForeColor = System.Drawing.Color.White;
            this.txtVMinTime7.Location = new System.Drawing.Point(323, 289);
            this.txtVMinTime7.Name = "txtVMinTime7";
            this.txtVMinTime7.Size = new System.Drawing.Size(60, 26);
            this.txtVMinTime7.TabIndex = 31;
            // 
            // txtVMinTime6
            // 
            this.txtVMinTime6.BackColor = System.Drawing.Color.Black;
            this.txtVMinTime6.ForeColor = System.Drawing.Color.White;
            this.txtVMinTime6.Location = new System.Drawing.Point(323, 265);
            this.txtVMinTime6.Name = "txtVMinTime6";
            this.txtVMinTime6.Size = new System.Drawing.Size(60, 26);
            this.txtVMinTime6.TabIndex = 30;
            // 
            // txtVMinTime5
            // 
            this.txtVMinTime5.BackColor = System.Drawing.Color.Black;
            this.txtVMinTime5.ForeColor = System.Drawing.Color.White;
            this.txtVMinTime5.Location = new System.Drawing.Point(323, 241);
            this.txtVMinTime5.Name = "txtVMinTime5";
            this.txtVMinTime5.Size = new System.Drawing.Size(60, 26);
            this.txtVMinTime5.TabIndex = 29;
            // 
            // txtVMinTime4
            // 
            this.txtVMinTime4.BackColor = System.Drawing.Color.Black;
            this.txtVMinTime4.ForeColor = System.Drawing.Color.White;
            this.txtVMinTime4.Location = new System.Drawing.Point(323, 217);
            this.txtVMinTime4.Name = "txtVMinTime4";
            this.txtVMinTime4.Size = new System.Drawing.Size(60, 26);
            this.txtVMinTime4.TabIndex = 28;
            // 
            // txtVMinTime3
            // 
            this.txtVMinTime3.BackColor = System.Drawing.Color.Black;
            this.txtVMinTime3.ForeColor = System.Drawing.Color.White;
            this.txtVMinTime3.Location = new System.Drawing.Point(323, 193);
            this.txtVMinTime3.Name = "txtVMinTime3";
            this.txtVMinTime3.Size = new System.Drawing.Size(60, 26);
            this.txtVMinTime3.TabIndex = 27;
            // 
            // label22
            // 
            this.label22.BackColor = System.Drawing.Color.Gold;
            this.label22.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label22.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label22.ForeColor = System.Drawing.Color.Black;
            this.label22.Location = new System.Drawing.Point(321, 106);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(64, 38);
            this.label22.TabIndex = 26;
            this.label22.Text = "V-Min Time";
            this.label22.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // txtVMinTime1
            // 
            this.txtVMinTime1.BackColor = System.Drawing.Color.Black;
            this.txtVMinTime1.ForeColor = System.Drawing.Color.White;
            this.txtVMinTime1.Location = new System.Drawing.Point(323, 145);
            this.txtVMinTime1.Name = "txtVMinTime1";
            this.txtVMinTime1.Size = new System.Drawing.Size(60, 26);
            this.txtVMinTime1.TabIndex = 25;
            // 
            // label34
            // 
            this.label34.BackColor = System.Drawing.Color.Gold;
            this.label34.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label34.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label34.ForeColor = System.Drawing.Color.Black;
            this.label34.Location = new System.Drawing.Point(164, 106);
            this.label34.Name = "label34";
            this.label34.Size = new System.Drawing.Size(55, 38);
            this.label34.TabIndex = 18;
            this.label34.Text = "PED Status";
            this.label34.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label33
            // 
            this.label33.BackColor = System.Drawing.Color.Gold;
            this.label33.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label33.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label33.ForeColor = System.Drawing.Color.Black;
            this.label33.Location = new System.Drawing.Point(34, 106);
            this.label33.Name = "label33";
            this.label33.Size = new System.Drawing.Size(67, 38);
            this.label33.TabIndex = 17;
            this.label33.Text = "PHASE Status";
            this.label33.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label16
            // 
            this.label16.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label16.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label16.ForeColor = System.Drawing.Color.Black;
            this.label16.Location = new System.Drawing.Point(10, 504);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(26, 24);
            this.label16.TabIndex = 16;
            this.label16.Text = "16";
            this.label16.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label15
            // 
            this.label15.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label15.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label15.ForeColor = System.Drawing.Color.Black;
            this.label15.Location = new System.Drawing.Point(10, 480);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(26, 24);
            this.label15.TabIndex = 15;
            this.label15.Text = "15";
            this.label15.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label14
            // 
            this.label14.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label14.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label14.ForeColor = System.Drawing.Color.Black;
            this.label14.Location = new System.Drawing.Point(10, 456);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(26, 24);
            this.label14.TabIndex = 14;
            this.label14.Text = "14";
            this.label14.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label13
            // 
            this.label13.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label13.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label13.ForeColor = System.Drawing.Color.Black;
            this.label13.Location = new System.Drawing.Point(10, 432);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(26, 24);
            this.label13.TabIndex = 13;
            this.label13.Text = "13";
            this.label13.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label12
            // 
            this.label12.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label12.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.ForeColor = System.Drawing.Color.Black;
            this.label12.Location = new System.Drawing.Point(10, 408);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(26, 24);
            this.label12.TabIndex = 12;
            this.label12.Text = "12";
            this.label12.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label11
            // 
            this.label11.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label11.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.ForeColor = System.Drawing.Color.Black;
            this.label11.Location = new System.Drawing.Point(10, 384);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(26, 24);
            this.label11.TabIndex = 11;
            this.label11.Text = "11";
            this.label11.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label10
            // 
            this.label10.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label10.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.ForeColor = System.Drawing.Color.Black;
            this.label10.Location = new System.Drawing.Point(10, 360);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(26, 24);
            this.label10.TabIndex = 10;
            this.label10.Text = "10";
            this.label10.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label9
            // 
            this.label9.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label9.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.ForeColor = System.Drawing.Color.Black;
            this.label9.Location = new System.Drawing.Point(10, 336);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(26, 24);
            this.label9.TabIndex = 9;
            this.label9.Text = "9";
            this.label9.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label8
            // 
            this.label8.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.ForeColor = System.Drawing.Color.Black;
            this.label8.Location = new System.Drawing.Point(10, 312);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(26, 24);
            this.label8.TabIndex = 8;
            this.label8.Text = "8";
            this.label8.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label7
            // 
            this.label7.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.ForeColor = System.Drawing.Color.Black;
            this.label7.Location = new System.Drawing.Point(10, 288);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(26, 24);
            this.label7.TabIndex = 7;
            this.label7.Text = "7";
            this.label7.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label6
            // 
            this.label6.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.ForeColor = System.Drawing.Color.Black;
            this.label6.Location = new System.Drawing.Point(10, 264);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(26, 24);
            this.label6.TabIndex = 6;
            this.label6.Text = "6";
            this.label6.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label5
            // 
            this.label5.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.Color.Black;
            this.label5.Location = new System.Drawing.Point(10, 240);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(26, 24);
            this.label5.TabIndex = 5;
            this.label5.Text = "5";
            this.label5.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label4
            // 
            this.label4.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.Color.Black;
            this.label4.Location = new System.Drawing.Point(10, 216);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(26, 24);
            this.label4.TabIndex = 4;
            this.label4.Text = "4";
            this.label4.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label3
            // 
            this.label3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.Black;
            this.label3.Location = new System.Drawing.Point(10, 192);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(26, 24);
            this.label3.TabIndex = 3;
            this.label3.Text = "3";
            this.label3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label2
            // 
            this.label2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.Black;
            this.label2.Location = new System.Drawing.Point(10, 168);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(26, 24);
            this.label2.TabIndex = 2;
            this.label2.Text = "2";
            this.label2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label1
            // 
            this.label1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.Black;
            this.label1.Location = new System.Drawing.Point(10, 144);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(26, 24);
            this.label1.TabIndex = 1;
            this.label1.Text = "1";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // shapeContainer1
            // 
            this.shapeContainer1.Location = new System.Drawing.Point(3, 22);
            this.shapeContainer1.Margin = new System.Windows.Forms.Padding(0);
            this.shapeContainer1.Name = "shapeContainer1";
            this.shapeContainer1.Shapes.AddRange(new Microsoft.VisualBasic.PowerPacks.Shape[] {
            this.shpOvlp16,
            this.shpOvlp15,
            this.shpOvlp14,
            this.shpOvlp13,
            this.shpOvlp12,
            this.shpOvlp11,
            this.shpOvlp10,
            this.shpOvlp9,
            this.shpOvlp8,
            this.shpOvlp7,
            this.shpOvlp6,
            this.shpOvlp5,
            this.shpOvlp4,
            this.shpOvlp3,
            this.shpOvlp2,
            this.shpOvlp1,
            this.shpPed1,
            this.shpPed2,
            this.shpPed3,
            this.shpPed4,
            this.shpPed5,
            this.shpPed6,
            this.shpPed7,
            this.shpPed8,
            this.shpPed9,
            this.shpPed10,
            this.shpPed11,
            this.shpPed12,
            this.shpPed13,
            this.shpPed14,
            this.shpPed15,
            this.shpPed16,
            this.shpPhase16,
            this.shpPhase15,
            this.shpPhase14,
            this.shpPhase13,
            this.shpPhase12,
            this.shpPhase11,
            this.shpPhase10,
            this.shpPhase9,
            this.shpPhase8,
            this.shpPhase7,
            this.shpPhase6,
            this.shpPhase5,
            this.shpPhase4,
            this.shpPhase3,
            this.shpPhase2,
            this.shpPhase1});
            this.shapeContainer1.Size = new System.Drawing.Size(702, 510);
            this.shapeContainer1.TabIndex = 130;
            this.shapeContainer1.TabStop = false;
            // 
            // shpOvlp16
            // 
            this.shpOvlp16.BackColor = System.Drawing.SystemColors.ControlDarkDark;
            this.shpOvlp16.BackStyle = Microsoft.VisualBasic.PowerPacks.BackStyle.Opaque;
            this.shpOvlp16.BorderColor = System.Drawing.Color.Black;
            this.shpOvlp16.BorderWidth = 2;
            this.shpOvlp16.Location = new System.Drawing.Point(115, 483);
            this.shpOvlp16.Name = "shpOvlp16";
            this.shpOvlp16.Size = new System.Drawing.Size(22, 22);
            // 
            // shpOvlp15
            // 
            this.shpOvlp15.BackColor = System.Drawing.SystemColors.ControlDarkDark;
            this.shpOvlp15.BackStyle = Microsoft.VisualBasic.PowerPacks.BackStyle.Opaque;
            this.shpOvlp15.BorderColor = System.Drawing.Color.Black;
            this.shpOvlp15.BorderWidth = 2;
            this.shpOvlp15.Location = new System.Drawing.Point(115, 459);
            this.shpOvlp15.Name = "shpOvlp15";
            this.shpOvlp15.Size = new System.Drawing.Size(22, 22);
            // 
            // shpOvlp14
            // 
            this.shpOvlp14.BackColor = System.Drawing.SystemColors.ControlDarkDark;
            this.shpOvlp14.BackStyle = Microsoft.VisualBasic.PowerPacks.BackStyle.Opaque;
            this.shpOvlp14.BorderColor = System.Drawing.Color.Black;
            this.shpOvlp14.BorderWidth = 2;
            this.shpOvlp14.Location = new System.Drawing.Point(115, 435);
            this.shpOvlp14.Name = "shpOvlp14";
            this.shpOvlp14.Size = new System.Drawing.Size(22, 22);
            // 
            // shpOvlp13
            // 
            this.shpOvlp13.BackColor = System.Drawing.SystemColors.ControlDarkDark;
            this.shpOvlp13.BackStyle = Microsoft.VisualBasic.PowerPacks.BackStyle.Opaque;
            this.shpOvlp13.BorderColor = System.Drawing.Color.Black;
            this.shpOvlp13.BorderWidth = 2;
            this.shpOvlp13.Location = new System.Drawing.Point(115, 411);
            this.shpOvlp13.Name = "shpOvlp13";
            this.shpOvlp13.Size = new System.Drawing.Size(22, 22);
            // 
            // shpOvlp12
            // 
            this.shpOvlp12.BackColor = System.Drawing.SystemColors.ControlDarkDark;
            this.shpOvlp12.BackStyle = Microsoft.VisualBasic.PowerPacks.BackStyle.Opaque;
            this.shpOvlp12.BorderColor = System.Drawing.Color.Black;
            this.shpOvlp12.BorderWidth = 2;
            this.shpOvlp12.Location = new System.Drawing.Point(115, 387);
            this.shpOvlp12.Name = "shpOvlp12";
            this.shpOvlp12.Size = new System.Drawing.Size(22, 22);
            // 
            // shpOvlp11
            // 
            this.shpOvlp11.BackColor = System.Drawing.SystemColors.ControlDarkDark;
            this.shpOvlp11.BackStyle = Microsoft.VisualBasic.PowerPacks.BackStyle.Opaque;
            this.shpOvlp11.BorderColor = System.Drawing.Color.Black;
            this.shpOvlp11.BorderWidth = 2;
            this.shpOvlp11.Location = new System.Drawing.Point(115, 363);
            this.shpOvlp11.Name = "shpOvlp11";
            this.shpOvlp11.Size = new System.Drawing.Size(22, 22);
            // 
            // shpOvlp10
            // 
            this.shpOvlp10.BackColor = System.Drawing.SystemColors.ControlDarkDark;
            this.shpOvlp10.BackStyle = Microsoft.VisualBasic.PowerPacks.BackStyle.Opaque;
            this.shpOvlp10.BorderColor = System.Drawing.Color.Black;
            this.shpOvlp10.BorderWidth = 2;
            this.shpOvlp10.Location = new System.Drawing.Point(115, 339);
            this.shpOvlp10.Name = "shpOvlp10";
            this.shpOvlp10.Size = new System.Drawing.Size(22, 22);
            // 
            // shpOvlp9
            // 
            this.shpOvlp9.BackColor = System.Drawing.SystemColors.ControlDarkDark;
            this.shpOvlp9.BackStyle = Microsoft.VisualBasic.PowerPacks.BackStyle.Opaque;
            this.shpOvlp9.BorderColor = System.Drawing.Color.Black;
            this.shpOvlp9.BorderWidth = 2;
            this.shpOvlp9.Location = new System.Drawing.Point(115, 315);
            this.shpOvlp9.Name = "shpOvlp9";
            this.shpOvlp9.Size = new System.Drawing.Size(22, 22);
            // 
            // shpOvlp8
            // 
            this.shpOvlp8.BackColor = System.Drawing.SystemColors.ControlDarkDark;
            this.shpOvlp8.BackStyle = Microsoft.VisualBasic.PowerPacks.BackStyle.Opaque;
            this.shpOvlp8.BorderColor = System.Drawing.Color.Black;
            this.shpOvlp8.BorderWidth = 2;
            this.shpOvlp8.Location = new System.Drawing.Point(115, 291);
            this.shpOvlp8.Name = "shpOvlp8";
            this.shpOvlp8.Size = new System.Drawing.Size(22, 22);
            // 
            // shpOvlp7
            // 
            this.shpOvlp7.BackColor = System.Drawing.SystemColors.ControlDarkDark;
            this.shpOvlp7.BackStyle = Microsoft.VisualBasic.PowerPacks.BackStyle.Opaque;
            this.shpOvlp7.BorderColor = System.Drawing.Color.Black;
            this.shpOvlp7.BorderWidth = 2;
            this.shpOvlp7.Location = new System.Drawing.Point(115, 267);
            this.shpOvlp7.Name = "shpOvlp7";
            this.shpOvlp7.Size = new System.Drawing.Size(22, 22);
            // 
            // shpOvlp6
            // 
            this.shpOvlp6.BackColor = System.Drawing.SystemColors.ControlDarkDark;
            this.shpOvlp6.BackStyle = Microsoft.VisualBasic.PowerPacks.BackStyle.Opaque;
            this.shpOvlp6.BorderColor = System.Drawing.Color.Black;
            this.shpOvlp6.BorderWidth = 2;
            this.shpOvlp6.Location = new System.Drawing.Point(115, 243);
            this.shpOvlp6.Name = "shpOvlp6";
            this.shpOvlp6.Size = new System.Drawing.Size(22, 22);
            // 
            // shpOvlp5
            // 
            this.shpOvlp5.BackColor = System.Drawing.SystemColors.ControlDarkDark;
            this.shpOvlp5.BackStyle = Microsoft.VisualBasic.PowerPacks.BackStyle.Opaque;
            this.shpOvlp5.BorderColor = System.Drawing.Color.Black;
            this.shpOvlp5.BorderWidth = 2;
            this.shpOvlp5.Location = new System.Drawing.Point(115, 219);
            this.shpOvlp5.Name = "shpOvlp5";
            this.shpOvlp5.Size = new System.Drawing.Size(22, 22);
            // 
            // shpOvlp4
            // 
            this.shpOvlp4.BackColor = System.Drawing.SystemColors.ControlDarkDark;
            this.shpOvlp4.BackStyle = Microsoft.VisualBasic.PowerPacks.BackStyle.Opaque;
            this.shpOvlp4.BorderColor = System.Drawing.Color.Black;
            this.shpOvlp4.BorderWidth = 2;
            this.shpOvlp4.Location = new System.Drawing.Point(115, 195);
            this.shpOvlp4.Name = "shpOvlp4";
            this.shpOvlp4.Size = new System.Drawing.Size(22, 22);
            // 
            // shpOvlp3
            // 
            this.shpOvlp3.BackColor = System.Drawing.SystemColors.ControlDarkDark;
            this.shpOvlp3.BackStyle = Microsoft.VisualBasic.PowerPacks.BackStyle.Opaque;
            this.shpOvlp3.BorderColor = System.Drawing.Color.Black;
            this.shpOvlp3.BorderWidth = 2;
            this.shpOvlp3.Location = new System.Drawing.Point(115, 171);
            this.shpOvlp3.Name = "shpOvlp3";
            this.shpOvlp3.Size = new System.Drawing.Size(22, 22);
            // 
            // shpOvlp2
            // 
            this.shpOvlp2.BackColor = System.Drawing.SystemColors.ControlDarkDark;
            this.shpOvlp2.BackStyle = Microsoft.VisualBasic.PowerPacks.BackStyle.Opaque;
            this.shpOvlp2.BorderColor = System.Drawing.Color.Black;
            this.shpOvlp2.BorderWidth = 2;
            this.shpOvlp2.Location = new System.Drawing.Point(115, 147);
            this.shpOvlp2.Name = "shpOvlp2";
            this.shpOvlp2.Size = new System.Drawing.Size(22, 22);
            // 
            // shpOvlp1
            // 
            this.shpOvlp1.BackColor = System.Drawing.SystemColors.ControlDarkDark;
            this.shpOvlp1.BackStyle = Microsoft.VisualBasic.PowerPacks.BackStyle.Opaque;
            this.shpOvlp1.BorderColor = System.Drawing.Color.Black;
            this.shpOvlp1.BorderWidth = 2;
            this.shpOvlp1.Location = new System.Drawing.Point(115, 123);
            this.shpOvlp1.Name = "shpOvlp1";
            this.shpOvlp1.Size = new System.Drawing.Size(22, 22);
            // 
            // shpPed1
            // 
            this.shpPed1.BackColor = System.Drawing.SystemColors.ControlDarkDark;
            this.shpPed1.BackStyle = Microsoft.VisualBasic.PowerPacks.BackStyle.Opaque;
            this.shpPed1.BorderColor = System.Drawing.Color.Black;
            this.shpPed1.BorderWidth = 2;
            this.shpPed1.Location = new System.Drawing.Point(168, 123);
            this.shpPed1.Name = "shpPed1";
            this.shpPed1.Size = new System.Drawing.Size(22, 22);
            // 
            // shpPed2
            // 
            this.shpPed2.BackColor = System.Drawing.SystemColors.ControlDarkDark;
            this.shpPed2.BackStyle = Microsoft.VisualBasic.PowerPacks.BackStyle.Opaque;
            this.shpPed2.BorderColor = System.Drawing.Color.Black;
            this.shpPed2.BorderWidth = 2;
            this.shpPed2.Location = new System.Drawing.Point(168, 147);
            this.shpPed2.Name = "shpPed2";
            this.shpPed2.Size = new System.Drawing.Size(22, 22);
            // 
            // shpPed3
            // 
            this.shpPed3.BackColor = System.Drawing.SystemColors.ControlDarkDark;
            this.shpPed3.BackStyle = Microsoft.VisualBasic.PowerPacks.BackStyle.Opaque;
            this.shpPed3.BorderColor = System.Drawing.Color.Black;
            this.shpPed3.BorderWidth = 2;
            this.shpPed3.Location = new System.Drawing.Point(168, 171);
            this.shpPed3.Name = "shpPed3";
            this.shpPed3.Size = new System.Drawing.Size(22, 22);
            // 
            // shpPed4
            // 
            this.shpPed4.BackColor = System.Drawing.SystemColors.ControlDarkDark;
            this.shpPed4.BackStyle = Microsoft.VisualBasic.PowerPacks.BackStyle.Opaque;
            this.shpPed4.BorderColor = System.Drawing.Color.Black;
            this.shpPed4.BorderWidth = 2;
            this.shpPed4.Location = new System.Drawing.Point(168, 195);
            this.shpPed4.Name = "shpPed4";
            this.shpPed4.Size = new System.Drawing.Size(22, 22);
            // 
            // shpPed5
            // 
            this.shpPed5.BackColor = System.Drawing.SystemColors.ControlDarkDark;
            this.shpPed5.BackStyle = Microsoft.VisualBasic.PowerPacks.BackStyle.Opaque;
            this.shpPed5.BorderColor = System.Drawing.Color.Black;
            this.shpPed5.BorderWidth = 2;
            this.shpPed5.Location = new System.Drawing.Point(168, 219);
            this.shpPed5.Name = "shpPed5";
            this.shpPed5.Size = new System.Drawing.Size(22, 22);
            // 
            // shpPed6
            // 
            this.shpPed6.BackColor = System.Drawing.SystemColors.ControlDarkDark;
            this.shpPed6.BackStyle = Microsoft.VisualBasic.PowerPacks.BackStyle.Opaque;
            this.shpPed6.BorderColor = System.Drawing.Color.Black;
            this.shpPed6.BorderWidth = 2;
            this.shpPed6.Location = new System.Drawing.Point(168, 243);
            this.shpPed6.Name = "shpPed6";
            this.shpPed6.Size = new System.Drawing.Size(22, 22);
            // 
            // shpPed7
            // 
            this.shpPed7.BackColor = System.Drawing.SystemColors.ControlDarkDark;
            this.shpPed7.BackStyle = Microsoft.VisualBasic.PowerPacks.BackStyle.Opaque;
            this.shpPed7.BorderColor = System.Drawing.Color.Black;
            this.shpPed7.BorderWidth = 2;
            this.shpPed7.Location = new System.Drawing.Point(168, 267);
            this.shpPed7.Name = "shpPed7";
            this.shpPed7.Size = new System.Drawing.Size(22, 22);
            // 
            // shpPed8
            // 
            this.shpPed8.BackColor = System.Drawing.SystemColors.ControlDarkDark;
            this.shpPed8.BackStyle = Microsoft.VisualBasic.PowerPacks.BackStyle.Opaque;
            this.shpPed8.BorderColor = System.Drawing.Color.Black;
            this.shpPed8.BorderWidth = 2;
            this.shpPed8.Location = new System.Drawing.Point(168, 291);
            this.shpPed8.Name = "shpPed8";
            this.shpPed8.Size = new System.Drawing.Size(22, 22);
            // 
            // shpPed9
            // 
            this.shpPed9.BackColor = System.Drawing.SystemColors.ControlDarkDark;
            this.shpPed9.BackStyle = Microsoft.VisualBasic.PowerPacks.BackStyle.Opaque;
            this.shpPed9.BorderColor = System.Drawing.Color.Black;
            this.shpPed9.BorderWidth = 2;
            this.shpPed9.Location = new System.Drawing.Point(168, 315);
            this.shpPed9.Name = "shpPed9";
            this.shpPed9.Size = new System.Drawing.Size(22, 22);
            // 
            // shpPed10
            // 
            this.shpPed10.BackColor = System.Drawing.SystemColors.ControlDarkDark;
            this.shpPed10.BackStyle = Microsoft.VisualBasic.PowerPacks.BackStyle.Opaque;
            this.shpPed10.BorderColor = System.Drawing.Color.Black;
            this.shpPed10.BorderWidth = 2;
            this.shpPed10.Location = new System.Drawing.Point(168, 339);
            this.shpPed10.Name = "shpPed10";
            this.shpPed10.Size = new System.Drawing.Size(22, 22);
            // 
            // shpPed11
            // 
            this.shpPed11.BackColor = System.Drawing.SystemColors.ControlDarkDark;
            this.shpPed11.BackStyle = Microsoft.VisualBasic.PowerPacks.BackStyle.Opaque;
            this.shpPed11.BorderColor = System.Drawing.Color.Black;
            this.shpPed11.BorderWidth = 2;
            this.shpPed11.Location = new System.Drawing.Point(168, 363);
            this.shpPed11.Name = "shpPed11";
            this.shpPed11.Size = new System.Drawing.Size(22, 22);
            // 
            // shpPed12
            // 
            this.shpPed12.BackColor = System.Drawing.SystemColors.ControlDarkDark;
            this.shpPed12.BackStyle = Microsoft.VisualBasic.PowerPacks.BackStyle.Opaque;
            this.shpPed12.BorderColor = System.Drawing.Color.Black;
            this.shpPed12.BorderWidth = 2;
            this.shpPed12.Location = new System.Drawing.Point(168, 387);
            this.shpPed12.Name = "shpPed12";
            this.shpPed12.Size = new System.Drawing.Size(22, 22);
            // 
            // shpPed13
            // 
            this.shpPed13.BackColor = System.Drawing.SystemColors.ControlDarkDark;
            this.shpPed13.BackStyle = Microsoft.VisualBasic.PowerPacks.BackStyle.Opaque;
            this.shpPed13.BorderColor = System.Drawing.Color.Black;
            this.shpPed13.BorderWidth = 2;
            this.shpPed13.Location = new System.Drawing.Point(168, 411);
            this.shpPed13.Name = "shpPed13";
            this.shpPed13.Size = new System.Drawing.Size(22, 22);
            // 
            // shpPed14
            // 
            this.shpPed14.BackColor = System.Drawing.SystemColors.ControlDarkDark;
            this.shpPed14.BackStyle = Microsoft.VisualBasic.PowerPacks.BackStyle.Opaque;
            this.shpPed14.BorderColor = System.Drawing.Color.Black;
            this.shpPed14.BorderWidth = 2;
            this.shpPed14.Location = new System.Drawing.Point(168, 435);
            this.shpPed14.Name = "shpPed14";
            this.shpPed14.Size = new System.Drawing.Size(22, 22);
            // 
            // shpPed15
            // 
            this.shpPed15.BackColor = System.Drawing.SystemColors.ControlDarkDark;
            this.shpPed15.BackStyle = Microsoft.VisualBasic.PowerPacks.BackStyle.Opaque;
            this.shpPed15.BorderColor = System.Drawing.Color.Black;
            this.shpPed15.BorderWidth = 2;
            this.shpPed15.Location = new System.Drawing.Point(168, 459);
            this.shpPed15.Name = "shpPed15";
            this.shpPed15.Size = new System.Drawing.Size(22, 22);
            // 
            // shpPed16
            // 
            this.shpPed16.BackColor = System.Drawing.SystemColors.ControlDarkDark;
            this.shpPed16.BackStyle = Microsoft.VisualBasic.PowerPacks.BackStyle.Opaque;
            this.shpPed16.BorderColor = System.Drawing.Color.Black;
            this.shpPed16.BorderWidth = 2;
            this.shpPed16.Location = new System.Drawing.Point(168, 483);
            this.shpPed16.Name = "shpPed16";
            this.shpPed16.Size = new System.Drawing.Size(22, 22);
            // 
            // shpPhase16
            // 
            this.shpPhase16.BackColor = System.Drawing.SystemColors.ControlDarkDark;
            this.shpPhase16.BackStyle = Microsoft.VisualBasic.PowerPacks.BackStyle.Opaque;
            this.shpPhase16.BorderColor = System.Drawing.Color.Black;
            this.shpPhase16.BorderWidth = 2;
            this.shpPhase16.Location = new System.Drawing.Point(59, 483);
            this.shpPhase16.Name = "shpPhase16";
            this.shpPhase16.Size = new System.Drawing.Size(22, 22);
            // 
            // shpPhase15
            // 
            this.shpPhase15.BackColor = System.Drawing.SystemColors.ControlDarkDark;
            this.shpPhase15.BackStyle = Microsoft.VisualBasic.PowerPacks.BackStyle.Opaque;
            this.shpPhase15.BorderColor = System.Drawing.Color.Black;
            this.shpPhase15.BorderWidth = 2;
            this.shpPhase15.Location = new System.Drawing.Point(59, 459);
            this.shpPhase15.Name = "shpPhase15";
            this.shpPhase15.Size = new System.Drawing.Size(22, 22);
            // 
            // shpPhase14
            // 
            this.shpPhase14.BackColor = System.Drawing.SystemColors.ControlDarkDark;
            this.shpPhase14.BackStyle = Microsoft.VisualBasic.PowerPacks.BackStyle.Opaque;
            this.shpPhase14.BorderColor = System.Drawing.Color.Black;
            this.shpPhase14.BorderWidth = 2;
            this.shpPhase14.Location = new System.Drawing.Point(59, 435);
            this.shpPhase14.Name = "shpPhase14";
            this.shpPhase14.Size = new System.Drawing.Size(22, 22);
            // 
            // shpPhase13
            // 
            this.shpPhase13.BackColor = System.Drawing.SystemColors.ControlDarkDark;
            this.shpPhase13.BackStyle = Microsoft.VisualBasic.PowerPacks.BackStyle.Opaque;
            this.shpPhase13.BorderColor = System.Drawing.Color.Black;
            this.shpPhase13.BorderWidth = 2;
            this.shpPhase13.Location = new System.Drawing.Point(59, 411);
            this.shpPhase13.Name = "shpPhase13";
            this.shpPhase13.Size = new System.Drawing.Size(22, 22);
            // 
            // shpPhase12
            // 
            this.shpPhase12.BackColor = System.Drawing.SystemColors.ControlDarkDark;
            this.shpPhase12.BackStyle = Microsoft.VisualBasic.PowerPacks.BackStyle.Opaque;
            this.shpPhase12.BorderColor = System.Drawing.Color.Black;
            this.shpPhase12.BorderWidth = 2;
            this.shpPhase12.Location = new System.Drawing.Point(59, 387);
            this.shpPhase12.Name = "shpPhase12";
            this.shpPhase12.Size = new System.Drawing.Size(22, 22);
            // 
            // shpPhase11
            // 
            this.shpPhase11.BackColor = System.Drawing.SystemColors.ControlDarkDark;
            this.shpPhase11.BackStyle = Microsoft.VisualBasic.PowerPacks.BackStyle.Opaque;
            this.shpPhase11.BorderColor = System.Drawing.Color.Black;
            this.shpPhase11.BorderWidth = 2;
            this.shpPhase11.Location = new System.Drawing.Point(59, 363);
            this.shpPhase11.Name = "shpPhase11";
            this.shpPhase11.Size = new System.Drawing.Size(22, 22);
            // 
            // shpPhase10
            // 
            this.shpPhase10.BackColor = System.Drawing.SystemColors.ControlDarkDark;
            this.shpPhase10.BackStyle = Microsoft.VisualBasic.PowerPacks.BackStyle.Opaque;
            this.shpPhase10.BorderColor = System.Drawing.Color.Black;
            this.shpPhase10.BorderWidth = 2;
            this.shpPhase10.Location = new System.Drawing.Point(59, 339);
            this.shpPhase10.Name = "shpPhase10";
            this.shpPhase10.Size = new System.Drawing.Size(22, 22);
            // 
            // shpPhase9
            // 
            this.shpPhase9.BackColor = System.Drawing.SystemColors.ControlDarkDark;
            this.shpPhase9.BackStyle = Microsoft.VisualBasic.PowerPacks.BackStyle.Opaque;
            this.shpPhase9.BorderColor = System.Drawing.Color.Black;
            this.shpPhase9.BorderWidth = 2;
            this.shpPhase9.Location = new System.Drawing.Point(59, 315);
            this.shpPhase9.Name = "shpPhase9";
            this.shpPhase9.Size = new System.Drawing.Size(22, 22);
            // 
            // shpPhase8
            // 
            this.shpPhase8.BackColor = System.Drawing.SystemColors.ControlDarkDark;
            this.shpPhase8.BackStyle = Microsoft.VisualBasic.PowerPacks.BackStyle.Opaque;
            this.shpPhase8.BorderColor = System.Drawing.Color.Black;
            this.shpPhase8.BorderWidth = 2;
            this.shpPhase8.Location = new System.Drawing.Point(59, 291);
            this.shpPhase8.Name = "shpPhase8";
            this.shpPhase8.Size = new System.Drawing.Size(22, 22);
            // 
            // shpPhase7
            // 
            this.shpPhase7.BackColor = System.Drawing.SystemColors.ControlDarkDark;
            this.shpPhase7.BackStyle = Microsoft.VisualBasic.PowerPacks.BackStyle.Opaque;
            this.shpPhase7.BorderColor = System.Drawing.Color.Black;
            this.shpPhase7.BorderWidth = 2;
            this.shpPhase7.Location = new System.Drawing.Point(59, 267);
            this.shpPhase7.Name = "shpPhase7";
            this.shpPhase7.Size = new System.Drawing.Size(22, 22);
            // 
            // shpPhase6
            // 
            this.shpPhase6.BackColor = System.Drawing.SystemColors.ControlDarkDark;
            this.shpPhase6.BackStyle = Microsoft.VisualBasic.PowerPacks.BackStyle.Opaque;
            this.shpPhase6.BorderColor = System.Drawing.Color.Black;
            this.shpPhase6.BorderWidth = 2;
            this.shpPhase6.Location = new System.Drawing.Point(59, 243);
            this.shpPhase6.Name = "shpPhase6";
            this.shpPhase6.Size = new System.Drawing.Size(22, 22);
            // 
            // shpPhase5
            // 
            this.shpPhase5.BackColor = System.Drawing.SystemColors.ControlDarkDark;
            this.shpPhase5.BackStyle = Microsoft.VisualBasic.PowerPacks.BackStyle.Opaque;
            this.shpPhase5.BorderColor = System.Drawing.Color.Black;
            this.shpPhase5.BorderWidth = 2;
            this.shpPhase5.Location = new System.Drawing.Point(59, 219);
            this.shpPhase5.Name = "shpPhase5";
            this.shpPhase5.Size = new System.Drawing.Size(22, 22);
            // 
            // shpPhase4
            // 
            this.shpPhase4.BackColor = System.Drawing.SystemColors.ControlDarkDark;
            this.shpPhase4.BackStyle = Microsoft.VisualBasic.PowerPacks.BackStyle.Opaque;
            this.shpPhase4.BorderColor = System.Drawing.Color.Black;
            this.shpPhase4.BorderWidth = 2;
            this.shpPhase4.Location = new System.Drawing.Point(59, 195);
            this.shpPhase4.Name = "shpPhase4";
            this.shpPhase4.Size = new System.Drawing.Size(22, 22);
            // 
            // shpPhase3
            // 
            this.shpPhase3.BackColor = System.Drawing.SystemColors.ControlDarkDark;
            this.shpPhase3.BackStyle = Microsoft.VisualBasic.PowerPacks.BackStyle.Opaque;
            this.shpPhase3.BorderColor = System.Drawing.Color.Black;
            this.shpPhase3.BorderWidth = 2;
            this.shpPhase3.Location = new System.Drawing.Point(59, 171);
            this.shpPhase3.Name = "shpPhase3";
            this.shpPhase3.Size = new System.Drawing.Size(22, 22);
            // 
            // shpPhase2
            // 
            this.shpPhase2.BackColor = System.Drawing.SystemColors.ControlDarkDark;
            this.shpPhase2.BackStyle = Microsoft.VisualBasic.PowerPacks.BackStyle.Opaque;
            this.shpPhase2.BorderColor = System.Drawing.Color.Black;
            this.shpPhase2.BorderWidth = 2;
            this.shpPhase2.Location = new System.Drawing.Point(59, 147);
            this.shpPhase2.Name = "shpPhase2";
            this.shpPhase2.Size = new System.Drawing.Size(22, 22);
            // 
            // shpPhase1
            // 
            this.shpPhase1.BackColor = System.Drawing.SystemColors.ControlDarkDark;
            this.shpPhase1.BackStyle = Microsoft.VisualBasic.PowerPacks.BackStyle.Opaque;
            this.shpPhase1.BorderColor = System.Drawing.Color.Black;
            this.shpPhase1.BorderWidth = 2;
            this.shpPhase1.Location = new System.Drawing.Point(58, 123);
            this.shpPhase1.Name = "shpPhase1";
            this.shpPhase1.Size = new System.Drawing.Size(22, 22);
            // 
            // txtVMaxTime7
            // 
            this.txtVMaxTime7.BackColor = System.Drawing.Color.Black;
            this.txtVMaxTime7.ForeColor = System.Drawing.Color.White;
            this.txtVMaxTime7.Location = new System.Drawing.Point(389, 290);
            this.txtVMaxTime7.Name = "txtVMaxTime7";
            this.txtVMaxTime7.Size = new System.Drawing.Size(60, 26);
            this.txtVMaxTime7.TabIndex = 47;
            // 
            // chkProgrammedFlash
            // 
            this.chkProgrammedFlash.AutoSize = true;
            this.chkProgrammedFlash.BackColor = System.Drawing.Color.LightGray;
            this.chkProgrammedFlash.Enabled = false;
            this.chkProgrammedFlash.Location = new System.Drawing.Point(748, 361);
            this.chkProgrammedFlash.Name = "chkProgrammedFlash";
            this.chkProgrammedFlash.Size = new System.Drawing.Size(178, 24);
            this.chkProgrammedFlash.TabIndex = 133;
            this.chkProgrammedFlash.Text = "Programmed Flash";
            this.chkProgrammedFlash.UseVisualStyleBackColor = false;
            // 
            // chkDiscontinuousFlag
            // 
            this.chkDiscontinuousFlag.AutoSize = true;
            this.chkDiscontinuousFlag.BackColor = System.Drawing.Color.LightGray;
            this.chkDiscontinuousFlag.Enabled = false;
            this.chkDiscontinuousFlag.ForeColor = System.Drawing.Color.Black;
            this.chkDiscontinuousFlag.Location = new System.Drawing.Point(748, 131);
            this.chkDiscontinuousFlag.Name = "chkDiscontinuousFlag";
            this.chkDiscontinuousFlag.Size = new System.Drawing.Size(177, 24);
            this.chkDiscontinuousFlag.TabIndex = 131;
            this.chkDiscontinuousFlag.Text = "DiscontinuousFlag";
            this.chkDiscontinuousFlag.UseVisualStyleBackColor = false;
            // 
            // chkCoordinationInTransition
            // 
            this.chkCoordinationInTransition.AutoSize = true;
            this.chkCoordinationInTransition.BackColor = System.Drawing.Color.LightGray;
            this.chkCoordinationInTransition.Enabled = false;
            this.chkCoordinationInTransition.Location = new System.Drawing.Point(748, 334);
            this.chkCoordinationInTransition.Name = "chkCoordinationInTransition";
            this.chkCoordinationInTransition.Size = new System.Drawing.Size(235, 24);
            this.chkCoordinationInTransition.TabIndex = 31;
            this.chkCoordinationInTransition.Text = "Coordination In Transition";
            this.chkCoordinationInTransition.UseVisualStyleBackColor = false;
            // 
            // chkCoordination
            // 
            this.chkCoordination.AutoSize = true;
            this.chkCoordination.BackColor = System.Drawing.Color.LightGray;
            this.chkCoordination.Enabled = false;
            this.chkCoordination.Location = new System.Drawing.Point(748, 305);
            this.chkCoordination.Name = "chkCoordination";
            this.chkCoordination.Size = new System.Drawing.Size(130, 24);
            this.chkCoordination.TabIndex = 30;
            this.chkCoordination.Text = "Coordination";
            this.chkCoordination.UseVisualStyleBackColor = false;
            // 
            // chkTSP
            // 
            this.chkTSP.AutoSize = true;
            this.chkTSP.BackColor = System.Drawing.Color.LightGray;
            this.chkTSP.Enabled = false;
            this.chkTSP.Location = new System.Drawing.Point(748, 276);
            this.chkTSP.Name = "chkTSP";
            this.chkTSP.Size = new System.Drawing.Size(61, 24);
            this.chkTSP.TabIndex = 29;
            this.chkTSP.Text = "TSP";
            this.chkTSP.UseVisualStyleBackColor = false;
            // 
            // chkPreempt
            // 
            this.chkPreempt.AutoSize = true;
            this.chkPreempt.BackColor = System.Drawing.Color.LightGray;
            this.chkPreempt.Enabled = false;
            this.chkPreempt.Location = new System.Drawing.Point(748, 247);
            this.chkPreempt.Name = "chkPreempt";
            this.chkPreempt.Size = new System.Drawing.Size(95, 24);
            this.chkPreempt.TabIndex = 28;
            this.chkPreempt.Text = "Preempt";
            this.chkPreempt.UseVisualStyleBackColor = false;
            // 
            // chkFaultFlash
            // 
            this.chkFaultFlash.AutoSize = true;
            this.chkFaultFlash.BackColor = System.Drawing.Color.LightGray;
            this.chkFaultFlash.Enabled = false;
            this.chkFaultFlash.Location = new System.Drawing.Point(748, 218);
            this.chkFaultFlash.Name = "chkFaultFlash";
            this.chkFaultFlash.Size = new System.Drawing.Size(118, 24);
            this.chkFaultFlash.TabIndex = 27;
            this.chkFaultFlash.Text = "Fault Flash";
            this.chkFaultFlash.UseVisualStyleBackColor = false;
            // 
            // chkStopTime
            // 
            this.chkStopTime.AutoSize = true;
            this.chkStopTime.BackColor = System.Drawing.Color.LightGray;
            this.chkStopTime.Enabled = false;
            this.chkStopTime.Location = new System.Drawing.Point(748, 189);
            this.chkStopTime.Name = "chkStopTime";
            this.chkStopTime.Size = new System.Drawing.Size(109, 24);
            this.chkStopTime.TabIndex = 26;
            this.chkStopTime.Text = "Stop Time";
            this.chkStopTime.UseVisualStyleBackColor = false;
            // 
            // chkManualControl
            // 
            this.chkManualControl.AutoSize = true;
            this.chkManualControl.BackColor = System.Drawing.Color.LightGray;
            this.chkManualControl.Enabled = false;
            this.chkManualControl.Location = new System.Drawing.Point(748, 160);
            this.chkManualControl.Name = "chkManualControl";
            this.chkManualControl.Size = new System.Drawing.Size(149, 24);
            this.chkManualControl.TabIndex = 25;
            this.chkManualControl.Text = "Manual Control";
            this.chkManualControl.UseVisualStyleBackColor = false;
            // 
            // lblControllerConnection
            // 
            this.lblControllerConnection.BackColor = System.Drawing.SystemColors.Control;
            this.lblControllerConnection.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblControllerConnection.Dock = System.Windows.Forms.DockStyle.Top;
            this.lblControllerConnection.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblControllerConnection.Location = new System.Drawing.Point(3, 3);
            this.lblControllerConnection.Name = "lblControllerConnection";
            this.lblControllerConnection.Size = new System.Drawing.Size(1003, 44);
            this.lblControllerConnection.TabIndex = 24;
            this.lblControllerConnection.Text = "label20";
            this.lblControllerConnection.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // tabpgActivityLog
            // 
            this.tabpgActivityLog.Controls.Add(this.splitContainer1);
            this.tabpgActivityLog.Location = new System.Drawing.Point(4, 32);
            this.tabpgActivityLog.Name = "tabpgActivityLog";
            this.tabpgActivityLog.Padding = new System.Windows.Forms.Padding(3);
            this.tabpgActivityLog.Size = new System.Drawing.Size(1009, 655);
            this.tabpgActivityLog.TabIndex = 1;
            this.tabpgActivityLog.Text = "SPAT Activity Logs";
            this.tabpgActivityLog.UseVisualStyleBackColor = true;
            // 
            // splitContainer1
            // 
            this.splitContainer1.BackColor = System.Drawing.Color.Transparent;
            this.splitContainer1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.splitContainer1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitContainer1.Location = new System.Drawing.Point(3, 3);
            this.splitContainer1.Name = "splitContainer1";
            this.splitContainer1.Orientation = System.Windows.Forms.Orientation.Horizontal;
            // 
            // splitContainer1.Panel1
            // 
            this.splitContainer1.Panel1.Controls.Add(this.splitContainer2);
            // 
            // splitContainer1.Panel2
            // 
            this.splitContainer1.Panel2.Controls.Add(this.splitContainer5);
            this.splitContainer1.Size = new System.Drawing.Size(1003, 649);
            this.splitContainer1.SplitterDistance = 416;
            this.splitContainer1.SplitterWidth = 12;
            this.splitContainer1.TabIndex = 3;
            // 
            // splitContainer2
            // 
            this.splitContainer2.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.splitContainer2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitContainer2.Location = new System.Drawing.Point(0, 0);
            this.splitContainer2.Name = "splitContainer2";
            this.splitContainer2.Orientation = System.Windows.Forms.Orientation.Horizontal;
            // 
            // splitContainer2.Panel1
            // 
            this.splitContainer2.Panel1.Controls.Add(this.splitContainer3);
            // 
            // splitContainer2.Panel2
            // 
            this.splitContainer2.Panel2.Controls.Add(this.splitContainer4);
            this.splitContainer2.Size = new System.Drawing.Size(1003, 416);
            this.splitContainer2.SplitterDistance = 195;
            this.splitContainer2.SplitterWidth = 10;
            this.splitContainer2.TabIndex = 2;
            // 
            // splitContainer3
            // 
            this.splitContainer3.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.splitContainer3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitContainer3.IsSplitterFixed = true;
            this.splitContainer3.Location = new System.Drawing.Point(0, 0);
            this.splitContainer3.Name = "splitContainer3";
            // 
            // splitContainer3.Panel1
            // 
            this.splitContainer3.Panel1.Controls.Add(this.label100);
            // 
            // splitContainer3.Panel2
            // 
            this.splitContainer3.Panel2.Controls.Add(this.lblBytesRead);
            this.splitContainer3.Panel2.Controls.Add(this.txtTSCLog);
            this.splitContainer3.Size = new System.Drawing.Size(1003, 195);
            this.splitContainer3.SplitterDistance = 74;
            this.splitContainer3.SplitterWidth = 10;
            this.splitContainer3.TabIndex = 3;
            // 
            // label100
            // 
            this.label100.BackColor = System.Drawing.Color.DarkGray;
            this.label100.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label100.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label100.Location = new System.Drawing.Point(0, 0);
            this.label100.Name = "label100";
            this.label100.Size = new System.Drawing.Size(70, 191);
            this.label100.TabIndex = 2;
            this.label100.Text = "TSC Data Log";
            this.label100.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblBytesRead
            // 
            this.lblBytesRead.BackColor = System.Drawing.Color.Yellow;
            this.lblBytesRead.Dock = System.Windows.Forms.DockStyle.Top;
            this.lblBytesRead.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblBytesRead.Location = new System.Drawing.Point(0, 0);
            this.lblBytesRead.Name = "lblBytesRead";
            this.lblBytesRead.Size = new System.Drawing.Size(915, 30);
            this.lblBytesRead.TabIndex = 2;
            this.lblBytesRead.Text = "TSC SPaT bytes read: ";
            this.lblBytesRead.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // txtTSCLog
            // 
            this.txtTSCLog.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(128)))));
            this.txtTSCLog.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.txtTSCLog.Location = new System.Drawing.Point(0, 13);
            this.txtTSCLog.Multiline = true;
            this.txtTSCLog.Name = "txtTSCLog";
            this.txtTSCLog.ScrollBars = System.Windows.Forms.ScrollBars.Both;
            this.txtTSCLog.Size = new System.Drawing.Size(915, 178);
            this.txtTSCLog.TabIndex = 1;
            // 
            // splitContainer4
            // 
            this.splitContainer4.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.splitContainer4.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitContainer4.IsSplitterFixed = true;
            this.splitContainer4.Location = new System.Drawing.Point(0, 0);
            this.splitContainer4.Name = "splitContainer4";
            // 
            // splitContainer4.Panel1
            // 
            this.splitContainer4.Panel1.Controls.Add(this.label18);
            // 
            // splitContainer4.Panel2
            // 
            this.splitContainer4.Panel2.Controls.Add(this.txtSPATMsgLog);
            this.splitContainer4.Size = new System.Drawing.Size(1003, 211);
            this.splitContainer4.SplitterDistance = 74;
            this.splitContainer4.SplitterWidth = 10;
            this.splitContainer4.TabIndex = 4;
            // 
            // label18
            // 
            this.label18.BackColor = System.Drawing.Color.DarkGray;
            this.label18.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label18.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label18.Location = new System.Drawing.Point(0, 0);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(70, 207);
            this.label18.TabIndex = 3;
            this.label18.Text = "SPAT Msg Log";
            this.label18.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // txtSPATMsgLog
            // 
            this.txtSPATMsgLog.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.txtSPATMsgLog.Dock = System.Windows.Forms.DockStyle.Fill;
            this.txtSPATMsgLog.Location = new System.Drawing.Point(0, 0);
            this.txtSPATMsgLog.Multiline = true;
            this.txtSPATMsgLog.Name = "txtSPATMsgLog";
            this.txtSPATMsgLog.ScrollBars = System.Windows.Forms.ScrollBars.Both;
            this.txtSPATMsgLog.Size = new System.Drawing.Size(915, 207);
            this.txtSPATMsgLog.TabIndex = 0;
            // 
            // splitContainer5
            // 
            this.splitContainer5.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.splitContainer5.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitContainer5.IsSplitterFixed = true;
            this.splitContainer5.Location = new System.Drawing.Point(0, 0);
            this.splitContainer5.Name = "splitContainer5";
            // 
            // splitContainer5.Panel1
            // 
            this.splitContainer5.Panel1.Controls.Add(this.label19);
            // 
            // splitContainer5.Panel2
            // 
            this.splitContainer5.Panel2.Controls.Add(this.txtActivityLog);
            this.splitContainer5.Size = new System.Drawing.Size(1003, 221);
            this.splitContainer5.SplitterDistance = 74;
            this.splitContainer5.SplitterWidth = 10;
            this.splitContainer5.TabIndex = 10;
            // 
            // label19
            // 
            this.label19.BackColor = System.Drawing.Color.DarkGray;
            this.label19.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label19.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label19.Location = new System.Drawing.Point(0, 0);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(70, 217);
            this.label19.TabIndex = 3;
            this.label19.Text = "SPAT System Activity Log";
            this.label19.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // txtActivityLog
            // 
            this.txtActivityLog.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.txtActivityLog.Dock = System.Windows.Forms.DockStyle.Fill;
            this.txtActivityLog.Location = new System.Drawing.Point(0, 0);
            this.txtActivityLog.Multiline = true;
            this.txtActivityLog.Name = "txtActivityLog";
            this.txtActivityLog.ScrollBars = System.Windows.Forms.ScrollBars.Both;
            this.txtActivityLog.Size = new System.Drawing.Size(915, 217);
            this.txtActivityLog.TabIndex = 2;
            // 
            // tabpgEnableSPATMsgPush
            // 
            this.tabpgEnableSPATMsgPush.Controls.Add(this.splitContainer7);
            this.tabpgEnableSPATMsgPush.Location = new System.Drawing.Point(4, 32);
            this.tabpgEnableSPATMsgPush.Name = "tabpgEnableSPATMsgPush";
            this.tabpgEnableSPATMsgPush.Size = new System.Drawing.Size(1009, 655);
            this.tabpgEnableSPATMsgPush.TabIndex = 5;
            this.tabpgEnableSPATMsgPush.Text = "Enable SPAT Msg Push";
            this.tabpgEnableSPATMsgPush.UseVisualStyleBackColor = true;
            // 
            // splitContainer7
            // 
            this.splitContainer7.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.splitContainer7.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitContainer7.Location = new System.Drawing.Point(0, 0);
            this.splitContainer7.Name = "splitContainer7";
            this.splitContainer7.Orientation = System.Windows.Forms.Orientation.Horizontal;
            // 
            // splitContainer7.Panel1
            // 
            this.splitContainer7.Panel1.Controls.Add(this.groupBox5);
            this.splitContainer7.Panel1.Controls.Add(this.groupBox8);
            // 
            // splitContainer7.Panel2
            // 
            this.splitContainer7.Panel2.Controls.Add(this.txtEnableSPATPush);
            this.splitContainer7.Size = new System.Drawing.Size(1009, 655);
            this.splitContainer7.SplitterDistance = 391;
            this.splitContainer7.SplitterWidth = 10;
            this.splitContainer7.TabIndex = 0;
            // 
            // groupBox5
            // 
            this.groupBox5.Controls.Add(this.chkPrmpt6);
            this.groupBox5.Controls.Add(this.chkPrmpt5);
            this.groupBox5.Controls.Add(this.chkPrmpt4);
            this.groupBox5.Controls.Add(this.chkPrmpt3);
            this.groupBox5.Controls.Add(this.chkPrmpt2);
            this.groupBox5.Controls.Add(this.chkPrmpt1);
            this.groupBox5.Controls.Add(this.btnDisablePreempt6);
            this.groupBox5.Controls.Add(this.btnDisablePreempt5);
            this.groupBox5.Controls.Add(this.btnDisablePreempt4);
            this.groupBox5.Controls.Add(this.btnEnablePreempt6);
            this.groupBox5.Controls.Add(this.btnEnablePreempt5);
            this.groupBox5.Controls.Add(this.btnEnablePreempt4);
            this.groupBox5.Controls.Add(this.btnDisablePreempt3);
            this.groupBox5.Controls.Add(this.btnEnablePreempt3);
            this.groupBox5.Controls.Add(this.btnDisablePreempt2);
            this.groupBox5.Controls.Add(this.btnEnablePreempt2);
            this.groupBox5.Controls.Add(this.btnDisablePreempt1);
            this.groupBox5.Controls.Add(this.btnEnablePreempt1);
            this.groupBox5.Location = new System.Drawing.Point(383, 12);
            this.groupBox5.Name = "groupBox5";
            this.groupBox5.Size = new System.Drawing.Size(350, 248);
            this.groupBox5.TabIndex = 48;
            this.groupBox5.TabStop = false;
            this.groupBox5.Text = "Preempts";
            // 
            // chkPrmpt6
            // 
            this.chkPrmpt6.AutoSize = true;
            this.chkPrmpt6.Location = new System.Drawing.Point(18, 211);
            this.chkPrmpt6.Name = "chkPrmpt6";
            this.chkPrmpt6.Size = new System.Drawing.Size(15, 14);
            this.chkPrmpt6.TabIndex = 60;
            this.chkPrmpt6.UseVisualStyleBackColor = true;
            // 
            // chkPrmpt5
            // 
            this.chkPrmpt5.AutoSize = true;
            this.chkPrmpt5.Location = new System.Drawing.Point(18, 175);
            this.chkPrmpt5.Name = "chkPrmpt5";
            this.chkPrmpt5.Size = new System.Drawing.Size(15, 14);
            this.chkPrmpt5.TabIndex = 59;
            this.chkPrmpt5.UseVisualStyleBackColor = true;
            // 
            // chkPrmpt4
            // 
            this.chkPrmpt4.AutoSize = true;
            this.chkPrmpt4.Location = new System.Drawing.Point(18, 140);
            this.chkPrmpt4.Name = "chkPrmpt4";
            this.chkPrmpt4.Size = new System.Drawing.Size(15, 14);
            this.chkPrmpt4.TabIndex = 58;
            this.chkPrmpt4.UseVisualStyleBackColor = true;
            // 
            // chkPrmpt3
            // 
            this.chkPrmpt3.AutoSize = true;
            this.chkPrmpt3.Location = new System.Drawing.Point(18, 104);
            this.chkPrmpt3.Name = "chkPrmpt3";
            this.chkPrmpt3.Size = new System.Drawing.Size(15, 14);
            this.chkPrmpt3.TabIndex = 57;
            this.chkPrmpt3.UseVisualStyleBackColor = true;
            // 
            // chkPrmpt2
            // 
            this.chkPrmpt2.AutoSize = true;
            this.chkPrmpt2.Location = new System.Drawing.Point(18, 68);
            this.chkPrmpt2.Name = "chkPrmpt2";
            this.chkPrmpt2.Size = new System.Drawing.Size(15, 14);
            this.chkPrmpt2.TabIndex = 56;
            this.chkPrmpt2.UseVisualStyleBackColor = true;
            // 
            // chkPrmpt1
            // 
            this.chkPrmpt1.AutoSize = true;
            this.chkPrmpt1.Location = new System.Drawing.Point(18, 32);
            this.chkPrmpt1.Name = "chkPrmpt1";
            this.chkPrmpt1.Size = new System.Drawing.Size(15, 14);
            this.chkPrmpt1.TabIndex = 55;
            this.chkPrmpt1.UseVisualStyleBackColor = true;
            // 
            // btnDisablePreempt6
            // 
            this.btnDisablePreempt6.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnDisablePreempt6.Location = new System.Drawing.Point(193, 205);
            this.btnDisablePreempt6.Name = "btnDisablePreempt6";
            this.btnDisablePreempt6.Size = new System.Drawing.Size(151, 30);
            this.btnDisablePreempt6.TabIndex = 54;
            this.btnDisablePreempt6.Text = "Disable Preempt 6";
            this.btnDisablePreempt6.UseVisualStyleBackColor = true;
            this.btnDisablePreempt6.Click += new System.EventHandler(this.btnDisablePreempt6_Click);
            // 
            // btnDisablePreempt5
            // 
            this.btnDisablePreempt5.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnDisablePreempt5.Location = new System.Drawing.Point(193, 169);
            this.btnDisablePreempt5.Name = "btnDisablePreempt5";
            this.btnDisablePreempt5.Size = new System.Drawing.Size(151, 30);
            this.btnDisablePreempt5.TabIndex = 53;
            this.btnDisablePreempt5.Text = "Disable Preempt 5";
            this.btnDisablePreempt5.UseVisualStyleBackColor = true;
            this.btnDisablePreempt5.Click += new System.EventHandler(this.btnDisablePreempt5_Click);
            // 
            // btnDisablePreempt4
            // 
            this.btnDisablePreempt4.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnDisablePreempt4.Location = new System.Drawing.Point(193, 133);
            this.btnDisablePreempt4.Name = "btnDisablePreempt4";
            this.btnDisablePreempt4.Size = new System.Drawing.Size(151, 30);
            this.btnDisablePreempt4.TabIndex = 52;
            this.btnDisablePreempt4.Text = "Disable Preempt 4";
            this.btnDisablePreempt4.UseVisualStyleBackColor = true;
            this.btnDisablePreempt4.Click += new System.EventHandler(this.btnDisablePreempt4_Click);
            // 
            // btnEnablePreempt6
            // 
            this.btnEnablePreempt6.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnEnablePreempt6.Location = new System.Drawing.Point(42, 203);
            this.btnEnablePreempt6.Name = "btnEnablePreempt6";
            this.btnEnablePreempt6.Size = new System.Drawing.Size(145, 30);
            this.btnEnablePreempt6.TabIndex = 51;
            this.btnEnablePreempt6.Text = "Enable Preempt 6";
            this.btnEnablePreempt6.UseVisualStyleBackColor = true;
            this.btnEnablePreempt6.Click += new System.EventHandler(this.btnEnablePreempt6_Click_1);
            // 
            // btnEnablePreempt5
            // 
            this.btnEnablePreempt5.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnEnablePreempt5.Location = new System.Drawing.Point(42, 167);
            this.btnEnablePreempt5.Name = "btnEnablePreempt5";
            this.btnEnablePreempt5.Size = new System.Drawing.Size(145, 30);
            this.btnEnablePreempt5.TabIndex = 50;
            this.btnEnablePreempt5.Text = "Enable Preempt 5";
            this.btnEnablePreempt5.UseVisualStyleBackColor = true;
            this.btnEnablePreempt5.Click += new System.EventHandler(this.btnEnablePreempt5_Click_1);
            // 
            // btnEnablePreempt4
            // 
            this.btnEnablePreempt4.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnEnablePreempt4.Location = new System.Drawing.Point(42, 132);
            this.btnEnablePreempt4.Name = "btnEnablePreempt4";
            this.btnEnablePreempt4.Size = new System.Drawing.Size(145, 30);
            this.btnEnablePreempt4.TabIndex = 49;
            this.btnEnablePreempt4.Text = "Enable Preempt 4";
            this.btnEnablePreempt4.UseVisualStyleBackColor = true;
            this.btnEnablePreempt4.Click += new System.EventHandler(this.btnEnablePreempt4_Click_1);
            // 
            // btnDisablePreempt3
            // 
            this.btnDisablePreempt3.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnDisablePreempt3.Location = new System.Drawing.Point(193, 97);
            this.btnDisablePreempt3.Name = "btnDisablePreempt3";
            this.btnDisablePreempt3.Size = new System.Drawing.Size(151, 30);
            this.btnDisablePreempt3.TabIndex = 48;
            this.btnDisablePreempt3.Text = "Disable Preempt 3";
            this.btnDisablePreempt3.UseVisualStyleBackColor = true;
            this.btnDisablePreempt3.Click += new System.EventHandler(this.btnDisablePreempt3_Click);
            // 
            // btnEnablePreempt3
            // 
            this.btnEnablePreempt3.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnEnablePreempt3.Location = new System.Drawing.Point(42, 96);
            this.btnEnablePreempt3.Name = "btnEnablePreempt3";
            this.btnEnablePreempt3.Size = new System.Drawing.Size(145, 30);
            this.btnEnablePreempt3.TabIndex = 47;
            this.btnEnablePreempt3.Text = "Enable Preempt 3";
            this.btnEnablePreempt3.UseVisualStyleBackColor = true;
            this.btnEnablePreempt3.Click += new System.EventHandler(this.btnEnablePreempt3_Click);
            // 
            // btnDisablePreempt2
            // 
            this.btnDisablePreempt2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnDisablePreempt2.Location = new System.Drawing.Point(193, 61);
            this.btnDisablePreempt2.Name = "btnDisablePreempt2";
            this.btnDisablePreempt2.Size = new System.Drawing.Size(151, 30);
            this.btnDisablePreempt2.TabIndex = 46;
            this.btnDisablePreempt2.Text = "Disable Preempt 2";
            this.btnDisablePreempt2.UseVisualStyleBackColor = true;
            this.btnDisablePreempt2.Click += new System.EventHandler(this.btnDisablePreempt2_Click);
            // 
            // btnEnablePreempt2
            // 
            this.btnEnablePreempt2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnEnablePreempt2.Location = new System.Drawing.Point(42, 60);
            this.btnEnablePreempt2.Name = "btnEnablePreempt2";
            this.btnEnablePreempt2.Size = new System.Drawing.Size(145, 30);
            this.btnEnablePreempt2.TabIndex = 45;
            this.btnEnablePreempt2.Text = "Enable Preempt 2";
            this.btnEnablePreempt2.UseVisualStyleBackColor = true;
            this.btnEnablePreempt2.Click += new System.EventHandler(this.btnEnablePreempt2_Click);
            // 
            // btnDisablePreempt1
            // 
            this.btnDisablePreempt1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnDisablePreempt1.Location = new System.Drawing.Point(193, 25);
            this.btnDisablePreempt1.Name = "btnDisablePreempt1";
            this.btnDisablePreempt1.Size = new System.Drawing.Size(151, 30);
            this.btnDisablePreempt1.TabIndex = 44;
            this.btnDisablePreempt1.Text = "Disable Preempt 1";
            this.btnDisablePreempt1.UseVisualStyleBackColor = true;
            this.btnDisablePreempt1.Click += new System.EventHandler(this.btnDisablePreempt1_Click);
            // 
            // btnEnablePreempt1
            // 
            this.btnEnablePreempt1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnEnablePreempt1.Location = new System.Drawing.Point(42, 24);
            this.btnEnablePreempt1.Name = "btnEnablePreempt1";
            this.btnEnablePreempt1.Size = new System.Drawing.Size(145, 30);
            this.btnEnablePreempt1.TabIndex = 43;
            this.btnEnablePreempt1.Text = "Enable Preempt 1";
            this.btnEnablePreempt1.UseVisualStyleBackColor = true;
            this.btnEnablePreempt1.Click += new System.EventHandler(this.btnEnablePreempt1_Click);
            // 
            // groupBox8
            // 
            this.groupBox8.Controls.Add(this.label55);
            this.groupBox8.Controls.Add(this.label45);
            this.groupBox8.Controls.Add(this.txtOIDValue);
            this.groupBox8.Controls.Add(this.btnSetOID);
            this.groupBox8.Controls.Add(this.txtOID);
            this.groupBox8.Controls.Add(this.label46);
            this.groupBox8.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox8.Location = new System.Drawing.Point(18, 12);
            this.groupBox8.Name = "groupBox8";
            this.groupBox8.Size = new System.Drawing.Size(351, 248);
            this.groupBox8.TabIndex = 38;
            this.groupBox8.TabStop = false;
            this.groupBox8.Text = "asc3VIIMessageEnable";
            // 
            // label55
            // 
            this.label55.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.label55.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label55.ForeColor = System.Drawing.Color.Blue;
            this.label55.Location = new System.Drawing.Point(84, 106);
            this.label55.Name = "label55";
            this.label55.Size = new System.Drawing.Size(255, 21);
            this.label55.TabIndex = 39;
            this.label55.Text = " 0 = Disable, 2= SPaT, 6 = SPaT +  Ped Info";
            this.label55.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label45
            // 
            this.label45.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label45.Location = new System.Drawing.Point(45, 33);
            this.label45.Name = "label45";
            this.label45.Size = new System.Drawing.Size(38, 21);
            this.label45.TabIndex = 37;
            this.label45.Text = "OID";
            this.label45.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // txtOIDValue
            // 
            this.txtOIDValue.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtOIDValue.Location = new System.Drawing.Point(87, 77);
            this.txtOIDValue.Name = "txtOIDValue";
            this.txtOIDValue.Size = new System.Drawing.Size(252, 26);
            this.txtOIDValue.TabIndex = 35;
            // 
            // btnSetOID
            // 
            this.btnSetOID.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.btnSetOID.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSetOID.Location = new System.Drawing.Point(6, 145);
            this.btnSetOID.Name = "btnSetOID";
            this.btnSetOID.Size = new System.Drawing.Size(333, 34);
            this.btnSetOID.TabIndex = 33;
            this.btnSetOID.Text = "Enable/Disable 100ms TSC SPAT Broadcast";
            this.btnSetOID.UseVisualStyleBackColor = false;
            this.btnSetOID.Click += new System.EventHandler(this.btnSetOID_Click);
            // 
            // txtOID
            // 
            this.txtOID.Enabled = false;
            this.txtOID.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtOID.Location = new System.Drawing.Point(87, 28);
            this.txtOID.Multiline = true;
            this.txtOID.Name = "txtOID";
            this.txtOID.Size = new System.Drawing.Size(252, 28);
            this.txtOID.TabIndex = 34;
            this.txtOID.Text = "1.3.6.1.4.1.1206.3.5.2.9.44.1.0";
            // 
            // label46
            // 
            this.label46.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label46.Location = new System.Drawing.Point(9, 78);
            this.label46.Name = "label46";
            this.label46.Size = new System.Drawing.Size(75, 21);
            this.label46.TabIndex = 36;
            this.label46.Text = "OID Value";
            this.label46.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // txtEnableSPATPush
            // 
            this.txtEnableSPATPush.Dock = System.Windows.Forms.DockStyle.Fill;
            this.txtEnableSPATPush.Location = new System.Drawing.Point(0, 0);
            this.txtEnableSPATPush.Multiline = true;
            this.txtEnableSPATPush.Name = "txtEnableSPATPush";
            this.txtEnableSPATPush.ScrollBars = System.Windows.Forms.ScrollBars.Both;
            this.txtEnableSPATPush.Size = new System.Drawing.Size(1005, 250);
            this.txtEnableSPATPush.TabIndex = 0;
            // 
            // tabpgGPS
            // 
            this.tabpgGPS.Controls.Add(this.splitContainer6);
            this.tabpgGPS.Controls.Add(this.txtGPSFix);
            this.tabpgGPS.Location = new System.Drawing.Point(4, 32);
            this.tabpgGPS.Name = "tabpgGPS";
            this.tabpgGPS.Size = new System.Drawing.Size(1009, 655);
            this.tabpgGPS.TabIndex = 6;
            this.tabpgGPS.Text = "GPS";
            this.tabpgGPS.UseVisualStyleBackColor = true;
            // 
            // splitContainer6
            // 
            this.splitContainer6.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.splitContainer6.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitContainer6.Location = new System.Drawing.Point(0, 26);
            this.splitContainer6.Name = "splitContainer6";
            this.splitContainer6.Orientation = System.Windows.Forms.Orientation.Horizontal;
            // 
            // splitContainer6.Panel1
            // 
            this.splitContainer6.Panel1.Controls.Add(this.txtGPSRawTime);
            this.splitContainer6.Panel1.Controls.Add(this.label68);
            this.splitContainer6.Panel1.Controls.Add(this.txtGPSLocalTime);
            this.splitContainer6.Panel1.Controls.Add(this.btnGPSUpdateFrequency);
            this.splitContainer6.Panel1.Controls.Add(this.txtSysBeforeTime);
            this.splitContainer6.Panel1.Controls.Add(this.label67);
            this.splitContainer6.Panel1.Controls.Add(this.txtSysAfterTime);
            this.splitContainer6.Panel1.Controls.Add(this.txtGPSUpdateFrequency);
            this.splitContainer6.Panel1.Controls.Add(this.label52);
            this.splitContainer6.Panel1.Controls.Add(this.label66);
            this.splitContainer6.Panel1.Controls.Add(this.label56);
            this.splitContainer6.Panel1.Controls.Add(this.txtNewTime);
            this.splitContainer6.Panel1.Controls.Add(this.label57);
            this.splitContainer6.Panel1.Controls.Add(this.label65);
            this.splitContainer6.Panel1.Controls.Add(this.txtLat);
            this.splitContainer6.Panel1.Controls.Add(this.txtSatelliteTime);
            this.splitContainer6.Panel1.Controls.Add(this.txtLon);
            this.splitContainer6.Panel1.Controls.Add(this.label64);
            this.splitContainer6.Panel1.Controls.Add(this.txtGPSDate);
            this.splitContainer6.Panel1.Controls.Add(this.label63);
            this.splitContainer6.Panel1.Controls.Add(this.label61);
            this.splitContainer6.Panel1.Controls.Add(this.label60);
            this.splitContainer6.Panel1.Controls.Add(this.txtGPSUTCTime);
            this.splitContainer6.Panel1.Controls.Add(this.label62);
            // 
            // splitContainer6.Panel2
            // 
            this.splitContainer6.Panel2.Controls.Add(this.txtGPSActivity);
            this.splitContainer6.Size = new System.Drawing.Size(1009, 629);
            this.splitContainer6.SplitterDistance = 283;
            this.splitContainer6.SplitterWidth = 10;
            this.splitContainer6.TabIndex = 181;
            // 
            // txtGPSRawTime
            // 
            this.txtGPSRawTime.Location = new System.Drawing.Point(225, 47);
            this.txtGPSRawTime.Name = "txtGPSRawTime";
            this.txtGPSRawTime.Size = new System.Drawing.Size(295, 26);
            this.txtGPSRawTime.TabIndex = 50;
            // 
            // label68
            // 
            this.label68.AutoSize = true;
            this.label68.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.label68.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label68.ForeColor = System.Drawing.Color.Red;
            this.label68.Location = new System.Drawing.Point(934, 22);
            this.label68.Name = "label68";
            this.label68.Size = new System.Drawing.Size(54, 16);
            this.label68.TabIndex = 180;
            this.label68.Text = "minutes";
            this.label68.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // txtGPSLocalTime
            // 
            this.txtGPSLocalTime.Location = new System.Drawing.Point(225, 144);
            this.txtGPSLocalTime.Name = "txtGPSLocalTime";
            this.txtGPSLocalTime.Size = new System.Drawing.Size(295, 26);
            this.txtGPSLocalTime.TabIndex = 31;
            // 
            // btnGPSUpdateFrequency
            // 
            this.btnGPSUpdateFrequency.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.btnGPSUpdateFrequency.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnGPSUpdateFrequency.ForeColor = System.Drawing.Color.Black;
            this.btnGPSUpdateFrequency.Location = new System.Drawing.Point(769, 47);
            this.btnGPSUpdateFrequency.Name = "btnGPSUpdateFrequency";
            this.btnGPSUpdateFrequency.Size = new System.Drawing.Size(229, 30);
            this.btnGPSUpdateFrequency.TabIndex = 179;
            this.btnGPSUpdateFrequency.Text = "Save GPS Update Frequency";
            this.btnGPSUpdateFrequency.UseVisualStyleBackColor = false;
            this.btnGPSUpdateFrequency.Click += new System.EventHandler(this.btnGPSUpdateFrequency_Click);
            // 
            // txtSysBeforeTime
            // 
            this.txtSysBeforeTime.Location = new System.Drawing.Point(225, 176);
            this.txtSysBeforeTime.Name = "txtSysBeforeTime";
            this.txtSysBeforeTime.Size = new System.Drawing.Size(295, 26);
            this.txtSysBeforeTime.TabIndex = 32;
            // 
            // label67
            // 
            this.label67.AutoSize = true;
            this.label67.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label67.Location = new System.Drawing.Point(541, 22);
            this.label67.Name = "label67";
            this.label67.Size = new System.Drawing.Size(222, 16);
            this.label67.TabIndex = 58;
            this.label67.Text = "Local-Time GPS Update Frequency";
            this.label67.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // txtSysAfterTime
            // 
            this.txtSysAfterTime.Location = new System.Drawing.Point(225, 240);
            this.txtSysAfterTime.Name = "txtSysAfterTime";
            this.txtSysAfterTime.Size = new System.Drawing.Size(295, 26);
            this.txtSysAfterTime.TabIndex = 33;
            // 
            // txtGPSUpdateFrequency
            // 
            this.txtGPSUpdateFrequency.Location = new System.Drawing.Point(769, 16);
            this.txtGPSUpdateFrequency.Name = "txtGPSUpdateFrequency";
            this.txtGPSUpdateFrequency.Size = new System.Drawing.Size(159, 26);
            this.txtGPSUpdateFrequency.TabIndex = 57;
            // 
            // label52
            // 
            this.label52.AutoSize = true;
            this.label52.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label52.Location = new System.Drawing.Point(20, 182);
            this.label52.Name = "label52";
            this.label52.Size = new System.Drawing.Size(199, 16);
            this.label52.TabIndex = 37;
            this.label52.Text = "System Local Time - Before Adj.";
            this.label52.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label66
            // 
            this.label66.AutoSize = true;
            this.label66.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label66.Location = new System.Drawing.Point(150, 214);
            this.label66.Name = "label66";
            this.label66.Size = new System.Drawing.Size(69, 16);
            this.label66.TabIndex = 56;
            this.label66.Text = "New Time";
            this.label66.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label56
            // 
            this.label56.AutoSize = true;
            this.label56.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label56.Location = new System.Drawing.Point(114, 150);
            this.label56.Name = "label56";
            this.label56.Size = new System.Drawing.Size(106, 16);
            this.label56.TabIndex = 38;
            this.label56.Text = "GPS Local Time";
            this.label56.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // txtNewTime
            // 
            this.txtNewTime.Location = new System.Drawing.Point(225, 208);
            this.txtNewTime.Name = "txtNewTime";
            this.txtNewTime.Size = new System.Drawing.Size(295, 26);
            this.txtNewTime.TabIndex = 55;
            // 
            // label57
            // 
            this.label57.AutoSize = true;
            this.label57.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label57.Location = new System.Drawing.Point(33, 246);
            this.label57.Name = "label57";
            this.label57.Size = new System.Drawing.Size(186, 16);
            this.label57.TabIndex = 39;
            this.label57.Text = "System Local Time - After Adj.";
            this.label57.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label65
            // 
            this.label65.AutoSize = true;
            this.label65.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label65.Location = new System.Drawing.Point(131, 118);
            this.label65.Name = "label65";
            this.label65.Size = new System.Drawing.Size(90, 16);
            this.label65.TabIndex = 54;
            this.label65.Text = "Satellite Time";
            this.label65.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // txtLat
            // 
            this.txtLat.Location = new System.Drawing.Point(619, 208);
            this.txtLat.Name = "txtLat";
            this.txtLat.Size = new System.Drawing.Size(207, 26);
            this.txtLat.TabIndex = 42;
            // 
            // txtSatelliteTime
            // 
            this.txtSatelliteTime.Location = new System.Drawing.Point(225, 112);
            this.txtSatelliteTime.Name = "txtSatelliteTime";
            this.txtSatelliteTime.Size = new System.Drawing.Size(295, 26);
            this.txtSatelliteTime.TabIndex = 53;
            // 
            // txtLon
            // 
            this.txtLon.Location = new System.Drawing.Point(619, 240);
            this.txtLon.Name = "txtLon";
            this.txtLon.Size = new System.Drawing.Size(207, 26);
            this.txtLon.TabIndex = 43;
            // 
            // label64
            // 
            this.label64.AutoSize = true;
            this.label64.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label64.Location = new System.Drawing.Point(120, 85);
            this.label64.Name = "label64";
            this.label64.Size = new System.Drawing.Size(101, 16);
            this.label64.TabIndex = 52;
            this.label64.Text = "GPS UTC Time";
            this.label64.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // txtGPSDate
            // 
            this.txtGPSDate.Location = new System.Drawing.Point(225, 16);
            this.txtGPSDate.Name = "txtGPSDate";
            this.txtGPSDate.Size = new System.Drawing.Size(295, 26);
            this.txtGPSDate.TabIndex = 44;
            // 
            // label63
            // 
            this.label63.AutoSize = true;
            this.label63.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label63.Location = new System.Drawing.Point(120, 54);
            this.label63.Name = "label63";
            this.label63.Size = new System.Drawing.Size(100, 16);
            this.label63.TabIndex = 51;
            this.label63.Text = "GPS Raw Time";
            this.label63.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label61
            // 
            this.label61.AutoSize = true;
            this.label61.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label61.Location = new System.Drawing.Point(151, 22);
            this.label61.Name = "label61";
            this.label61.Size = new System.Drawing.Size(68, 16);
            this.label61.TabIndex = 45;
            this.label61.Text = "GPS Date";
            this.label61.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label60
            // 
            this.label60.AutoSize = true;
            this.label60.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label60.Location = new System.Drawing.Point(558, 213);
            this.label60.Name = "label60";
            this.label60.Size = new System.Drawing.Size(55, 16);
            this.label60.TabIndex = 46;
            this.label60.Text = "Latitude";
            this.label60.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // txtGPSUTCTime
            // 
            this.txtGPSUTCTime.Location = new System.Drawing.Point(226, 80);
            this.txtGPSUTCTime.Name = "txtGPSUTCTime";
            this.txtGPSUTCTime.Size = new System.Drawing.Size(295, 26);
            this.txtGPSUTCTime.TabIndex = 49;
            // 
            // label62
            // 
            this.label62.AutoSize = true;
            this.label62.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label62.Location = new System.Drawing.Point(546, 245);
            this.label62.Name = "label62";
            this.label62.Size = new System.Drawing.Size(67, 16);
            this.label62.TabIndex = 47;
            this.label62.Text = "Longitude";
            this.label62.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // txtGPSActivity
            // 
            this.txtGPSActivity.Dock = System.Windows.Forms.DockStyle.Fill;
            this.txtGPSActivity.Location = new System.Drawing.Point(0, 0);
            this.txtGPSActivity.Multiline = true;
            this.txtGPSActivity.Name = "txtGPSActivity";
            this.txtGPSActivity.ScrollBars = System.Windows.Forms.ScrollBars.Both;
            this.txtGPSActivity.Size = new System.Drawing.Size(1005, 332);
            this.txtGPSActivity.TabIndex = 0;
            // 
            // txtGPSFix
            // 
            this.txtGPSFix.BackColor = System.Drawing.Color.Red;
            this.txtGPSFix.Dock = System.Windows.Forms.DockStyle.Top;
            this.txtGPSFix.Location = new System.Drawing.Point(0, 0);
            this.txtGPSFix.Name = "txtGPSFix";
            this.txtGPSFix.Size = new System.Drawing.Size(1009, 26);
            this.txtGPSFix.TabIndex = 40;
            this.txtGPSFix.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // tabpgSPATConfiguration
            // 
            this.tabpgSPATConfiguration.Controls.Add(this.pnlSPATConfiguration);
            this.tabpgSPATConfiguration.Location = new System.Drawing.Point(4, 32);
            this.tabpgSPATConfiguration.Name = "tabpgSPATConfiguration";
            this.tabpgSPATConfiguration.Size = new System.Drawing.Size(1009, 655);
            this.tabpgSPATConfiguration.TabIndex = 2;
            this.tabpgSPATConfiguration.Text = "SPAT Configuration";
            this.tabpgSPATConfiguration.UseVisualStyleBackColor = true;
            // 
            // pnlSPATConfiguration
            // 
            this.pnlSPATConfiguration.Controls.Add(this.button1);
            this.pnlSPATConfiguration.Controls.Add(this.label112);
            this.pnlSPATConfiguration.Controls.Add(this.label111);
            this.pnlSPATConfiguration.Controls.Add(this.txtDiskSpace);
            this.pnlSPATConfiguration.Controls.Add(this.btnQuitSPaTSystem);
            this.pnlSPATConfiguration.Controls.Add(this.groupBox6);
            this.pnlSPATConfiguration.Controls.Add(this.label93);
            this.pnlSPATConfiguration.Controls.Add(this.label92);
            this.pnlSPATConfiguration.Controls.Add(this.txtSPaTPushCode);
            this.pnlSPATConfiguration.Controls.Add(this.gbPortSettings);
            this.pnlSPATConfiguration.Controls.Add(this.groupBox1);
            this.pnlSPATConfiguration.Controls.Add(this.groupBox3);
            this.pnlSPATConfiguration.Controls.Add(this.groupBox9);
            this.pnlSPATConfiguration.Controls.Add(this.groupBox2);
            this.pnlSPATConfiguration.Controls.Add(this.groupBox4);
            this.pnlSPATConfiguration.Controls.Add(this.btnSaveSPATConfiguration);
            this.pnlSPATConfiguration.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pnlSPATConfiguration.Location = new System.Drawing.Point(0, 0);
            this.pnlSPATConfiguration.Name = "pnlSPATConfiguration";
            this.pnlSPATConfiguration.Size = new System.Drawing.Size(1009, 655);
            this.pnlSPATConfiguration.TabIndex = 0;
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.button1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.ForeColor = System.Drawing.Color.Black;
            this.button1.Location = new System.Drawing.Point(203, 614);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(193, 26);
            this.button1.TabIndex = 140;
            this.button1.Text = "Set Disk Space Limit";
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // label112
            // 
            this.label112.AutoSize = true;
            this.label112.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.label112.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label112.ForeColor = System.Drawing.Color.Blue;
            this.label112.Location = new System.Drawing.Point(117, 619);
            this.label112.Name = "label112";
            this.label112.Size = new System.Drawing.Size(29, 16);
            this.label112.TabIndex = 139;
            this.label112.Text = "GB";
            // 
            // label111
            // 
            this.label111.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.label111.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label111.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.label111.Location = new System.Drawing.Point(31, 589);
            this.label111.Name = "label111";
            this.label111.Size = new System.Drawing.Size(380, 20);
            this.label111.TabIndex = 138;
            this.label111.Text = "Minimum Disk Space for Allowing Data Logging";
            this.label111.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // txtDiskSpace
            // 
            this.txtDiskSpace.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtDiskSpace.Location = new System.Drawing.Point(34, 613);
            this.txtDiskSpace.Name = "txtDiskSpace";
            this.txtDiskSpace.Size = new System.Drawing.Size(76, 26);
            this.txtDiskSpace.TabIndex = 137;
            this.txtDiskSpace.Text = "5";
            // 
            // btnQuitSPaTSystem
            // 
            this.btnQuitSPaTSystem.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.btnQuitSPaTSystem.Location = new System.Drawing.Point(687, 594);
            this.btnQuitSPaTSystem.Name = "btnQuitSPaTSystem";
            this.btnQuitSPaTSystem.Size = new System.Drawing.Size(259, 45);
            this.btnQuitSPaTSystem.TabIndex = 136;
            this.btnQuitSPaTSystem.Text = "Exit SPAT System";
            this.btnQuitSPaTSystem.UseVisualStyleBackColor = false;
            this.btnQuitSPaTSystem.Click += new System.EventHandler(this.btnQuitSPaTSystem_Click);
            // 
            // groupBox6
            // 
            this.groupBox6.Controls.Add(this.label94);
            this.groupBox6.Controls.Add(this.label101);
            this.groupBox6.Controls.Add(this.label95);
            this.groupBox6.Controls.Add(this.chkPedDetectPhase1);
            this.groupBox6.Controls.Add(this.label96);
            this.groupBox6.Controls.Add(this.chkPedDetectPhase2);
            this.groupBox6.Controls.Add(this.label97);
            this.groupBox6.Controls.Add(this.chkPedDetectPhase3);
            this.groupBox6.Controls.Add(this.label98);
            this.groupBox6.Controls.Add(this.chkPedDetectPhase4);
            this.groupBox6.Controls.Add(this.label99);
            this.groupBox6.Controls.Add(this.chkPedDetectPhase5);
            this.groupBox6.Controls.Add(this.chkPedDetectPhase6);
            this.groupBox6.Controls.Add(this.label102);
            this.groupBox6.Controls.Add(this.chkPedDetectPhase7);
            this.groupBox6.Controls.Add(this.label103);
            this.groupBox6.Controls.Add(this.chkPedDetectPhase8);
            this.groupBox6.Controls.Add(this.label104);
            this.groupBox6.Controls.Add(this.chkPedDetectPhase9);
            this.groupBox6.Controls.Add(this.label105);
            this.groupBox6.Controls.Add(this.chkPedDetectPhase10);
            this.groupBox6.Controls.Add(this.label106);
            this.groupBox6.Controls.Add(this.chkPedDetectPhase11);
            this.groupBox6.Controls.Add(this.label107);
            this.groupBox6.Controls.Add(this.chkPedDetectPhase12);
            this.groupBox6.Controls.Add(this.label108);
            this.groupBox6.Controls.Add(this.chkPedDetectPhase13);
            this.groupBox6.Controls.Add(this.label109);
            this.groupBox6.Controls.Add(this.chkPedDetectPhase14);
            this.groupBox6.Controls.Add(this.label110);
            this.groupBox6.Controls.Add(this.chkPedDetectPhase15);
            this.groupBox6.Controls.Add(this.chkPedDetectPhase16);
            this.groupBox6.Location = new System.Drawing.Point(426, 465);
            this.groupBox6.Name = "groupBox6";
            this.groupBox6.Size = new System.Drawing.Size(520, 91);
            this.groupBox6.TabIndex = 78;
            this.groupBox6.TabStop = false;
            this.groupBox6.Text = "Select Ped Phases with Ped Detection";
            // 
            // label94
            // 
            this.label94.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label94.Location = new System.Drawing.Point(479, 27);
            this.label94.Name = "label94";
            this.label94.Size = new System.Drawing.Size(30, 20);
            this.label94.TabIndex = 111;
            this.label94.Text = "16";
            this.label94.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label101
            // 
            this.label101.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label101.Location = new System.Drawing.Point(273, 27);
            this.label101.Name = "label101";
            this.label101.Size = new System.Drawing.Size(30, 20);
            this.label101.TabIndex = 105;
            this.label101.Text = "10";
            this.label101.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label95
            // 
            this.label95.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label95.Location = new System.Drawing.Point(443, 27);
            this.label95.Name = "label95";
            this.label95.Size = new System.Drawing.Size(30, 20);
            this.label95.TabIndex = 110;
            this.label95.Text = "15";
            this.label95.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // chkPedDetectPhase1
            // 
            this.chkPedDetectPhase1.AutoSize = true;
            this.chkPedDetectPhase1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chkPedDetectPhase1.Location = new System.Drawing.Point(9, 62);
            this.chkPedDetectPhase1.Name = "chkPedDetectPhase1";
            this.chkPedDetectPhase1.Size = new System.Drawing.Size(15, 14);
            this.chkPedDetectPhase1.TabIndex = 79;
            this.chkPedDetectPhase1.UseVisualStyleBackColor = true;
            this.chkPedDetectPhase1.CheckedChanged += new System.EventHandler(this.chkPedDetectPhase1_CheckedChanged);
            // 
            // label96
            // 
            this.label96.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label96.Location = new System.Drawing.Point(409, 27);
            this.label96.Name = "label96";
            this.label96.Size = new System.Drawing.Size(30, 20);
            this.label96.TabIndex = 109;
            this.label96.Text = "14";
            this.label96.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // chkPedDetectPhase2
            // 
            this.chkPedDetectPhase2.AutoSize = true;
            this.chkPedDetectPhase2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chkPedDetectPhase2.Location = new System.Drawing.Point(39, 62);
            this.chkPedDetectPhase2.Name = "chkPedDetectPhase2";
            this.chkPedDetectPhase2.Size = new System.Drawing.Size(15, 14);
            this.chkPedDetectPhase2.TabIndex = 80;
            this.chkPedDetectPhase2.UseVisualStyleBackColor = true;
            this.chkPedDetectPhase2.CheckedChanged += new System.EventHandler(this.chkPedDetectPhase2_CheckedChanged);
            // 
            // label97
            // 
            this.label97.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label97.Location = new System.Drawing.Point(375, 27);
            this.label97.Name = "label97";
            this.label97.Size = new System.Drawing.Size(30, 20);
            this.label97.TabIndex = 108;
            this.label97.Text = "13";
            this.label97.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // chkPedDetectPhase3
            // 
            this.chkPedDetectPhase3.AutoSize = true;
            this.chkPedDetectPhase3.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chkPedDetectPhase3.Location = new System.Drawing.Point(69, 62);
            this.chkPedDetectPhase3.Name = "chkPedDetectPhase3";
            this.chkPedDetectPhase3.Size = new System.Drawing.Size(15, 14);
            this.chkPedDetectPhase3.TabIndex = 81;
            this.chkPedDetectPhase3.UseVisualStyleBackColor = true;
            this.chkPedDetectPhase3.CheckedChanged += new System.EventHandler(this.chkPedDetectPhase3_CheckedChanged);
            // 
            // label98
            // 
            this.label98.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label98.Location = new System.Drawing.Point(341, 27);
            this.label98.Name = "label98";
            this.label98.Size = new System.Drawing.Size(30, 20);
            this.label98.TabIndex = 107;
            this.label98.Text = "12";
            this.label98.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // chkPedDetectPhase4
            // 
            this.chkPedDetectPhase4.AutoSize = true;
            this.chkPedDetectPhase4.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chkPedDetectPhase4.Location = new System.Drawing.Point(99, 62);
            this.chkPedDetectPhase4.Name = "chkPedDetectPhase4";
            this.chkPedDetectPhase4.Size = new System.Drawing.Size(15, 14);
            this.chkPedDetectPhase4.TabIndex = 82;
            this.chkPedDetectPhase4.UseVisualStyleBackColor = true;
            this.chkPedDetectPhase4.CheckedChanged += new System.EventHandler(this.chkPedDetectPhase4_CheckedChanged);
            // 
            // label99
            // 
            this.label99.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label99.Location = new System.Drawing.Point(307, 27);
            this.label99.Name = "label99";
            this.label99.Size = new System.Drawing.Size(30, 20);
            this.label99.TabIndex = 106;
            this.label99.Text = "11";
            this.label99.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // chkPedDetectPhase5
            // 
            this.chkPedDetectPhase5.AutoSize = true;
            this.chkPedDetectPhase5.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chkPedDetectPhase5.Location = new System.Drawing.Point(129, 62);
            this.chkPedDetectPhase5.Name = "chkPedDetectPhase5";
            this.chkPedDetectPhase5.Size = new System.Drawing.Size(15, 14);
            this.chkPedDetectPhase5.TabIndex = 83;
            this.chkPedDetectPhase5.UseVisualStyleBackColor = true;
            this.chkPedDetectPhase5.CheckedChanged += new System.EventHandler(this.chkPedDetectPhase5_CheckedChanged);
            // 
            // chkPedDetectPhase6
            // 
            this.chkPedDetectPhase6.AutoSize = true;
            this.chkPedDetectPhase6.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chkPedDetectPhase6.Location = new System.Drawing.Point(159, 62);
            this.chkPedDetectPhase6.Name = "chkPedDetectPhase6";
            this.chkPedDetectPhase6.Size = new System.Drawing.Size(15, 14);
            this.chkPedDetectPhase6.TabIndex = 84;
            this.chkPedDetectPhase6.UseVisualStyleBackColor = true;
            this.chkPedDetectPhase6.CheckedChanged += new System.EventHandler(this.chkPedDetectPhase6_CheckedChanged);
            // 
            // label102
            // 
            this.label102.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label102.Location = new System.Drawing.Point(241, 27);
            this.label102.Name = "label102";
            this.label102.Size = new System.Drawing.Size(30, 20);
            this.label102.TabIndex = 104;
            this.label102.Text = "9";
            this.label102.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // chkPedDetectPhase7
            // 
            this.chkPedDetectPhase7.AutoSize = true;
            this.chkPedDetectPhase7.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chkPedDetectPhase7.Location = new System.Drawing.Point(189, 62);
            this.chkPedDetectPhase7.Name = "chkPedDetectPhase7";
            this.chkPedDetectPhase7.Size = new System.Drawing.Size(15, 14);
            this.chkPedDetectPhase7.TabIndex = 85;
            this.chkPedDetectPhase7.UseVisualStyleBackColor = true;
            this.chkPedDetectPhase7.CheckedChanged += new System.EventHandler(this.chkPedDetectPhase7_CheckedChanged);
            // 
            // label103
            // 
            this.label103.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label103.Location = new System.Drawing.Point(211, 27);
            this.label103.Name = "label103";
            this.label103.Size = new System.Drawing.Size(30, 20);
            this.label103.TabIndex = 103;
            this.label103.Text = "8";
            this.label103.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // chkPedDetectPhase8
            // 
            this.chkPedDetectPhase8.AutoSize = true;
            this.chkPedDetectPhase8.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chkPedDetectPhase8.Location = new System.Drawing.Point(219, 62);
            this.chkPedDetectPhase8.Name = "chkPedDetectPhase8";
            this.chkPedDetectPhase8.Size = new System.Drawing.Size(15, 14);
            this.chkPedDetectPhase8.TabIndex = 86;
            this.chkPedDetectPhase8.UseVisualStyleBackColor = true;
            this.chkPedDetectPhase8.CheckedChanged += new System.EventHandler(this.chkPedDetectPhase8_CheckedChanged);
            // 
            // label104
            // 
            this.label104.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label104.Location = new System.Drawing.Point(181, 27);
            this.label104.Name = "label104";
            this.label104.Size = new System.Drawing.Size(30, 20);
            this.label104.TabIndex = 102;
            this.label104.Text = "7";
            this.label104.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // chkPedDetectPhase9
            // 
            this.chkPedDetectPhase9.AutoSize = true;
            this.chkPedDetectPhase9.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chkPedDetectPhase9.Location = new System.Drawing.Point(249, 62);
            this.chkPedDetectPhase9.Name = "chkPedDetectPhase9";
            this.chkPedDetectPhase9.Size = new System.Drawing.Size(15, 14);
            this.chkPedDetectPhase9.TabIndex = 87;
            this.chkPedDetectPhase9.UseVisualStyleBackColor = true;
            this.chkPedDetectPhase9.CheckedChanged += new System.EventHandler(this.chkPedDetectPhase9_CheckedChanged);
            // 
            // label105
            // 
            this.label105.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label105.Location = new System.Drawing.Point(151, 27);
            this.label105.Name = "label105";
            this.label105.Size = new System.Drawing.Size(30, 20);
            this.label105.TabIndex = 101;
            this.label105.Text = "6";
            this.label105.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // chkPedDetectPhase10
            // 
            this.chkPedDetectPhase10.AutoSize = true;
            this.chkPedDetectPhase10.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chkPedDetectPhase10.Location = new System.Drawing.Point(281, 62);
            this.chkPedDetectPhase10.Name = "chkPedDetectPhase10";
            this.chkPedDetectPhase10.Size = new System.Drawing.Size(15, 14);
            this.chkPedDetectPhase10.TabIndex = 88;
            this.chkPedDetectPhase10.UseVisualStyleBackColor = true;
            this.chkPedDetectPhase10.CheckedChanged += new System.EventHandler(this.chkPedDetectPhase10_CheckedChanged);
            // 
            // label106
            // 
            this.label106.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label106.Location = new System.Drawing.Point(121, 27);
            this.label106.Name = "label106";
            this.label106.Size = new System.Drawing.Size(30, 20);
            this.label106.TabIndex = 100;
            this.label106.Text = "5";
            this.label106.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // chkPedDetectPhase11
            // 
            this.chkPedDetectPhase11.AutoSize = true;
            this.chkPedDetectPhase11.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chkPedDetectPhase11.Location = new System.Drawing.Point(315, 62);
            this.chkPedDetectPhase11.Name = "chkPedDetectPhase11";
            this.chkPedDetectPhase11.Size = new System.Drawing.Size(15, 14);
            this.chkPedDetectPhase11.TabIndex = 89;
            this.chkPedDetectPhase11.UseVisualStyleBackColor = true;
            this.chkPedDetectPhase11.CheckedChanged += new System.EventHandler(this.chkPedDetectPhase11_CheckedChanged);
            // 
            // label107
            // 
            this.label107.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label107.Location = new System.Drawing.Point(91, 27);
            this.label107.Name = "label107";
            this.label107.Size = new System.Drawing.Size(30, 20);
            this.label107.TabIndex = 99;
            this.label107.Text = "4";
            this.label107.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // chkPedDetectPhase12
            // 
            this.chkPedDetectPhase12.AutoSize = true;
            this.chkPedDetectPhase12.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chkPedDetectPhase12.Location = new System.Drawing.Point(349, 62);
            this.chkPedDetectPhase12.Name = "chkPedDetectPhase12";
            this.chkPedDetectPhase12.Size = new System.Drawing.Size(15, 14);
            this.chkPedDetectPhase12.TabIndex = 90;
            this.chkPedDetectPhase12.UseVisualStyleBackColor = true;
            this.chkPedDetectPhase12.CheckedChanged += new System.EventHandler(this.chkPedDetectPhase12_CheckedChanged);
            // 
            // label108
            // 
            this.label108.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label108.Location = new System.Drawing.Point(61, 27);
            this.label108.Name = "label108";
            this.label108.Size = new System.Drawing.Size(30, 20);
            this.label108.TabIndex = 98;
            this.label108.Text = "3";
            this.label108.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // chkPedDetectPhase13
            // 
            this.chkPedDetectPhase13.AutoSize = true;
            this.chkPedDetectPhase13.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chkPedDetectPhase13.Location = new System.Drawing.Point(383, 62);
            this.chkPedDetectPhase13.Name = "chkPedDetectPhase13";
            this.chkPedDetectPhase13.Size = new System.Drawing.Size(15, 14);
            this.chkPedDetectPhase13.TabIndex = 91;
            this.chkPedDetectPhase13.UseVisualStyleBackColor = true;
            this.chkPedDetectPhase13.CheckedChanged += new System.EventHandler(this.chkPedDetectPhase13_CheckedChanged);
            // 
            // label109
            // 
            this.label109.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label109.Location = new System.Drawing.Point(31, 27);
            this.label109.Name = "label109";
            this.label109.Size = new System.Drawing.Size(30, 20);
            this.label109.TabIndex = 97;
            this.label109.Text = "2";
            this.label109.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // chkPedDetectPhase14
            // 
            this.chkPedDetectPhase14.AutoSize = true;
            this.chkPedDetectPhase14.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chkPedDetectPhase14.Location = new System.Drawing.Point(417, 62);
            this.chkPedDetectPhase14.Name = "chkPedDetectPhase14";
            this.chkPedDetectPhase14.Size = new System.Drawing.Size(15, 14);
            this.chkPedDetectPhase14.TabIndex = 92;
            this.chkPedDetectPhase14.UseVisualStyleBackColor = true;
            this.chkPedDetectPhase14.CheckedChanged += new System.EventHandler(this.chkPedDetectPhase14_CheckedChanged);
            // 
            // label110
            // 
            this.label110.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label110.Location = new System.Drawing.Point(1, 27);
            this.label110.Name = "label110";
            this.label110.Size = new System.Drawing.Size(30, 20);
            this.label110.TabIndex = 96;
            this.label110.Text = "1";
            this.label110.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // chkPedDetectPhase15
            // 
            this.chkPedDetectPhase15.AutoSize = true;
            this.chkPedDetectPhase15.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chkPedDetectPhase15.Location = new System.Drawing.Point(451, 62);
            this.chkPedDetectPhase15.Name = "chkPedDetectPhase15";
            this.chkPedDetectPhase15.Size = new System.Drawing.Size(15, 14);
            this.chkPedDetectPhase15.TabIndex = 93;
            this.chkPedDetectPhase15.UseVisualStyleBackColor = true;
            this.chkPedDetectPhase15.CheckedChanged += new System.EventHandler(this.chkPedDetectPhase15_CheckedChanged);
            // 
            // chkPedDetectPhase16
            // 
            this.chkPedDetectPhase16.AutoSize = true;
            this.chkPedDetectPhase16.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chkPedDetectPhase16.Location = new System.Drawing.Point(487, 62);
            this.chkPedDetectPhase16.Name = "chkPedDetectPhase16";
            this.chkPedDetectPhase16.Size = new System.Drawing.Size(15, 14);
            this.chkPedDetectPhase16.TabIndex = 94;
            this.chkPedDetectPhase16.UseVisualStyleBackColor = true;
            this.chkPedDetectPhase16.CheckedChanged += new System.EventHandler(this.chkPedDetectPhase16_CheckedChanged);
            // 
            // label93
            // 
            this.label93.AutoSize = true;
            this.label93.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.label93.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label93.ForeColor = System.Drawing.Color.Blue;
            this.label93.Location = new System.Drawing.Point(669, 568);
            this.label93.Name = "label93";
            this.label93.Size = new System.Drawing.Size(197, 16);
            this.label93.TabIndex = 77;
            this.label93.Text = "SPaTDataOn=2, SPaTOff=0";
            // 
            // label92
            // 
            this.label92.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.label92.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label92.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.label92.Location = new System.Drawing.Point(431, 565);
            this.label92.Name = "label92";
            this.label92.Size = new System.Drawing.Size(149, 20);
            this.label92.TabIndex = 76;
            this.label92.Text = "TSC SPaT-Push Code";
            this.label92.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // txtSPaTPushCode
            // 
            this.txtSPaTPushCode.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtSPaTPushCode.Location = new System.Drawing.Point(587, 562);
            this.txtSPaTPushCode.Name = "txtSPaTPushCode";
            this.txtSPaTPushCode.Size = new System.Drawing.Size(74, 26);
            this.txtSPaTPushCode.TabIndex = 75;
            // 
            // gbPortSettings
            // 
            this.gbPortSettings.Controls.Add(this.label58);
            this.gbPortSettings.Controls.Add(this.cmbHandShake);
            this.gbPortSettings.Controls.Add(this.cmbPortName);
            this.gbPortSettings.Controls.Add(this.cmbBaudRate);
            this.gbPortSettings.Controls.Add(this.cmbStopBits);
            this.gbPortSettings.Controls.Add(this.cmbParity);
            this.gbPortSettings.Controls.Add(this.cmbDataBits);
            this.gbPortSettings.Controls.Add(this.lblComPort);
            this.gbPortSettings.Controls.Add(this.lblStopBits);
            this.gbPortSettings.Controls.Add(this.lblBaudRate);
            this.gbPortSettings.Controls.Add(this.lblDataBits);
            this.gbPortSettings.Controls.Add(this.label59);
            this.gbPortSettings.ForeColor = System.Drawing.Color.Blue;
            this.gbPortSettings.Location = new System.Drawing.Point(426, 371);
            this.gbPortSettings.Name = "gbPortSettings";
            this.gbPortSettings.Size = new System.Drawing.Size(520, 88);
            this.gbPortSettings.TabIndex = 74;
            this.gbPortSettings.TabStop = false;
            this.gbPortSettings.Text = "GPS Serial Port Settings";
            // 
            // label58
            // 
            this.label58.AutoSize = true;
            this.label58.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label58.ForeColor = System.Drawing.Color.Black;
            this.label58.Location = new System.Drawing.Point(394, 29);
            this.label58.Name = "label58";
            this.label58.Size = new System.Drawing.Size(81, 16);
            this.label58.TabIndex = 11;
            this.label58.Text = "Handshake:";
            // 
            // cmbHandShake
            // 
            this.cmbHandShake.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbHandShake.FormattingEnabled = true;
            this.cmbHandShake.Items.AddRange(new object[] {
            "None",
            "XOnXOff",
            "Send",
            "SendXonXOff"});
            this.cmbHandShake.Location = new System.Drawing.Point(397, 45);
            this.cmbHandShake.Name = "cmbHandShake";
            this.cmbHandShake.Size = new System.Drawing.Size(117, 28);
            this.cmbHandShake.TabIndex = 10;
            // 
            // cmbPortName
            // 
            this.cmbPortName.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbPortName.FormattingEnabled = true;
            this.cmbPortName.Items.AddRange(new object[] {
            "COM1",
            "COM2",
            "COM3",
            "COM4",
            "COM5",
            "COM6",
            "COM7",
            "COM8",
            "COM9",
            "COM10",
            "COM11",
            "COM12",
            "COM13",
            "COM14",
            "COM15",
            "COM16",
            "COM17",
            "COM18",
            "COM19",
            "COM20"});
            this.cmbPortName.Location = new System.Drawing.Point(6, 45);
            this.cmbPortName.Name = "cmbPortName";
            this.cmbPortName.Size = new System.Drawing.Size(80, 28);
            this.cmbPortName.TabIndex = 1;
            // 
            // cmbBaudRate
            // 
            this.cmbBaudRate.FormattingEnabled = true;
            this.cmbBaudRate.Items.AddRange(new object[] {
            "1200",
            "2400",
            "4800",
            "9600",
            "19200",
            "38400",
            "57600",
            "115200"});
            this.cmbBaudRate.Location = new System.Drawing.Point(94, 45);
            this.cmbBaudRate.Name = "cmbBaudRate";
            this.cmbBaudRate.Size = new System.Drawing.Size(79, 28);
            this.cmbBaudRate.TabIndex = 3;
            // 
            // cmbStopBits
            // 
            this.cmbStopBits.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbStopBits.FormattingEnabled = true;
            this.cmbStopBits.Items.AddRange(new object[] {
            "1",
            "1.5",
            "2",
            "None"});
            this.cmbStopBits.Location = new System.Drawing.Point(327, 45);
            this.cmbStopBits.Name = "cmbStopBits";
            this.cmbStopBits.Size = new System.Drawing.Size(64, 28);
            this.cmbStopBits.TabIndex = 9;
            // 
            // cmbParity
            // 
            this.cmbParity.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbParity.FormattingEnabled = true;
            this.cmbParity.Items.AddRange(new object[] {
            "None",
            "Even",
            "Odd",
            "Mark",
            "Space"});
            this.cmbParity.Location = new System.Drawing.Point(181, 45);
            this.cmbParity.Name = "cmbParity";
            this.cmbParity.Size = new System.Drawing.Size(69, 28);
            this.cmbParity.TabIndex = 5;
            // 
            // cmbDataBits
            // 
            this.cmbDataBits.FormattingEnabled = true;
            this.cmbDataBits.Items.AddRange(new object[] {
            "7",
            "8",
            "9"});
            this.cmbDataBits.Location = new System.Drawing.Point(256, 45);
            this.cmbDataBits.Name = "cmbDataBits";
            this.cmbDataBits.Size = new System.Drawing.Size(63, 28);
            this.cmbDataBits.TabIndex = 7;
            // 
            // lblComPort
            // 
            this.lblComPort.AutoSize = true;
            this.lblComPort.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblComPort.ForeColor = System.Drawing.Color.Black;
            this.lblComPort.Location = new System.Drawing.Point(4, 29);
            this.lblComPort.Name = "lblComPort";
            this.lblComPort.Size = new System.Drawing.Size(68, 16);
            this.lblComPort.TabIndex = 0;
            this.lblComPort.Text = "COM Port:";
            // 
            // lblStopBits
            // 
            this.lblStopBits.AutoSize = true;
            this.lblStopBits.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblStopBits.ForeColor = System.Drawing.Color.Black;
            this.lblStopBits.Location = new System.Drawing.Point(325, 29);
            this.lblStopBits.Name = "lblStopBits";
            this.lblStopBits.Size = new System.Drawing.Size(64, 16);
            this.lblStopBits.TabIndex = 8;
            this.lblStopBits.Text = "Stop Bits:";
            // 
            // lblBaudRate
            // 
            this.lblBaudRate.AutoSize = true;
            this.lblBaudRate.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblBaudRate.ForeColor = System.Drawing.Color.Black;
            this.lblBaudRate.Location = new System.Drawing.Point(92, 29);
            this.lblBaudRate.Name = "lblBaudRate";
            this.lblBaudRate.Size = new System.Drawing.Size(75, 16);
            this.lblBaudRate.TabIndex = 2;
            this.lblBaudRate.Text = "Baud Rate:";
            // 
            // lblDataBits
            // 
            this.lblDataBits.AutoSize = true;
            this.lblDataBits.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblDataBits.ForeColor = System.Drawing.Color.Black;
            this.lblDataBits.Location = new System.Drawing.Point(254, 29);
            this.lblDataBits.Name = "lblDataBits";
            this.lblDataBits.Size = new System.Drawing.Size(65, 16);
            this.lblDataBits.TabIndex = 6;
            this.lblDataBits.Text = "Data Bits:";
            // 
            // label59
            // 
            this.label59.AutoSize = true;
            this.label59.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label59.ForeColor = System.Drawing.Color.Black;
            this.label59.Location = new System.Drawing.Point(179, 29);
            this.label59.Name = "label59";
            this.label59.Size = new System.Drawing.Size(45, 16);
            this.label59.TabIndex = 4;
            this.label59.Text = "Parity:";
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.btnSelectPTLMFile);
            this.groupBox1.Controls.Add(this.txtPTLMFile);
            this.groupBox1.ForeColor = System.Drawing.Color.Blue;
            this.groupBox1.Location = new System.Drawing.Point(426, 173);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(520, 92);
            this.groupBox1.TabIndex = 9;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Intersection Phase-to-Lane Movement Mapping File";
            // 
            // btnSelectPTLMFile
            // 
            this.btnSelectPTLMFile.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.btnSelectPTLMFile.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSelectPTLMFile.ForeColor = System.Drawing.Color.Black;
            this.btnSelectPTLMFile.Location = new System.Drawing.Point(9, 55);
            this.btnSelectPTLMFile.Name = "btnSelectPTLMFile";
            this.btnSelectPTLMFile.Size = new System.Drawing.Size(505, 31);
            this.btnSelectPTLMFile.TabIndex = 10;
            this.btnSelectPTLMFile.Text = "Select Intersection PTLM Mapping File";
            this.btnSelectPTLMFile.UseVisualStyleBackColor = false;
            this.btnSelectPTLMFile.Click += new System.EventHandler(this.btnSelectPTLMFile_Click);
            // 
            // txtPTLMFile
            // 
            this.txtPTLMFile.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtPTLMFile.Location = new System.Drawing.Point(9, 25);
            this.txtPTLMFile.Name = "txtPTLMFile";
            this.txtPTLMFile.Size = new System.Drawing.Size(505, 26);
            this.txtPTLMFile.TabIndex = 8;
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.label51);
            this.groupBox3.Controls.Add(this.label47);
            this.groupBox3.Controls.Add(this.txtSpatMsgTargetPort);
            this.groupBox3.Controls.Add(this.txtSpatMsgLocalPort);
            this.groupBox3.Controls.Add(this.label36);
            this.groupBox3.Controls.Add(this.txtRTCMMsgTargetPort);
            this.groupBox3.Controls.Add(this.label37);
            this.groupBox3.Controls.Add(this.txtRTCMMsgLocalPort);
            this.groupBox3.Controls.Add(this.label28);
            this.groupBox3.Controls.Add(this.txtSSMMsgTargetPort);
            this.groupBox3.Controls.Add(this.label29);
            this.groupBox3.Controls.Add(this.txtSSMMsgLocalPort);
            this.groupBox3.Controls.Add(this.label44);
            this.groupBox3.Controls.Add(this.txtSRMMsgTargetPort);
            this.groupBox3.Controls.Add(this.label43);
            this.groupBox3.Controls.Add(this.txtSRMMsgLocalPort);
            this.groupBox3.Controls.Add(this.label42);
            this.groupBox3.Controls.Add(this.txtMapMsgTargetPort);
            this.groupBox3.Controls.Add(this.label40);
            this.groupBox3.Controls.Add(this.txtMapMsgLocalPort);
            this.groupBox3.Controls.Add(this.label39);
            this.groupBox3.Controls.Add(this.label38);
            this.groupBox3.Controls.Add(this.label35);
            this.groupBox3.Controls.Add(this.label31);
            this.groupBox3.Controls.Add(this.txtSPATSystemSPATPort);
            this.groupBox3.Controls.Add(this.txtTSCNTCIPPort);
            this.groupBox3.ForeColor = System.Drawing.Color.Blue;
            this.groupBox3.Location = new System.Drawing.Point(23, 173);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(393, 411);
            this.groupBox3.TabIndex = 73;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "Port Numbers";
            // 
            // label51
            // 
            this.label51.AutoSize = true;
            this.label51.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.label51.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label51.ForeColor = System.Drawing.Color.Blue;
            this.label51.Location = new System.Drawing.Point(25, 46);
            this.label51.Name = "label51";
            this.label51.Size = new System.Drawing.Size(217, 16);
            this.label51.TabIndex = 75;
            this.label51.Text = "Siemens: 1034 Econolite: 6053";
            // 
            // label47
            // 
            this.label47.AutoSize = true;
            this.label47.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.label47.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label47.ForeColor = System.Drawing.Color.Blue;
            this.label47.Location = new System.Drawing.Point(41, 90);
            this.label47.Name = "label47";
            this.label47.Size = new System.Drawing.Size(201, 16);
            this.label47.TabIndex = 74;
            this.label47.Text = "Siemens: 161 Econolite: 501";
            // 
            // txtSpatMsgTargetPort
            // 
            this.txtSpatMsgTargetPort.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtSpatMsgTargetPort.Location = new System.Drawing.Point(248, 140);
            this.txtSpatMsgTargetPort.Name = "txtSpatMsgTargetPort";
            this.txtSpatMsgTargetPort.Size = new System.Drawing.Size(139, 26);
            this.txtSpatMsgTargetPort.TabIndex = 29;
            // 
            // txtSpatMsgLocalPort
            // 
            this.txtSpatMsgLocalPort.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtSpatMsgLocalPort.Location = new System.Drawing.Point(248, 111);
            this.txtSpatMsgLocalPort.Name = "txtSpatMsgLocalPort";
            this.txtSpatMsgLocalPort.Size = new System.Drawing.Size(139, 26);
            this.txtSpatMsgLocalPort.TabIndex = 28;
            // 
            // label36
            // 
            this.label36.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.label36.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label36.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.label36.Location = new System.Drawing.Point(62, 377);
            this.label36.Name = "label36";
            this.label36.Size = new System.Drawing.Size(181, 20);
            this.label36.TabIndex = 27;
            this.label36.Text = "RTCM Msg RSE Port";
            this.label36.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // txtRTCMMsgTargetPort
            // 
            this.txtRTCMMsgTargetPort.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtRTCMMsgTargetPort.Location = new System.Drawing.Point(249, 374);
            this.txtRTCMMsgTargetPort.Name = "txtRTCMMsgTargetPort";
            this.txtRTCMMsgTargetPort.Size = new System.Drawing.Size(139, 26);
            this.txtRTCMMsgTargetPort.TabIndex = 26;
            // 
            // label37
            // 
            this.label37.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.label37.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label37.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.label37.Location = new System.Drawing.Point(61, 348);
            this.label37.Name = "label37";
            this.label37.Size = new System.Drawing.Size(182, 20);
            this.label37.TabIndex = 25;
            this.label37.Text = "RTCM Msg BBox Port";
            this.label37.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // txtRTCMMsgLocalPort
            // 
            this.txtRTCMMsgLocalPort.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtRTCMMsgLocalPort.Location = new System.Drawing.Point(249, 345);
            this.txtRTCMMsgLocalPort.Name = "txtRTCMMsgLocalPort";
            this.txtRTCMMsgLocalPort.Size = new System.Drawing.Size(139, 26);
            this.txtRTCMMsgLocalPort.TabIndex = 24;
            // 
            // label28
            // 
            this.label28.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.label28.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label28.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.label28.Location = new System.Drawing.Point(62, 319);
            this.label28.Name = "label28";
            this.label28.Size = new System.Drawing.Size(181, 20);
            this.label28.TabIndex = 23;
            this.label28.Text = "SSM Msg RSE Port";
            this.label28.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // txtSSMMsgTargetPort
            // 
            this.txtSSMMsgTargetPort.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtSSMMsgTargetPort.Location = new System.Drawing.Point(249, 316);
            this.txtSSMMsgTargetPort.Name = "txtSSMMsgTargetPort";
            this.txtSSMMsgTargetPort.Size = new System.Drawing.Size(139, 26);
            this.txtSSMMsgTargetPort.TabIndex = 22;
            // 
            // label29
            // 
            this.label29.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.label29.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label29.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.label29.Location = new System.Drawing.Point(62, 290);
            this.label29.Name = "label29";
            this.label29.Size = new System.Drawing.Size(181, 20);
            this.label29.TabIndex = 21;
            this.label29.Text = "SSM Msg BBox Port";
            this.label29.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // txtSSMMsgLocalPort
            // 
            this.txtSSMMsgLocalPort.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtSSMMsgLocalPort.Location = new System.Drawing.Point(249, 287);
            this.txtSSMMsgLocalPort.Name = "txtSSMMsgLocalPort";
            this.txtSSMMsgLocalPort.Size = new System.Drawing.Size(139, 26);
            this.txtSSMMsgLocalPort.TabIndex = 20;
            // 
            // label44
            // 
            this.label44.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.label44.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label44.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.label44.Location = new System.Drawing.Point(62, 260);
            this.label44.Name = "label44";
            this.label44.Size = new System.Drawing.Size(181, 20);
            this.label44.TabIndex = 19;
            this.label44.Text = "SRM Msg RSE Port";
            this.label44.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // txtSRMMsgTargetPort
            // 
            this.txtSRMMsgTargetPort.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtSRMMsgTargetPort.Location = new System.Drawing.Point(249, 257);
            this.txtSRMMsgTargetPort.Name = "txtSRMMsgTargetPort";
            this.txtSRMMsgTargetPort.Size = new System.Drawing.Size(139, 26);
            this.txtSRMMsgTargetPort.TabIndex = 18;
            // 
            // label43
            // 
            this.label43.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.label43.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label43.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.label43.Location = new System.Drawing.Point(62, 231);
            this.label43.Name = "label43";
            this.label43.Size = new System.Drawing.Size(181, 20);
            this.label43.TabIndex = 17;
            this.label43.Text = "SRM Msg BBox Port";
            this.label43.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // txtSRMMsgLocalPort
            // 
            this.txtSRMMsgLocalPort.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtSRMMsgLocalPort.Location = new System.Drawing.Point(249, 228);
            this.txtSRMMsgLocalPort.Name = "txtSRMMsgLocalPort";
            this.txtSRMMsgLocalPort.Size = new System.Drawing.Size(139, 26);
            this.txtSRMMsgLocalPort.TabIndex = 16;
            // 
            // label42
            // 
            this.label42.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.label42.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label42.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.label42.Location = new System.Drawing.Point(62, 201);
            this.label42.Name = "label42";
            this.label42.Size = new System.Drawing.Size(181, 20);
            this.label42.TabIndex = 15;
            this.label42.Text = "MAP Msg RSE Port";
            this.label42.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // txtMapMsgTargetPort
            // 
            this.txtMapMsgTargetPort.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtMapMsgTargetPort.Location = new System.Drawing.Point(249, 198);
            this.txtMapMsgTargetPort.Name = "txtMapMsgTargetPort";
            this.txtMapMsgTargetPort.Size = new System.Drawing.Size(139, 26);
            this.txtMapMsgTargetPort.TabIndex = 14;
            // 
            // label40
            // 
            this.label40.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.label40.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label40.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.label40.Location = new System.Drawing.Point(62, 172);
            this.label40.Name = "label40";
            this.label40.Size = new System.Drawing.Size(181, 20);
            this.label40.TabIndex = 13;
            this.label40.Text = "MAP Msg BBox Port";
            this.label40.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // txtMapMsgLocalPort
            // 
            this.txtMapMsgLocalPort.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtMapMsgLocalPort.Location = new System.Drawing.Point(249, 169);
            this.txtMapMsgLocalPort.Name = "txtMapMsgLocalPort";
            this.txtMapMsgLocalPort.Size = new System.Drawing.Size(139, 26);
            this.txtMapMsgLocalPort.TabIndex = 12;
            // 
            // label39
            // 
            this.label39.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.label39.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label39.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.label39.Location = new System.Drawing.Point(62, 143);
            this.label39.Name = "label39";
            this.label39.Size = new System.Drawing.Size(181, 20);
            this.label39.TabIndex = 11;
            this.label39.Text = "SPaT Msg RSE Port";
            this.label39.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label38
            // 
            this.label38.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.label38.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label38.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.label38.Location = new System.Drawing.Point(62, 114);
            this.label38.Name = "label38";
            this.label38.Size = new System.Drawing.Size(181, 20);
            this.label38.TabIndex = 10;
            this.label38.Text = "SPaT Msg BBox Port";
            this.label38.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label35
            // 
            this.label35.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.label35.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label35.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.label35.Location = new System.Drawing.Point(62, 69);
            this.label35.Name = "label35";
            this.label35.Size = new System.Drawing.Size(181, 20);
            this.label35.TabIndex = 9;
            this.label35.Text = "TSC NTCIP Port";
            this.label35.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label31
            // 
            this.label31.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.label31.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label31.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.label31.Location = new System.Drawing.Point(62, 26);
            this.label31.Name = "label31";
            this.label31.Size = new System.Drawing.Size(181, 20);
            this.label31.TabIndex = 8;
            this.label31.Text = "BBox TSC Data Port";
            this.label31.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // txtSPATSystemSPATPort
            // 
            this.txtSPATSystemSPATPort.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtSPATSystemSPATPort.Location = new System.Drawing.Point(248, 23);
            this.txtSPATSystemSPATPort.Name = "txtSPATSystemSPATPort";
            this.txtSPATSystemSPATPort.Size = new System.Drawing.Size(139, 26);
            this.txtSPATSystemSPATPort.TabIndex = 1;
            // 
            // txtTSCNTCIPPort
            // 
            this.txtTSCNTCIPPort.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtTSCNTCIPPort.Location = new System.Drawing.Point(248, 66);
            this.txtTSCNTCIPPort.Name = "txtTSCNTCIPPort";
            this.txtTSCNTCIPPort.Size = new System.Drawing.Size(139, 26);
            this.txtTSCNTCIPPort.TabIndex = 1;
            // 
            // groupBox9
            // 
            this.groupBox9.BackColor = System.Drawing.SystemColors.Control;
            this.groupBox9.Controls.Add(this.label54);
            this.groupBox9.Controls.Add(this.txtState);
            this.groupBox9.Controls.Add(this.label53);
            this.groupBox9.Controls.Add(this.txtCity);
            this.groupBox9.Controls.Add(this.label49);
            this.groupBox9.Controls.Add(this.label50);
            this.groupBox9.Controls.Add(this.txtIntersectionName);
            this.groupBox9.Controls.Add(this.txtIntersectionID);
            this.groupBox9.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox9.ForeColor = System.Drawing.Color.Blue;
            this.groupBox9.Location = new System.Drawing.Point(426, 11);
            this.groupBox9.Name = "groupBox9";
            this.groupBox9.Size = new System.Drawing.Size(520, 156);
            this.groupBox9.TabIndex = 72;
            this.groupBox9.TabStop = false;
            this.groupBox9.Text = " Intersection Information";
            // 
            // label54
            // 
            this.label54.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.label54.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label54.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.label54.Location = new System.Drawing.Point(4, 122);
            this.label54.Name = "label54";
            this.label54.Size = new System.Drawing.Size(64, 20);
            this.label54.TabIndex = 13;
            this.label54.Text = "State";
            this.label54.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // txtState
            // 
            this.txtState.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtState.Location = new System.Drawing.Point(70, 119);
            this.txtState.Name = "txtState";
            this.txtState.Size = new System.Drawing.Size(444, 26);
            this.txtState.TabIndex = 12;
            // 
            // label53
            // 
            this.label53.AccessibleName = "State";
            this.label53.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.label53.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label53.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.label53.Location = new System.Drawing.Point(4, 59);
            this.label53.Name = "label53";
            this.label53.Size = new System.Drawing.Size(64, 20);
            this.label53.TabIndex = 11;
            this.label53.Text = "City";
            this.label53.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // txtCity
            // 
            this.txtCity.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtCity.Location = new System.Drawing.Point(70, 56);
            this.txtCity.Name = "txtCity";
            this.txtCity.Size = new System.Drawing.Size(444, 26);
            this.txtCity.TabIndex = 10;
            // 
            // label49
            // 
            this.label49.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.label49.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label49.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.label49.Location = new System.Drawing.Point(4, 90);
            this.label49.Name = "label49";
            this.label49.Size = new System.Drawing.Size(64, 20);
            this.label49.TabIndex = 7;
            this.label49.Text = "ID";
            this.label49.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label50
            // 
            this.label50.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.label50.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label50.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.label50.Location = new System.Drawing.Point(4, 28);
            this.label50.Name = "label50";
            this.label50.Size = new System.Drawing.Size(64, 20);
            this.label50.TabIndex = 6;
            this.label50.Text = "Name";
            this.label50.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // txtIntersectionName
            // 
            this.txtIntersectionName.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtIntersectionName.Location = new System.Drawing.Point(70, 25);
            this.txtIntersectionName.Name = "txtIntersectionName";
            this.txtIntersectionName.Size = new System.Drawing.Size(444, 26);
            this.txtIntersectionName.TabIndex = 5;
            // 
            // txtIntersectionID
            // 
            this.txtIntersectionID.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtIntersectionID.Location = new System.Drawing.Point(70, 87);
            this.txtIntersectionID.Name = "txtIntersectionID";
            this.txtIntersectionID.Size = new System.Drawing.Size(444, 26);
            this.txtIntersectionID.TabIndex = 4;
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.label30);
            this.groupBox2.Controls.Add(this.label21);
            this.groupBox2.Controls.Add(this.label20);
            this.groupBox2.Controls.Add(this.label17);
            this.groupBox2.Controls.Add(this.txtSPATSystemIPV6Address);
            this.groupBox2.Controls.Add(this.txtTSCIPV4Address);
            this.groupBox2.Controls.Add(this.txtRSEIPV6Address);
            this.groupBox2.Controls.Add(this.txtSPATSystemIPV4Address);
            this.groupBox2.ForeColor = System.Drawing.Color.Blue;
            this.groupBox2.Location = new System.Drawing.Point(23, 11);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(393, 156);
            this.groupBox2.TabIndex = 70;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "SPaT System Devices IP Addresses";
            // 
            // label30
            // 
            this.label30.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.label30.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label30.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.label30.Location = new System.Drawing.Point(7, 55);
            this.label30.Name = "label30";
            this.label30.Size = new System.Drawing.Size(149, 20);
            this.label30.TabIndex = 10;
            this.label30.Text = "TSC IPV4 IP";
            this.label30.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label21
            // 
            this.label21.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.label21.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label21.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.label21.Location = new System.Drawing.Point(7, 114);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(149, 20);
            this.label21.TabIndex = 9;
            this.label21.Text = "RSE IPV6 IP";
            this.label21.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label20
            // 
            this.label20.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.label20.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label20.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.label20.Location = new System.Drawing.Point(7, 85);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(149, 20);
            this.label20.TabIndex = 8;
            this.label20.Text = "BlackBox IPV6 IP";
            this.label20.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label17
            // 
            this.label17.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.label17.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label17.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.label17.Location = new System.Drawing.Point(7, 26);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(149, 20);
            this.label17.TabIndex = 7;
            this.label17.Text = "BlackBox IPV4 IP";
            this.label17.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // txtSPATSystemIPV6Address
            // 
            this.txtSPATSystemIPV6Address.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtSPATSystemIPV6Address.Location = new System.Drawing.Point(162, 82);
            this.txtSPATSystemIPV6Address.Name = "txtSPATSystemIPV6Address";
            this.txtSPATSystemIPV6Address.Size = new System.Drawing.Size(225, 26);
            this.txtSPATSystemIPV6Address.TabIndex = 0;
            // 
            // txtTSCIPV4Address
            // 
            this.txtTSCIPV4Address.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtTSCIPV4Address.Location = new System.Drawing.Point(162, 52);
            this.txtTSCIPV4Address.Name = "txtTSCIPV4Address";
            this.txtTSCIPV4Address.Size = new System.Drawing.Size(225, 26);
            this.txtTSCIPV4Address.TabIndex = 0;
            // 
            // txtRSEIPV6Address
            // 
            this.txtRSEIPV6Address.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtRSEIPV6Address.Location = new System.Drawing.Point(162, 111);
            this.txtRSEIPV6Address.Name = "txtRSEIPV6Address";
            this.txtRSEIPV6Address.Size = new System.Drawing.Size(225, 26);
            this.txtRSEIPV6Address.TabIndex = 0;
            // 
            // txtSPATSystemIPV4Address
            // 
            this.txtSPATSystemIPV4Address.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtSPATSystemIPV4Address.Location = new System.Drawing.Point(162, 23);
            this.txtSPATSystemIPV4Address.Name = "txtSPATSystemIPV4Address";
            this.txtSPATSystemIPV4Address.Size = new System.Drawing.Size(225, 26);
            this.txtSPATSystemIPV4Address.TabIndex = 0;
            // 
            // groupBox4
            // 
            this.groupBox4.BackColor = System.Drawing.SystemColors.Control;
            this.groupBox4.Controls.Add(this.btnModifySPATMsgDir);
            this.groupBox4.Controls.Add(this.txtSPATDailyLogFolder);
            this.groupBox4.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox4.ForeColor = System.Drawing.Color.Blue;
            this.groupBox4.Location = new System.Drawing.Point(426, 274);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Size = new System.Drawing.Size(520, 91);
            this.groupBox4.TabIndex = 14;
            this.groupBox4.TabStop = false;
            this.groupBox4.Text = "Daily Log Files Directory";
            // 
            // btnModifySPATMsgDir
            // 
            this.btnModifySPATMsgDir.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.btnModifySPATMsgDir.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnModifySPATMsgDir.ForeColor = System.Drawing.Color.Black;
            this.btnModifySPATMsgDir.Location = new System.Drawing.Point(9, 49);
            this.btnModifySPATMsgDir.Name = "btnModifySPATMsgDir";
            this.btnModifySPATMsgDir.Size = new System.Drawing.Size(505, 31);
            this.btnModifySPATMsgDir.TabIndex = 8;
            this.btnModifySPATMsgDir.Text = "Select Daily Log Files Folder";
            this.btnModifySPATMsgDir.UseVisualStyleBackColor = false;
            this.btnModifySPATMsgDir.Click += new System.EventHandler(this.btnModifySPATMsgDir_Click);
            // 
            // txtSPATDailyLogFolder
            // 
            this.txtSPATDailyLogFolder.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtSPATDailyLogFolder.Location = new System.Drawing.Point(9, 20);
            this.txtSPATDailyLogFolder.Name = "txtSPATDailyLogFolder";
            this.txtSPATDailyLogFolder.Size = new System.Drawing.Size(505, 26);
            this.txtSPATDailyLogFolder.TabIndex = 4;
            // 
            // btnSaveSPATConfiguration
            // 
            this.btnSaveSPATConfiguration.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.btnSaveSPATConfiguration.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSaveSPATConfiguration.ForeColor = System.Drawing.Color.Black;
            this.btnSaveSPATConfiguration.Location = new System.Drawing.Point(426, 594);
            this.btnSaveSPATConfiguration.Name = "btnSaveSPATConfiguration";
            this.btnSaveSPATConfiguration.Size = new System.Drawing.Size(250, 45);
            this.btnSaveSPATConfiguration.TabIndex = 9;
            this.btnSaveSPATConfiguration.Text = "Save Settings to XML File";
            this.btnSaveSPATConfiguration.UseVisualStyleBackColor = false;
            this.btnSaveSPATConfiguration.Click += new System.EventHandler(this.btnSaveSPATConfiguration_Click);
            // 
            // tabpgPeds
            // 
            this.tabpgPeds.Controls.Add(this.groupBox12);
            this.tabpgPeds.Controls.Add(this.chkPedActive);
            this.tabpgPeds.Controls.Add(this.groupBox11);
            this.tabpgPeds.Controls.Add(this.groupBox10);
            this.tabpgPeds.Controls.Add(this.groupBox7);
            this.tabpgPeds.Controls.Add(this.grpPedSimulator);
            this.tabpgPeds.Controls.Add(this.btnPedSimulator);
            this.tabpgPeds.Location = new System.Drawing.Point(4, 32);
            this.tabpgPeds.Name = "tabpgPeds";
            this.tabpgPeds.Size = new System.Drawing.Size(1009, 655);
            this.tabpgPeds.TabIndex = 10;
            this.tabpgPeds.Text = "Ped Calls and Detectors Status";
            this.tabpgPeds.UseVisualStyleBackColor = true;
            // 
            // groupBox12
            // 
            this.groupBox12.Controls.Add(this.label127);
            this.groupBox12.Controls.Add(this.txtMvmntPedDets);
            this.groupBox12.Controls.Add(this.txtNoCalls);
            this.groupBox12.Location = new System.Drawing.Point(509, 153);
            this.groupBox12.Name = "groupBox12";
            this.groupBox12.Size = new System.Drawing.Size(334, 123);
            this.groupBox12.TabIndex = 101;
            this.groupBox12.TabStop = false;
            this.groupBox12.Text = "Movements with Active Ped Detectors";
            // 
            // label127
            // 
            this.label127.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label127.Location = new System.Drawing.Point(6, 54);
            this.label127.Name = "label127";
            this.label127.Size = new System.Drawing.Size(183, 21);
            this.label127.TabIndex = 90;
            this.label127.Text = "Active Ped Detectors";
            this.label127.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // txtMvmntPedDets
            // 
            this.txtMvmntPedDets.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtMvmntPedDets.Location = new System.Drawing.Point(9, 23);
            this.txtMvmntPedDets.Name = "txtMvmntPedDets";
            this.txtMvmntPedDets.ScrollBars = System.Windows.Forms.ScrollBars.Horizontal;
            this.txtMvmntPedDets.Size = new System.Drawing.Size(313, 26);
            this.txtMvmntPedDets.TabIndex = 93;
            // 
            // txtNoCalls
            // 
            this.txtNoCalls.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtNoCalls.Location = new System.Drawing.Point(6, 78);
            this.txtNoCalls.Name = "txtNoCalls";
            this.txtNoCalls.Size = new System.Drawing.Size(54, 26);
            this.txtNoCalls.TabIndex = 96;
            // 
            // chkPedActive
            // 
            this.chkPedActive.AutoSize = true;
            this.chkPedActive.Location = new System.Drawing.Point(509, 282);
            this.chkPedActive.Name = "chkPedActive";
            this.chkPedActive.Size = new System.Drawing.Size(157, 24);
            this.chkPedActive.TabIndex = 95;
            this.chkPedActive.Text = "Ped Calls Active";
            this.chkPedActive.UseVisualStyleBackColor = true;
            this.chkPedActive.Visible = false;
            // 
            // groupBox11
            // 
            this.groupBox11.Controls.Add(this.label120);
            this.groupBox11.Controls.Add(this.txtMvmntPedCalls);
            this.groupBox11.Location = new System.Drawing.Point(509, 14);
            this.groupBox11.Name = "groupBox11";
            this.groupBox11.Size = new System.Drawing.Size(334, 118);
            this.groupBox11.TabIndex = 100;
            this.groupBox11.TabStop = false;
            this.groupBox11.Text = "Movements with Un-Serviced Ped Calls";
            // 
            // label120
            // 
            this.label120.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label120.Location = new System.Drawing.Point(6, 58);
            this.label120.Name = "label120";
            this.label120.Size = new System.Drawing.Size(183, 21);
            this.label120.TabIndex = 90;
            this.label120.Text = "Un Serviced Ped Movements";
            this.label120.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // txtMvmntPedCalls
            // 
            this.txtMvmntPedCalls.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtMvmntPedCalls.Location = new System.Drawing.Point(9, 29);
            this.txtMvmntPedCalls.Name = "txtMvmntPedCalls";
            this.txtMvmntPedCalls.ScrollBars = System.Windows.Forms.ScrollBars.Horizontal;
            this.txtMvmntPedCalls.Size = new System.Drawing.Size(319, 26);
            this.txtMvmntPedCalls.TabIndex = 87;
            // 
            // groupBox10
            // 
            this.groupBox10.Controls.Add(this.txtPedDet);
            this.groupBox10.Controls.Add(this.txtByte242);
            this.groupBox10.Controls.Add(this.label118);
            this.groupBox10.Controls.Add(this.label124);
            this.groupBox10.Controls.Add(this.txtByte241);
            this.groupBox10.Controls.Add(this.txtBytes241242);
            this.groupBox10.Controls.Add(this.label125);
            this.groupBox10.Controls.Add(this.label126);
            this.groupBox10.Location = new System.Drawing.Point(11, 153);
            this.groupBox10.Name = "groupBox10";
            this.groupBox10.Size = new System.Drawing.Size(489, 123);
            this.groupBox10.TabIndex = 99;
            this.groupBox10.TabStop = false;
            this.groupBox10.Text = "Controller Ped Detector Data";
            // 
            // txtPedDet
            // 
            this.txtPedDet.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtPedDet.Location = new System.Drawing.Point(13, 64);
            this.txtPedDet.Name = "txtPedDet";
            this.txtPedDet.ScrollBars = System.Windows.Forms.ScrollBars.Horizontal;
            this.txtPedDet.Size = new System.Drawing.Size(461, 26);
            this.txtPedDet.TabIndex = 89;
            // 
            // txtByte242
            // 
            this.txtByte242.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtByte242.Location = new System.Drawing.Point(73, 25);
            this.txtByte242.Name = "txtByte242";
            this.txtByte242.Size = new System.Drawing.Size(69, 26);
            this.txtByte242.TabIndex = 76;
            // 
            // label118
            // 
            this.label118.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label118.Location = new System.Drawing.Point(10, 29);
            this.label118.Name = "label118";
            this.label118.Size = new System.Drawing.Size(62, 21);
            this.label118.TabIndex = 77;
            this.label118.Text = "Byte 242";
            this.label118.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label124
            // 
            this.label124.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label124.Location = new System.Drawing.Point(158, 29);
            this.label124.Name = "label124";
            this.label124.Size = new System.Drawing.Size(62, 21);
            this.label124.TabIndex = 79;
            this.label124.Text = "Byte 241";
            this.label124.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // txtByte241
            // 
            this.txtByte241.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtByte241.Location = new System.Drawing.Point(221, 25);
            this.txtByte241.Name = "txtByte241";
            this.txtByte241.Size = new System.Drawing.Size(69, 26);
            this.txtByte241.TabIndex = 78;
            // 
            // txtBytes241242
            // 
            this.txtBytes241242.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtBytes241242.Location = new System.Drawing.Point(405, 24);
            this.txtBytes241242.Name = "txtBytes241242";
            this.txtBytes241242.Size = new System.Drawing.Size(69, 26);
            this.txtBytes241242.TabIndex = 84;
            // 
            // label125
            // 
            this.label125.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label125.Location = new System.Drawing.Point(306, 28);
            this.label125.Name = "label125";
            this.label125.Size = new System.Drawing.Size(93, 21);
            this.label125.TabIndex = 85;
            this.label125.Text = "Bytes 241-242";
            this.label125.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label126
            // 
            this.label126.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label126.Location = new System.Drawing.Point(10, 93);
            this.label126.Name = "label126";
            this.label126.Size = new System.Drawing.Size(143, 21);
            this.label126.TabIndex = 88;
            this.label126.Text = "Active Ped Detectors";
            this.label126.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // groupBox7
            // 
            this.groupBox7.Controls.Add(this.txtByte244);
            this.groupBox7.Controls.Add(this.label113);
            this.groupBox7.Controls.Add(this.label114);
            this.groupBox7.Controls.Add(this.txtByte243);
            this.groupBox7.Controls.Add(this.txtBytes243244);
            this.groupBox7.Controls.Add(this.label117);
            this.groupBox7.Controls.Add(this.txtPedCalls);
            this.groupBox7.Controls.Add(this.label119);
            this.groupBox7.Location = new System.Drawing.Point(11, 14);
            this.groupBox7.Name = "groupBox7";
            this.groupBox7.Size = new System.Drawing.Size(489, 123);
            this.groupBox7.TabIndex = 98;
            this.groupBox7.TabStop = false;
            this.groupBox7.Text = "Controller Ped Calls Data";
            // 
            // txtByte244
            // 
            this.txtByte244.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtByte244.Location = new System.Drawing.Point(73, 25);
            this.txtByte244.Name = "txtByte244";
            this.txtByte244.Size = new System.Drawing.Size(69, 26);
            this.txtByte244.TabIndex = 76;
            // 
            // label113
            // 
            this.label113.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label113.Location = new System.Drawing.Point(10, 29);
            this.label113.Name = "label113";
            this.label113.Size = new System.Drawing.Size(62, 21);
            this.label113.TabIndex = 77;
            this.label113.Text = "Byte 244";
            this.label113.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label114
            // 
            this.label114.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label114.Location = new System.Drawing.Point(158, 29);
            this.label114.Name = "label114";
            this.label114.Size = new System.Drawing.Size(62, 21);
            this.label114.TabIndex = 79;
            this.label114.Text = "Byte 243";
            this.label114.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // txtByte243
            // 
            this.txtByte243.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtByte243.Location = new System.Drawing.Point(221, 25);
            this.txtByte243.Name = "txtByte243";
            this.txtByte243.Size = new System.Drawing.Size(69, 26);
            this.txtByte243.TabIndex = 78;
            // 
            // txtBytes243244
            // 
            this.txtBytes243244.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtBytes243244.Location = new System.Drawing.Point(405, 24);
            this.txtBytes243244.Name = "txtBytes243244";
            this.txtBytes243244.Size = new System.Drawing.Size(69, 26);
            this.txtBytes243244.TabIndex = 84;
            // 
            // label117
            // 
            this.label117.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label117.Location = new System.Drawing.Point(306, 28);
            this.label117.Name = "label117";
            this.label117.Size = new System.Drawing.Size(93, 21);
            this.label117.TabIndex = 85;
            this.label117.Text = "Bytes 243-244";
            this.label117.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // txtPedCalls
            // 
            this.txtPedCalls.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtPedCalls.Location = new System.Drawing.Point(13, 68);
            this.txtPedCalls.Name = "txtPedCalls";
            this.txtPedCalls.ScrollBars = System.Windows.Forms.ScrollBars.Horizontal;
            this.txtPedCalls.Size = new System.Drawing.Size(461, 26);
            this.txtPedCalls.TabIndex = 87;
            // 
            // label119
            // 
            this.label119.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label119.Location = new System.Drawing.Point(11, 97);
            this.label119.Name = "label119";
            this.label119.Size = new System.Drawing.Size(131, 21);
            this.label119.TabIndex = 88;
            this.label119.Text = "Active Push Buttons";
            this.label119.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // grpPedSimulator
            // 
            this.grpPedSimulator.Controls.Add(this.chkPedDetect15);
            this.grpPedSimulator.Controls.Add(this.label91);
            this.grpPedSimulator.Controls.Add(this.label90);
            this.grpPedSimulator.Controls.Add(this.label89);
            this.grpPedSimulator.Controls.Add(this.label88);
            this.grpPedSimulator.Controls.Add(this.label87);
            this.grpPedSimulator.Controls.Add(this.label86);
            this.grpPedSimulator.Controls.Add(this.label85);
            this.grpPedSimulator.Controls.Add(this.label84);
            this.grpPedSimulator.Controls.Add(this.label83);
            this.grpPedSimulator.Controls.Add(this.label82);
            this.grpPedSimulator.Controls.Add(this.label81);
            this.grpPedSimulator.Controls.Add(this.label80);
            this.grpPedSimulator.Controls.Add(this.label79);
            this.grpPedSimulator.Controls.Add(this.label78);
            this.grpPedSimulator.Controls.Add(this.label77);
            this.grpPedSimulator.Controls.Add(this.label76);
            this.grpPedSimulator.Controls.Add(this.label75);
            this.grpPedSimulator.Controls.Add(this.label69);
            this.grpPedSimulator.Controls.Add(this.chkPedDetect16);
            this.grpPedSimulator.Controls.Add(this.chkPedDetect14);
            this.grpPedSimulator.Controls.Add(this.chkPedDetect13);
            this.grpPedSimulator.Controls.Add(this.chkPedDetect12);
            this.grpPedSimulator.Controls.Add(this.chkPedDetect11);
            this.grpPedSimulator.Controls.Add(this.chkPedDetect10);
            this.grpPedSimulator.Controls.Add(this.chkPedDetect9);
            this.grpPedSimulator.Controls.Add(this.chkPedDetect8);
            this.grpPedSimulator.Controls.Add(this.chkPedDetect7);
            this.grpPedSimulator.Controls.Add(this.chkPedDetect6);
            this.grpPedSimulator.Controls.Add(this.chkPedDetect5);
            this.grpPedSimulator.Controls.Add(this.chkPedDetect4);
            this.grpPedSimulator.Controls.Add(this.chkPedDetect3);
            this.grpPedSimulator.Controls.Add(this.chkPedDetect2);
            this.grpPedSimulator.Controls.Add(this.chkPedDetect1);
            this.grpPedSimulator.Controls.Add(this.chkPedCall16);
            this.grpPedSimulator.Controls.Add(this.chkPedCall15);
            this.grpPedSimulator.Controls.Add(this.chkPedCall14);
            this.grpPedSimulator.Controls.Add(this.chkPedCall13);
            this.grpPedSimulator.Controls.Add(this.chkPedCall12);
            this.grpPedSimulator.Controls.Add(this.chkPedCall11);
            this.grpPedSimulator.Controls.Add(this.chkPedCall10);
            this.grpPedSimulator.Controls.Add(this.chkPedCall9);
            this.grpPedSimulator.Controls.Add(this.chkPedCall8);
            this.grpPedSimulator.Controls.Add(this.chkPedCall7);
            this.grpPedSimulator.Controls.Add(this.chkPedCall6);
            this.grpPedSimulator.Controls.Add(this.chkPedCall5);
            this.grpPedSimulator.Controls.Add(this.chkPedCall4);
            this.grpPedSimulator.Controls.Add(this.chkPedCall3);
            this.grpPedSimulator.Controls.Add(this.chkPedCall2);
            this.grpPedSimulator.Controls.Add(this.chkPedCall1);
            this.grpPedSimulator.Location = new System.Drawing.Point(124, 298);
            this.grpPedSimulator.Name = "grpPedSimulator";
            this.grpPedSimulator.Size = new System.Drawing.Size(586, 107);
            this.grpPedSimulator.TabIndex = 54;
            this.grpPedSimulator.TabStop = false;
            this.grpPedSimulator.Text = "Pedestrian Call and Detection";
            this.grpPedSimulator.Visible = false;
            // 
            // chkPedDetect15
            // 
            this.chkPedDetect15.AutoSize = true;
            this.chkPedDetect15.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chkPedDetect15.Location = new System.Drawing.Point(536, 81);
            this.chkPedDetect15.Name = "chkPedDetect15";
            this.chkPedDetect15.Size = new System.Drawing.Size(15, 14);
            this.chkPedDetect15.TabIndex = 55;
            this.chkPedDetect15.UseVisualStyleBackColor = true;
            // 
            // label91
            // 
            this.label91.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label91.Location = new System.Drawing.Point(560, 18);
            this.label91.Name = "label91";
            this.label91.Size = new System.Drawing.Size(30, 20);
            this.label91.TabIndex = 54;
            this.label91.Text = "16";
            this.label91.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label90
            // 
            this.label90.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label90.Location = new System.Drawing.Point(528, 18);
            this.label90.Name = "label90";
            this.label90.Size = new System.Drawing.Size(30, 20);
            this.label90.TabIndex = 53;
            this.label90.Text = "15";
            this.label90.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label89
            // 
            this.label89.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label89.Location = new System.Drawing.Point(494, 18);
            this.label89.Name = "label89";
            this.label89.Size = new System.Drawing.Size(30, 20);
            this.label89.TabIndex = 52;
            this.label89.Text = "14";
            this.label89.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label88
            // 
            this.label88.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label88.Location = new System.Drawing.Point(462, 18);
            this.label88.Name = "label88";
            this.label88.Size = new System.Drawing.Size(30, 20);
            this.label88.TabIndex = 51;
            this.label88.Text = "13";
            this.label88.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label87
            // 
            this.label87.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label87.Location = new System.Drawing.Point(430, 18);
            this.label87.Name = "label87";
            this.label87.Size = new System.Drawing.Size(30, 20);
            this.label87.TabIndex = 50;
            this.label87.Text = "12";
            this.label87.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label86
            // 
            this.label86.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label86.Location = new System.Drawing.Point(400, 18);
            this.label86.Name = "label86";
            this.label86.Size = new System.Drawing.Size(30, 20);
            this.label86.TabIndex = 49;
            this.label86.Text = "11";
            this.label86.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label85
            // 
            this.label85.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label85.Location = new System.Drawing.Point(368, 18);
            this.label85.Name = "label85";
            this.label85.Size = new System.Drawing.Size(30, 20);
            this.label85.TabIndex = 48;
            this.label85.Text = "10";
            this.label85.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label84
            // 
            this.label84.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label84.Location = new System.Drawing.Point(334, 18);
            this.label84.Name = "label84";
            this.label84.Size = new System.Drawing.Size(30, 20);
            this.label84.TabIndex = 47;
            this.label84.Text = "9";
            this.label84.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label83
            // 
            this.label83.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label83.Location = new System.Drawing.Point(302, 18);
            this.label83.Name = "label83";
            this.label83.Size = new System.Drawing.Size(30, 20);
            this.label83.TabIndex = 46;
            this.label83.Text = "8";
            this.label83.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label82
            // 
            this.label82.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label82.Location = new System.Drawing.Point(270, 18);
            this.label82.Name = "label82";
            this.label82.Size = new System.Drawing.Size(30, 20);
            this.label82.TabIndex = 45;
            this.label82.Text = "7";
            this.label82.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label81
            // 
            this.label81.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label81.Location = new System.Drawing.Point(238, 18);
            this.label81.Name = "label81";
            this.label81.Size = new System.Drawing.Size(30, 20);
            this.label81.TabIndex = 44;
            this.label81.Text = "6";
            this.label81.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label80
            // 
            this.label80.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label80.Location = new System.Drawing.Point(206, 18);
            this.label80.Name = "label80";
            this.label80.Size = new System.Drawing.Size(30, 20);
            this.label80.TabIndex = 43;
            this.label80.Text = "5";
            this.label80.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label79
            // 
            this.label79.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label79.Location = new System.Drawing.Point(174, 18);
            this.label79.Name = "label79";
            this.label79.Size = new System.Drawing.Size(30, 20);
            this.label79.TabIndex = 42;
            this.label79.Text = "4";
            this.label79.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label78
            // 
            this.label78.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label78.Location = new System.Drawing.Point(144, 18);
            this.label78.Name = "label78";
            this.label78.Size = new System.Drawing.Size(30, 20);
            this.label78.TabIndex = 41;
            this.label78.Text = "3";
            this.label78.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label77
            // 
            this.label77.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label77.Location = new System.Drawing.Point(116, 18);
            this.label77.Name = "label77";
            this.label77.Size = new System.Drawing.Size(30, 20);
            this.label77.TabIndex = 40;
            this.label77.Text = "2";
            this.label77.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label76
            // 
            this.label76.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label76.Location = new System.Drawing.Point(86, 18);
            this.label76.Name = "label76";
            this.label76.Size = new System.Drawing.Size(30, 20);
            this.label76.TabIndex = 39;
            this.label76.Text = "1";
            this.label76.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label75
            // 
            this.label75.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label75.Location = new System.Drawing.Point(6, 78);
            this.label75.Name = "label75";
            this.label75.Size = new System.Drawing.Size(82, 21);
            this.label75.TabIndex = 38;
            this.label75.Text = "Ped. Detect";
            this.label75.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label69
            // 
            this.label69.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label69.Location = new System.Drawing.Point(6, 50);
            this.label69.Name = "label69";
            this.label69.Size = new System.Drawing.Size(82, 21);
            this.label69.TabIndex = 37;
            this.label69.Text = "Ped. Button";
            this.label69.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // chkPedDetect16
            // 
            this.chkPedDetect16.AutoSize = true;
            this.chkPedDetect16.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chkPedDetect16.Location = new System.Drawing.Point(568, 81);
            this.chkPedDetect16.Name = "chkPedDetect16";
            this.chkPedDetect16.Size = new System.Drawing.Size(15, 14);
            this.chkPedDetect16.TabIndex = 31;
            this.chkPedDetect16.UseVisualStyleBackColor = true;
            // 
            // chkPedDetect14
            // 
            this.chkPedDetect14.AutoSize = true;
            this.chkPedDetect14.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chkPedDetect14.Location = new System.Drawing.Point(502, 81);
            this.chkPedDetect14.Name = "chkPedDetect14";
            this.chkPedDetect14.Size = new System.Drawing.Size(15, 14);
            this.chkPedDetect14.TabIndex = 30;
            this.chkPedDetect14.UseVisualStyleBackColor = true;
            // 
            // chkPedDetect13
            // 
            this.chkPedDetect13.AutoSize = true;
            this.chkPedDetect13.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chkPedDetect13.Location = new System.Drawing.Point(470, 81);
            this.chkPedDetect13.Name = "chkPedDetect13";
            this.chkPedDetect13.Size = new System.Drawing.Size(15, 14);
            this.chkPedDetect13.TabIndex = 29;
            this.chkPedDetect13.UseVisualStyleBackColor = true;
            // 
            // chkPedDetect12
            // 
            this.chkPedDetect12.AutoSize = true;
            this.chkPedDetect12.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chkPedDetect12.Location = new System.Drawing.Point(438, 81);
            this.chkPedDetect12.Name = "chkPedDetect12";
            this.chkPedDetect12.Size = new System.Drawing.Size(15, 14);
            this.chkPedDetect12.TabIndex = 28;
            this.chkPedDetect12.UseVisualStyleBackColor = true;
            // 
            // chkPedDetect11
            // 
            this.chkPedDetect11.AutoSize = true;
            this.chkPedDetect11.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chkPedDetect11.Location = new System.Drawing.Point(408, 81);
            this.chkPedDetect11.Name = "chkPedDetect11";
            this.chkPedDetect11.Size = new System.Drawing.Size(15, 14);
            this.chkPedDetect11.TabIndex = 27;
            this.chkPedDetect11.UseVisualStyleBackColor = true;
            // 
            // chkPedDetect10
            // 
            this.chkPedDetect10.AutoSize = true;
            this.chkPedDetect10.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chkPedDetect10.Location = new System.Drawing.Point(376, 81);
            this.chkPedDetect10.Name = "chkPedDetect10";
            this.chkPedDetect10.Size = new System.Drawing.Size(15, 14);
            this.chkPedDetect10.TabIndex = 26;
            this.chkPedDetect10.UseVisualStyleBackColor = true;
            // 
            // chkPedDetect9
            // 
            this.chkPedDetect9.AutoSize = true;
            this.chkPedDetect9.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chkPedDetect9.Location = new System.Drawing.Point(342, 81);
            this.chkPedDetect9.Name = "chkPedDetect9";
            this.chkPedDetect9.Size = new System.Drawing.Size(15, 14);
            this.chkPedDetect9.TabIndex = 24;
            this.chkPedDetect9.UseVisualStyleBackColor = true;
            // 
            // chkPedDetect8
            // 
            this.chkPedDetect8.AutoSize = true;
            this.chkPedDetect8.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chkPedDetect8.Location = new System.Drawing.Point(310, 81);
            this.chkPedDetect8.Name = "chkPedDetect8";
            this.chkPedDetect8.Size = new System.Drawing.Size(15, 14);
            this.chkPedDetect8.TabIndex = 23;
            this.chkPedDetect8.UseVisualStyleBackColor = true;
            // 
            // chkPedDetect7
            // 
            this.chkPedDetect7.AutoSize = true;
            this.chkPedDetect7.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chkPedDetect7.Location = new System.Drawing.Point(278, 81);
            this.chkPedDetect7.Name = "chkPedDetect7";
            this.chkPedDetect7.Size = new System.Drawing.Size(15, 14);
            this.chkPedDetect7.TabIndex = 22;
            this.chkPedDetect7.UseVisualStyleBackColor = true;
            // 
            // chkPedDetect6
            // 
            this.chkPedDetect6.AutoSize = true;
            this.chkPedDetect6.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chkPedDetect6.Location = new System.Drawing.Point(246, 81);
            this.chkPedDetect6.Name = "chkPedDetect6";
            this.chkPedDetect6.Size = new System.Drawing.Size(15, 14);
            this.chkPedDetect6.TabIndex = 21;
            this.chkPedDetect6.UseVisualStyleBackColor = true;
            // 
            // chkPedDetect5
            // 
            this.chkPedDetect5.AutoSize = true;
            this.chkPedDetect5.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chkPedDetect5.Location = new System.Drawing.Point(214, 81);
            this.chkPedDetect5.Name = "chkPedDetect5";
            this.chkPedDetect5.Size = new System.Drawing.Size(15, 14);
            this.chkPedDetect5.TabIndex = 20;
            this.chkPedDetect5.UseVisualStyleBackColor = true;
            // 
            // chkPedDetect4
            // 
            this.chkPedDetect4.AutoSize = true;
            this.chkPedDetect4.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chkPedDetect4.Location = new System.Drawing.Point(182, 81);
            this.chkPedDetect4.Name = "chkPedDetect4";
            this.chkPedDetect4.Size = new System.Drawing.Size(15, 14);
            this.chkPedDetect4.TabIndex = 19;
            this.chkPedDetect4.UseVisualStyleBackColor = true;
            // 
            // chkPedDetect3
            // 
            this.chkPedDetect3.AutoSize = true;
            this.chkPedDetect3.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chkPedDetect3.Location = new System.Drawing.Point(152, 81);
            this.chkPedDetect3.Name = "chkPedDetect3";
            this.chkPedDetect3.Size = new System.Drawing.Size(15, 14);
            this.chkPedDetect3.TabIndex = 18;
            this.chkPedDetect3.UseVisualStyleBackColor = true;
            // 
            // chkPedDetect2
            // 
            this.chkPedDetect2.AutoSize = true;
            this.chkPedDetect2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chkPedDetect2.Location = new System.Drawing.Point(124, 81);
            this.chkPedDetect2.Name = "chkPedDetect2";
            this.chkPedDetect2.Size = new System.Drawing.Size(15, 14);
            this.chkPedDetect2.TabIndex = 17;
            this.chkPedDetect2.UseVisualStyleBackColor = true;
            // 
            // chkPedDetect1
            // 
            this.chkPedDetect1.AutoSize = true;
            this.chkPedDetect1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chkPedDetect1.Location = new System.Drawing.Point(94, 81);
            this.chkPedDetect1.Name = "chkPedDetect1";
            this.chkPedDetect1.Size = new System.Drawing.Size(15, 14);
            this.chkPedDetect1.TabIndex = 16;
            this.chkPedDetect1.UseVisualStyleBackColor = true;
            // 
            // chkPedCall16
            // 
            this.chkPedCall16.AutoSize = true;
            this.chkPedCall16.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chkPedCall16.Location = new System.Drawing.Point(568, 53);
            this.chkPedCall16.Name = "chkPedCall16";
            this.chkPedCall16.Size = new System.Drawing.Size(15, 14);
            this.chkPedCall16.TabIndex = 15;
            this.chkPedCall16.UseVisualStyleBackColor = true;
            // 
            // chkPedCall15
            // 
            this.chkPedCall15.AutoSize = true;
            this.chkPedCall15.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chkPedCall15.Location = new System.Drawing.Point(536, 53);
            this.chkPedCall15.Name = "chkPedCall15";
            this.chkPedCall15.Size = new System.Drawing.Size(15, 14);
            this.chkPedCall15.TabIndex = 14;
            this.chkPedCall15.UseVisualStyleBackColor = true;
            // 
            // chkPedCall14
            // 
            this.chkPedCall14.AutoSize = true;
            this.chkPedCall14.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chkPedCall14.Location = new System.Drawing.Point(502, 53);
            this.chkPedCall14.Name = "chkPedCall14";
            this.chkPedCall14.Size = new System.Drawing.Size(15, 14);
            this.chkPedCall14.TabIndex = 13;
            this.chkPedCall14.UseVisualStyleBackColor = true;
            // 
            // chkPedCall13
            // 
            this.chkPedCall13.AutoSize = true;
            this.chkPedCall13.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chkPedCall13.Location = new System.Drawing.Point(470, 53);
            this.chkPedCall13.Name = "chkPedCall13";
            this.chkPedCall13.Size = new System.Drawing.Size(15, 14);
            this.chkPedCall13.TabIndex = 12;
            this.chkPedCall13.UseVisualStyleBackColor = true;
            // 
            // chkPedCall12
            // 
            this.chkPedCall12.AutoSize = true;
            this.chkPedCall12.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chkPedCall12.Location = new System.Drawing.Point(438, 53);
            this.chkPedCall12.Name = "chkPedCall12";
            this.chkPedCall12.Size = new System.Drawing.Size(15, 14);
            this.chkPedCall12.TabIndex = 11;
            this.chkPedCall12.UseVisualStyleBackColor = true;
            // 
            // chkPedCall11
            // 
            this.chkPedCall11.AutoSize = true;
            this.chkPedCall11.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chkPedCall11.Location = new System.Drawing.Point(408, 53);
            this.chkPedCall11.Name = "chkPedCall11";
            this.chkPedCall11.Size = new System.Drawing.Size(15, 14);
            this.chkPedCall11.TabIndex = 10;
            this.chkPedCall11.UseVisualStyleBackColor = true;
            // 
            // chkPedCall10
            // 
            this.chkPedCall10.AutoSize = true;
            this.chkPedCall10.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chkPedCall10.Location = new System.Drawing.Point(376, 53);
            this.chkPedCall10.Name = "chkPedCall10";
            this.chkPedCall10.Size = new System.Drawing.Size(15, 14);
            this.chkPedCall10.TabIndex = 9;
            this.chkPedCall10.UseVisualStyleBackColor = true;
            // 
            // chkPedCall9
            // 
            this.chkPedCall9.AutoSize = true;
            this.chkPedCall9.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chkPedCall9.Location = new System.Drawing.Point(342, 53);
            this.chkPedCall9.Name = "chkPedCall9";
            this.chkPedCall9.Size = new System.Drawing.Size(15, 14);
            this.chkPedCall9.TabIndex = 8;
            this.chkPedCall9.UseVisualStyleBackColor = true;
            // 
            // chkPedCall8
            // 
            this.chkPedCall8.AutoSize = true;
            this.chkPedCall8.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chkPedCall8.Location = new System.Drawing.Point(310, 53);
            this.chkPedCall8.Name = "chkPedCall8";
            this.chkPedCall8.Size = new System.Drawing.Size(15, 14);
            this.chkPedCall8.TabIndex = 7;
            this.chkPedCall8.UseVisualStyleBackColor = true;
            // 
            // chkPedCall7
            // 
            this.chkPedCall7.AutoSize = true;
            this.chkPedCall7.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chkPedCall7.Location = new System.Drawing.Point(278, 53);
            this.chkPedCall7.Name = "chkPedCall7";
            this.chkPedCall7.Size = new System.Drawing.Size(15, 14);
            this.chkPedCall7.TabIndex = 6;
            this.chkPedCall7.UseVisualStyleBackColor = true;
            // 
            // chkPedCall6
            // 
            this.chkPedCall6.AutoSize = true;
            this.chkPedCall6.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chkPedCall6.Location = new System.Drawing.Point(246, 53);
            this.chkPedCall6.Name = "chkPedCall6";
            this.chkPedCall6.Size = new System.Drawing.Size(15, 14);
            this.chkPedCall6.TabIndex = 5;
            this.chkPedCall6.UseVisualStyleBackColor = true;
            // 
            // chkPedCall5
            // 
            this.chkPedCall5.AutoSize = true;
            this.chkPedCall5.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chkPedCall5.Location = new System.Drawing.Point(214, 53);
            this.chkPedCall5.Name = "chkPedCall5";
            this.chkPedCall5.Size = new System.Drawing.Size(15, 14);
            this.chkPedCall5.TabIndex = 4;
            this.chkPedCall5.UseVisualStyleBackColor = true;
            // 
            // chkPedCall4
            // 
            this.chkPedCall4.AutoSize = true;
            this.chkPedCall4.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chkPedCall4.Location = new System.Drawing.Point(182, 53);
            this.chkPedCall4.Name = "chkPedCall4";
            this.chkPedCall4.Size = new System.Drawing.Size(15, 14);
            this.chkPedCall4.TabIndex = 3;
            this.chkPedCall4.UseVisualStyleBackColor = true;
            // 
            // chkPedCall3
            // 
            this.chkPedCall3.AutoSize = true;
            this.chkPedCall3.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chkPedCall3.Location = new System.Drawing.Point(152, 53);
            this.chkPedCall3.Name = "chkPedCall3";
            this.chkPedCall3.Size = new System.Drawing.Size(15, 14);
            this.chkPedCall3.TabIndex = 2;
            this.chkPedCall3.UseVisualStyleBackColor = true;
            // 
            // chkPedCall2
            // 
            this.chkPedCall2.AutoSize = true;
            this.chkPedCall2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chkPedCall2.Location = new System.Drawing.Point(124, 53);
            this.chkPedCall2.Name = "chkPedCall2";
            this.chkPedCall2.Size = new System.Drawing.Size(15, 14);
            this.chkPedCall2.TabIndex = 1;
            this.chkPedCall2.UseVisualStyleBackColor = true;
            // 
            // chkPedCall1
            // 
            this.chkPedCall1.AutoSize = true;
            this.chkPedCall1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chkPedCall1.Location = new System.Drawing.Point(94, 53);
            this.chkPedCall1.Name = "chkPedCall1";
            this.chkPedCall1.Size = new System.Drawing.Size(15, 14);
            this.chkPedCall1.TabIndex = 0;
            this.chkPedCall1.UseVisualStyleBackColor = true;
            // 
            // btnPedSimulator
            // 
            this.btnPedSimulator.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.btnPedSimulator.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnPedSimulator.Location = new System.Drawing.Point(11, 301);
            this.btnPedSimulator.Name = "btnPedSimulator";
            this.btnPedSimulator.Size = new System.Drawing.Size(104, 107);
            this.btnPedSimulator.TabIndex = 53;
            this.btnPedSimulator.Text = "Show Ped Call/Detect Tester";
            this.btnPedSimulator.UseVisualStyleBackColor = false;
            this.btnPedSimulator.Click += new System.EventHandler(this.btnPedSimulator_Click_1);
            // 
            // tabpgPRG
            // 
            this.tabpgPRG.Controls.Add(this.splitContainer8);
            this.tabpgPRG.Location = new System.Drawing.Point(4, 32);
            this.tabpgPRG.Name = "tabpgPRG";
            this.tabpgPRG.Size = new System.Drawing.Size(1009, 655);
            this.tabpgPRG.TabIndex = 7;
            this.tabpgPRG.Text = "PRG";
            this.tabpgPRG.UseVisualStyleBackColor = true;
            // 
            // splitContainer8
            // 
            this.splitContainer8.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.splitContainer8.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitContainer8.Location = new System.Drawing.Point(0, 0);
            this.splitContainer8.Name = "splitContainer8";
            this.splitContainer8.Orientation = System.Windows.Forms.Orientation.Horizontal;
            // 
            // splitContainer8.Panel1
            // 
            this.splitContainer8.Panel1.Controls.Add(this.lstboxPRG);
            this.splitContainer8.Panel1.Controls.Add(this.chkProgrammedFlash1);
            this.splitContainer8.Panel1.Controls.Add(this.chkCoordinationInTransition1);
            this.splitContainer8.Panel1.Controls.Add(this.chkCoordination1);
            this.splitContainer8.Panel1.Controls.Add(this.chkTSP1);
            this.splitContainer8.Panel1.Controls.Add(this.chkPreempt1);
            this.splitContainer8.Panel1.Controls.Add(this.chkFaultFlash1);
            this.splitContainer8.Panel1.Controls.Add(this.chkStopTime1);
            this.splitContainer8.Panel1.Controls.Add(this.chkManualControl1);
            // 
            // splitContainer8.Panel2
            // 
            this.splitContainer8.Panel2.Controls.Add(this.splitContainer9);
            this.splitContainer8.Size = new System.Drawing.Size(1009, 655);
            this.splitContainer8.SplitterDistance = 219;
            this.splitContainer8.SplitterWidth = 10;
            this.splitContainer8.TabIndex = 0;
            // 
            // lstboxPRG
            // 
            this.lstboxPRG.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lstboxPRG.FormattingEnabled = true;
            this.lstboxPRG.ItemHeight = 16;
            this.lstboxPRG.Location = new System.Drawing.Point(256, 3);
            this.lstboxPRG.Name = "lstboxPRG";
            this.lstboxPRG.ScrollAlwaysVisible = true;
            this.lstboxPRG.Size = new System.Drawing.Size(784, 228);
            this.lstboxPRG.TabIndex = 142;
            // 
            // chkProgrammedFlash1
            // 
            this.chkProgrammedFlash1.AutoSize = true;
            this.chkProgrammedFlash1.BackColor = System.Drawing.Color.LightGray;
            this.chkProgrammedFlash1.Location = new System.Drawing.Point(18, 204);
            this.chkProgrammedFlash1.Name = "chkProgrammedFlash1";
            this.chkProgrammedFlash1.Size = new System.Drawing.Size(232, 24);
            this.chkProgrammedFlash1.TabIndex = 141;
            this.chkProgrammedFlash1.Text = "Programmed Flash Active";
            this.chkProgrammedFlash1.UseVisualStyleBackColor = false;
            // 
            // chkCoordinationInTransition1
            // 
            this.chkCoordinationInTransition1.AutoSize = true;
            this.chkCoordinationInTransition1.BackColor = System.Drawing.Color.LightGray;
            this.chkCoordinationInTransition1.Enabled = false;
            this.chkCoordinationInTransition1.Location = new System.Drawing.Point(18, 177);
            this.chkCoordinationInTransition1.Name = "chkCoordinationInTransition1";
            this.chkCoordinationInTransition1.Size = new System.Drawing.Size(206, 24);
            this.chkCoordinationInTransition1.TabIndex = 140;
            this.chkCoordinationInTransition1.Text = "Coord In Trans. Active";
            this.chkCoordinationInTransition1.UseVisualStyleBackColor = false;
            // 
            // chkCoordination1
            // 
            this.chkCoordination1.AutoSize = true;
            this.chkCoordination1.BackColor = System.Drawing.Color.LightGray;
            this.chkCoordination1.Enabled = false;
            this.chkCoordination1.Location = new System.Drawing.Point(18, 148);
            this.chkCoordination1.Name = "chkCoordination1";
            this.chkCoordination1.Size = new System.Drawing.Size(130, 24);
            this.chkCoordination1.TabIndex = 139;
            this.chkCoordination1.Text = "Coord Active";
            this.chkCoordination1.UseVisualStyleBackColor = false;
            // 
            // chkTSP1
            // 
            this.chkTSP1.AutoSize = true;
            this.chkTSP1.BackColor = System.Drawing.Color.LightGray;
            this.chkTSP1.Enabled = false;
            this.chkTSP1.Location = new System.Drawing.Point(18, 119);
            this.chkTSP1.Name = "chkTSP1";
            this.chkTSP1.Size = new System.Drawing.Size(115, 24);
            this.chkTSP1.TabIndex = 138;
            this.chkTSP1.Text = "TSP Active";
            this.chkTSP1.UseVisualStyleBackColor = false;
            // 
            // chkPreempt1
            // 
            this.chkPreempt1.AutoSize = true;
            this.chkPreempt1.BackColor = System.Drawing.Color.LightGray;
            this.chkPreempt1.Location = new System.Drawing.Point(18, 90);
            this.chkPreempt1.Name = "chkPreempt1";
            this.chkPreempt1.Size = new System.Drawing.Size(149, 24);
            this.chkPreempt1.TabIndex = 137;
            this.chkPreempt1.Text = "Preempt Active";
            this.chkPreempt1.UseVisualStyleBackColor = false;
            // 
            // chkFaultFlash1
            // 
            this.chkFaultFlash1.AutoSize = true;
            this.chkFaultFlash1.BackColor = System.Drawing.Color.LightGray;
            this.chkFaultFlash1.Location = new System.Drawing.Point(18, 61);
            this.chkFaultFlash1.Name = "chkFaultFlash1";
            this.chkFaultFlash1.Size = new System.Drawing.Size(172, 24);
            this.chkFaultFlash1.TabIndex = 136;
            this.chkFaultFlash1.Text = "Fault Flash Active";
            this.chkFaultFlash1.UseVisualStyleBackColor = false;
            // 
            // chkStopTime1
            // 
            this.chkStopTime1.AutoSize = true;
            this.chkStopTime1.BackColor = System.Drawing.Color.LightGray;
            this.chkStopTime1.Location = new System.Drawing.Point(18, 32);
            this.chkStopTime1.Name = "chkStopTime1";
            this.chkStopTime1.Size = new System.Drawing.Size(163, 24);
            this.chkStopTime1.TabIndex = 135;
            this.chkStopTime1.Text = "Stop Time Active";
            this.chkStopTime1.UseVisualStyleBackColor = false;
            // 
            // chkManualControl1
            // 
            this.chkManualControl1.AutoSize = true;
            this.chkManualControl1.BackColor = System.Drawing.Color.LightGray;
            this.chkManualControl1.Location = new System.Drawing.Point(18, 3);
            this.chkManualControl1.Name = "chkManualControl1";
            this.chkManualControl1.Size = new System.Drawing.Size(203, 24);
            this.chkManualControl1.TabIndex = 134;
            this.chkManualControl1.Text = "Manual Control Active";
            this.chkManualControl1.UseVisualStyleBackColor = false;
            // 
            // splitContainer9
            // 
            this.splitContainer9.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.splitContainer9.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitContainer9.Location = new System.Drawing.Point(0, 0);
            this.splitContainer9.Name = "splitContainer9";
            this.splitContainer9.Orientation = System.Windows.Forms.Orientation.Horizontal;
            // 
            // splitContainer9.Panel1
            // 
            this.splitContainer9.Panel1.Controls.Add(this.txtPRGActivity);
            // 
            // splitContainer9.Panel2
            // 
            this.splitContainer9.Panel2.Controls.Add(this.txtSSMActivity);
            this.splitContainer9.Size = new System.Drawing.Size(1009, 426);
            this.splitContainer9.SplitterDistance = 208;
            this.splitContainer9.SplitterWidth = 10;
            this.splitContainer9.TabIndex = 1;
            // 
            // txtPRGActivity
            // 
            this.txtPRGActivity.Dock = System.Windows.Forms.DockStyle.Fill;
            this.txtPRGActivity.Location = new System.Drawing.Point(0, 0);
            this.txtPRGActivity.Multiline = true;
            this.txtPRGActivity.Name = "txtPRGActivity";
            this.txtPRGActivity.ScrollBars = System.Windows.Forms.ScrollBars.Both;
            this.txtPRGActivity.Size = new System.Drawing.Size(1005, 204);
            this.txtPRGActivity.TabIndex = 0;
            // 
            // txtSSMActivity
            // 
            this.txtSSMActivity.Dock = System.Windows.Forms.DockStyle.Fill;
            this.txtSSMActivity.Location = new System.Drawing.Point(0, 0);
            this.txtSSMActivity.Multiline = true;
            this.txtSSMActivity.Name = "txtSSMActivity";
            this.txtSSMActivity.ScrollBars = System.Windows.Forms.ScrollBars.Both;
            this.txtSSMActivity.Size = new System.Drawing.Size(1005, 204);
            this.txtSSMActivity.TabIndex = 0;
            // 
            // tabpgPriorityStrategies
            // 
            this.tabpgPriorityStrategies.Controls.Add(this.splitContainer10);
            this.tabpgPriorityStrategies.Location = new System.Drawing.Point(4, 32);
            this.tabpgPriorityStrategies.Name = "tabpgPriorityStrategies";
            this.tabpgPriorityStrategies.Size = new System.Drawing.Size(1009, 655);
            this.tabpgPriorityStrategies.TabIndex = 9;
            this.tabpgPriorityStrategies.Text = "Priority Strategies";
            this.tabpgPriorityStrategies.UseVisualStyleBackColor = true;
            // 
            // splitContainer10
            // 
            this.splitContainer10.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitContainer10.Location = new System.Drawing.Point(0, 0);
            this.splitContainer10.Name = "splitContainer10";
            // 
            // splitContainer10.Panel1
            // 
            this.splitContainer10.Panel1.Controls.Add(this.button4);
            this.splitContainer10.Panel1.Controls.Add(this.label74);
            this.splitContainer10.Panel1.Controls.Add(this.textBox14);
            this.splitContainer10.Panel1.Controls.Add(this.label73);
            this.splitContainer10.Panel1.Controls.Add(this.label72);
            this.splitContainer10.Panel1.Controls.Add(this.label71);
            this.splitContainer10.Panel1.Controls.Add(this.label70);
            this.splitContainer10.Panel1.Controls.Add(this.comboBox12);
            this.splitContainer10.Panel1.Controls.Add(this.comboBox9);
            this.splitContainer10.Panel1.Controls.Add(this.comboBox4);
            this.splitContainer10.Panel1.Controls.Add(this.textBox13);
            // 
            // splitContainer10.Panel2
            // 
            this.splitContainer10.Panel2.Controls.Add(this.splitContainer11);
            this.splitContainer10.Size = new System.Drawing.Size(1009, 655);
            this.splitContainer10.SplitterDistance = 547;
            this.splitContainer10.TabIndex = 0;
            // 
            // button4
            // 
            this.button4.Location = new System.Drawing.Point(143, 284);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(195, 35);
            this.button4.TabIndex = 10;
            this.button4.Text = "Add Priority Strategy";
            this.button4.UseVisualStyleBackColor = true;
            // 
            // label74
            // 
            this.label74.AutoSize = true;
            this.label74.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.label74.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.label74.Location = new System.Drawing.Point(11, 235);
            this.label74.Name = "label74";
            this.label74.Size = new System.Drawing.Size(204, 20);
            this.label74.TabIndex = 9;
            this.label74.Text = "Priority Strategy Number";
            // 
            // textBox14
            // 
            this.textBox14.Location = new System.Drawing.Point(217, 232);
            this.textBox14.Name = "textBox14";
            this.textBox14.Size = new System.Drawing.Size(121, 26);
            this.textBox14.TabIndex = 8;
            // 
            // label73
            // 
            this.label73.AutoSize = true;
            this.label73.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.label73.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.label73.Location = new System.Drawing.Point(139, 183);
            this.label73.Name = "label73";
            this.label73.Size = new System.Drawing.Size(76, 20);
            this.label73.TabIndex = 7;
            this.label73.Text = "Preempt";
            // 
            // label72
            // 
            this.label72.AutoSize = true;
            this.label72.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.label72.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.label72.Location = new System.Drawing.Point(51, 126);
            this.label72.Name = "label72";
            this.label72.Size = new System.Drawing.Size(164, 20);
            this.label72.TabIndex = 6;
            this.label72.Text = "Vehicle Class Level";
            // 
            // label71
            // 
            this.label71.AutoSize = true;
            this.label71.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.label71.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.label71.Location = new System.Drawing.Point(55, 73);
            this.label71.Name = "label71";
            this.label71.Size = new System.Drawing.Size(160, 20);
            this.label71.TabIndex = 5;
            this.label71.Text = "Vehicle Class Type";
            // 
            // label70
            // 
            this.label70.AutoSize = true;
            this.label70.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.label70.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.label70.Location = new System.Drawing.Point(135, 21);
            this.label70.Name = "label70";
            this.label70.Size = new System.Drawing.Size(80, 20);
            this.label70.TabIndex = 4;
            this.label70.Text = "In-Lanes";
            // 
            // comboBox12
            // 
            this.comboBox12.FormattingEnabled = true;
            this.comboBox12.Location = new System.Drawing.Point(217, 179);
            this.comboBox12.Name = "comboBox12";
            this.comboBox12.Size = new System.Drawing.Size(121, 28);
            this.comboBox12.TabIndex = 3;
            // 
            // comboBox9
            // 
            this.comboBox9.FormattingEnabled = true;
            this.comboBox9.Location = new System.Drawing.Point(217, 122);
            this.comboBox9.Name = "comboBox9";
            this.comboBox9.Size = new System.Drawing.Size(121, 28);
            this.comboBox9.TabIndex = 2;
            // 
            // comboBox4
            // 
            this.comboBox4.FormattingEnabled = true;
            this.comboBox4.Location = new System.Drawing.Point(217, 69);
            this.comboBox4.Name = "comboBox4";
            this.comboBox4.Size = new System.Drawing.Size(121, 28);
            this.comboBox4.TabIndex = 1;
            // 
            // textBox13
            // 
            this.textBox13.Location = new System.Drawing.Point(217, 18);
            this.textBox13.Name = "textBox13";
            this.textBox13.Size = new System.Drawing.Size(121, 26);
            this.textBox13.TabIndex = 0;
            // 
            // splitContainer11
            // 
            this.splitContainer11.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitContainer11.Location = new System.Drawing.Point(0, 0);
            this.splitContainer11.Name = "splitContainer11";
            this.splitContainer11.Orientation = System.Windows.Forms.Orientation.Horizontal;
            // 
            // splitContainer11.Panel1
            // 
            this.splitContainer11.Panel1.Controls.Add(this.checkedListBox1);
            // 
            // splitContainer11.Panel2
            // 
            this.splitContainer11.Panel2.Controls.Add(this.button6);
            this.splitContainer11.Panel2.Controls.Add(this.button5);
            this.splitContainer11.Size = new System.Drawing.Size(458, 655);
            this.splitContainer11.SplitterDistance = 593;
            this.splitContainer11.TabIndex = 1;
            // 
            // checkedListBox1
            // 
            this.checkedListBox1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.checkedListBox1.FormattingEnabled = true;
            this.checkedListBox1.HorizontalScrollbar = true;
            this.checkedListBox1.Location = new System.Drawing.Point(0, 0);
            this.checkedListBox1.Name = "checkedListBox1";
            this.checkedListBox1.ScrollAlwaysVisible = true;
            this.checkedListBox1.Size = new System.Drawing.Size(458, 593);
            this.checkedListBox1.TabIndex = 0;
            // 
            // button6
            // 
            this.button6.Location = new System.Drawing.Point(250, 8);
            this.button6.Name = "button6";
            this.button6.Size = new System.Drawing.Size(221, 40);
            this.button6.TabIndex = 1;
            this.button6.Text = "Save Priority Strategies";
            this.button6.UseVisualStyleBackColor = true;
            // 
            // button5
            // 
            this.button5.Location = new System.Drawing.Point(12, 8);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(232, 40);
            this.button5.TabIndex = 0;
            this.button5.Text = "Delete Priority Strategies";
            this.button5.UseVisualStyleBackColor = true;
            // 
            // tmrUDPClient
            // 
            this.tmrUDPClient.Tick += new System.EventHandler(this.tmrUDPClient_Tick);
            // 
            // folderBrowserDialog1
            // 
            this.folderBrowserDialog1.HelpRequest += new System.EventHandler(this.folderBrowserDialog1_HelpRequest);
            // 
            // spGPS
            // 
            this.spGPS.BaudRate = 4800;
            this.spGPS.PortName = "COM0";
            // 
            // tmrGPS
            // 
            this.tmrGPS.Interval = 60000;
            this.tmrGPS.Tick += new System.EventHandler(this.tmrGPS_Tick);
            // 
            // tmrSRM
            // 
            this.tmrSRM.Interval = 1000;
            this.tmrSRM.Tick += new System.EventHandler(this.tmrSRM_Tick);
            // 
            // openFileDialog1
            // 
            this.openFileDialog1.DefaultExt = "*.ptlm";
            this.openFileDialog1.FileName = "openFileDialog1";
            this.openFileDialog1.Filter = "PTLM Files|*.xml";
            this.openFileDialog1.RestoreDirectory = true;
            this.openFileDialog1.SupportMultiDottedExtensions = true;
            this.openFileDialog1.Title = "Select the Phase-to-Lane Movement Mapping File";
            // 
            // frmMain
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1017, 691);
            this.Controls.Add(this.tabCntrlSAPTSystem);
            this.Name = "frmMain";
            this.Text = "Signal Phase and Timing (SPaT) System";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.frmMain_FormClosing);
            this.Load += new System.EventHandler(this.frmMain_Load);
            this.tabCntrlSAPTSystem.ResumeLayout(false);
            this.tabpgSPATMsg.ResumeLayout(false);
            this.tabpgSPATMsg.PerformLayout();
            this.grpStatusDisplay.ResumeLayout(false);
            this.grpStatusDisplay.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.axaxNtcipIO1)).EndInit();
            this.tabpgActivityLog.ResumeLayout(false);
            this.splitContainer1.Panel1.ResumeLayout(false);
            this.splitContainer1.Panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer1)).EndInit();
            this.splitContainer1.ResumeLayout(false);
            this.splitContainer2.Panel1.ResumeLayout(false);
            this.splitContainer2.Panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer2)).EndInit();
            this.splitContainer2.ResumeLayout(false);
            this.splitContainer3.Panel1.ResumeLayout(false);
            this.splitContainer3.Panel2.ResumeLayout(false);
            this.splitContainer3.Panel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer3)).EndInit();
            this.splitContainer3.ResumeLayout(false);
            this.splitContainer4.Panel1.ResumeLayout(false);
            this.splitContainer4.Panel2.ResumeLayout(false);
            this.splitContainer4.Panel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer4)).EndInit();
            this.splitContainer4.ResumeLayout(false);
            this.splitContainer5.Panel1.ResumeLayout(false);
            this.splitContainer5.Panel2.ResumeLayout(false);
            this.splitContainer5.Panel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer5)).EndInit();
            this.splitContainer5.ResumeLayout(false);
            this.tabpgEnableSPATMsgPush.ResumeLayout(false);
            this.splitContainer7.Panel1.ResumeLayout(false);
            this.splitContainer7.Panel2.ResumeLayout(false);
            this.splitContainer7.Panel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer7)).EndInit();
            this.splitContainer7.ResumeLayout(false);
            this.groupBox5.ResumeLayout(false);
            this.groupBox5.PerformLayout();
            this.groupBox8.ResumeLayout(false);
            this.groupBox8.PerformLayout();
            this.tabpgGPS.ResumeLayout(false);
            this.tabpgGPS.PerformLayout();
            this.splitContainer6.Panel1.ResumeLayout(false);
            this.splitContainer6.Panel1.PerformLayout();
            this.splitContainer6.Panel2.ResumeLayout(false);
            this.splitContainer6.Panel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer6)).EndInit();
            this.splitContainer6.ResumeLayout(false);
            this.tabpgSPATConfiguration.ResumeLayout(false);
            this.pnlSPATConfiguration.ResumeLayout(false);
            this.pnlSPATConfiguration.PerformLayout();
            this.groupBox6.ResumeLayout(false);
            this.groupBox6.PerformLayout();
            this.gbPortSettings.ResumeLayout(false);
            this.gbPortSettings.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            this.groupBox9.ResumeLayout(false);
            this.groupBox9.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.groupBox4.ResumeLayout(false);
            this.groupBox4.PerformLayout();
            this.tabpgPeds.ResumeLayout(false);
            this.tabpgPeds.PerformLayout();
            this.groupBox12.ResumeLayout(false);
            this.groupBox12.PerformLayout();
            this.groupBox11.ResumeLayout(false);
            this.groupBox11.PerformLayout();
            this.groupBox10.ResumeLayout(false);
            this.groupBox10.PerformLayout();
            this.groupBox7.ResumeLayout(false);
            this.groupBox7.PerformLayout();
            this.grpPedSimulator.ResumeLayout(false);
            this.grpPedSimulator.PerformLayout();
            this.tabpgPRG.ResumeLayout(false);
            this.splitContainer8.Panel1.ResumeLayout(false);
            this.splitContainer8.Panel1.PerformLayout();
            this.splitContainer8.Panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer8)).EndInit();
            this.splitContainer8.ResumeLayout(false);
            this.splitContainer9.Panel1.ResumeLayout(false);
            this.splitContainer9.Panel1.PerformLayout();
            this.splitContainer9.Panel2.ResumeLayout(false);
            this.splitContainer9.Panel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer9)).EndInit();
            this.splitContainer9.ResumeLayout(false);
            this.tabpgPriorityStrategies.ResumeLayout(false);
            this.splitContainer10.Panel1.ResumeLayout(false);
            this.splitContainer10.Panel1.PerformLayout();
            this.splitContainer10.Panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer10)).EndInit();
            this.splitContainer10.ResumeLayout(false);
            this.splitContainer11.Panel1.ResumeLayout(false);
            this.splitContainer11.Panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer11)).EndInit();
            this.splitContainer11.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TabControl tabCntrlSAPTSystem;
        private System.Windows.Forms.TabPage tabpgSPATMsg;
        private System.Windows.Forms.TabPage tabpgActivityLog;
        private System.Windows.Forms.GroupBox grpStatusDisplay;
        private System.Windows.Forms.TextBox txtSysTime;
        private System.Windows.Forms.Label label41;
        private System.Windows.Forms.TextBox txtPed2;
        private System.Windows.Forms.TextBox txtPed1;
        private System.Windows.Forms.TextBox txtPed16;
        private System.Windows.Forms.TextBox txtPed3;
        private System.Windows.Forms.TextBox txtPed15;
        private System.Windows.Forms.TextBox txtPed4;
        private System.Windows.Forms.TextBox txtPed14;
        private System.Windows.Forms.TextBox txtPed5;
        private System.Windows.Forms.TextBox txtPed13;
        private System.Windows.Forms.TextBox txtPed6;
        private System.Windows.Forms.TextBox txtPed12;
        private System.Windows.Forms.TextBox txtPed7;
        private System.Windows.Forms.TextBox txtPed11;
        private System.Windows.Forms.TextBox txtPed8;
        private System.Windows.Forms.TextBox txtPed10;
        private System.Windows.Forms.TextBox txtPed9;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.TextBox txtOMaxTime2;
        private System.Windows.Forms.TextBox txtOMaxTime16;
        private System.Windows.Forms.TextBox txtOMaxTime15;
        private System.Windows.Forms.TextBox txtOMaxTime14;
        private System.Windows.Forms.TextBox txtOMaxTime13;
        private System.Windows.Forms.TextBox txtOMaxTime12;
        private System.Windows.Forms.TextBox txtOMaxTime11;
        private System.Windows.Forms.TextBox txtOMaxTime10;
        private System.Windows.Forms.TextBox txtOMaxTime9;
        private System.Windows.Forms.TextBox txtOMaxTime8;
        private System.Windows.Forms.TextBox txtOMaxTime7;
        private System.Windows.Forms.TextBox txtOMaxTime6;
        private System.Windows.Forms.TextBox txtOMaxTime5;
        private System.Windows.Forms.TextBox txtOMaxTime4;
        private System.Windows.Forms.TextBox txtOMaxTime3;
        private System.Windows.Forms.TextBox txtOMaxTime1;
        private System.Windows.Forms.TextBox txtOMinTime2;
        private System.Windows.Forms.TextBox txtOMinTime16;
        private System.Windows.Forms.TextBox txtOMinTime15;
        private System.Windows.Forms.TextBox txtOMinTime14;
        private System.Windows.Forms.TextBox txtOMinTime13;
        private System.Windows.Forms.TextBox txtOMinTime12;
        private System.Windows.Forms.TextBox txtOMinTime11;
        private System.Windows.Forms.TextBox txtOMinTime10;
        private System.Windows.Forms.TextBox txtOMinTime9;
        private System.Windows.Forms.TextBox txtOMinTime8;
        private System.Windows.Forms.TextBox txtOMinTime7;
        private System.Windows.Forms.TextBox txtOMinTime6;
        private System.Windows.Forms.TextBox txtOMinTime5;
        private System.Windows.Forms.TextBox txtOMinTime4;
        private System.Windows.Forms.TextBox txtOMinTime3;
        private System.Windows.Forms.Label label27;
        private System.Windows.Forms.TextBox txtOMinTime1;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.TextBox txtPMaxTime2;
        private System.Windows.Forms.TextBox txtPMaxTime16;
        private System.Windows.Forms.TextBox txtPMaxTime15;
        private System.Windows.Forms.TextBox txtPMaxTime14;
        private System.Windows.Forms.TextBox txtPMaxTime13;
        private System.Windows.Forms.TextBox txtPMaxTime12;
        private System.Windows.Forms.TextBox txtPMaxTime11;
        private System.Windows.Forms.TextBox txtPMaxTime10;
        private System.Windows.Forms.TextBox txtPMaxTime9;
        private System.Windows.Forms.TextBox txtPMaxTime8;
        private System.Windows.Forms.TextBox txtPMaxTime7;
        private System.Windows.Forms.TextBox txtPMaxTime6;
        private System.Windows.Forms.TextBox txtPMaxTime5;
        private System.Windows.Forms.TextBox txtPMaxTime4;
        private System.Windows.Forms.TextBox txtPMaxTime3;
        private System.Windows.Forms.TextBox txtPMaxTime1;
        private System.Windows.Forms.TextBox txtPMinTime2;
        private System.Windows.Forms.TextBox txtPMinTime16;
        private System.Windows.Forms.TextBox txtPMinTime15;
        private System.Windows.Forms.TextBox txtPMinTime14;
        private System.Windows.Forms.TextBox txtPMinTime13;
        private System.Windows.Forms.TextBox txtPMinTime12;
        private System.Windows.Forms.TextBox txtPMinTime11;
        private System.Windows.Forms.TextBox txtPMinTime10;
        private System.Windows.Forms.TextBox txtPMinTime9;
        private System.Windows.Forms.TextBox txtPMinTime8;
        private System.Windows.Forms.TextBox txtPMinTime7;
        private System.Windows.Forms.TextBox txtPMinTime6;
        private System.Windows.Forms.TextBox txtPMinTime5;
        private System.Windows.Forms.TextBox txtPMinTime4;
        private System.Windows.Forms.TextBox txtPMinTime3;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.TextBox txtPMinTime1;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.TextBox txtVMaxTime2;
        private System.Windows.Forms.TextBox txtVMaxTime16;
        private System.Windows.Forms.TextBox txtVMaxTime15;
        private System.Windows.Forms.TextBox txtVMaxTime14;
        private System.Windows.Forms.TextBox txtVMaxTime13;
        private System.Windows.Forms.TextBox txtVMaxTime12;
        private System.Windows.Forms.TextBox txtVMaxTime11;
        private System.Windows.Forms.TextBox txtVMaxTime10;
        private System.Windows.Forms.TextBox txtVMaxTime9;
        private System.Windows.Forms.TextBox txtVMaxTime8;
        private System.Windows.Forms.TextBox txtVMaxTime7;
        private System.Windows.Forms.TextBox txtVMaxTime6;
        private System.Windows.Forms.TextBox txtVMaxTime5;
        private System.Windows.Forms.TextBox txtVMaxTime4;
        private System.Windows.Forms.TextBox txtVMaxTime3;
        private System.Windows.Forms.TextBox txtVMaxTime1;
        private System.Windows.Forms.TextBox txtVMinTime2;
        private System.Windows.Forms.TextBox txtVMinTime16;
        private System.Windows.Forms.TextBox txtVMinTime15;
        private System.Windows.Forms.TextBox txtVMinTime14;
        private System.Windows.Forms.TextBox txtVMinTime13;
        private System.Windows.Forms.TextBox txtVMinTime12;
        private System.Windows.Forms.TextBox txtVMinTime11;
        private System.Windows.Forms.TextBox txtVMinTime10;
        private System.Windows.Forms.TextBox txtVMinTime9;
        private System.Windows.Forms.TextBox txtVMinTime8;
        private System.Windows.Forms.TextBox txtVMinTime7;
        private System.Windows.Forms.TextBox txtVMinTime6;
        private System.Windows.Forms.TextBox txtVMinTime5;
        private System.Windows.Forms.TextBox txtVMinTime4;
        private System.Windows.Forms.TextBox txtVMinTime3;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.TextBox txtVMinTime1;
        private System.Windows.Forms.Label label34;
        private System.Windows.Forms.Label label33;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Timer tmrUDPClient;
        private AxaxNtcipIOControl.AxaxNtcipIO axaxNtcipIO1;
        private System.Windows.Forms.SplitContainer splitContainer1;
        private System.Windows.Forms.SplitContainer splitContainer2;
        private System.Windows.Forms.TextBox txtTSCLog;
        private System.Windows.Forms.TextBox txtSPATMsgLog;
        private System.Windows.Forms.TextBox txtActivityLog;
        private System.Windows.Forms.SplitContainer splitContainer3;
        private System.Windows.Forms.Label label100;
        private System.Windows.Forms.SplitContainer splitContainer4;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.SplitContainer splitContainer5;
        private System.Windows.Forms.Label lblControllerConnection;
        private System.Windows.Forms.TabPage tabpgSPATConfiguration;
        private System.Windows.Forms.Panel pnlSPATConfiguration;
        private System.Windows.Forms.TextBox txtSPATSystemIPV4Address;
        private System.Windows.Forms.Button btnSaveSPATConfiguration;
        private Microsoft.VisualBasic.PowerPacks.ShapeContainer shapeContainer1;
        private Microsoft.VisualBasic.PowerPacks.OvalShape shpPed1;
        private Microsoft.VisualBasic.PowerPacks.OvalShape shpPed2;
        private Microsoft.VisualBasic.PowerPacks.OvalShape shpPed3;
        private Microsoft.VisualBasic.PowerPacks.OvalShape shpPed4;
        private Microsoft.VisualBasic.PowerPacks.OvalShape shpPed5;
        private Microsoft.VisualBasic.PowerPacks.OvalShape shpPed6;
        private Microsoft.VisualBasic.PowerPacks.OvalShape shpPed7;
        private Microsoft.VisualBasic.PowerPacks.OvalShape shpPed8;
        private Microsoft.VisualBasic.PowerPacks.OvalShape shpPed9;
        private Microsoft.VisualBasic.PowerPacks.OvalShape shpPed10;
        private Microsoft.VisualBasic.PowerPacks.OvalShape shpPed11;
        private Microsoft.VisualBasic.PowerPacks.OvalShape shpPed12;
        private Microsoft.VisualBasic.PowerPacks.OvalShape shpPed13;
        private Microsoft.VisualBasic.PowerPacks.OvalShape shpPed14;
        private Microsoft.VisualBasic.PowerPacks.OvalShape shpPed15;
        private Microsoft.VisualBasic.PowerPacks.OvalShape shpPed16;
        private Microsoft.VisualBasic.PowerPacks.OvalShape shpPhase16;
        private Microsoft.VisualBasic.PowerPacks.OvalShape shpPhase15;
        private Microsoft.VisualBasic.PowerPacks.OvalShape shpPhase14;
        private Microsoft.VisualBasic.PowerPacks.OvalShape shpPhase13;
        private Microsoft.VisualBasic.PowerPacks.OvalShape shpPhase12;
        private Microsoft.VisualBasic.PowerPacks.OvalShape shpPhase11;
        private Microsoft.VisualBasic.PowerPacks.OvalShape shpPhase10;
        private Microsoft.VisualBasic.PowerPacks.OvalShape shpPhase9;
        private Microsoft.VisualBasic.PowerPacks.OvalShape shpPhase8;
        private Microsoft.VisualBasic.PowerPacks.OvalShape shpPhase7;
        private Microsoft.VisualBasic.PowerPacks.OvalShape shpPhase6;
        private Microsoft.VisualBasic.PowerPacks.OvalShape shpPhase5;
        private Microsoft.VisualBasic.PowerPacks.OvalShape shpPhase4;
        private Microsoft.VisualBasic.PowerPacks.OvalShape shpPhase3;
        private Microsoft.VisualBasic.PowerPacks.OvalShape shpPhase2;
        private Microsoft.VisualBasic.PowerPacks.OvalShape shpPhase1;
        private System.Windows.Forms.TabPage tabpgEnableSPATMsgPush;
        private System.Windows.Forms.SplitContainer splitContainer7;
        private System.Windows.Forms.GroupBox groupBox8;
        private System.Windows.Forms.Label label45;
        private System.Windows.Forms.TextBox txtOIDValue;
        private System.Windows.Forms.Button btnSetOID;
        private System.Windows.Forms.TextBox txtOID;
        private System.Windows.Forms.Label label46;
        private System.Windows.Forms.TextBox txtEnableSPATPush;
        private System.Windows.Forms.TextBox txtDiscontinuousFlag;
        private System.Windows.Forms.CheckBox chkDiscontinuousFlag;
        private System.Windows.Forms.CheckBox chkCoordinationInTransition;
        private System.Windows.Forms.CheckBox chkCoordination;
        private System.Windows.Forms.CheckBox chkTSP;
        private System.Windows.Forms.CheckBox chkPreempt;
        private System.Windows.Forms.CheckBox chkFaultFlash;
        private System.Windows.Forms.CheckBox chkStopTime;
        private System.Windows.Forms.CheckBox chkManualControl;
        private System.Windows.Forms.Label lblTSCMsgNo;
        private System.Windows.Forms.TextBox txtTSCMsgNo;
        private System.Windows.Forms.CheckBox chkProgrammedFlash;
        private System.Windows.Forms.Label label48;
        private System.Windows.Forms.Label lblSysTime;
        private Microsoft.VisualBasic.PowerPacks.OvalShape shpOvlp16;
        private Microsoft.VisualBasic.PowerPacks.OvalShape shpOvlp15;
        private Microsoft.VisualBasic.PowerPacks.OvalShape shpOvlp14;
        private Microsoft.VisualBasic.PowerPacks.OvalShape shpOvlp13;
        private Microsoft.VisualBasic.PowerPacks.OvalShape shpOvlp12;
        private Microsoft.VisualBasic.PowerPacks.OvalShape shpOvlp11;
        private Microsoft.VisualBasic.PowerPacks.OvalShape shpOvlp10;
        private Microsoft.VisualBasic.PowerPacks.OvalShape shpOvlp9;
        private Microsoft.VisualBasic.PowerPacks.OvalShape shpOvlp8;
        private Microsoft.VisualBasic.PowerPacks.OvalShape shpOvlp7;
        private Microsoft.VisualBasic.PowerPacks.OvalShape shpOvlp6;
        private Microsoft.VisualBasic.PowerPacks.OvalShape shpOvlp5;
        private Microsoft.VisualBasic.PowerPacks.OvalShape shpOvlp4;
        private Microsoft.VisualBasic.PowerPacks.OvalShape shpOvlp3;
        private Microsoft.VisualBasic.PowerPacks.OvalShape shpOvlp2;
        private Microsoft.VisualBasic.PowerPacks.OvalShape shpOvlp1;
        private System.Windows.Forms.Label lblOvlp16;
        private System.Windows.Forms.Label lblOvlp15;
        private System.Windows.Forms.Label lblOvlp14;
        private System.Windows.Forms.Label lblOvlp13;
        private System.Windows.Forms.Label lblOvlp12;
        private System.Windows.Forms.Label lblOvlp11;
        private System.Windows.Forms.Label lblOvlp10;
        private System.Windows.Forms.Label lblOvlp9;
        private System.Windows.Forms.Label lblOvlp8;
        private System.Windows.Forms.Label lblOvlp7;
        private System.Windows.Forms.Label lblOvlp6;
        private System.Windows.Forms.Label lblOvlp5;
        private System.Windows.Forms.Label lblOvlp4;
        private System.Windows.Forms.Label lblOvlp3;
        private System.Windows.Forms.Label lblOvlp2;
        private System.Windows.Forms.Label lblOvlp1;
        private System.Windows.Forms.Label lblPhase16;
        private System.Windows.Forms.Label lblPhase15;
        private System.Windows.Forms.Label lblPhase14;
        private System.Windows.Forms.Label lblPhase13;
        private System.Windows.Forms.Label lblPhase12;
        private System.Windows.Forms.Label lblPhase11;
        private System.Windows.Forms.Label lblPhase10;
        private System.Windows.Forms.Label lblPhase9;
        private System.Windows.Forms.Label lblPhase8;
        private System.Windows.Forms.Label lblPhase7;
        private System.Windows.Forms.Label lblPhase6;
        private System.Windows.Forms.Label lblPhase5;
        private System.Windows.Forms.Label lblPhase4;
        private System.Windows.Forms.Label lblPhase3;
        private System.Windows.Forms.Label lblPhase2;
        private System.Windows.Forms.Label lblPhase1;
        private System.Windows.Forms.Button btnExitSPATSystem;
        private System.Windows.Forms.Button btnHaltSPATSystem;
        private System.Windows.Forms.CheckBox chkEnableDisableSPAT;
        private System.Windows.Forms.TextBox txtRSEIPV6Address;
        private System.Windows.Forms.TextBox txtTSCIPV4Address;
        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.Button btnModifySPATMsgDir;
        private System.Windows.Forms.TextBox txtSPATDailyLogFolder;
        private System.Windows.Forms.TextBox txtSPATSystemIPV6Address;
        private System.Windows.Forms.GroupBox groupBox5;
        private System.Windows.Forms.Button btnDisablePreempt3;
        private System.Windows.Forms.Button btnEnablePreempt3;
        private System.Windows.Forms.Button btnDisablePreempt2;
        private System.Windows.Forms.Button btnEnablePreempt2;
        private System.Windows.Forms.Button btnDisablePreempt1;
        private System.Windows.Forms.Button btnEnablePreempt1;
        private System.Windows.Forms.CheckBox chkEnableSpatMessagePush;
        private System.Windows.Forms.FolderBrowserDialog folderBrowserDialog1;
        private System.Windows.Forms.Label label32;
        private System.Windows.Forms.TextBox txtTimeBaseActionStatus;
        private System.Windows.Forms.TabPage tabpgGPS;
        private System.IO.Ports.SerialPort spGPS;
        public System.Windows.Forms.TextBox txtGPSActivity;
        private System.Windows.Forms.Timer tmrGPS;
        private System.Windows.Forms.TabPage tabpgPRG;
        private System.Windows.Forms.SplitContainer splitContainer8;
        private System.Windows.Forms.TextBox txtPRGActivity;
        private System.Windows.Forms.Button btnDisablePreempt6;
        private System.Windows.Forms.Button btnDisablePreempt5;
        private System.Windows.Forms.Button btnDisablePreempt4;
        private System.Windows.Forms.Button btnEnablePreempt6;
        private System.Windows.Forms.Button btnEnablePreempt5;
        private System.Windows.Forms.Button btnEnablePreempt4;
        private System.Windows.Forms.SplitContainer splitContainer9;
        private System.Windows.Forms.TextBox txtSSMActivity;
        private System.Windows.Forms.CheckBox chkProgrammedFlash1;
        private System.Windows.Forms.CheckBox chkCoordinationInTransition1;
        private System.Windows.Forms.CheckBox chkCoordination1;
        private System.Windows.Forms.CheckBox chkTSP1;
        private System.Windows.Forms.CheckBox chkPreempt1;
        private System.Windows.Forms.CheckBox chkFaultFlash1;
        private System.Windows.Forms.CheckBox chkStopTime1;
        private System.Windows.Forms.CheckBox chkManualControl1;
        private System.Windows.Forms.ListBox lstboxPRG;
        private System.Windows.Forms.Timer tmrSRM;
        private System.Windows.Forms.CheckBox chkEnableSSMMessagePush;
        private System.Windows.Forms.TabPage tabpgPriorityStrategies;
        private System.Windows.Forms.CheckBox chkEnableDataLogging;
        private System.Windows.Forms.SplitContainer splitContainer10;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.Label label74;
        private System.Windows.Forms.TextBox textBox14;
        private System.Windows.Forms.Label label73;
        private System.Windows.Forms.Label label72;
        private System.Windows.Forms.Label label71;
        private System.Windows.Forms.Label label70;
        private System.Windows.Forms.ComboBox comboBox12;
        private System.Windows.Forms.ComboBox comboBox9;
        private System.Windows.Forms.ComboBox comboBox4;
        private System.Windows.Forms.TextBox textBox13;
        private System.Windows.Forms.CheckedListBox checkedListBox1;
        private System.Windows.Forms.SplitContainer splitContainer11;
        private System.Windows.Forms.Button button6;
        private System.Windows.Forms.Button button5;
        private System.Windows.Forms.Label lblSysInterval;
        private System.Windows.Forms.TextBox txtSPaTSysInterval;
        private System.Windows.Forms.TextBox txtTSCMsgInterval;
        private System.Windows.Forms.Label lblTSCInterval;
        private System.Windows.Forms.TextBox txtSpatMsgGenerationTime;
        private System.Windows.Forms.Label lblSpatTime;
        private System.Windows.Forms.Label lblTSCTime;
        private System.Windows.Forms.TextBox txtTSCMsgTime;
        private System.Windows.Forms.Button btnHideSysTime;
        private System.Windows.Forms.Button btnHideTSCTime;
        private System.Windows.Forms.TextBox txtSysMsec;
        private System.Windows.Forms.TextBox txtTSCMSec;
        private System.Windows.Forms.Label lblSysMSec;
        private System.Windows.Forms.Label lblTSCMsec;
        private System.Windows.Forms.TextBox txtSysAfterTime;
        private System.Windows.Forms.TextBox txtSysBeforeTime;
        private System.Windows.Forms.TextBox txtGPSLocalTime;
        private System.Windows.Forms.CheckBox chkLaneMvmnt;
        private System.Windows.Forms.CheckBox chkSPaTMsg;
        private System.Windows.Forms.CheckBox chkTSCData;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Button btnSelectPTLMFile;
        private System.Windows.Forms.TextBox txtPTLMFile;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.TextBox txtSpatMsgTargetPort;
        private System.Windows.Forms.TextBox txtSpatMsgLocalPort;
        private System.Windows.Forms.Label label36;
        private System.Windows.Forms.TextBox txtRTCMMsgTargetPort;
        private System.Windows.Forms.Label label37;
        private System.Windows.Forms.TextBox txtRTCMMsgLocalPort;
        private System.Windows.Forms.Label label28;
        private System.Windows.Forms.TextBox txtSSMMsgTargetPort;
        private System.Windows.Forms.Label label29;
        private System.Windows.Forms.TextBox txtSSMMsgLocalPort;
        private System.Windows.Forms.Label label44;
        private System.Windows.Forms.TextBox txtSRMMsgTargetPort;
        private System.Windows.Forms.Label label43;
        private System.Windows.Forms.TextBox txtSRMMsgLocalPort;
        private System.Windows.Forms.Label label42;
        private System.Windows.Forms.TextBox txtMapMsgTargetPort;
        private System.Windows.Forms.Label label40;
        private System.Windows.Forms.TextBox txtMapMsgLocalPort;
        private System.Windows.Forms.Label label39;
        private System.Windows.Forms.Label label38;
        private System.Windows.Forms.Label label35;
        private System.Windows.Forms.Label label31;
        private System.Windows.Forms.TextBox txtSPATSystemSPATPort;
        private System.Windows.Forms.TextBox txtTSCNTCIPPort;
        private System.Windows.Forms.GroupBox groupBox9;
        private System.Windows.Forms.Label label54;
        private System.Windows.Forms.TextBox txtState;
        private System.Windows.Forms.Label label53;
        private System.Windows.Forms.TextBox txtCity;
        private System.Windows.Forms.Label label49;
        private System.Windows.Forms.Label label50;
        private System.Windows.Forms.TextBox txtIntersectionName;
        private System.Windows.Forms.TextBox txtIntersectionID;
        private System.Windows.Forms.Label label30;
        private System.Windows.Forms.Label label51;
        private System.Windows.Forms.Label label47;
        private System.Windows.Forms.GroupBox gbPortSettings;
        private System.Windows.Forms.Label label58;
        private System.Windows.Forms.ComboBox cmbHandShake;
        private System.Windows.Forms.ComboBox cmbPortName;
        private System.Windows.Forms.ComboBox cmbBaudRate;
        private System.Windows.Forms.ComboBox cmbStopBits;
        private System.Windows.Forms.ComboBox cmbParity;
        private System.Windows.Forms.ComboBox cmbDataBits;
        private System.Windows.Forms.Label lblComPort;
        private System.Windows.Forms.Label lblStopBits;
        private System.Windows.Forms.Label lblBaudRate;
        private System.Windows.Forms.Label lblDataBits;
        private System.Windows.Forms.Label label59;
        private System.Windows.Forms.Label label55;
        private System.Windows.Forms.Label label61;
        private System.Windows.Forms.TextBox txtGPSDate;
        private System.Windows.Forms.TextBox txtLon;
        private System.Windows.Forms.TextBox txtLat;
        private System.Windows.Forms.TextBox txtGPSFix;
        private System.Windows.Forms.Label label57;
        private System.Windows.Forms.Label label56;
        private System.Windows.Forms.Label label52;
        private System.Windows.Forms.Label label62;
        private System.Windows.Forms.Label label60;
        private System.Windows.Forms.Label label64;
        private System.Windows.Forms.Label label63;
        private System.Windows.Forms.TextBox txtGPSRawTime;
        private System.Windows.Forms.TextBox txtGPSUTCTime;
        private System.Windows.Forms.Label label65;
        private System.Windows.Forms.TextBox txtSatelliteTime;
        private System.Windows.Forms.Label label66;
        private System.Windows.Forms.TextBox txtNewTime;
        private System.Windows.Forms.Button btnGPSUpdateFrequency;
        private System.Windows.Forms.Label label67;
        private System.Windows.Forms.TextBox txtGPSUpdateFrequency;
        private System.Windows.Forms.Label label68;
        private System.Windows.Forms.CheckBox chkPrmpt6;
        private System.Windows.Forms.CheckBox chkPrmpt5;
        private System.Windows.Forms.CheckBox chkPrmpt4;
        private System.Windows.Forms.CheckBox chkPrmpt3;
        private System.Windows.Forms.CheckBox chkPrmpt2;
        private System.Windows.Forms.CheckBox chkPrmpt1;
        private System.Windows.Forms.OpenFileDialog openFileDialog1;
        private System.Windows.Forms.Label label92;
        private System.Windows.Forms.TextBox txtSPaTPushCode;
        private System.Windows.Forms.Label lblBytesRead;
        private System.Windows.Forms.GroupBox groupBox6;
        private System.Windows.Forms.Label label94;
        private System.Windows.Forms.Label label101;
        private System.Windows.Forms.Label label95;
        private System.Windows.Forms.CheckBox chkPedDetectPhase1;
        private System.Windows.Forms.Label label96;
        private System.Windows.Forms.CheckBox chkPedDetectPhase2;
        private System.Windows.Forms.Label label97;
        private System.Windows.Forms.CheckBox chkPedDetectPhase3;
        private System.Windows.Forms.Label label98;
        private System.Windows.Forms.CheckBox chkPedDetectPhase4;
        private System.Windows.Forms.Label label99;
        private System.Windows.Forms.CheckBox chkPedDetectPhase5;
        private System.Windows.Forms.CheckBox chkPedDetectPhase6;
        private System.Windows.Forms.Label label102;
        private System.Windows.Forms.CheckBox chkPedDetectPhase7;
        private System.Windows.Forms.Label label103;
        private System.Windows.Forms.CheckBox chkPedDetectPhase8;
        private System.Windows.Forms.Label label104;
        private System.Windows.Forms.CheckBox chkPedDetectPhase9;
        private System.Windows.Forms.Label label105;
        private System.Windows.Forms.CheckBox chkPedDetectPhase10;
        private System.Windows.Forms.Label label106;
        private System.Windows.Forms.CheckBox chkPedDetectPhase11;
        private System.Windows.Forms.Label label107;
        private System.Windows.Forms.CheckBox chkPedDetectPhase12;
        private System.Windows.Forms.Label label108;
        private System.Windows.Forms.CheckBox chkPedDetectPhase13;
        private System.Windows.Forms.Label label109;
        private System.Windows.Forms.CheckBox chkPedDetectPhase14;
        private System.Windows.Forms.Label label110;
        private System.Windows.Forms.CheckBox chkPedDetectPhase15;
        private System.Windows.Forms.CheckBox chkPedDetectPhase16;
        private System.Windows.Forms.Label label93;
        private System.Windows.Forms.Button btnQuitSPaTSystem;
        private System.Windows.Forms.SplitContainer splitContainer6;
        private System.Windows.Forms.Label label112;
        private System.Windows.Forms.Label label111;
        private System.Windows.Forms.TextBox txtDiskSpace;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.TabPage tabpgPeds;
        private System.Windows.Forms.GroupBox groupBox12;
        private System.Windows.Forms.Label label127;
        private System.Windows.Forms.TextBox txtMvmntPedDets;
        private System.Windows.Forms.CheckBox chkPedActive;
        private System.Windows.Forms.GroupBox groupBox11;
        private System.Windows.Forms.TextBox txtPedDet;
        private System.Windows.Forms.Label label120;
        private System.Windows.Forms.GroupBox groupBox10;
        private System.Windows.Forms.TextBox txtByte242;
        private System.Windows.Forms.Label label118;
        private System.Windows.Forms.Label label124;
        private System.Windows.Forms.TextBox txtByte241;
        private System.Windows.Forms.TextBox txtBytes241242;
        private System.Windows.Forms.Label label125;
        private System.Windows.Forms.TextBox txtMvmntPedCalls;
        private System.Windows.Forms.Label label126;
        private System.Windows.Forms.GroupBox groupBox7;
        private System.Windows.Forms.TextBox txtByte244;
        private System.Windows.Forms.Label label113;
        private System.Windows.Forms.Label label114;
        private System.Windows.Forms.TextBox txtByte243;
        private System.Windows.Forms.TextBox txtBytes243244;
        private System.Windows.Forms.Label label117;
        private System.Windows.Forms.TextBox txtPedCalls;
        private System.Windows.Forms.Label label119;
        private System.Windows.Forms.TextBox txtNoCalls;
        private System.Windows.Forms.GroupBox grpPedSimulator;
        private System.Windows.Forms.CheckBox chkPedDetect15;
        private System.Windows.Forms.Label label91;
        private System.Windows.Forms.Label label90;
        private System.Windows.Forms.Label label89;
        private System.Windows.Forms.Label label88;
        private System.Windows.Forms.Label label87;
        private System.Windows.Forms.Label label86;
        private System.Windows.Forms.Label label85;
        private System.Windows.Forms.Label label84;
        private System.Windows.Forms.Label label83;
        private System.Windows.Forms.Label label82;
        private System.Windows.Forms.Label label81;
        private System.Windows.Forms.Label label80;
        private System.Windows.Forms.Label label79;
        private System.Windows.Forms.Label label78;
        private System.Windows.Forms.Label label77;
        private System.Windows.Forms.Label label76;
        private System.Windows.Forms.Label label75;
        private System.Windows.Forms.Label label69;
        private System.Windows.Forms.CheckBox chkPedDetect16;
        private System.Windows.Forms.CheckBox chkPedDetect14;
        private System.Windows.Forms.CheckBox chkPedDetect13;
        private System.Windows.Forms.CheckBox chkPedDetect12;
        private System.Windows.Forms.CheckBox chkPedDetect11;
        private System.Windows.Forms.CheckBox chkPedDetect10;
        private System.Windows.Forms.CheckBox chkPedDetect9;
        private System.Windows.Forms.CheckBox chkPedDetect8;
        private System.Windows.Forms.CheckBox chkPedDetect7;
        private System.Windows.Forms.CheckBox chkPedDetect6;
        private System.Windows.Forms.CheckBox chkPedDetect5;
        private System.Windows.Forms.CheckBox chkPedDetect4;
        private System.Windows.Forms.CheckBox chkPedDetect3;
        private System.Windows.Forms.CheckBox chkPedDetect2;
        private System.Windows.Forms.CheckBox chkPedDetect1;
        private System.Windows.Forms.CheckBox chkPedCall16;
        private System.Windows.Forms.CheckBox chkPedCall15;
        private System.Windows.Forms.CheckBox chkPedCall14;
        private System.Windows.Forms.CheckBox chkPedCall13;
        private System.Windows.Forms.CheckBox chkPedCall12;
        private System.Windows.Forms.CheckBox chkPedCall11;
        private System.Windows.Forms.CheckBox chkPedCall10;
        private System.Windows.Forms.CheckBox chkPedCall9;
        private System.Windows.Forms.CheckBox chkPedCall8;
        private System.Windows.Forms.CheckBox chkPedCall7;
        private System.Windows.Forms.CheckBox chkPedCall6;
        private System.Windows.Forms.CheckBox chkPedCall5;
        private System.Windows.Forms.CheckBox chkPedCall4;
        private System.Windows.Forms.CheckBox chkPedCall3;
        private System.Windows.Forms.CheckBox chkPedCall2;
        private System.Windows.Forms.CheckBox chkPedCall1;
        private System.Windows.Forms.Button btnPedSimulator;
    }
}

