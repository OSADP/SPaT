﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace SPaTDemo
{


    public class clsSPAT
    {

        /*public enum spat_intersection_status { manual = 1, stopped = 2, flash = 4, preempt = 8, priority = 16 };
        public enum spat_pedestrian { unavailable = 0, none = 1, oneormore = 2 };
        public enum map_movements { straight = 1, leftturn = 2, rightturn = 4, uturn = 8, softleft = 16, softright = 32, mergeleft = 64, mergeright = 128 };
        
        private const int spat_maxlanes = 10;
        public int SpatMaxlanes
        {
            get { return spat_maxlanes; }
        }
        
        private const int spat_maxmovements = 10;
        public int SpatMaxmovements
        {
            get { return spat_maxmovements; }
        }*/


        /* Common Structures */
        public struct blob
        {
            //unsigned int messageid;
            public UInt16 messageid;
            //unsigned int version;
            public UInt16 version;
            //unsigned char *pblob;
            public byte[] pblob;
            //unsigned int size;
            public UInt16 size;
        };

        /* SPAT Structures */
        public struct spat_data
        {
            //unsigned long state;
            public uint state;
            //unsigned int  mintime;
            public UInt16 mintime;
            //unsigned int  maxtime;
            public UInt16 maxtime;
            //unsigned long yellowstate;
            public uint yellowstate;
            //unsigned int  yellowtime;
            public UInt16 yellowtime;
            //unsigned char pedestrian;
            public byte pedestrian;
            //unsigned char count;
            public byte count;
        };

        public struct spat_movement
        {
            //unsigned char type;
            public byte type;
            //unsigned char lane[spat_maxlanes];
            public byte[] lane;//= new byte[clsSPATGlobals.spat_maxlanes];
            public spat_data data;
        };

        public struct spat
        {
            //unsigned long intersectionid;
            public uint intersectionid;
            //unsigned char intersectionstatus;
            public byte intersectionstatus;
            //unsigned long timestampseconds;
            public uint timestampseconds;
            //unsigned char timestamptenths;
            public byte timestamptenths;

            public spat_movement[] movement;//= new spat_movement[clsSPATGlobals.spat_maxmovements];

            public blob payload;
        };


        public struct spat_manuver
        {
            //unsigned short manuver[spat_maxmovements];
            public ushort[] manuver;//= new ushort[clsSPATGlobals.spat_maxmovements];
            //spat_data* data;
            public spat_data data;//= new spat_data();
        };

        private spat m_message;
        public spat Message
        {
            get { return m_message; }
            set { m_message = Message; }
        }
        private byte[] m_pblob;
        public byte[] Pblob
        {
            get { return m_pblob; }
        }
        private ushort[] m_crc_table;
        //static int crc_table_initialized = 0;
        private bool m_crc_table_initialized = false;
        //public static unsigned short crc_table[256];
        //public static ushort[] crc_table = new ushort[256];
        //public static byte[] pblob = new byte[1024];

        private spat_manuver[] m_manuver;// = new spat_manuver[clsSPATGlobals.spat_maxmovements];
        public spat_manuver[] Manuver
        {
            get { return m_manuver; }
        }

        public clsSPAT(byte contentversion) 
        {
            m_pblob = new byte[1024];
            m_crc_table = new ushort[256];
            m_crc_table_initialized = false;
            m_message = new spat();
            m_message.movement = new spat_movement[GlobalVars.spat_maxmovements];
            for (int i = 0; i < GlobalVars.spat_maxmovements; i++)
            {
                m_message.movement[i].lane = new byte[GlobalVars.spat_maxlanes];
            }
            m_manuver = new spat_manuver[GlobalVars.spat_maxmovements];
            for (int j = 0; j < GlobalVars.spat_maxmovements; j++)
            {
                m_manuver[j].manuver = new ushort[GlobalVars.spat_maxmovements]; ;
            }
            for (int k = 0; k < GlobalVars.spat_maxmovements; k++)
            {
                m_manuver[k].data = new spat_data();
                for (int l = 0; l < GlobalVars.spat_maxmovements; l++)
                {
                    m_manuver[k].manuver[l] = 0;
                }
            }
        }

        ~clsSPAT()
        {
            m_pblob = null;
            m_crc_table = null;
            m_message.movement = null;
            m_manuver = null;
            Console.WriteLine("Disposing of clsspat class");
        }
        /* CRC Calcuation Procedures */

        /*************************************************************************************
        *  Name       : initialize_crc_table 
        *  Purpose    : Initialize the look-up table for the CRC calculation
        *  Parameters : none
        *************************************************************************************/
        public void initialize_crc_table() 
        {
            int i, j;
            //unsigned short crc, c;
            ushort crc;
            ushort c;

            for (i=0; i<256; i++) 
            {
                crc = 0;
                //c = ((unsigned short) i) << 8;
                c = (ushort)(((ushort) i) << 8);
                for (j=0; j<8; j++) 
                {
                    //if ((crc^c) & 0x8000 )
                    if (((crc ^ c) & 0x8000) != 0)
                    {
                        crc = (ushort)((crc << 1) ^ 0x1021);
                    }
                    else
                    {
                        crc = (ushort)(crc << 1);
                    }
                    c = (ushort)((c << 1));
                }
                m_crc_table[i] = crc;
            }
        
            m_crc_table_initialized = true;
        } 

        /*************************************************************************************
        *  Name       : crc_update
        *  Purpose    : Update the CRC calculation
        *  Parameters : crc  - Current CRC value
        *               c    - Next byte to be included in the CRC calculation
        *************************************************************************************/
        //unsigned short crc_update(unsigned short crc, char c)
        public ushort crc_update(ushort crc, byte c) 
        {
            //unsigned short tmp, short_c;
            ushort tmp;
            ushort short_c;

            //short_c  = 0x00ff & (unsigned short) c;
            short_c  = (ushort)(0x00ff & (ushort)c);

            //if (!crc_table_initialized) initialize_crc_table();
            if (!m_crc_table_initialized)
            {
                initialize_crc_table();
            }

            tmp = (ushort)((crc >> 8) ^ short_c);
            crc = (ushort)((crc << 8) ^ m_crc_table[tmp]);

            return crc;
        } 
        /*************************************************************************************
        *  Name       : crc_ccitt
        *  Purpose    : Calculate the CRC value
        *  Parameters : pblob    - Pointer to the blob binary byte array
        *               size     - Size of the array
        *************************************************************************************/
        //unsigned short crc_ccitt(unsigned char *pblob, int size)
        public ushort crc_ccitt(byte[] pblob, int size)
        {
            //unsigned short crc;
            ushort crc;
            int i = 0;

            crc=0;
            //while (size) { crc = crc_update(crc, (*pblob)); pblob++; size--; }
            while (size > 0)
            {
                crc = crc_update(crc, (pblob[i]));
                i++;
                //pblob++; 
                size--;
            }
            return crc;
        
}

        public void spat_load()
        {
            DateTime CurrDateTime = DateTime.Now;
            TimeSpan diffDate = CurrDateTime.Subtract(GlobalVars.ReferenceDate);
            double diffDateSecs = (uint)diffDate.TotalSeconds;
            //double maximumuintvalue = uint.MaxValue;
            double diffDateTenthSecs = ((diffDate.TotalMilliseconds - (diffDateSecs * (uint)1000)) / 10);

            m_message.timestampseconds = (uint)diffDateSecs;
            m_message.timestamptenths = (byte)diffDateTenthSecs;
            m_message.intersectionid = GlobalVars.IntersectionID;
            m_message.intersectionstatus = GlobalVars.IntersectionStatus;

            int i = 0;
            for (int m = 0; m < GlobalVars.PTLMRecords; m++)
            {
                m_message.movement[m].data.count = GlobalVars.PTLMTable[m].count;
                m_message.movement[m].data.pedestrian = GlobalVars.PTLMTable[m].pedestrian;
                m_message.movement[m].data.mintime = GlobalVars.PTLMTable[m].minTime;
                m_message.movement[m].data.maxtime = GlobalVars.PTLMTable[m].maxTime;
                m_message.movement[m].data.state = GlobalVars.PTLMTable[m].state;
                m_message.movement[m].data.yellowtime = GlobalVars.PTLMTable[m].yellowTime;
                m_message.movement[m].data.yellowstate = GlobalVars.PTLMTable[m].yellowState;
                m_message.movement[m].type = GlobalVars.PTLMTable[m].Movement;

                i = 0;
                string[] Lanes = GlobalVars.PTLMTable[m].Lanes.Split(',');
                foreach (string l in Lanes)
                {
                    m_message.movement[m].lane[i++] = Convert.ToByte(l);
                }
            }

            
            
            /*m_message.intersectionid = 100;
            m_message.intersectionstatus = 0x00;
            m_message.timestampseconds = 1320875701;
            m_message.timestamptenths = 2;
            for (int i = 0; i < GlobalVars.PTLMRecords; i++)
            {
                m_message.movement[0].type = (byte)GlobalVars.enum_map_movements.straight;
                m_message.movement[0].lane[0] = 1;
                m_message.movement[0].lane[1] = 2;
                m_message.movement[0].lane[2] = 7;
                m_message.movement[0].data.state = 0x01;
                m_message.movement[0].data.mintime = 30;
                m_message.movement[0].data.maxtime = 56;
                m_message.movement[0].data.yellowstate = 0x01;
                m_message.movement[0].data.yellowtime = 36;
            }

            m_message.intersectionid = 100;
            m_message.intersectionstatus = 0x00;
            m_message.timestampseconds = 1320875701;
            m_message.timestamptenths = 2;
            m_message.movement[0].type = (byte)GlobalVars.enum_map_movements.straight;
            m_message.movement[0].lane[0] = 1;
            m_message.movement[0].lane[1] = 2;
            m_message.movement[0].lane[2] = 7;
            m_message.movement[0].data.state = 0x01;
            m_message.movement[0].data.mintime = 30;
            m_message.movement[0].data.maxtime = 56;
            m_message.movement[0].data.yellowstate = 0x01;
            m_message.movement[0].data.yellowtime = 36;
            m_message.movement[1].type = (byte)GlobalVars.enum_map_movements.rightturn;
            m_message.movement[1].lane[0] = 1;
            m_message.movement[1].lane[1] = 7;
            m_message.movement[1].data.state = 0x100;
            m_message.movement[1].data.mintime = 20;
            m_message.movement[1].data.maxtime = 25;
            m_message.movement[1].data.yellowstate = 0x01;
            m_message.movement[1].data.yellowtime = 36;
            m_message.movement[2].type = (byte)GlobalVars.enum_map_movements.straight;
            m_message.movement[2].lane[0] = 3;
            m_message.movement[2].lane[1] = 4;
            m_message.movement[2].data.state = 0x100;
            m_message.movement[2].data.mintime = 20;
            m_message.movement[2].data.maxtime = 25;
            m_message.movement[2].data.yellowstate = 0x01;
            m_message.movement[2].data.yellowtime = 36;
            m_message.movement[3].type = (byte)GlobalVars.enum_map_movements.leftturn;
            m_message.movement[3].lane[0] = 1;
            m_message.movement[3].lane[1] = 7;
            m_message.movement[3].data.state = 0x100;
            m_message.movement[3].data.mintime = 20;
            m_message.movement[3].data.maxtime = 25;
            m_message.movement[3].data.yellowstate = 0x01;
            m_message.movement[3].data.yellowtime = 36;
            m_message.movement[4].type = (byte)GlobalVars.enum_map_movements.leftturn;
            m_message.movement[4].lane[0] = 2;
            m_message.movement[4].lane[1] = 7;
            m_message.movement[4].data.state = 0x01;
            m_message.movement[4].data.mintime = 30;
            m_message.movement[4].data.maxtime = 56;
            m_message.movement[4].data.yellowstate = 0x01;
            m_message.movement[4].data.yellowtime = 36;
             * */
        }


        /* Functions */

        /*************************************************************************************
        *  Name       : spat_clear 
        *  Purpose    : Clear the contents of the SPAT structure
        *  Parameters : message  - Pointer to the SPAT message structure
        *************************************************************************************/
        public void spat_clear()
        {
            int l, m;

            /*  Clear all Data from the SPAT Message Structure */
            m_message.intersectionid = 0;
            m_message.intersectionstatus = 0;
            m_message.timestampseconds = 0;
            m_message.timestamptenths = 0;

            for (m = 0; m < GlobalVars.spat_maxmovements; m++)
            {

                /*Clear all Data from the Movement Structure */
                for (l = 0; l < GlobalVars.spat_maxlanes; l++)
                {
                    m_message.movement[m].lane[l] = 0;
                }
                m_message.movement[m].type = 0;
                m_message.movement[m].data.state = 0;
                m_message.movement[m].data.mintime = 0;
                m_message.movement[m].data.maxtime = 0;
                m_message.movement[m].data.count = 0;
                m_message.movement[m].data.yellowstate = 0;
                m_message.movement[m].data.yellowtime = 0;
                m_message.movement[m].data.pedestrian = 0;
            }
        }

        /* SPAT Procedures */

        /*************************************************************************************
        *  Name       : spat_initialize 
        *  Purpose    : Initialize the SPAT structure
        *  Parameters : message  - Pointer to the SPAT message structure
        *************************************************************************************/
        public int spat_initialize()
        {
            spat_clear();
            m_message.payload.pblob = null;
            m_message.payload.size = 0;
            m_message.payload.messageid = 0;
            m_message.payload.version = 0;
            return 1;
        }
        
        
        /*************************************************************************************
        *  Name       : spat_equals 
        *  Purpose    : Determine the data elements between two SPAT movements are equal.
        *  Parameters : a  - Pointer to the first movment data structure
        *               b  - Pointer to the second movment data structure
        *************************************************************************************/
        public int spat_equals(spat_data a, spat_data b)
        {
            if ((a).state != (b).state) return 0;
            if ((a).mintime != (b).mintime) return 0;
            if ((a).maxtime != (b).maxtime) return 0;
            if ((a).yellowstate != (b).yellowstate) return 0;
            if ((a).yellowtime != (b).yellowtime) return 0;
            if ((a).pedestrian != (b).pedestrian) return 0;
            if ((a).count != (b).count) return 0;
            return 1;
        }

        /*************************************************************************************
        *  Name       : spat_compile
        *  Purpose    : Compile the SPAT message for encoding
        *  Parameters : message  - Pointer to the SPAT message structure
        *************************************************************************************/
        //int spat_compile(spat *message, spat_manuver *manuver)
        //public int spat_compile(spat_manuver[] manuver)
        public int spat_compile()
        {
            int i, j, l, m, n, count;
            //int used[spat_maxmovements];
            int[] used = new int[GlobalVars.spat_maxmovements];
            //int index[spat_maxmovements][spat_maxmovements];
            int[,] index = new int[GlobalVars.spat_maxmovements, GlobalVars.spat_maxmovements];
            //spat_movement *pm;
            spat_movement pm = new spat_movement();
    
            /*  Initialize Variables */
            for (i = 0; i < GlobalVars.spat_maxmovements; i++) 
            {
                used[i]= 0;
                for (j = 0; j < GlobalVars.spat_maxmovements; j++) 
                {
                    index[i,j] = -1; 
                    m_manuver[i].manuver[j] = 0; 
                }        
            }

        /*  Compile the Movement Matrix */
            i = 0;
            for (m = 0; m < GlobalVars.spat_maxmovements; m++) 
            {
                if ((m_message).movement[m].type == 0) 
                {
                    break;
                }
                //if (!used[m])
                if (used[m] == 0)
                {
                    j = 0;
                    for (n = m; n < GlobalVars.spat_maxmovements; n++) 
                    {
                        if ((m_message).movement[n].type == 0)
                        {
                            break;
                        }
                        //if (!used[n])
                        if (used[n] == 0)
                        {
                            //if (spat_equals(&(*message).movement[m].data, &(*message).movement[n].data))
                            //FIXIT
                            if (spat_equals(m_message.movement[m].data, m_message.movement[n].data) == 1)
                            {
                                index[i,j++] = n;
                                used[n] = 1;
                            }
                        }
                    }
                }   
                i++;    
            }
            count = (m - 1);
    
        /*  Compile the Movement Manuver List */
            for (i=0; i<=count; i++) 
            {
                //(m_manuver[i]).data = (m_message).movement[index[i, 0]].data;
                (m_manuver[i]).data = (m_message).movement[i].data;
                j = 0;
                while (index[i,j] != -1)
                {
                    l=0;
                    // pm = &(*message).movement[index[i][j]];
                    pm = m_message.movement[index[i, j]];
                    //while ((*pm).lane[l] != 0)
                    while ((pm).lane[l] != 0)
                    {
                        for (m = 0; m < GlobalVars.spat_maxmovements; m++)
                        {
                            //if ((*manuver).manuver[m] == 0) 
                            if (m_manuver[i].manuver[m] == 0)
                            {
                                //(*manuver).manuver[m] = ((*pm).type << 8) | (*pm).lane[l]
                                m_manuver[i].manuver[m] = (ushort)((pm.type << 8) | pm.lane[l]);
                                break;
                            }
                            else 
                            {
                                //(((*manuver).manuver[m] & 0xff) == (*pm).lane[l])
                                if ((m_manuver[i].manuver[m] & 0xff) == pm.lane[l]) 
                                {
                                    //(*manuver).manuver[m] |= ((*pm).type << 8)
                                    m_manuver[i].manuver[m] |= (ushort)(pm.type << 8);
                                    break;
                                }
                            }
                        }
                        l++;
                }  
                j++;         
            }
            //manuver++;
        }
        
        /*  Return the Size of the Manuvers List */
        return count;    
    }
        
        /*************************************************************************************
        *  Name       : spat_encode 
        *  Purpose    : Encode the SPAT message into the blob payload
        *  Parameters : message          - Pointer to the SPAT message structure
        *               content_version  - Version number to assign to the message content
        *************************************************************************************/
        //public static int spat_encode(spat *message, unsigned char content_version)
        public int spat_encode(byte content_version)
        {
            int i;
            int j, m, n, s, count;
            //unsigned char *pblob;
            //byte [] pblob;
            //unsigned short crc;
            ushort crc;
            //spat_manuver manuver[spat_maxmovements];
           //DoubleCheck the declaration
            
            
            
            
            //spat_manuver[] manuver = new spat_manuver[spat_maxmovements];

            
            
            
            /*  Free any Previously Allocated Memory */
            //blob_free(&(*message).payload);
    
            /*  Create the SPAT Blob */
            //pblob = (unsigned char*) malloc(1024);
            //pblob = new byte[1024];

            

            
            if (m_pblob == null) 
            { 
                return 0;
            }  

            for (i=0; i<1024; i++) 
            {
                m_pblob[i] = 0;
            }

            /*  Encode the Message Header */
            i = 0;
            m_pblob[i++] = 0x8d;
            m_pblob[i++] = content_version;
            s = i++;
            i++;
    
            /*  Encode the Intersection ID */
            m_pblob[i++] = 1;
            m_pblob[i++] = 4;    
            for (j=0; j<4; j++) 
            {
                //m_pblob[i++] = ((*message).intersectionid & (0xff000000 >> (8*j))) >> (8*(3-j));
                m_pblob[i++] = (byte)(((m_message).intersectionid & (0xff000000 >> (8*j))) >> (8*(3-j)));
            }
            /*  Encode the Intersection Status */
            m_pblob[i++] = 2;
            m_pblob[i++] = 1;
            //m_pblob[i++] = (*message).intersectionstatus;
            m_pblob[i++] = (m_message).intersectionstatus;

            /*  Encode the Timestamp */
            m_pblob[i++] = 3;
            m_pblob[i++] = 5;
            for (j=0; j<4; j++) 
            {
                //m_pblob[i++] = ((*message).timestampseconds & (0xff000000 >> (8*j))) >> (8*(3-j));
                m_pblob[i++] = (byte)(((m_message).timestampseconds & (0xff000000 >> (8*j))) >> (8*(3-j)));
            }
            //m_pblob[i++] = (*message).timestamptenths;
            m_pblob[i++] = (m_message).timestamptenths;

            //DoubleCheck
            /*  Compile the SPAT Message */
            //DoubleCheck Uncomment the next line.
            //count = spat_compile(manuver);
            count = spat_compile();
            
            /*  Encode Each Movement */
            for(m=0; m<count; m++)
            {
                m_pblob[i++] = 4;

                /*      Encode the Lane Set */
                m_pblob[i++] = 5;
                m_pblob[i++] = 0;
                n=0;
                //while (manuver[m].manuver[n] !=0)
                while (m_manuver[m].manuver[n] !=0)
                {
                    for (j=0; j<2; j++)
                    {
                        // m_pblob[i++] = (byte)((manuver[m].manuver[n] & (0xff00 >> (8*j))) >> (8*(1-j)));
                        m_pblob[i++] = (byte)((m_manuver[m].manuver[n] & (0xff00 >> (8*j))) >> (8*(1-j))); 
                        n++;
                    }
                }
                m_pblob[i-(n*2)-1] = (byte)(n*2);
            
                /*      Encode the Current State */
                m_pblob[i++] = 6;
                n = i;
                m_pblob[i++] = 0;
                for (j=0; j<4; j++) 
                {
//                  if ((((*manuver[m].data).state & (0xff000000 >> (8*j))) != 0) || (m_pblob[n] > 0)) 
                    //if (((manuver[m].data.state & (0xff000000 >> (8*j))) != 0) || (m_pblob[n] > 0)) 
                    if (((m_manuver[m].data.state & (0xff000000 >> (8*j))) != 0) || (m_pblob[n] > 0)) 
                    {
//                      m_pblob[i++] = ((*manuver[m].data).state & (0xff000000 >> (8*j))) >> (8*(3-j));
                        //m_pblob[i++] = (byte)((manuver[m].data.state & (0xff000000 >> (8*j))) >> (8*(3-j)));
                        m_pblob[i++] = (byte)((m_manuver[m].data.state & (0xff000000 >> (8 * j))) >> (8 * (3 - j)));
                        m_pblob[n] = (byte)(m_pblob[n] + 1);
                    }
                }            

                /*      Encode the Minimum Time Remaining */
                m_pblob[i++] = 7;
                m_pblob[i++] = 2;
                for (j=0; j<2; j++)
                {
                    //m_pblob[i++] = ((*manuver[m].data).mintime & (0xff00 >> (8*j))) >> (8*(1-j));
                    //m_pblob[i++] = (byte)((manuver[m].data.mintime & (0xff00 >> (8*j))) >> (8*(1-j)));
                    m_pblob[i++] = (byte)((m_manuver[m].data.mintime & (0xff00 >> (8 * j))) >> (8 * (1 - j)));
                }

                /*      Encode the Maximum Time Remaining */
                m_pblob[i++] = 8;
                m_pblob[i++] = 2;
                for (j=0; j<2; j++)
                {
                    //m_pblob[i++] = ((*manuver[m].data).maxtime & (0xff00 >> (8*j))) >> (8*(1-j));
                    //m_pblob[i++] = (byte)((manuver[m].data.maxtime & (0xff00 >> (8*j))) >> (8*(1-j)));
                    m_pblob[i++] = (byte)((m_manuver[m].data.maxtime & (0xff00 >> (8*j))) >> (8*(1-j)));
                }

                /*      Encode the Yellow State */
//              if ((*manuver[m].data).yellowstate != 0)
                //if (manuver[m].data.yellowstate != 0)
                if (m_manuver[m].data.yellowstate != 0)
                {
                    m_pblob[i++] = 9;
                    n = i;
                    m_pblob[i++] = 0;
                    for (j=0; j<4; j++) 
                    {
                        //if ((((*manuver[m].data).yellowstate & (0xff000000 >> (8*j))) != 0) || (m_pblob[n] > 0)) 
                        //if (((manuver[m].data.yellowstate & (0xff000000 >> (8*j))) != 0) || (m_pblob[n] > 0)) 
                        if (((m_manuver[m].data.yellowstate & (0xff000000 >> (8*j))) != 0) || (m_pblob[n] > 0)) 
                        {
                            //m_pblob[i++] = ((*manuver[m].data).yellowstate & (0xff000000 >> (8*j))) >> (8*(3-j));
                            //m_pblob[i++] = (byte)((manuver[m].data.yellowstate & (0xff000000 >> (8*j))) >> (8*(3-j)));
                            m_pblob[i++] = (byte)((m_manuver[m].data.yellowstate & (0xff000000 >> (8*j))) >> (8*(3-j)));
                            m_pblob[n] = (byte)(m_pblob[n] + 1);
                        }
                    }
                
        /*          Encode the Yellow Time */
                    m_pblob[i++] = 10;
                    m_pblob[i++] = 2;
                    for (j=0; j<2; j++)
                    {
                        //m_pblob[i++] = ((*manuver[m].data).yellowtime & (0xff00 >> (8*j))) >> (8*(1-j));
                        //m_pblob[i++] = (byte)((manuver[m].data.yellowtime & (0xff00 >> (8*j))) >> (8*(1-j)));
                        m_pblob[i++] = (byte)((m_manuver[m].data.yellowtime & (0xff00 >> (8*j))) >> (8*(1-j)));
                    }
                }

        /*      Encode the Pedestrian Detect */
//              if ((*manuver[m].data).pedestrian != unavailable)
                //if (manuver[m].data.pedestrian != (byte)(spat_pedestrian.unavailable))
                if (m_manuver[m].data.pedestrian != (byte)(GlobalVars.enum_spat_pedestrian.unavailable))
                {
                    m_pblob[i++] = 11;
                    m_pblob[i++] = 1;
                    //m_pblob[i++] = (*manuver[m].data).pedestrian;
                    //m_pblob[i++] = manuver[m].data.pedestrian;
                    m_pblob[i++] = m_manuver[m].data.pedestrian;
                }
            
        /*      Encode the Count */
                //if ((*manuver[m].data).count != 0)
                // if (manuver[m].data.count != 0)
                if (m_manuver[m].data.count != 0)
                {
                    m_pblob[i++] = 12;
                    m_pblob[i++] = 1;
                    //m_pblob[i++] = (*manuver[m].data).count;
                    //m_pblob[i++] = (byte)(manuver[m].data.count);
                    m_pblob[i++] = (byte)(m_manuver[m].data.count);
                }
            }

        /*  End of Blob */
            m_pblob[i++] = 255;

        /*  Record the Message Size */
            for (j=0; j<2; j++)
            {
                m_pblob[s++] = (byte)(((i-4) & (0xff00 >> (8*j))) >> (8*(1-j)));
            }

        /*  Calculate the CRC Value */
            crc = crc_ccitt(m_pblob, i);    
            for (j=0; j<2; j++)
            {
                m_pblob[i++] = (byte)((crc & (0xff00 >> (8*j))) >> (8*(1-j)));
            }

        /*  Resize the SPAT Blob  */
            //DoubleCheck
            //m_pblob = (unsigned char*) realloc(m_pblob, i);
            m_message.payload.pblob = new byte[i];

            ASCIIEncoding ascii = new ASCIIEncoding();

        /*  Return the Blob and Size */        
            System.Array.Copy(m_pblob, m_message.payload.pblob, System.Math.Min(m_pblob.Length, i));
            //(m_message).payload.pblob = m_pblob;
            (m_message).payload.size = (UInt16)i;
    
        /*  Return TRUE */
            return 1;
        }   
    }        /* SPAT Enumerations */
}
