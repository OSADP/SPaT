﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace SPaTDemo
{
    class clsPRG
    {
        public enum SRStatus { inQueue = 0, processed = 1, expired = 2, cancelled = 4, cleared = 8};
        public struct ServiceRequest
        {
            string msgID;
            string intersectionID;
            int msgCnt;
            DateTime timeOfService;
            DateTime endOfService;
            string transitStatus;
            string vehicleVIN;
            string vehicleDat;
            string status;
            bool isCancel;
            int inLane;
            int outLane;
            int vehicleClassType;
            bool serviced;
            bool newRequest;
            int priorityStrategyNo;
        }

        public List<ServiceRequest> SRList = new List<ServiceRequest>();
        public List<ServiceRequest> ExpiredSRList = new List<ServiceRequest>();

        string ReadAvailableServiceRequests()
        {
            string retValue = string.Empty;

            return retValue;
        }
        bool SRExists()
        {
            bool newSR = false;
            return newSR;
        }
        string UpdateSR()
        {
            string retValue = string.Empty;
            return retValue;
        }
        string CheckForExpiredSRs()
        {
            string retValue = string.Empty;
            return retValue;
        }
        string ProcessNewSRs()
        {
            string retValue = string.Empty;
            return retValue;
        }
        string GenerateSSMs()
        {
            string retValue = string.Empty;
            return retValue;
        }
    }
}
